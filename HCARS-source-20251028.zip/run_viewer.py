# run_viewer.py  — Launcher to run Streamlit app inside a frozen bundle
import os, sys
from pathlib import Path

def resource_path(rel: str) -> str:
    base = getattr(sys, "_MEIPASS", None)
    if base:
        return str(Path(base, rel))
    return str(Path(__file__).resolve().parent / rel)

def main():
    # اجعل العمل من جذر الحزمة كي تُحلّ المسارات النسبية (config.yaml, outputs, assets, ...)
    os.chdir(Path(resource_path(".")).resolve())

    # شغّل Streamlit عبر واجهة CLI الرسمية
    from streamlit.web import cli as stcli
    target = resource_path("main.py")
    # عدّل المنفذ أو الإعدادات كما تريد
    sys.argv = ["streamlit", "run", target, "--server.headless=true", "--server.port=8501"]
    sys.exit(stcli.main())

if __name__ == "__main__":
    main()