"""
imputation.py
===============
This module defines robust imputation strategies for clinical datasets used in:
"Hybrid Context-Aware Recommendation System for Hypertension Problem" (HCARS thesis).

It includes:
- Median, mode, and iterative model-based imputation
- Outlier clipping and probabilistic handling using IterativeImputer
- Integration with RobustScaler for normalization
- Medical bounds-based handling of implausible values

These imputation methods support post-train/test split processing and protect against data leakage,
ensuring clinical validity and statistical soundness.
"""

import pandas as pd
import numpy as np
from utils.logging_utils import get_logger
from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.impute import IterativeImputer, SimpleImputer, KNNImputer
from sklearn.preprocessing import RobustScaler
from xgboost import XGBRegressor
from utils import load_config
from utils.validation import ClinicalValidator
from utils.risk_score_transformer import RiskScoreTransformer
from utils.safe_copy import safe_copy_for_imputation
from utils.column_audit import audit_columns
import logging
import uuid

# Ensure logs directory exists
import os
os.makedirs("logs", exist_ok=True)
log_id = uuid.uuid4().hex[:8]

pipeline_logger = logging.getLogger(__name__)
config = load_config()

imputation_logger = get_logger("imputation")

# Helper function for structured column presence logging
def log_column_presence(columns, df, stage):
    for col in columns:
        if col in df.columns:
            imputation_logger.info(f"[{log_id}] [{stage}] Column '{col}' preserved.")
        else:
            imputation_logger.warning(f"[{log_id}] [{stage}] Column '{col}' missing.")

# Utility function for selecting numeric columns for imputation
def select_numeric_imputation_columns(df: pd.DataFrame) -> list:
    """
    Select numeric columns suitable for imputation, excluding columns with 'target' in the name or ending with '_copy'.
    """
    return [col for col in df.select_dtypes(include=[np.number]).columns if 'target' not in col.lower() and not col.endswith("_copy")]

# Utility function for selecting categorical columns for imputation, with special handling for 'sex'
def select_categorical_imputation_columns(df: pd.DataFrame) -> list:
    """
    Select categorical columns suitable for imputation, including special handling for 'sex'.
    """
    categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    if 'sex' in df.columns and df['sex'].dtype in ['float64', 'int64'] and df['sex'].nunique() <= 3:
        if 'sex' not in categorical_cols:
            categorical_cols.append('sex')
    return categorical_cols

def build_imputer(
    strategy: str = 'median',
    use_knn: bool = False,
    use_iterative: bool = False
) -> SimpleImputer | KNNImputer | IterativeImputer:
    """
    Create and return an appropriate imputer based on specified strategy.

    Parameters
    ----------
    strategy : str, default='median'
        Imputation strategy ('mean', 'median', etc.)
    use_knn : bool, default=False
        Whether to use KNNImputer
    use_iterative : bool, default=False
        Whether to use IterativeImputer

    Returns
    -------
    imputer : Union[SimpleImputer, KNNImputer, IterativeImputer]
        Configured imputer instance.
    """
    if use_iterative:
        return IterativeImputer(
            estimator=XGBRegressor(n_estimators=100, random_state=0, tree_method='hist'),
            max_iter=20,
            random_state=0,
            verbose=2
        )
    if use_knn:
        return KNNImputer(n_neighbors=5)
    return SimpleImputer(strategy=strategy)


def get_iterative_imputer(disease: str):
    """
    Setup IterativeImputer and RobustScaler for columns based on disease type.

    Parameters
    ----------
    disease : str
        Name of the disease (currently only 'hypertension' supported)

    Returns
    -------
    imputer : IterativeImputer
        Iterative imputer instance
    scaler : RobustScaler
        Robust scaler instance
    columns_to_impute : list str
        list of columns to impute
    """
    disease_columns_bounds = {
        'hypertension': {
            'age': (0, 120),
            'trestbps': (80, 200),
            'thalach': (60, 220),
        },
    }

    if disease not in disease_columns_bounds:
        raise ValueError(f"Disease '{disease}' not supported. Only 'hypertension' is currently enabled.")

    columns_bounds = disease_columns_bounds[disease]
    columns_to_impute = list(columns_bounds.keys())

    try:
        imputation_logger.info(f"[{log_id}] 🧩 [get_iterative_imputer] Disease: '{disease}' selected.")
        imputation_logger.info(f"[{log_id}] 🧩 [get_iterative_imputer] Columns to impute: {columns_to_impute}")
    except (AttributeError, ValueError, TypeError):
        pass

    # ⚖️ إعداد RobustScaler
    scaler = RobustScaler()

    # 🔁 إعداد IterativeImputer
    imputer = IterativeImputer(
        estimator=XGBRegressor(n_estimators=100, random_state=0, tree_method='hist'),
        max_iter=20,
        random_state=0,
        verbose=2
    )

    return imputer, scaler, columns_to_impute




class MedicalImputer:
    """
    MedicalImputer provides robust imputation for clinical datasets.

    Parameters
    ----------
    strategy : str, default='median'
        Imputation strategy for numeric columns ('mean', 'median', etc.).
    use_iterative : bool, default=False
        Whether to use IterativeImputer for numeric columns.
    use_knn : bool, default=False
        Whether to use KNNImputer for numeric columns.
    """
    def __init__(self, strategy='median', use_iterative=False, use_knn=False):
        self.strategy = strategy
        self.use_iterative = use_iterative
        self.use_knn = use_knn
        self.numeric_imputer = None
        self.cat_imputer = None

    def fit(self, df: pd.DataFrame):
        """
        Fit the imputer(s) on the provided DataFrame.

        Parameters
        ----------
        df : pd.DataFrame
            Input DataFrame to fit imputers on.
        """
        # Exclude 'target' and any target-related columns to prevent imputation issues
        numeric_cols = select_numeric_imputation_columns(df)
        categorical_cols = select_categorical_imputation_columns(df)
        imputation_logger.debug(f"[{log_id}] [Trace] Numeric columns selected for imputation: {numeric_cols}")
        imputation_logger.debug(f"[{log_id}] [Trace] Categorical columns selected for imputation: {list(categorical_cols)}")

        if self.use_iterative:
            self.numeric_imputer = IterativeImputer(
                estimator=XGBRegressor(n_estimators=100, random_state=0, tree_method='hist'),
                max_iter=20,
                random_state=0,
                verbose=0
            )
            try:
                imputation_logger.info(f"[{log_id}] 🧩 [MedicalImputer.fit] Using IterativeImputer for numeric columns.")
            except (AttributeError, ValueError, TypeError):
                pass
        elif self.use_knn:
            self.numeric_imputer = KNNImputer(n_neighbors=5)
            try:
                imputation_logger.info(f"[{log_id}] 🧩 [MedicalImputer.fit] Using KNNImputer for numeric columns.")
            except (AttributeError, ValueError, TypeError):
                pass
        else:
            self.numeric_imputer = SimpleImputer(strategy=self.strategy)
            try:
                imputation_logger.info(f"[{log_id}] 🧩 [MedicalImputer.fit] Using SimpleImputer with strategy '{self.strategy}' for numeric columns.")
            except (AttributeError, ValueError, TypeError):
                pass

        if len(numeric_cols) > 0:
            self.numeric_imputer.fit(df[numeric_cols])
            try:
                imputation_logger.info(f"[{log_id}] 🧩 [MedicalImputer.fit] Numeric imputer fitted on columns: {numeric_cols}")
            except (AttributeError, ValueError, TypeError):
                pass

        if len(categorical_cols) > 0:
            self.cat_imputer = SimpleImputer(strategy='most_frequent')
            self.cat_imputer.fit(df[categorical_cols])
            try:
                imputation_logger.info(f"[{log_id}] 🧩 [MedicalImputer.fit] Categorical imputer fitted on columns: {list(categorical_cols)}")
            except (AttributeError, ValueError, TypeError):
                pass

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Transform the provided DataFrame by imputing missing values.

        Parameters
        ----------
        df : pd.DataFrame
            Input DataFrame to impute.

        Returns
        -------
        pd.DataFrame
            DataFrame with imputed values.
        """
        df = safe_copy_for_imputation(df)
        # Protect 'target_copy' if it exists in original df
        if "target_copy" in df.columns:
            target_copy_values = df["target_copy"].copy()
        else:
            target_copy_values = None
        # Exclude 'target' and any target-related columns to prevent imputation issues
        numeric_cols = select_numeric_imputation_columns(df)
        categorical_cols = select_categorical_imputation_columns(df)
        imputation_logger.debug(f"[{log_id}] [Trace] Numeric columns for transformation: {numeric_cols}")
        imputation_logger.debug(f"[{log_id}] [Trace] Categorical columns for transformation: {list(categorical_cols)}")
        imputation_logger.debug(f"[{log_id}] [Trace] Columns before transformation: {df.columns.tolist()}")

        if self.numeric_imputer and len(numeric_cols) > 0:
            transformed_numeric = pd.DataFrame(
                self.numeric_imputer.transform(df[numeric_cols]),
                columns=numeric_cols,
                index=df.index
            ).infer_objects()
            try:
                imputation_logger.info(f"[{log_id}] 🧩 [MedicalImputer.transform] Numeric data transformed shape: {transformed_numeric.shape}")
            except (AttributeError, ValueError, TypeError):
                pass
            if transformed_numeric.shape[1] != len(numeric_cols):
                raise ValueError(
                    f"❌ [Numeric Imputer] Columns mismatch during transform: "
                    f"{transformed_numeric.shape[1]} ≠ {len(numeric_cols)}. "
                    f"Check excluded columns like 'target_copy', 'risk_age_score', or derived features."
                )
            df.loc[:, numeric_cols] = transformed_numeric
            imputation_logger.debug(f"[{log_id}] [Trace] Columns after numeric imputation: {df.columns.tolist()}")

        if self.cat_imputer and len(categorical_cols) > 0:
            transformed_cat = self.cat_imputer.transform(df[categorical_cols])
            try:
                imputation_logger.info(f"[{log_id}] 🧩 [MedicalImputer.transform] Categorical data transformed shape: {transformed_cat.shape}")
            except (AttributeError, ValueError, TypeError):
                pass
            if transformed_cat.shape[1] != len(categorical_cols):
                raise ValueError(
                    f"❌ [Categorical Imputer] Columns mismatch during transform: "
                    f"{transformed_cat.shape[1]} ≠ {len(categorical_cols)}."
                )
            df.loc[:, categorical_cols] = transformed_cat
            imputation_logger.debug(f"[{log_id}] [Trace] Columns after categorical imputation: {df.columns.tolist()}")
            # --- Logging which value was used to fill missing categorical values ---
            for col in categorical_cols:
                if df[col].isnull().sum() > 0:
                    filled_value = pd.Series(self.cat_imputer.statistics_, index=categorical_cols)[col]
                    pipeline_logger.info(f"[{log_id}] 🧩 [Imputation] Filled missing values in categorical column '{col}' with '{filled_value}' (most frequent).")
            # --- Explicitly log filling of missing values in 'sex' column ---
            if 'sex' in categorical_cols:
                filled_count = df['sex'].isnull().sum()
                if filled_count == 0:
                    print(f"🟢 Column 'sex': Filled all missing values successfully. Remaining: 0")
                    imputation_logger.info(f"[{log_id}] 🟢 Column 'sex': Filled all missing values successfully. Remaining: 0")
                else:
                    print(f"⚠️ Column 'sex': Still has {filled_count} missing value(s) after imputation.")
                    imputation_logger.warning(f"[{log_id}] ⚠️ Column 'sex': Still has {filled_count} missing value(s) after imputation.")

        # Restore 'target_copy' if it was temporarily dropped
        if target_copy_values is not None and "target_copy" not in df.columns:
            df["target_copy"] = target_copy_values
            try:
                imputation_logger.info(f"[{log_id}] [Leakage Protection] Restored 'target_copy' after transformation.")
            except (AttributeError, ValueError, TypeError):
                pass


        # Restore 'target' from target_copy if missing
        if target_copy_values is not None and "target" not in df.columns:
            df["target"] = target_copy_values
            try:
                imputation_logger.info(f"[{log_id}] [Leakage Protection] Restored 'target' column from 'target_copy' after transformation.")
            except (AttributeError, ValueError, TypeError):
                pass

        # Structured logging for target and risk columns
        log_column_presence(['target', 'age', 'risk_score'], df, stage="Transform")

        return df


def backup_target_column(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create a backup copy of the 'target' column named 'target_copy' if it doesn't exist.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame

    Returns
    -------
    pd.DataFrame
        DataFrame with 'target_copy' column added if it was missing
    """
    df = safe_copy_for_imputation(df)
    if "target" in df.columns and "target_copy" not in df.columns:
        df["target_copy"] = df["target"]
        try:
            imputation_logger.info(f"[{log_id}] [Leakage Protection] Backup 'target_copy' created from 'target' for protection before imputation.")
        except (AttributeError, ValueError, TypeError):
            pass
    return df


def prepare_numeric_columns(df: pd.DataFrame) -> list:
    """
    Prepare a list of numeric columns for imputation by excluding derived or irrelevant columns.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame

    Returns
    -------
    list str
        List of numeric column names suitable for imputation
    """
    excluded_cols = ['target', 'risk_age_score', 'chol_flag']
    numeric_cols = [col for col in df.select_dtypes(include=[np.number]).columns if col not in excluded_cols and df[col].notna().any()]
    return numeric_cols


def setup_imputer(strategy: str, use_iterative: bool, use_knn: bool) -> MedicalImputer:
    """
    Setup and return a MedicalImputer instance based on the specified strategy and flags.

    Parameters
    ----------
    strategy : str
        Imputation strategy ('mean', 'median', etc.)
    use_iterative : bool
        Whether to use IterativeImputer
    use_knn : bool
        Whether to use KNNImputer

    Returns
    -------
    MedicalImputer
        Configured MedicalImputer instance
    """
    imputer = MedicalImputer(strategy=strategy, use_iterative=use_iterative, use_knn=use_knn)
    return imputer


def cleanup_after_imputation(df: pd.DataFrame, df_before: pd.DataFrame) -> pd.DataFrame:
    """
    Restore the 'target' column if lost during imputation and clean up temporary columns.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame after imputation
    df_before : pd.DataFrame
        DataFrame before imputation

    Returns
    -------
    pd.DataFrame
        Cleaned DataFrame with necessary columns restored
    """
    df = safe_copy_for_imputation(df)
    # Restore 'target' if it was removed
    if "target" in df_before.columns and "target" not in df.columns:
        df["target"] = df_before["target"]
        try:
            imputation_logger.info(f"[{log_id}] [Leakage Protection] 'target' column was restored after imputation.")
        except (AttributeError, ValueError, TypeError):
            pass

    # Remove orphaned derived target_copy columns if target exists
    derived_target_cols = [col for col in df.columns if col.endswith("__target_copy") and col != "target_copy"]
    if "target" in df.columns:
        df.drop(columns=derived_target_cols, inplace=True, errors="ignore")
        try:
            if derived_target_cols:
                imputation_logger.info(f"[{log_id}] [Leakage Protection] Dropped orphaned derived columns: {derived_target_cols}")
        except (AttributeError, ValueError, TypeError):
            pass

    # Ensure 'target_copy' exists if 'target' exists
    if "target_copy" not in df.columns and "target" in df.columns:
        df["target_copy"] = df["target"]
        try:
            imputation_logger.info(f"[{log_id}] [Leakage Protection] 'target_copy' column created from 'target' after cleanup.")
        except (AttributeError, ValueError, TypeError):
            pass

    return df


def impute_missing_values(
    df: pd.DataFrame,
    strategy: str = 'median',
    dataset_name: str = None,
    is_training: bool = True,
    use_knn: bool = False,
    use_iterative: bool = False
) -> pd.DataFrame:
    """
    Impute missing values in a DataFrame with robust strategies.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame
    strategy : str, default='median'
        Imputation strategy for numeric columns
    dataset_name : str, optional
        Name of the dataset for logging (optional)
    is_training : bool, default=True
        Whether this is a training set (fit imputer if True)
    use_knn : bool, default=False
        Whether to use KNNImputer for numeric columns
    use_iterative : bool, default=False
        Whether to use IterativeImputer for numeric columns

    Returns
    -------
    pd.DataFrame
        DataFrame with imputed values and protected clinical columns.
    """
    try:
        imputation_logger.info(f"[{log_id}] 🛡️ Starting imputation process...")
    except (AttributeError, ValueError, TypeError):
        pass
    df = safe_copy_for_imputation(df)
    df = backup_target_column(df)
    df_before_imputation = df.copy()

    # Ensure all numeric columns are converted to float for consistent imputation
    for col in df.columns:
        if df[col].dtype == 'int64' or df[col].dtype == 'int32':
            df[col] = df[col].astype(float)

    if dataset_name:
        try:
            imputation_logger.info(f"[{log_id}] 🧩 📋 Preparing numeric columns for dataset: {dataset_name}")
        except (AttributeError, ValueError, TypeError):
            pass
    numeric_cols = prepare_numeric_columns(df)

    if 'age' in df.columns and df['age'].dtype == 'object':
        df['age'] = pd.to_numeric(df['age'], errors='coerce')
        try:
            imputation_logger.warning(f"[{log_id}] [Clinical Warning] Converted 'age' column to numeric type for imputation.")
        except (AttributeError, ValueError, TypeError):
            pass

    if 'age' not in numeric_cols:
        if 'age' in df.columns:
            try:
                imputation_logger.warning(f"[{log_id}] [Clinical Warning] Column 'age' is in DataFrame but excluded from numeric imputation candidates. Check for incorrect dtype or placeholder NaN injection.")
            except (AttributeError, ValueError, TypeError):
                pass
        else:
            try:
                imputation_logger.error(f"[{log_id}] [Clinical Warning] Column 'age' is completely missing from DataFrame before imputation.")
            except (AttributeError, ValueError, TypeError):
                pass
    elif not np.issubdtype(df['age'].dtype, np.number):
        try:
            imputation_logger.error(f"[{log_id}] [Clinical Warning] Column 'age' is not numeric. Please ensure proper loading and type enforcement.")
        except (AttributeError, ValueError, TypeError):
            pass

    for col in ['target', 'risk_score']:
        if col in df.columns:
            try:
                imputation_logger.info(f"[{log_id}] [Leakage Protection] '{col}' column present before imputation.")
            except (AttributeError, ValueError, TypeError):
                pass
        else:
            try:
                imputation_logger.warning(f"[{log_id}] [Leakage Protection] '{col}' column missing before imputation.")
            except (AttributeError, ValueError, TypeError):
                pass

    if 'age' in df.columns:
        try:
            imputation_logger.info(f"[{log_id}] 🧩 🧪 'age' dtype: {df['age'].dtype}, NaNs: {df['age'].isna().sum()} / {len(df)}")
        except (AttributeError, ValueError, TypeError):
            pass

    imputer = setup_imputer(strategy, use_iterative, use_knn)

    try:
        imputation_logger.info(f"[{log_id}] 🕒 Start fitting imputer using {'iterative' if use_iterative else 'knn' if use_knn else strategy} strategy.")
        if is_training:
            imputer.fit(df)
        imputation_logger.info(f"[{log_id}] 🕒 Finished fitting imputer.")
    except (ValueError, RuntimeError, TypeError) as fit_error:
        imputation_logger.error(f"[{log_id}] ❌ Imputation fit failed: {fit_error}")

    try:
        imputation_logger.info(f"[{log_id}] 🕒 Start transforming data using imputer.")
        df_imputed = imputer.transform(df)
        imputation_logger.info(f"[{log_id}] 🕒 Finished transforming data.")
        try:
            imputation_logger.info(f"[{log_id}] ✅ Imputation completed using {'iterative' if use_iterative else 'knn' if use_knn else strategy} strategy.")
        except (AttributeError, ValueError, TypeError):
            pass
        # --- Imputation Effect Logging ---
        for col in df.columns:
            if col in df_imputed.columns:
                nulls_before = df[col].isnull().sum()
                nulls_after = df_imputed[col].isnull().sum()
                if nulls_before > 0:
                    filled_ratio = ((nulls_before - nulls_after) / nulls_before) * 100
                    imputation_logger.info(f"[{log_id}] [Imputation Effect] Column '{col}': filled {nulls_before - nulls_after} of {nulls_before} missing values ({filled_ratio:.2f}%).")
                elif nulls_after > 0:
                    imputation_logger.warning(f"[{log_id}] [Imputation Effect] Column '{col}' had no NaNs before but now has {nulls_after} missing values — check transformation logic.")
    except (ValueError, RuntimeError, TypeError) as transform_error:
        imputation_logger.warning(f"[{log_id}] [Fallback] Imputation transform failed: {transform_error}")
        df_imputed = safe_copy_for_imputation(df)

    # 🔍 Post-imputation validation for critical clinical columns
    critical_columns = ['age', 'trestbps', 'thalach', 'chol', 'risk_score', 'target']
    for col in critical_columns:
        if col in df_imputed.columns:
            null_count = df_imputed[col].isnull().sum()
            if null_count > 0:
                imputation_logger.warning(f"[{log_id}] [Post-Imputation Check] Column '{col}' has {null_count} missing values after imputation.")
            else:
                imputation_logger.info(f"[{log_id}] [Post-Imputation Check] Column '{col}' is complete (no NaNs).")
        else:
            imputation_logger.warning(f"[{log_id}] [Post-Imputation Check] Critical column '{col}' is missing from DataFrame after imputation.")

    missing_summary = df_imputed.isnull().sum()
    missing_remaining = missing_summary[missing_summary > 0]
    try:
        if not missing_remaining.empty:
            imputation_logger.info(f"[{log_id}] 🔍 Remaining missing values after imputation:")
            imputation_logger.info(f"[{log_id}] {missing_remaining}")
        else:
            imputation_logger.info(f"[{log_id}] ✅ No missing values remaining.")
    except (AttributeError, ValueError, TypeError):
        pass

    try:
        imputation_logger.info(f"[{log_id}] 🎯 Imputation process completed.\n" + "-"*50)
    except (AttributeError, ValueError, TypeError):
        pass
    # Call check_column_consistency according to latest validation logic
    try:
        ClinicalValidator.check_column_consistency(df, df_imputed, stage="Imputation")
    except TypeError:
        # fallback to old signature if needed
        ClinicalValidator.check_column_consistency(df, df_imputed, stage="Imputation")

    df_final = cleanup_after_imputation(df_imputed, df)

    # After imputation, check for clinical columns
    log_column_presence(['target', 'age', 'risk_score'], df_final, stage="Final Output")

    try:
        if "age" in df_final.columns:
            df_final = RiskScoreTransformer().transform(df_final)
            try:
                imputation_logger.info(f"[{log_id}] [Clinical Warning] Risk scoring applied successfully during imputation process.")
            except (AttributeError, ValueError, TypeError):
                pass
        else:
            try:
                imputation_logger.warning(f"[{log_id}] [Clinical Warning] Skipped risk scoring during imputation: 'age' column not found.")
            except (AttributeError, ValueError, TypeError):
                pass
    except (AttributeError, ValueError, TypeError):
        try:
            imputation_logger.warning(f"[{log_id}] [Clinical Warning] Risk scoring skipped during imputation due to an error.")
        except (AttributeError, ValueError, TypeError):
            pass


    # Additional noncontextual schema validation after post-imputation
    try:
        from utils.validation import validate_noncontextual_schema
        validate_noncontextual_schema(
            df_final,
            schema_path_or_dict="schemas/post-imputation.yaml",
            dataset_name=dataset_name,
        )
    except (ImportError, ValueError, TypeError) as validation_error:
        imputation_logger.warning(f"[{log_id}] [Noncontextual Schema Check] Validation failed: {validation_error}")

    try:
        imputation_logger.info(f"[{log_id}] 🏁 Imputation process finished successfully.")
    except (AttributeError, ValueError, TypeError):
        pass
    ClinicalValidator.check_column_consistency(df_before_imputation, df_final, stage="Fallback Imputation")


    audit_columns(df_final, stage="Imputation", log_id=log_id)
    return df_final


def self_test_imputation():
    try:
        imputation_logger.info(f"[{log_id}] 🧩 Starting self-test of imputation module...")
    except (AttributeError, ValueError, TypeError):
        pass
    data = {
        'age': [25, np.nan, 35, 40, np.nan],
        'trestbps': [120, 130, np.nan, 110, 115],
        'thalach': [150, 160, 170, np.nan, 165],
        'chol': [200, 210, 190, 180, np.nan],
        'target': [1, 0, 1, 0, 1]
    }
    df_test = pd.DataFrame(data)
    try:
        missing_before = df_test.isnull().sum().sum()
        imputation_logger.info(f"[{log_id}] 🧩 Self-test: Before imputation - shape: {df_test.shape}, missing values: {missing_before}")
    except (AttributeError, ValueError, TypeError):
        pass

    df_imputed = impute_missing_values(df_test, strategy='median', is_training=True)

    try:
        missing_after = df_imputed.isnull().sum().sum()
        imputation_logger.info(f"[{log_id}] 🧩 Self-test: After imputation - shape: {df_imputed.shape}, missing values: {missing_after}")
        imputation_logger.info(f"[{log_id}] 🧩 Self-test of imputation module completed successfully.")
    except (AttributeError, ValueError, TypeError):
        pass


__all__ = [
    'select_numeric_imputation_columns',
    'select_categorical_imputation_columns',
    'build_imputer',
    'get_iterative_imputer',
    'MedicalImputer',
    'backup_target_column',
    'prepare_numeric_columns',
    'setup_imputer',
    'cleanup_after_imputation',
    'impute_missing_values',
    'self_test_imputation'
]
