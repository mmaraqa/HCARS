import pandas as pd
import logging
from pathlib import Path
from utils.risk_score_transformer import apply_risk_score_as_dict

# Import real preprocessing modules
from .data_cleaning import clean_data as clean_hypertension_data
#from .integration import integrate_data_sources
from utils.validation import validate_noncontextual_schema
from .imputation import impute_missing_values
from .encoding import encode_hypertension_data

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def print_stage_summary(stage_name, df: pd.DataFrame):
    print(f"\n✅ [{stage_name}] Completed")
    print(f"📊 Shape: {df.shape}")
    print(f"🔍 Columns: {list(df.columns)}")
    print("🧾 Head:\n", df.head())

def main():
    data_path = Path("data/hypertension_data.csv")
    if not data_path.exists():
        raise FileNotFoundError(f"❌ File not found: {data_path}")

    df = pd.read_csv(data_path)
    # Validate schema after loading raw dataset
    df = validate_noncontextual_schema(
        df,
        schema_path_or_dict="schemas/raw_input.yaml",
        dataset_name="debug_preprocessing_raw"
    )
    # Enhanced schema verification logic
    if df is None or not isinstance(df, pd.DataFrame):
        raise ValueError("❌ [Schema Validation] Returned object is not a valid DataFrame.")
    required_cols = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg", "thalach", "exang", "oldpeak", "slope", "ca", "thal", "target"]
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f"❌ [Schema Validation] Missing columns after schema check: {missing_cols}")
    print(f"✅ Schema validation passed. Columns present: {list(df.columns)}")
    print("📥 Loaded dataset")
    print_stage_summary("Raw Input", df)
    print(f"[Raw Input] Total rows: {df.shape[0]}, Total columns: {df.shape[1]}")
    print(f"[Raw Input] Null values per column:\n{df.isnull().sum()}")

    # Step 1: Data Cleaning
    df_cleaned = clean_hypertension_data(df.copy())
    # Validate schema after data cleaning
    df_cleaned = validate_noncontextual_schema(
        df_cleaned,
        schema_path_or_dict="schemas/cleaned_data.yaml",
        dataset_name="debug_preprocessing_cleaned"
    )
    # Ensure only columns specified in schemas/cleaned_data.yaml are kept before saving
    ALLOWED_COLUMNS = [
        "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg", "thalach", "exang", "oldpeak",
        "slope", "ca", "thal", "target", "age_group", "risk_score", "risk_level",
        "multi__risk_level_high", "multi__risk_level_medium", "multi__risk_level_low"
    ]
    df_cleaned = df_cleaned[[col for col in ALLOWED_COLUMNS if col in df_cleaned.columns]]
    df_cleaned.to_csv("outputs/tmp/df_cleaned.csv", index=False)
    logger.info("✅ df_cleaned saved to outputs/tmp/df_cleaned.csv")
    print(f"[Data Cleaning] Rows before: {df.shape[0]}, after: {df_cleaned.shape[0]}")
    print(f"[Data Cleaning] Null values per column after cleaning:\n{df_cleaned.isnull().sum()}")
    print(f"[Data Cleaning] Rows removed or affected: {df.shape[0] - df_cleaned.shape[0]}")
    print(f"[Data Cleaning] Completed cleaning operations. Shape after cleaning: {df_cleaned.shape}")
    print_stage_summary("Data Cleaning", df_cleaned)

    # Step 2: Integration
    df_integrated_dict = apply_risk_score_as_dict(df_cleaned.copy())
    if not df_integrated_dict or "hypertension_df" not in df_integrated_dict:
        raise KeyError("❌ [Error] 'hypertension_df' not found in returned dict from apply_risk_score. Please ensure it returns a dictionary with the correct key.")
    df_integrated = df_integrated_dict["hypertension_df"]
    # Validate schema after integration
    df_integrated = validate_noncontextual_schema(
        df_integrated,
        schema_path_or_dict="schemas/cleaned_data.yaml",
        dataset_name="debug_preprocessing_integrated"
    )
    print(f"[Integration] Merged or aligned contextual information with context checks skipped. Shape after integration: {df_integrated.shape}")
    print(f"[Integration] Null values per column:\n{df_integrated.isnull().sum()}")
    print_stage_summary("Integration", df_integrated)

    # Step 3: Imputation
    df_pre_impute = df_integrated.copy()
    for col in ["bp_category", "chol_category", "risk_level"]:
        if col in df_pre_impute.columns:
            df_pre_impute.drop(columns=[col], inplace=True)
    df_imputed = impute_missing_values(df_pre_impute)
    # Validate schema after imputation
    df_imputed = validate_noncontextual_schema(
        df_imputed,
        schema_path_or_dict="schemas/cleaned_data.yaml",
        dataset_name="debug_preprocessing_imputed"
    )
    # --- Detailed Imputation Report ---
    nulls_before = df_integrated.isnull().sum()
    nulls_after = df_imputed.isnull().sum()
    print("\n🧮 [Imputation Summary]")
    for col in df_integrated.columns:
        if nulls_before[col] > 0:
            filled = nulls_before[col] - nulls_after[col]
            print(f"🟢 Column '{col}': Filled {filled} missing value(s), Remaining: {nulls_after[col]}")
            if nulls_after[col] == 0:
                print(f"✅ Column '{col}' is now fully imputed and ready for the next stages.")
            else:
                print(f"⚠️ Column '{col}' still has {nulls_after[col]} missing value(s). Review imputation strategy.")
    # Explicitly ensure 'sex' column imputation status is printed clearly even if no missing values before or after
    if 'sex' in df_integrated.columns:
        sex_null_before = nulls_before['sex']
        sex_null_after = nulls_after['sex']
        if sex_null_before > 0:
            filled_sex = sex_null_before - sex_null_after
            print(f"🟢 Column 'sex': Filled {filled_sex} missing value(s), Remaining: {sex_null_after}")
            if sex_null_after == 0:
                print(f"✅ Column 'sex' is now fully imputed and ready for the next stages.")
            else:
                print(f"⚠️ Column 'sex' still has {sex_null_after} missing value(s). Review imputation strategy.")
        elif sex_null_before == 0:
            print(f"✅ Column 'sex' had no missing values and is ready for the next stages.")
    missing_before = df_integrated.isnull().sum().sum()
    missing_after = df_imputed.isnull().sum().sum()
    filled_values = missing_before - missing_after
    print(f"[Imputation] Filled missing values. Shape after imputation: {df_imputed.shape}")
    print(f"[Imputation] Null values per column:\n{df_imputed.isnull().sum()}")
    print(f"[Imputation] Total missing values filled: {filled_values}")
    print_stage_summary("Imputation", df_imputed)

    # Step 5: Encoding
    df_encoded = encode_hypertension_data(df_imputed.copy())
    # Validate schema after encoding
    df_encoded = validate_noncontextual_schema(
        df_encoded,
        schema_path_or_dict="schemas/post-encoding.yaml",
        dataset_name="debug_preprocessing_encoded"
    )
    print(f"[Encoding] Applied categorical and numerical encodings. Shape after encoding: {df_encoded.shape}")
    print(f"[Encoding] Null values per column:\n{df_encoded.isnull().sum()}")
    print_stage_summary("Encoding", df_encoded)
    print(f"[Encoding] Total columns after encoding: {len(df_encoded.columns)}")


    print("\n✅ Preprocessing pipeline completed successfully. Ready for context stage.")

    # Final validation of missing values
    final_nulls = df_encoded[[
        "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg", "thalach",
        "exang", "oldpeak", "slope", "ca", "thal", "target", "target_copy",
        "age_group", "risk_score", "risk_level",
        "multi__risk_level_high", "multi__risk_level_low", "multi__risk_level_medium"
    ]].isnull().sum()
    total_missing = final_nulls.sum()
    print("\n🔍 [Final Null Check]")
    if total_missing == 0:
        print("✅ All columns verified. No missing values remain in the final encoded dataset.")
    else:
        print(f"❌ Final dataset still contains {total_missing} missing value(s):")
        print(final_nulls[final_nulls > 0])

    # --- Clear feature_engineering.log at the end of preprocessing ---
    try:
        with open("logs/feature_engineering.log", "w") as f:
            f.truncate(0)  # يفرغ محتوى الملف بالكامل
        print("🧹 [Cleanup] Emptied feature_engineering.log after preprocessing.")
    except Exception as e:
        print(f"⚠️ [Cleanup] Could not empty feature_engineering.log: {e}")

if __name__ == "__main__":
    main()