import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from utils.risk_score_transformer import RiskScoreTransformer
from utils.column_audit import audit_columns

from utils.logging_utils import setup_logger

# Updated to use centralized validation from utils.validation
from utils.validation import validate_noncontextual_schema

# --- Global config loading ---
from utils.config_loader import load_global_config
CONFIG = load_global_config()

# Logging configuration using logging_utils
data_quality_logger = setup_logger("data_quality_logger", "logs/data_quality.log")
cleaning_logger = setup_logger("cleaning_logger", "logs/cleaning.log")
# Improved processing to reduce data leakage by deferring complex transformations until after splitting the data.

__all__ = [
    "MedicalDataCleaner",
    "build_imputer",
    "prepare_post_split_pipeline",
    "analyze_feature_types",
    "build_post_split_pipeline",
    "clean_data"
]

# هذا المِلف مسؤول عن تنظيف البيانات الأولية بشكل عام، بالإضافة إلى تنظيف مخصص لكل مرض (سكري، ضغط دَم، سكتة دماغية)



class MedicalDataCleaner:
    def __init__(self, log_id: str = "global"):
        cleaning_logger.info(f"[{log_id}] 🧹 Cleaning | MedicalDataCleaner initialized.")


    @staticmethod
    def generate_age_group(df: pd.DataFrame, log_id: str = "global") -> pd.DataFrame:
        """
        Generate an 'age_group' column based on the patient's age.

        Parameters
        ----------
        df : pd.DataFrame
            The input DataFrame containing an 'age' column.
        log_id : str, optional
            Optional string used for consistent logging across pipeline components.

        Returns
        -------
        pd.DataFrame
            Modified DataFrame with an additional 'age_group' column.
        """
        cleaning_logger.info(f"[{log_id}] 🔢 Numeric | Generating 'age_group' based on age bins.")
        cleaning_logger.info(f"[{log_id}] [Medical Data Security] Binning 'age' into clinical ranges for 'age_group'.")
        from utils.safe_copy import safe_copy_for_preprocessing
        df = safe_copy_for_preprocessing(df)

        # Correct implementation as per requirement
        if 'age' in df.columns and not df['age'].dropna().empty:
            df['age'] = pd.to_numeric(df['age'], errors='coerce')
            bins = [0, 18, 30, 45, 60, 75, 120]
            from utils.constants import AGE_GROUPS
            labels = AGE_GROUPS
            df['age_group'] = pd.cut(df['age'], bins=bins, labels=labels, right=False)
            if df['age_group'].isnull().all():
                data_quality_logger.warning(f"[{log_id}] ⚠️ Warning | All values in 'age_group' are NaN. Possible binning issue or missing 'age'.")
        else:
            data_quality_logger.warning(f"[{log_id}] ⚠️ Warning | 'age' column missing or empty. Cannot generate 'age_group'.")
        # Validation call after creating age_group
        from utils.config_loader import load_schema
        schema = load_schema("schemas/clean_hypertension_data.yaml")
        validate_noncontextual_schema(df, schema, dataset_name="hypertension")
        return df

    @staticmethod
    def convert_numeric_columns(df: pd.DataFrame, columns: list, log_id: str = "global") -> pd.DataFrame:
        """
        Convert specified columns to numeric dtype.

        Parameters
        ----------
        df : pd.DataFrame
            Dataset to be modified.
        columns : list  str
            List of column names to convert.
        log_id : str, optional
            Identifier for logging context. Default is "global".

        Returns
        -------
        pd.DataFrame
            Dataset with specified columns converted to numeric types.

        Raises
        ------
        Exception
            If conversion fails for any column.
        """
        cleaning_logger.info(f"[{log_id}] 🔢 Numeric | Converting fields to numeric: {columns}")
        # Use a safe copy of the DataFrame before making any changes.
        from utils.safe_copy import safe_copy_for_preprocessing
        df = safe_copy_for_preprocessing(df)
        for col in columns:
            try:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
                    cleaning_logger.info(f"[{log_id}] 🔢 Numeric | Converted '{col}' to numeric.")
                else:
                    data_quality_logger.warning(f"[{log_id}] ⚠️ Warning | Column '{col}' not found for numeric conversion.")
            except Exception as e:
                cleaning_logger.warning(f"[{log_id}] ❌ Error | Failed to convert column '{col}' to numeric: {e}")
        # validate_loaded_dataset(df, filename="convert_numeric_columns")
        # Validation skipped: no schema file required for numeric conversion
        return df

    @staticmethod
    def log_age_group_distribution(df: pd.DataFrame, log_id: str = "global") -> None:
        """
        Logs the distribution of age groups for monitoring and analysis.

        Parameters
        ----------
        df : pd.DataFrame
            DataFrame containing the 'age_group' column.
        log_id : str
            Unique identifier for the logging context.
        """
        if 'age_group' in df.columns:
            cleaning_logger.info(f"[{log_id}] 🧠 Age Group | Distribution:\n" + df['age_group'].value_counts().sort_index().to_string())
        else:
            cleaning_logger.info(f"[{log_id}] 🧠 Age Group | 'age_group' column not found. No distribution to log.")

    @staticmethod
    def generate_missing_report(df: pd.DataFrame, label: str = "", log_id: str = "global") -> pd.DataFrame:
        summary = df.isnull().sum()
        percent = (summary / len(df)) * 100
        report = pd.DataFrame({
            "Missing Count": summary,
            "Missing %": percent.round(2)
        })
        report = report[report["Missing Count"] > 0]
        if not report.empty:
            cleaning_logger.info(f"[{log_id}] [Missing Report] Missing report ({label}):\n{report.to_string()}")
        else:
            cleaning_logger.info(f"[{log_id}] [Missing Report] No missing values found ({label}).")
        return report

    @staticmethod
    def clean_generic(df: pd.DataFrame, dataset_name: str, run_self_test: bool = True, log_id: str = "global") -> pd.DataFrame:
        """
        Perform standard cleaning on a general healthcare dataset.

        Cleans and standardizes columns, removes duplicates, drops columns with high missingness,
        and checks for the presence of clinically important fields. Does not apply imputation or encoding
        to avoid data leakage.

        Parameters
        ----------
        df : pd.DataFrame
            Raw input dataset.
        dataset_name : str
            Name of the dataset (used for logging).
        run_self_test : bool, optional
            Whether to run internal validation after cleaning. Default is True.
        log_id : str, optional
            Optional string used for tagging log messages uniquely across pipeline stages.

        Returns
        -------
        pd.DataFrame
            Cleaned and preprocessed DataFrame.

        Raises
        ------
        ValueError
            If any error occurs during the cleaning process.

        Notes
        -----
        - Imputation and encoding are intentionally not performed at this stage.
        - Essential clinical columns are logged and checked for presence.
        """
        try:
            from utils.safe_copy import safe_copy_for_preprocessing
            df = safe_copy_for_preprocessing(df)
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Cleaning dataset: {dataset_name}")

            # Step 1: Standardize column names
            print(f"🔍 Columns before cleaning: {len(df.columns)}")
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Columns before cleaning: {len(df.columns)}")
            empty_cols = df.columns[df.isnull().all()].to_list()
            if empty_cols:
                data_quality_logger.warning(f"[{log_id}] [Data Integrity] Dropping 100% null columns: {empty_cols}")
                df.drop(columns=[col for col in empty_cols if col != 'target'], inplace=True)
            cleaning_logger.info(f"[{log_id}] [Diagnostics] Columns after dropping 100% nulls: {len(df.columns)}")
            # Standardize column names once after dropping all-null columns
            df.columns = [col.strip().lower().replace(" ", "_") for col in df.columns]
            cleaning_logger.info(f"[{log_id}] [Diagnostics] Number of columns after standardization: {len(df.columns)}")
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Standardized columns: {list(df.columns)}")
            # Ensure 'target' column is preserved (insert/correct here)
            if 'target' in df.columns:
                df['target_copy'] = df['target'].copy()
                cleaning_logger.info(f"[{log_id}] [Data Integrity] 'target' column preserved in cleaned data.")

            cleaning_logger.info(f"[{log_id}] [Data Integrity] Finished column standardization.")

            # Step 2: Log duplicate count before removing duplicates
            duplicate_count = df.duplicated().sum()
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Found {duplicate_count} duplicate rows.")
            print(f"[Data Integrity] Found {duplicate_count} duplicate rows.")
            # Remove duplicates
            original_shape = df.shape
            df = df.drop_duplicates()
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Removed {original_shape[0] - df.shape[0]} duplicate rows.")
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Finished duplicate removal.")

            # Step 3: Missing value analysis
            missing_report = df.isnull().sum()
            missing_percent = (missing_report / len(df)) * 100
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Missing value percentages:\n" + missing_percent.round(2).to_string())
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Finished missing value analysis.")

            # Step 4: Drop columns with >30% missing data
            cols_to_drop = [col for col in missing_percent[missing_percent > 30].index if col != 'target']
            if cols_to_drop:
                data_quality_logger.warning(f"[{log_id}] [Data Integrity] Dropping columns with >30% missing data: {cols_to_drop}")
                df.drop(columns=cols_to_drop, inplace=True)
                cleaning_logger.info(f"[{log_id}] [Diagnostics] Columns after dropping high-missing columns: {len(df.columns)}")
                print(f"[Data Integrity] Dropped columns with >30% missing data: {cols_to_drop}")
                # Calculate and log missing ratio (based on original + dropped columns)
                total_cols = len(df.columns) + len(cols_to_drop)
                missing_ratio = round(len(cols_to_drop) / total_cols * 100, 2) if total_cols else 0
                cleaning_logger.info(f"[{log_id}] [Data Integrity] Dropped {len(cols_to_drop)} columns ({missing_ratio}%) due to missing threshold.")
            else:
                print("[Data Integrity] No columns dropped based on missing threshold.")
                cleaning_logger.info(f"[{log_id}] [Data Integrity] No columns dropped based on missing threshold.")
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Remaining columns after dropping high-missing: {list(df.columns)}")
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Finished high-missing column drop.")

            # Step 4.1: Ensure numeric consistency for known clinical features
            numeric_columns_to_force = ['age', 'trestbps', 'chol']
            for col in numeric_columns_to_force:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
                    cleaning_logger.info(f"[{log_id}] [Type Enforcement] Converted '{col}' to float for consistency.")

            # NOTE: No imputation, mapping, or dtype conversions are applied here to avoid data leakage.
            # This function only standardizes columns and drops high-missing columns and duplicates.

            print(f"[Data Integrity] Final cleaned dataset shape: {df.shape}")
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Final cleaned dataset shape: {df.shape}")
            # Drop columns that are completely empty (contain only NaN) to remove irrelevant features early.
            # Never drop 'target' even if empty unless explicitly intended.
            cols_all_nan = [col for col in df.columns if df[col].isnull().all() and col != 'target']
            if cols_all_nan:
                df.drop(columns=cols_all_nan, inplace=True)
            cleaning_logger.info(f"[{log_id}] [Diagnostics] Final column count after removing all-NaN columns: {len(df.columns)}")
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Final columns in cleaned dataset: {list(df.columns)}")
            print("=" * 50)
            # --- Insert essential risk columns strict check here ---
            # 🔍 Ensure essential columns for risk scoring are present (strict clinical integrity)
            essential_risk_cols = ["age", "trestbps", "chol"]
            missing_essentials = [col for col in essential_risk_cols if col not in df.columns]
            if missing_essentials:
                error_msg = f"[{log_id}] [Clinical Error] Essential clinical columns missing post-cleaning: {missing_essentials}. Aborting to avoid medical inconsistency."
                cleaning_logger.critical(error_msg)
                raise ValueError(error_msg)
            else:
                cleaning_logger.info(f"[{log_id}] [Clinical Validation] All essential clinical columns present: {essential_risk_cols}")
            # --- End essential risk columns strict check ---

            # After logging remaining columns, add clinical validation logging
            retained_important = ['age', 'trestbps', 'chol', 'target']
            retained_present = [col for col in retained_important if col in df.columns]
            cleaning_logger.info(f"[{log_id}] [Clinical Validation] Retained clinically important columns: {retained_present}")
            if 'target' in df.columns:
                class_dist = df['target'].value_counts(normalize=True).round(2).to_dict()
                cleaning_logger.info(f"[{log_id}] [Clinical Validation] Target distribution: {class_dist}")

            # Self-test after cleaning (optionally)
            if run_self_test:
                MedicalDataCleaner.self_test(df, dataset_name, log_id=log_id)
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Finished cleaning for {dataset_name}")
            return df
        except Exception as e:
            cleaning_logger.exception(f"[{log_id}] [Clinical Warning] Error occurred while cleaning {dataset_name} dataset: {e}")
            raise ValueError(f"Error occurred while cleaning {dataset_name} dataset") from e

    def clean_hypertension_data(self, df: pd.DataFrame, skip_risk_scoring: bool = False, run_self_test: bool = True, log_id: str = "global") -> pd.DataFrame:
        """
        Clean and transform a dataset for hypertension-specific modeling.

        Applies age group generation, numeric conversion, and risk score transformation,
        ensuring the presence of essential columns before proceeding.

        Parameters
        ----------
        df : pd.DataFrame
            Raw hypertension dataset.
        skip_risk_scoring : bool, optional
            If True, skips risk score calculation. Default is False.
        run_self_test : bool, optional
            If True, run internal validation tests after cleaning. Default is True.
        log_id : str, optional
            Optional string used for tagging log messages uniquely across pipeline stages.

        Returns
        -------
        pd.DataFrame
            Cleaned DataFrame with medical features transformed and risk score applied.

        Raises
        ------
        ValueError
            If essential columns are missing or cleaning fails.

        Notes
        -----
        - Applies clinical feature transformations relevant to hypertension.
        - May skip risk scoring if configured.
        """
        dataset_name = "hypertension"
        try:
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Cleaning dataset: {dataset_name}")
            # --- Inject strict_mode and required_columns from CONFIG ---
            strict_mode = CONFIG.get("strict_mode", False)
            required_columns = CONFIG.get("required_columns", ["age", "trestbps", "chol"])
            # Check for essential columns before proceeding
            essential_columns = required_columns
            missing_essentials = [col for col in essential_columns if col not in df.columns]
            if missing_essentials:
                cleaning_logger.error(f"[{log_id}] [Data Integrity] ❌ Essential columns missing for hypertension cleaning: {missing_essentials}.")
                raise ValueError(f"[Strict Mode: {strict_mode}] Essential columns missing: {missing_essentials}")
            from utils.safe_copy import safe_copy_for_preprocessing
            df = safe_copy_for_preprocessing(df)
            df = self.clean_generic(df, dataset_name, run_self_test=False, log_id=log_id)

            # --- Global Missing Value Report Before Any Row Deletion ---
            full_report = self.generate_missing_report(df, label="Initial", log_id=log_id)
            if not full_report.empty:
                print(f"[Missing Report] Initial missing value summary:\n{full_report.to_string()}")
            else:
                print("[Missing Report] No missing values detected.")
            # --- End Global Missing Value Report ---
            cleaning_logger.debug(f"[{log_id}] [Trace] After clean_generic — Columns: {df.columns.tolist()}")
            df = self.generate_age_group(df, log_id=log_id)
            cleaning_logger.debug(f"[{log_id}] [Trace] After generate_age_group — Columns: {df.columns.tolist()}")
            df = self.convert_numeric_columns(df, ['sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 'thalach', 'exang'], log_id=log_id)
            cleaning_logger.debug(f"[{log_id}] [Trace] After convert_numeric_columns — Columns: {df.columns.tolist()}")
            # --- Intelligent Filtering for Missing 'sex' Values ---
            # --- Global Missing Value Report Before Row Deletion ---
            full_report = self.generate_missing_report(df, label="Before Deletion", log_id=log_id)
            # --- End Global Missing Value Report ---

            # Ensure original_len and removed_rows are always initialized before any conditional use
            original_len = len(df)
            removed_rows = 0

            if 'sex' in df.columns:
                missing_sex_rows = df[df['sex'].isnull()]
                if not missing_sex_rows.empty:
                    # 🧪 قبل الحذف: راقب توزيع الأعمدة السريرية الرئيسية في الصفوف التي سيتم حذفها
                    critical_cols = ['age', 'trestbps', 'chol']
                    pre_drop_stats = missing_sex_rows[critical_cols].describe(include='all')
                    cleaning_logger.warning(f"[{log_id}] [Diagnostic] Stats of rows with missing 'sex' before deletion:\n{pre_drop_stats.to_string()}")
                    print(f"[Diagnostic] Preview of rows with missing 'sex':\n{missing_sex_rows[critical_cols].head(3).to_string(index=False)}")

                    original_len = len(df)
                    df = df.dropna(subset=['sex'])
                    removed_rows = original_len - len(df)

                    cleaning_logger.info(f"[{log_id}] [Data Integrity] Removed {removed_rows} rows with missing 'sex' values.")
                    print(f"[Data Integrity] Removed {removed_rows} rows with missing 'sex' values.")
                    cleaning_logger.info(f"[{log_id}] [Data Integrity] Shape after removing rows with missing 'sex': {df.shape}")
                else:
                    cleaning_logger.info(f"[{log_id}] [Data Integrity] No rows with missing 'sex' found.")
            # --- End Intelligent Filtering ---

            # --- Intelligent Filtering for Missing 'age' Values ---
            if 'age' in df.columns:
                missing_age_rows = df[df['age'].isnull()]
                if not missing_age_rows.empty:
                    critical_cols = ['trestbps', 'chol', 'sex']
                    pre_drop_stats_age = missing_age_rows[critical_cols].describe(include='all')
                    cleaning_logger.warning(f"[{log_id}] [Diagnostic] Stats of rows with missing 'age' before deletion:\n{pre_drop_stats_age.to_string()}")
                    print(f"[Diagnostic] Preview of rows with missing 'age':\n{missing_age_rows[critical_cols].head(3).to_string(index=False)}")

                    original_len = len(df)
                    df = df.dropna(subset=['age'])
                    removed_rows = original_len - len(df)

                    cleaning_logger.info(f"[{log_id}] [Data Integrity] Removed {removed_rows} rows with missing 'age' values.")
                    print(f"[Data Integrity] Removed {removed_rows} rows with missing 'age' values.")
                    cleaning_logger.info(f"[{log_id}] [Data Integrity] Shape after removing rows with missing 'age': {df.shape}")
                else:
                    cleaning_logger.info(f"[{log_id}] [Data Integrity] No rows with missing 'age' found.")
            # --- End Intelligent Filtering ---

            # --- Global Missing Value Report After Row Deletion ---
            post_report = self.generate_missing_report(df, label="After Deletion", log_id=log_id)

            # Print comparison if there was missing data before
            if not full_report.empty:
                comparison = full_report.join(post_report, lsuffix='_before', rsuffix='_after', how='outer').fillna(0)
                cleaning_logger.info(f"[{log_id}] [Missing Report] Comparison of missing values before vs. after deletion:\n{comparison.to_string()}")
                print(f"[Missing Report] Comparison before vs. after:\n{comparison.to_string()}")

                total_before = full_report["Missing Count"].sum()
                total_after = post_report["Missing Count"].sum()
                dropped_total = total_before - total_after
                dropped_ratio = (dropped_total / total_before * 100) if total_before > 0 else 0

                # Ensure variables are defined before usage in this block
                if 'original_len' not in locals():
                    original_len = len(df)
                if 'removed_rows' not in locals():
                    removed_rows = 0

                if dropped_ratio > 40:
                    warning_msg = f"[⚠️ WARNING] More than 40% of missing rows were dropped ({dropped_ratio:.2f}%). This may reduce data reliability."
                    cleaning_logger.warning(f"[{log_id}] {warning_msg}")
                    print(warning_msg)
                    if 'removed_rows' in locals() and 'original_len' in locals() and original_len > 0:
                        if (removed_rows / original_len) > 0.05:
                            raise ValueError("❌ Too many rows removed during cleaning — check missing value policy.")
            # --- End Global Missing Value Report ---

            self.log_age_group_distribution(df, log_id=log_id)
            # --- Insert risk scoring step here ---
            if not skip_risk_scoring:
                try:
                    if "age" in df.columns:
                        df = RiskScoreTransformer().transform(df)
                        cleaning_logger.debug(f"[{log_id}] [Trace] After RiskScoreTransformer — Columns: {df.columns.tolist()}")
                        cleaning_logger.info(f"[{log_id}] [Clinical Validation] Risk scoring applied successfully during hypertension data cleaning.")
                    else:
                        cleaning_logger.warning(f"[{log_id}] [Clinical Warning] Skipped risk scoring during hypertension cleaning: 'age' column not found.")
                except Exception as e:
                    cleaning_logger.warning(f"[{log_id}] [Clinical Warning] ⚠️ Risk scoring skipped due to: {e}")
            else:
                cleaning_logger.info(f"[{log_id}] [Clinical Validation] Skipped risk scoring as per configuration (skip_risk_scoring=True).")
            # --- End risk scoring step ---
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Final columns in cleaned {dataset_name} dataset: {df.columns.tolist()}")
            if 'target' in df.columns:
                cleaning_logger.info(f"[{log_id}] [Clinical Validation] 'target' column confirmed present after hypertension cleaning.")
            if run_self_test:
                MedicalDataCleaner.self_test(df, dataset_name, log_id=log_id)
            cleaning_logger.info(f"[{log_id}] [Data Integrity] Finished cleaning for {dataset_name}")

            from utils.config_loader import load_schema
            # Post-integration validation: use correct schema for integrated/cleaned data
            schema = load_schema("schemas/clean_hypertension_data.yaml")
            validate_noncontextual_schema(df, schema, dataset_name="hypertension")
            audit_columns(df, "After Cleaning")
            # --- Strict mode enforcement after logging final columns ---
            if strict_mode and missing_essentials:
                raise ValueError(f"Strict mode active — missing essential columns: {missing_essentials}")
            return df
        except Exception as e:
            cleaning_logger.exception(f"[{log_id}] [Clinical Warning] Error occurred while cleaning {dataset_name} dataset: {e}")
            raise ValueError(f"Error occurred while cleaning {dataset_name} dataset") from e


    @staticmethod
    def clean_medical_data(df: pd.DataFrame, run_self_test: bool = True, log_id: str = "global") -> pd.DataFrame:
        """
        Advanced cleaning pipeline for merged or multi-disease clinical data.

        Drops empty columns and rows with missing critical values, standardizes column names,
        and optimizes categorical features for memory, preparing the dataset for downstream
        imputation and encoding.

        Parameters
        ----------
        df : pd.DataFrame
            Combined clinical dataset.
        run_self_test : bool, optional
            Whether to run internal validation checks after cleaning. Default is True.
        log_id : str, optional
            Optional string used for tagging log messages uniquely across preprocessing stages.

        Returns
        -------
        pd.DataFrame
            Cleaned dataset ready for further preprocessing.

        Raises
        ------
        Exception
            If any step fails during cleaning.

        Notes
        -----
        - Used for integrated pipelines before splitting by disease type.
        - Does not perform imputation or encoding.
        """
        dataset_name = "medical_data"
        try:
            cleaning_logger.info(f"[{log_id}] 🔍 Starting missing column drop.")
            cleaning_logger.info(f"[{log_id}] Initial shape: {df.shape}")
            initial_columns = df.columns.tolist()

            # Drop completely empty columns
            df.dropna(axis=1, how='all', inplace=True)
            removed_columns = list(set(initial_columns) - set(df.columns))
            if removed_columns:
                cleaning_logger.info(f"[{log_id}] Columns dropped during cleaning: {removed_columns}")

            cleaning_logger.info(f"[{log_id}] 🔍 Standardizing column names.")
            # Standardize column names to lowercase
            df.columns = [col.lower().strip() for col in df.columns]

            # Standardize binary categorical values
            if 'sex' in df.columns:
                cleaning_logger.info(f"[{log_id}] [Medical Data Security] Standardizing 'sex' column with mapping and logging.")
                df['sex'] = df['sex'].astype(str).str.strip().str.lower()
                df['sex'] = df['sex'].replace({'1': 'male', '0': 'female', 'm': 'male', 'f': 'female'})
                mode_sex = df['sex'].mode()[0]
                # Do not impute categorical features here; defer to post-split preprocessing pipeline.
                print(f"🩺 Imputing missing 'sex' values with mode: {mode_sex}")
                cleaning_logger.info(f"[{log_id}] Standardized 'sex' column with mode: {mode_sex}")

            # Clean and cap age values
            if 'age' in df.columns:
                cleaning_logger.info(f"[{log_id}] [Medical Data Security] Clipping and validating 'age' for plausibility and safety.")
                # نقوم بتقييد القيم لضمان بقائها ضمن النطاقات الطبية المنطقية
                df['age'] = df['age'].clip(lower=0, upper=120)
                df.dropna(subset=['age'], inplace=True)
                cleaning_logger.info(f"[{log_id}] Clipped 'age' to range 0–120 and dropped missing.")

            # Drop rows with missing critical values
            df.dropna(subset=['sex', 'age'], inplace=True)

            cleaning_logger.info(f"[{log_id}] 🔍 Optimizing memory by converting objects to categories.")
            cleaning_logger.info(f"[{log_id}] Final shape after cleaning: {df.shape}")
            cleaning_logger.info(f"[{log_id}] Medical data cleaning completed.")

            # Optimize categorical features for memory usage
            for col in df.select_dtypes(include="object").columns:
                if df[col].nunique() < df.shape[0] * 0.05:
                    df[col] = df[col].astype("category")
                    cleaning_logger.info(f"[{log_id}] Converted '{col}' to category for optimization.")

            # Log retained missing columns for external imputation pipeline
            retained_missing = df.isnull().sum()
            retained_missing = retained_missing[retained_missing > 0]
            if not retained_missing.empty:
                cleaning_logger.info(f"[{log_id}] Missing values retained for MICE imputation:\n" + retained_missing.to_string())

            if 'target' in df.columns:
                cleaning_logger.info(f"[{log_id}] ✅ 'target' column preserved during medical data cleaning.")
            if run_self_test:
                MedicalDataCleaner.self_test(df, dataset_name, log_id=log_id)
            cleaning_logger.info(f"[{log_id}] ✅ Finished cleaning for {dataset_name}")
            return df
        except Exception as e:
            cleaning_logger.exception(f"[{log_id}] ❌ Error occurred while cleaning {dataset_name} dataset: {e}")
            raise

    def clean_for_separate_models(self, df: pd.DataFrame, disease: str, run_self_test: bool = True, log_id: str = "global") -> pd.DataFrame:
        """
        Clean and preprocess the data for separate disease-specific models.

        Parameters
        ----------
        df : pd.DataFrame
            The input DataFrame containing medical data.
        disease : str
            The disease for which the model is being built (e.g., "hypertension").
        run_self_test : bool, optional
            If True, performs a self-test after cleaning (default is True).
        log_id : str, optional
            Unique identifier for logging and tracing (default is "global").

        Returns
        -------
        pd.DataFrame
            The cleaned and preprocessed DataFrame.
        """
        dataset_name = f"{disease}_specific_data"
        try:
            cleaning_logger.info(f"[{log_id}] Starting cleaning for separate model: {disease}")

            # Only hypertension is currently supported
            if disease == "hypertension":
                cleaning_logger.info(f"[{log_id}] ⚙️ Performing hypertension-specific preprocessing.")
                cols_required = ["age", "sex", "trestbps", "chol", "fbs"]
                df = df[cols_required]
                cleaning_logger.info(f"[{log_id}] Retained columns for {disease}: {cols_required}")
            else:
                raise ValueError(f"Unsupported disease model: {disease} — only 'hypertension' is currently supported.")

            # Apply only generic cleaning (no imputation, mapping, or encoding)
            df = self.clean_generic(df, dataset_name, run_self_test=False, log_id=log_id)
            cleaning_logger.info(f"[{log_id}] Columns after generic cleaning for {disease}: {df.columns.tolist()}")

            # Handle outliers and specific conditions for hypertension only
            for col in ["trestbps", "chol"]:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            df['trestbps'] = df['trestbps'].clip(lower=80, upper=200)
            df['chol'] = df['chol'].clip(lower=100, upper=400)

            cleaning_logger.info(f"[{log_id}] Completed specific cleaning for {disease}")
            if run_self_test:
                MedicalDataCleaner.self_test(df, dataset_name, log_id=log_id)
            cleaning_logger.info(f"[{log_id}] ✅ Finished cleaning for {dataset_name}")
            return df
        except Exception as e:
            cleaning_logger.exception(f"[{log_id}] ❌ Error occurred while cleaning {dataset_name} dataset: {e}")
            raise

    # validate_loaded_dataset already imported at module level, so no need to import repeatedly

    @staticmethod
    def self_test(df: pd.DataFrame, dataset_name: str = "", log_id: str = "global") -> None:
        """
        Perform a self-check on the cleaned dataset to verify basic expectations.

        Parameters
        ----------
        df : pd.DataFrame
            The dataset to check.
        dataset_name : str, optional
            A name for the dataset used in logs.
        log_id : str, default="global"
            Identifier for logging and traceability in pipeline steps.
        """
        try:
            cleaning_logger.info(f"[{log_id}] 🧪 Self-Test | Starting validation for {dataset_name}")

            if df.empty:
                cleaning_logger.error(f"[{log_id}] ❌ Self-Test Failed | {dataset_name} DataFrame is empty after cleaning.")
                return
            else:
                cleaning_logger.info(f"[{log_id}] ✅ Self-Test | {dataset_name} shape: {df.shape}")

            if 'target' not in df.columns:
                cleaning_logger.warning(f"[{log_id}] ⚠️ Self-Test Warning | 'target' column missing in {dataset_name}.")

            fully_null_cols = df.columns[df.isnull().all()].tolist()
            if fully_null_cols:
                cleaning_logger.warning(f"[{log_id}] ⚠️ Self-Test Warning | Fully empty columns: {fully_null_cols}")

            stats_msg = df.describe(include='all').transpose().to_string()
            cleaning_logger.info(f"[{log_id}] 📊 Self-Test | Statistical overview for {dataset_name}:\n{stats_msg}")

            cleaning_logger.info(f"[{log_id}] ✅ Self-Test Completed | {dataset_name} passed structural checks.")

        except Exception as e:
            cleaning_logger.exception(f"[{log_id}] ❌ Self-Test Error | Exception during validation of {dataset_name}: {e}")

def build_imputer(strategy: str = 'median'):
    """
    Create a scikit-learn SimpleImputer for numeric features.

    Parameters
    ----------
    strategy : str, optional
        Imputation strategy; one of {'mean', 'median', 'most_frequent'}. Default is 'median'.

    Returns
    -------
    SimpleImputer
        A scikit-learn SimpleImputer object for numeric columns.

    Raises
    ------
    ValueError
        If an invalid strategy is provided.
    """
    return SimpleImputer(strategy=strategy)


def prepare_post_split_pipeline(numeric_features, categorical_features):
    """
    Build a preprocessing pipeline for post-train-test-split data.

    Constructs a scikit-learn ColumnTransformer that imputes and scales numeric features,
    and imputes and one-hot encodes categorical features.

    Parameters
    ----------
    numeric_features : list str
        Names numeric columns.
    categorical_features : list str
        Names categorical columns.

    Returns
    -------
    ColumnTransformer
        Combined transformer for preprocessing numeric and categorical features.
    """
    from sklearn.compose import ColumnTransformer
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder, StandardScaler
    from sklearn.impute import SimpleImputer


    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])

    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore"))
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_features),
            ("cat", categorical_transformer, categorical_features)
        ]
    )

    return preprocessor

def analyze_feature_types(df: pd.DataFrame):
    """
    Analyze and separate dataset columns into numeric and categorical features.

    Parameters
    ----------
    df : pd.DataFrame
        Input dataset.

    Returns
    -------
    tuple of lists
        (numeric_columns, categorical_columns)
        - numeric_columns: list of str
        - categorical_columns: list of str
    """
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
    return numeric_cols, categorical_cols

def build_post_split_pipeline(numeric_features, categorical_features):
    """
    Create a complete preprocessing pipeline for post-split train/test sets.

    Returns a ColumnTransformer that imputes and scales numeric features, and imputes and
    one-hot encodes categorical features using dense output.

    Parameters
    ----------
    numeric_features : list str
        Names numeric features.
    categorical_features : list str
        Names categorical features.

    Returns
    -------
    ColumnTransformer
        Complete transformation pipeline for numeric and categorical features.
    """
    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])

    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
    ])

    full_pipeline = ColumnTransformer(transformers=[
        ("num", numeric_transformer, numeric_features),
        ("cat", categorical_transformer, categorical_features)
    ])

    return full_pipeline


# Compatibility alias for older tests expecting a clean_data function
def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compatibility alias for older tests expecting a clean_data function.
    Internally calls MedicalDataCleaner().clean_hypertension_data().
    Ensures all cleaning steps and validations are performed before returning the cleaned DataFrame.
    """
    cleaner = MedicalDataCleaner()
    df_cleaned = cleaner.clean_hypertension_data(df)
    return df_cleaned
