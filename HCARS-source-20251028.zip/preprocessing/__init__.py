# Makes preprocessing a package
from .data_cleaning import clean_data
from .encoding import (
    encode_hypertension_data,
    encode_features,
    encode_categoricals,
    encode_diabetes_data,
    build_encoder,
    self_test_encoding
)
from .imputation import (
    impute_missing_values,
    build_imputer,
    get_iterative_imputer,
    backup_target_column,
    prepare_numeric_columns,
    setup_imputer,
    cleanup_after_imputation,
    self_test_imputation
)
from .integration import (
    integrate_data_sources,
    separate_and_backup_target,
    validate_required_encoding_columns,
    create_protected_backups,
    encode_train_test,
    restore_critical_columns,
    impute_missing_values,
    final_validations,
    cleanup_temp_columns,
    backup_protected_columns,
    prepare_hypertension_pre_split,
    integrate_for_separate_models,
    process_post_split_hypertension,
    backup_targets,
    post_split_processing,
    validate_and_restore_targets,
    cleanup_backup_columns,
    ensure_target_integrity,
    verify_risk_score_columns
)

__all__ = [
    # data cleaning
    'clean_data',
    # encoding
    'encode_hypertension_data',
    'encode_features',
    'encode_categoricals',
    'encode_diabetes_data',
    'build_encoder',
    'self_test_encoding',
    # imputation
    'impute_missing_values',
    'build_imputer',
    'get_iterative_imputer',
    'backup_target_column',
    'prepare_numeric_columns',
    'setup_imputer',
    'cleanup_after_imputation',
    'self_test_imputation',
    # integration
    'integrate_data_sources',
    'separate_and_backup_target',
    'validate_required_encoding_columns',
    'create_protected_backups',
    'encode_train_test',
    'restore_critical_columns',
    'impute_missing_values',
    'final_validations',
    'cleanup_temp_columns',
    'backup_protected_columns',
    'prepare_hypertension_pre_split',
    'integrate_for_separate_models',
    'process_post_split_hypertension',
    'backup_targets',
    'post_split_processing',
    'validate_and_restore_targets',
    'cleanup_backup_columns',
    'ensure_target_integrity',
    'verify_risk_score_columns'
]