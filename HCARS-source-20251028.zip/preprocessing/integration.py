
# --- Global configuration import and load ---
from utils.config_loader import load_global_config
GLOBAL_CONFIG = load_global_config()
import os
import pandas as pd
import numpy as np

from utils.safe_copy import safe_copy_for_preprocessing
from preprocessing.data_cleaning import MedicalDataCleaner
from preprocessing.encoding import encode_hypertension_data
from preprocessing.imputation import build_imputer
import yaml
from utils.risk_score_transformer import RiskScoreTransformer
from utils.logging_utils import setup_logger
pipeline_logger = setup_logger("integration_pipeline_logger", "logs/pipeline.log")
data_quality_logger = setup_logger("integration_quality_logger", "logs/data_quality.log")

def backup_and_remove_target(df, backup, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    if "target" in df.columns:
        pipeline_logger.info(f"[{log_id}] [Target Backup] Backing up and removing target column.")
    else:
        pipeline_logger.warning(f"[{log_id}] [Target Backup] Target column not found.")
    target = df["target"].copy() if "target" in df.columns else None
    if backup is None:
        backup = target.copy() if target is not None else None
    if "target" in df.columns:
        df = df.drop(columns=["target"])
    return df, backup

def separate_and_backup_target(train_df, test_df, y_train_backup=None, y_test_backup=None, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [separate_and_backup_target] Backing up and removing 'target' column for encoding.")
    try:
        train_df, y_train_backup = backup_and_remove_target(train_df, y_train_backup, log_id=log_id)
        test_df, y_test_backup = backup_and_remove_target(test_df, y_test_backup, log_id=log_id)
        pipeline_logger.info(f"[{log_id}] [separate_and_backup_target] 'target' column backed up and removed.")
        return train_df, test_df, y_train_backup, y_test_backup
    except Exception as e:
        data_quality_logger.error(f"[{log_id}] [separate_and_backup_target] Error during backup/removal: {e}")
        raise

def validate_required_encoding_columns(train_df, test_df, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [validate_required_encoding_columns] Validating required columns for encoding.")
    required_encoding_columns = ['sex', 'fbs', 'exang', 'cp', 'restecg', 'slope', 'ca', 'thal']
    missing_train_cols = [column for column in required_encoding_columns if column not in train_df.columns]
    missing_test_cols = [column for column in required_encoding_columns if column not in test_df.columns]
    if missing_train_cols or missing_test_cols:
        data_quality_logger.warning(f"[{log_id}] [Hypertension] Missing columns in training data: {missing_train_cols}")
        data_quality_logger.warning(f"[{log_id}] [Hypertension] Missing columns in test data: {missing_test_cols}")
        columns_to_keep = required_encoding_columns + ["age"]
        train_df = train_df[[column for column in train_df.columns if column in columns_to_keep or train_df[column].dtype in [np.number]]]
        test_df = test_df[[column for column in test_df.columns if column in columns_to_keep or test_df[column].dtype in [np.number]]]
    pipeline_logger.info(f"[{log_id}] [validate_required_encoding_columns] Training columns before encoding: {train_df.columns.tolist()}")
    pipeline_logger.info(f"[{log_id}] [validate_required_encoding_columns] Testing columns before encoding: {test_df.columns.tolist()}")
    return train_df, test_df

def create_protected_backups(train_df, test_df, protected_columns, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [create_protected_backups] Creating backup copies for protected columns: {protected_columns}")
    try:
        # Preserve 'age' before encoding
        if "age" in train_df.columns:
            train_df["age_preserved"] = train_df["age"]
        if "age" in test_df.columns:
            test_df["age_preserved"] = test_df["age"]
        for column in protected_columns:
            if column in train_df.columns:
                train_df[f"{column}_copy"] = train_df[column]
            if column in test_df.columns:
                test_df[f"{column}_copy"] = test_df[column]
        # Ensure backup copies of required_final_columns before encoding
        required_final_columns = ['sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'ca', 'thal', 'target']
        for column in required_final_columns:
            if f"{column}_copy" not in train_df.columns and column in train_df.columns:
                train_df[f"{column}_copy"] = train_df[column]
            if f"{column}_copy" not in test_df.columns and column in test_df.columns:
                test_df[f"{column}_copy"] = test_df[column]
        # Ensure risk_level_copy is backed up
        if "risk_level" in train_df.columns and "risk_level_copy" not in train_df.columns:
            train_df["risk_level_copy"] = train_df["risk_level"]
            pipeline_logger.info(f"[{log_id}] [create_protected_backups] Backed up 'risk_level' as 'risk_level_copy' in train_df.")
        if "risk_level" in test_df.columns and "risk_level_copy" not in test_df.columns:
            test_df["risk_level_copy"] = test_df["risk_level"]
            pipeline_logger.info(f"[{log_id}] [create_protected_backups] Backed up 'risk_level' as 'risk_level_copy' in test_df.")
        pipeline_logger.info(f"[{log_id}] [create_protected_backups] All protected and required columns backed up.")
        return train_df, test_df
    except Exception as e:
        data_quality_logger.error(f"[{log_id}] [create_protected_backups] Error creating backups: {e}")
        raise

def encode_train_test(train_df, test_df, y_train_backup=None, y_test_backup=None, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [encode_train_test] Encoding train and test sets.")
    # 🔄 دمج النسخ الاحتياطية للـ target إذا كانت موجودة
    if y_train_backup is not None and "target_train_copy" in y_train_backup:
        train_df["target_train_copy"] = y_train_backup["target_train_copy"]
    if y_test_backup is not None:
        # If a DataFrame with 'target_test_copy' column
        if isinstance(y_test_backup, pd.DataFrame) and "target_test_copy" in y_test_backup.columns:
            test_df["target_test_copy"] = y_test_backup["target_test_copy"]
        # If a Series
        elif isinstance(y_test_backup, pd.Series):
            test_df["target_test_copy"] = y_test_backup
    # --- Additional fallback logic for target_test_copy as dict ---
    if "target_test_copy" not in test_df.columns and y_test_backup is not None:
        if isinstance(y_test_backup, dict) and "target_test_copy" in y_test_backup:
            test_df["target_test_copy"] = y_test_backup["target_test_copy"]
            pipeline_logger.info(f"[{log_id}] [Fallback] Injected 'target_test_copy' into test_df from y_test_backup")
    # Log columns of test_df before encoding
    pipeline_logger.info(f"[{log_id}] [encode_train_test] Columns in test_df before encoding: {test_df.columns.tolist()}")
    try:
        # --- ENCODING WITH COLUMN AUDIT ---
        from utils.column_audit import audit_columns
        train_df_encoded = encode_hypertension_data(train_df)
        audit_columns(train_df_encoded, stage="Encoding")
        test_df_encoded = encode_hypertension_data(test_df)
        audit_columns(test_df_encoded, stage="Encoding")
        pipeline_logger.info(f"[{log_id}] [encode_train_test] Encoding completed.")
        return train_df_encoded, test_df_encoded
    except Exception as e:
        data_quality_logger.error(f"[{log_id}] [encode_train_test] Error during encoding: {e}")
        raise

def restore_critical_columns(train_df, test_df, required_final_columns, y_train_backup, y_test_backup, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [restore_critical_columns] Restoring critical columns: {required_final_columns}")
    try:
        # Restore 'target' from backup if missing
        if y_train_backup is not None and "target" not in train_df.columns:
            train_df["target"] = y_train_backup
            pipeline_logger.info(f"[{log_id}] [restore_critical_columns] 'target' restored to train_df after encoding.")
        if y_test_backup is not None and "target" not in test_df.columns:
            test_df["target"] = y_test_backup
            pipeline_logger.info(f"[{log_id}] [restore_critical_columns] 'target' restored to test_df after encoding.")

        # Use local restore_protected_columns with fallback_data
        train_df = restore_protected_columns(
            train_df,
            required_final_columns,
            fallback_data=y_train_backup.to_frame() if isinstance(y_train_backup, pd.Series) else y_train_backup,
            log_id=log_id
        )
        test_df = restore_protected_columns(
            test_df,
            required_final_columns,
            fallback_data=y_test_backup.to_frame() if isinstance(y_test_backup, pd.Series) else y_test_backup,
            log_id=log_id
        )

        # Log missing protected columns after restore
        missing_after_restore_train = [col for col in required_final_columns if col not in train_df.columns]
        missing_after_restore_test = [col for col in required_final_columns if col not in test_df.columns]
        pipeline_logger.info(f"[{log_id}] [restore_critical_columns] Missing in train_df: {missing_after_restore_train}")
        pipeline_logger.info(f"[{log_id}] [restore_critical_columns] Missing in test_df: {missing_after_restore_test}")

        # Ensure essential protected columns exist before feature engineering
        protected_columns = GLOBAL_CONFIG.get("preprocessing", {}).get("protected_columns", []) if GLOBAL_CONFIG else []
        for column in protected_columns:
            backup_col = f"{column}_copy"
            if column not in train_df.columns and backup_col in train_df.columns:
                train_df[column] = train_df[backup_col]
                data_quality_logger.warning(f"[{log_id}] [restore_critical_columns] Reinstated missing column '{column}' in train_df from '{backup_col}'")
            if column not in test_df.columns and backup_col in test_df.columns:
                test_df[column] = test_df[backup_col]
                data_quality_logger.warning(f"[{log_id}] [restore_critical_columns] Reinstated missing column '{column}' in test_df from '{backup_col}'")

        pipeline_logger.info(f"[{log_id}] [restore_critical_columns] Critical columns restored.")
        return train_df, test_df
    except Exception as e:
        data_quality_logger.error(f"[{log_id}] [restore_critical_columns] Error restoring critical columns: {e}")
        raise

def impute_missing_values(df, strategy="median", use_knn=False, use_iterative=False, exclude_columns=None, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [impute_missing_values] Imputing missing values in numeric columns.")
    try:
        imputer = build_imputer(strategy=strategy, use_knn=use_knn, use_iterative=use_iterative)
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        protected = ["target", "target_copy", "age"]
        if exclude_columns:
            protected += exclude_columns
        numeric_cols = [col_ for col_ in numeric_cols if col_ not in protected]
        imputed_values = imputer.fit_transform(df[numeric_cols])
        valid_column_count = imputed_values.shape[1]
        valid_columns = numeric_cols[:valid_column_count]
        imputed_df = pd.DataFrame(imputed_values, columns=valid_columns, index=df.index)
        df[valid_columns] = imputed_df
        # 🔍 Post-imputation validation
        critical_columns = ["age", "trestbps", "thalach", "chol", "risk_score", "target"]
        cols_with_nans = [col_ for col_ in critical_columns if col_ in df.columns and df[col_].isnull().any()]
        if cols_with_nans:
            for col_ in cols_with_nans:
                dtype = df[col_].dtype
                nan_count = df[col_].isnull().sum()
                data_quality_logger.warning(f"[{log_id}] [Imputation Check] Column '{col_}' has {nan_count} NaNs after imputation. Dtype: {dtype}")
            pipeline_logger.warning(f"[{log_id}] [Imputation Check] Critical columns with remaining NaNs: {cols_with_nans}")
        else:
            pipeline_logger.info(f"[{log_id}] [Imputation Check] All critical columns imputed successfully — no NaNs detected.")
        pipeline_logger.info(f"[{log_id}] [impute_missing_values] Imputation completed.")
        # 🔍 Contextual integrity check and auto-generation for contextual columns
        return df
    except Exception as e:
        data_quality_logger.error(f"[{log_id}] [impute_missing_values] Error during imputation: {e}")
        raise

def final_validations(train_df, required_final_columns, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [final_validations] Performing final validations on training set.")
    try:
        train_df = restore_protected_columns(train_df, required_final_columns, log_id=log_id)
        missing_post_engineering = [col for col in required_final_columns if col not in train_df.columns]
        for col in required_final_columns:
            if col not in train_df.columns:
                data_quality_logger.error(f"[{log_id}] [Final Check] Required column '{col}' is missing from training data.")
            elif train_df[col].isnull().all():
                data_quality_logger.error(f"[{log_id}] [Final Check] Column '{col}' exists but contains only null values in training data.")
        if missing_post_engineering:
            data_quality_logger.error(f"[{log_id}] [Validation Error] Missing required columns after post-processing: {missing_post_engineering}")
            raise ValueError(f"Missing critical columns after processing: {missing_post_engineering}")
        # Additional safeguard: Ensure no column has all NaNs after full processing
        null_columns = [col for col in train_df.columns if train_df[col].isnull().all()]
        if null_columns:
            data_quality_logger.warning(f"[{log_id}] [Final Validation] The following columns contain only NaN values in training set: {null_columns}")
        pipeline_logger.info(f"[{log_id}] [final_validations] Final validation completed successfully.")
        return train_df
    except Exception as e:
        data_quality_logger.error(f"[{log_id}] [final_validations] Error during final validations: {e}")
        raise

def cleanup_temp_columns(train_df, test_df, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [cleanup_temp_columns] Cleaning up temporary columns.")
    try:
        train_df = train_df.drop(columns=["age_preserved"], errors="ignore")
        test_df = test_df.drop(columns=["age_preserved"], errors="ignore")
        train_df = train_df.drop(columns=[col for col in train_df.columns if col.endswith('_copy')], errors="ignore")
        test_df = test_df.drop(columns=[col for col in test_df.columns if col.endswith('_copy')], errors="ignore")
        pipeline_logger.info(f"[{log_id}] [cleanup_temp_columns] Temporary columns removed.")
        return train_df, test_df
    except Exception as e:
        data_quality_logger.error(f"[{log_id}] [cleanup_temp_columns] Error during cleanup: {e}")
        raise
def backup_protected_columns(df: pd.DataFrame, columns: list[str], log_id=None) -> pd.DataFrame:
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    for column in columns:
        backup_col = f"{column}_copy"
        if column in df.columns:
            df[backup_col] = df[column]
            pipeline_logger.info(f"[{log_id}] [Backup] Column '{column}' backed up as '{backup_col}'")
        else:
            data_quality_logger.warning(f"[{log_id}] [Backup] Column '{column}' not found for backup.")
    return df

import uuid

# Refactored restore_protected_columns with new signature and logging
def restore_protected_columns(df, required_columns, fallback_data=None, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [restore_protected_columns] Restoring protected columns...")
    # The actual restoration logic would go here, possibly using fallback_data if needed.
    # For now, delegate to the previous implementation if it exists (from utils.restoration), else perform a minimal local restoration.
    try:
        # Try to import the original function if available, but override signature and logging
        from utils.restoration import restore_protected_columns as _orig_restore
        return _orig_restore(df, required_columns, fallback_data=fallback_data, log_id=log_id)
    except ImportError:
        # Minimal fallback: restore columns from fallback_data if missing
        for col in required_columns:
            if col not in df.columns and fallback_data is not None:
                if isinstance(fallback_data, pd.DataFrame) and col in fallback_data.columns:
                    df[col] = fallback_data[col]
                    pipeline_logger.info(f"[{log_id}] [restore_protected_columns] Restored column '{col}' from fallback_data.")
                elif isinstance(fallback_data, pd.Series) and fallback_data.name == col:
                    df[col] = fallback_data
                    pipeline_logger.info(f"[{log_id}] [restore_protected_columns] Restored column '{col}' from fallback_data Series.")
                else:
                    pipeline_logger.warning(f"[{log_id}] [restore_protected_columns] Could not restore column '{col}' from fallback_data.")
        return df

def standardize_columns(df, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    df.columns = [col.strip().lower().replace(" ", "_") for col in df.columns]
    pipeline_logger.info(f"[{log_id}] 🧾 Standardized column names.")
    return df


# 🩺 إعداد بيانات مرضى ارتفاع ضغط الدَم:
# تقوم هذه الدالة بتنظيف البيانات، وتوحيد الأعمدة
def prepare_hypertension_pre_split(hypertension_df, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    cleaner = MedicalDataCleaner()
    original_rows = len(hypertension_df)
    hypertension_df = cleaner.clean_hypertension_data(hypertension_df.copy())
    cleaned_rows = len(hypertension_df)
    dropped_rows = original_rows - cleaned_rows
    drop_ratio = (dropped_rows / original_rows) * 100 if original_rows else 0
    pipeline_logger.info(
        f"[{log_id}] [Cleaning Summary] Dropped {dropped_rows} rows out of {original_rows} ({drop_ratio:.2f}%) during cleaning.")

    hypertension_df = standardize_columns(hypertension_df, log_id=log_id)
    pipeline_logger.debug(f"[{log_id}] [Column Check] Columns after standardization: {list(hypertension_df.columns)}")
    if "age" in hypertension_df.columns:
        hypertension_df["age"] = pd.to_numeric(hypertension_df["age"], errors="coerce")
    # Apply risk score only (without any contextual features)
    from utils.hcars_utils import apply_risk_score

    # يجب التأكد أن apply_risk_score لا يولد إلا risk_score من الأعمدة الخام فقط
    hypertension_df = apply_risk_score(hypertension_df)
    pipeline_logger.info(f"[{log_id}] [prepare_hypertension_pre_split] Applied apply_risk_score.")

    pipeline_logger.info(f"[{log_id}] ✅ [Hypertension] Final DataFrame shape after risk processing: {hypertension_df.shape}")

    return hypertension_df

# 📊 دمج البيانات بشكل منفصل:
# هذه الدالة تُستخدم لتحضير البيانات بشكل مستقل لكل مرض،
# بحيث يتم بناء نموذج مخصص لكل نوع مرض دون خلط الخصائص.
def integrate_for_separate_models(_, hypertension_df, __, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    hypertension_prepared = prepare_hypertension_pre_split(hypertension_df, log_id=log_id)
    return {
        "hypertension": hypertension_prepared
    }

    # --- Unified integration function for all disease datasets (wrapper) ---
def integrate_data_sources(hypertension_df, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    """
    integrate and prepare the hypertension dataset for model training and evaluation.

    Args:
        hypertension_df (pd.DataFrame): The hypertension dataset.
        skip_context_check (bool): If True, skips checking for required contextual columns.

    Returns:
        dict: Dictionary containing the prepared hypertension DataFrame.
    """
    pipeline_logger.info(f"[{log_id}] [integrate_data_sources] Integrating hypertension dataset...")
    # Contextual columns check logic
    return integrate_for_separate_models(hypertension_df, hypertension_df, None, log_id=log_id)

def process_post_split_hypertension(train_df, test_df, y_train_backup=None, y_test_backup=None, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] 🧪 Starting post-split hypertension processing...")
    # Ensure safe copy of train_df and test_df
    train_df = safe_copy_for_preprocessing(train_df)
    test_df = safe_copy_for_preprocessing(test_df)

    # 🔐 Target Backup Phase
    pipeline_logger.info(f"[{log_id}] 🔐 [Target Backup Phase] Backing up and removing 'target' columns for safe processing...")
    train_df, test_df, y_train_backup, y_test_backup = backup_targets(train_df, test_df, y_train_backup, y_test_backup, log_id=log_id)
    if y_train_backup is None:
        data_quality_logger.error(f"[{log_id}] 🔐 [Target Backup Phase] Failed to backup 'target' for train set.")
    if y_test_backup is None:
        data_quality_logger.warning(f"[{log_id}] 🔐 [Target Backup Phase] Failed to backup 'target' for test set.")

    # ✅ Fallback protection: Create 'target_copy' from backup if missing
    if "target_copy" not in train_df.columns and y_train_backup is not None:
        train_df["target_copy"] = y_train_backup
        pipeline_logger.info(f"[{log_id}] [Fallback] Created 'target_copy' in train_df from y_train_backup")
    if "target_copy" not in test_df.columns and y_test_backup is not None:
        test_df["target_copy"] = y_test_backup
        pipeline_logger.info(f"[{log_id}] [Fallback] Created 'target_copy' in test_df from y_test_backup")

    # 🩺 Ensure risk_level is present before backups
    try:
        train_df = RiskScoreTransformer().transform(train_df)
        test_df = RiskScoreTransformer().transform(test_df)
        pipeline_logger.info(f"[{log_id}] [process_post_split_hypertension] risk_level transformation applied before protected backups.")
    except Exception as e:
        data_quality_logger.warning(f"[{log_id}] [process_post_split_hypertension] Skipped risk_level transformation due to: {e}")

    # 🛡️ Ensure protected columns are backed up before encoding
    protected_columns = GLOBAL_CONFIG.get("preprocessing", {}).get("protected_columns", []) if GLOBAL_CONFIG else []
    train_df, test_df = create_protected_backups(train_df, test_df, protected_columns=protected_columns, log_id=log_id)

    # 🧬 Encoding Phase
    pipeline_logger.info(f"[{log_id}] 🧬 [Encoding Phase] Validating required columns for encoding...")
    train_df, test_df = validate_required_encoding_columns(train_df, test_df, log_id=log_id)
    for col in ['sex', 'fbs', 'exang', 'cp', 'restecg', 'slope', 'ca', 'thal']:
        if col not in train_df.columns:
            data_quality_logger.warning(f"[{log_id}] 🧬 [Encoding Phase] '{col}' missing from train set before encoding.")
        if col not in test_df.columns:
            data_quality_logger.warning(f"[{log_id}] 🧬 [Encoding Phase] '{col}' missing from test set before encoding.")

    # 🛠️ Feature Engineering, Imputation, Restoration
    pipeline_logger.info(f"[{log_id}] 🛠️ [Feature Engineering Phase] Running post-split processing pipeline...")
    train_df, test_df = post_split_processing(train_df, test_df, log_id=log_id)
    # Check existence of engineered columns (example: check 'age_group')
    if "age_group" not in train_df.columns:
        data_quality_logger.warning(f"[{log_id}] 🛠️ [Feature Eng.] 'age_group' missing from train set after engineering.")

    # 🧩 Imputation Phase
    pipeline_logger.info(f"[{log_id}] 🧩 [Imputation Phase] Checking for imputed columns...")
    null_impute_cols = [col for col in train_df.columns if train_df[col].isnull().any()]
    if null_impute_cols:
        pipeline_logger.info(f"[{log_id}] 🧩 [Imputation Phase] Columns with missing values after imputation: {null_impute_cols}")

    # ✅ Final Check: Target Restoration and Validation
    pipeline_logger.info(f"[{log_id}] ✅ [Final Check Phase] Validating and restoring 'target' columns...")
    train_df = validate_and_restore_targets(train_df, test_df, y_train_backup, y_test_backup, log_id=log_id)
    if "target" not in train_df.columns:
        data_quality_logger.error(f"[{log_id}] ✅ [Final Check Phase] 'target' column missing from train set after restoration.")
    if "target" not in test_df.columns:
        data_quality_logger.error(f"[{log_id}] ✅ [Final Check Phase] 'target' column missing from test set after restoration.")

    # Risk Score Column Verification
    verify_risk_score_columns(train_df, log_id=log_id)

    # Ensure these columns are never dropped
    preserve_columns = ["target_copy"]

    def cleanup_preserving_critical(df):
        df = df.drop(columns=["age_preserved"], errors="ignore")
        cols_to_drop = [c for c in df.columns if c.endswith('_copy') and c not in preserve_columns]
        df = df.drop(columns=cols_to_drop, errors="ignore")
        return df

    train_df = cleanup_preserving_critical(train_df)
    test_df = cleanup_preserving_critical(test_df)

    pipeline_logger.info(f"[{log_id}] ✅ Completed post-split hypertension processing.")
    return train_df, test_df


# =========================
# Modular Helper Functions for Post-Split Hypertension Processing
# =========================

def backup_targets(train_df, test_df, y_train_backup, y_test_backup, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [backup_targets] Backing up and removing 'target' columns for post-split processing.")
    try:
        y_train = train_df["target"].copy() if "target" in train_df.columns else None
        if y_train_backup is None and y_train is not None:
            y_train_backup = y_train.copy()
        if "target" in train_df.columns:
            train_df = train_df.drop(columns=["target"])
        y_test = test_df["target"].copy() if "target" in test_df.columns else None
        if y_test_backup is None and y_test is not None:
            y_test_backup = y_test.copy()
        if "target" in test_df.columns:
            test_df = test_df.drop(columns=["target"])
        pipeline_logger.info(f"[{log_id}] [backup_targets] Successfully backed up and removed 'target' columns.")
        return train_df, test_df, y_train_backup, y_test_backup
    except Exception as e:
        data_quality_logger.error(f"[{log_id}] [backup_targets] Error during backup/removal: {e}")
        raise

def post_split_processing(train_df, test_df, y_train_backup=None, y_test_backup=None, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [post_split_processing] Starting post-split processing sequence.")
    try:
        # Backup protected columns before encoding
        protected_columns = GLOBAL_CONFIG.get("preprocessing", {}).get("protected_columns", []) if GLOBAL_CONFIG else []
        train_df, test_df = create_protected_backups(train_df, test_df, protected_columns=protected_columns, log_id=log_id)

        # Fallback-protect: Ensure 'target_copy' exists before encoding
        if "target_copy" not in train_df.columns and y_train_backup is not None:
            train_df["target_copy"] = y_train_backup
            data_quality_logger.warning(f"[{log_id}] [Fallback-Protect] Created 'target_copy' in train_df from y_train_backup")
        if "target_copy" not in test_df.columns and y_test_backup is not None:
            test_df["target_copy"] = y_test_backup
            data_quality_logger.warning(f"[{log_id}] [Fallback-Protect] Created 'target_copy' in test_df from y_test_backup")

        # Encode train and test sets
        train_df, test_df = encode_train_test(
            train_df, test_df,
            y_train_backup=y_train_backup,
            y_test_backup=y_test_backup,
            log_id=log_id
        )

        # Restore critical columns (protected, not contextual)
        train_df, test_df = restore_critical_columns(
            train_df, test_df,
            required_final_columns=['sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'ca', 'thal', 'target'],
            y_train_backup=y_train_backup,
            y_test_backup=y_test_backup,
            log_id=log_id
        )

        # Impute missing values for numeric columns
        train_df = impute_missing_values(train_df, strategy="median", use_knn=False, log_id=log_id)
        test_df = impute_missing_values(test_df, strategy="median", use_knn=False, log_id=log_id)

        pipeline_logger.info(f"[{log_id}] [post_split_processing] Completed post-split processing steps.")
        return train_df, test_df
    except Exception as e:
        data_quality_logger.error(f"[{log_id}] [post_split_processing] Error during post-split processing: {e}")
        raise

def validate_and_restore_targets(x_train, x_test, y_train_backup, y_test_backup, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [validate_and_restore_targets] Validating and restoring 'target' columns after processing.")
    try:
        if "target" in x_train.columns:
            class_dist_train = x_train["target"].value_counts(normalize=True).round(4)
            pipeline_logger.info(f"[{log_id}] [Target Distribution] Train set:\n{class_dist_train.to_string()}")
        if "target" in x_test.columns:
            class_dist_test = x_test["target"].value_counts(normalize=True).round(4)
            pipeline_logger.info(f"[{log_id}] [Target Distribution] Test set:\n{class_dist_test.to_string()}")

        # 📌 Safety fallback: restoring 'target' if missing after post-split operations
        if "target" not in x_test.columns and y_test_backup is not None:
            x_test.loc[:, "target"] = y_test_backup
            pipeline_logger.warning(f"[{log_id}] [validate_and_restore_targets] 'target' restored to x_test from y_test_backup.")

        try:
            # Schema validation with error handling
            from utils.validation import validate_noncontextual_schema
            x_train = validate_noncontextual_schema(
                x_train,
                schema_path_or_dict="schemas/cleaned_data.yaml",  # أو post-encoding.yaml حسب التسلسل
                dataset_name="hypertension"
            )
        except Exception as e:
            pipeline_logger.warning(f"[{log_id}] [Integration] Schema validation skipped or failed due to: {str(e)}")

        x_train = final_validations(
            x_train,
            required_final_columns=['sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'ca', 'thal', 'target'],
            log_id=log_id
        )

        # Final validation: Ensure 'target' column is present before returning
        if "target" not in x_train.columns:
            data_quality_logger.error(f"[{log_id}] [Final Check] 'target' column missing in x_train at end of processing.")
            raise ValueError("Missing 'target' column in x_train.")
        if "target" not in x_test.columns:
            data_quality_logger.error(f"[{log_id}] [Final Check] 'target' column missing in x_test at end of processing.")
            raise ValueError("Missing 'target' column in x_test.")
        # Additional safeguard: ensure target integrity at the very end
        if y_train_backup is not None:
            x_train = ensure_target_integrity(x_train, y_train_backup, log_id=log_id)
        else:
            data_quality_logger.error(f"[{log_id}] [Post-Processing (Train)] Skipped target integrity check — y_train_backup is None")
        if y_test_backup is not None:
            x_test = ensure_target_integrity(x_test, y_test_backup, log_id=log_id)
        else:
            data_quality_logger.error(f"[{log_id}] [Post-Processing (Test)] Skipped target integrity check — y_test_backup is None")
        # Final confirmation that 'target' exists and is not all null in both train and test
        if "target" not in x_train.columns or x_train["target"].isnull().all():
            data_quality_logger.critical(f"[{log_id}] [Final Check] 'target' column is missing or null in x_train after full processing.")
        if "target" not in x_test.columns or x_test["target"].isnull().all():
            data_quality_logger.critical(f"[{log_id}] [Final Check] 'target' column is missing or null in x_test after full processing.")
        pipeline_logger.info(f"[{log_id}] [validate_and_restore_targets] Target columns validated and restored.")
        return x_train
    except Exception as error:
        data_quality_logger.error(f"[{log_id}] [validate_and_restore_targets] Failed to restore targets: {error}")
        raise

def cleanup_backup_columns(x_train, x_test, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    pipeline_logger.info(f"[{log_id}] [cleanup_backup_columns] Removing backup and temporary columns after processing.")
    try:
        # Remove 'age_preserved' and all columns ending with '_copy', except those we preserve
        x_train = x_train.drop(columns=["age_preserved"], errors="ignore")
        x_test = x_test.drop(columns=["age_preserved"], errors="ignore")
        # 📌 Safety fallback: preserve 'target_copy' during cleanup of _copy columns
        preserve_columns = ["target_copy"]
        x_train = x_train.drop(columns=[col for col in x_train.columns if col.endswith('_copy') and col not in preserve_columns], errors="ignore")
        x_test = x_test.drop(columns=[col for col in x_test.columns if col.endswith('_copy') and col not in preserve_columns], errors="ignore")
        pipeline_logger.info(f"[{log_id}] [cleanup_backup_columns] All backup and temporary columns removed.")
        return x_train, x_test
    except Exception as error:
        data_quality_logger.error(f"[{log_id}] [Cleanup] Failed to cleanup backup columns: {error}")
        raise


# --- Utility: Ensure target integrity after all processing steps ---
def ensure_target_integrity(df: pd.DataFrame, backup_df: pd.DataFrame, log_id=None) -> pd.DataFrame:
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    if "target" not in df.columns:
        if "target" in backup_df.columns:
            df["target"] = backup_df["target"]
            data_quality_logger.warning(f"[{log_id}] 'target' restored from backup_df.")
        else:
            df["target"] = np.nan
            data_quality_logger.error(f"[{log_id}] 'target' missing and no fallback found. Column created as NaN.")
    return df


# 🧪 Unit Test to verify 'target' survives pipeline processing
def test_target_survives_pipeline():
    import pandas as pds
    # Simulated minimal config and sample data for test
    def load_cleaned_data():
        return pds.DataFrame({
            "age": [45, 60],
            "sex": [1, 0],
            "cp": [2, 3],
            "fbs": [0, 1],
            "restecg": [0, 1],
            "exang": [0, 0],
            "slope": [1, 2],
            "ca": [0, 1],
            "thal": [2, 3],
            "target": [1, 0]
        })

    def get_config():
        return {"target_column": "target"}

    df_cleaned = load_cleaned_data()
    config = get_config()
    target_col = config["target_column"]

    # Backup protected column for target (for consistency with production logic)
    df_cleaned = backup_protected_columns(df_cleaned, [target_col])

    # (Removed call to prepare_hypertension_pre_split and integrate_data_sources as per instructions)

    # The rest of the test is unchanged (simulate encoding drop, restoration, etc.)
    y_backup = df_cleaned[target_col].copy()

    # Simulate encoding drop
    # 'dummy' encode_hypertension_data: identity for test (replace if real function is imported)
    try:
        encode_func = encode_hypertension_data
    except NameError:
        encode_func = lambda df: df
    df_encoded = encode_func(df_cleaned.drop(columns=[target_col]))

    # Attempt restoration (ensure fallback_data is used to simulate pipeline)
    df_restored = restore_protected_columns(df_encoded, [target_col], fallback_data=y_backup.to_frame())

    assert target_col in df_restored.columns, "❌ 'target' column missing after restoration!"
    # Validate restored values match original
    assert df_restored[target_col].equals(y_backup), "❌ Restored values of 'target' do not match original!"
    print(f"[{uuid.uuid4().hex[:8]}] ✅ test_target_survives_pipeline passed — 'target' restored successfully with correct values.")

# --- Global config setup after yaml.safe_load (only once, at the top) ---
def load_global_config_and_verify_schemas(log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    with open("pipeline/config.yaml", "r") as file:
        global GLOBAL_CONFIG
        GLOBAL_CONFIG = yaml.safe_load(file)

        # --- Log and verify all YAML schema references used in the pipeline ---
        pipeline_logger.info(f"[{log_id}] [CONFIG] Loaded preprocessing protected columns: {GLOBAL_CONFIG.get('preprocessing', {}).get('protected_columns', [])}")
        pipeline_logger.info(f"[{log_id}] [CONFIG] Verifying YAML schema names in use...")

        schema_paths = [
            "schemas/clean_hypertension_data.yaml",
            "schemas/hypertension.yaml",
            "schemas/post-cleaning.yaml",
            "schemas/post-encoding.yaml",
            "schemas/cleaned_data.yaml",
            "schemas/post-imputation.yaml",
            "schemas/raw.yaml"
        ]

        for path in schema_paths:
            if not os.path.exists(path):
                pipeline_logger.critical(f"[{log_id}] [SCHEMA CHECK] Missing schema file: {path}")
                raise SystemExit(f"[{log_id}] [SCHEMA CHECK] Missing schema file: {path}")
            else:
                pipeline_logger.info(f"[{log_id}] [SCHEMA CHECK] ✅ Found: {path}")

# Call the config loader at import time
load_global_config_and_verify_schemas()


# --- Risk Score Column Verification Function ---
def verify_risk_score_columns(df: pd.DataFrame, log_id=None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    essential_risk_score_cols = ["age", "trestbps", "chol"]
    optional_risk_score_cols = ["diabetes", "smoker"]
    missing_essential = [col for col in essential_risk_score_cols if col not in df.columns]
    if missing_essential:
        data_quality_logger.error(f"[{log_id}] [Risk Score ❌] Missing essential columns: {missing_essential}")
        raise ValueError(f"Missing critical columns required for risk scoring: {missing_essential}")
    missing_optional = [col for col in optional_risk_score_cols if col not in df.columns]
    if missing_optional:
        pipeline_logger.warning(f"[{log_id}] [Risk Score ⚠️] Optional columns skipped: {missing_optional}")
    pipeline_logger.info(f"[{log_id}] [Risk Score ✅] All required columns validated.")