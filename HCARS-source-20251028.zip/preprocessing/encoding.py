
import pandas as pd
import numpy as np
from utils.logging_utils import get_logger
from utils.column_audit import audit_columns
from sklearn.preprocessing import OneHotEncoder, OrdinalEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from utils.risk_score_transformer import RiskScoreTransformer
from utils.safe_copy import safe_copy_for_preprocessing
from utils.validation import validate_noncontextual_schema

logger = get_logger("encoding_logger")
data_quality_logger = get_logger("data_quality_logger")

def encode_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Alias to encode_categoricals for compatibility with tests and pipeline.
    """
    return encode_categoricals(df)

class MedicalDataCleaner:
    def __init__(self, drop_first: bool = True, scale_numeric: bool = False):
        """
        MedicalDataCleaner constructor.

        Args:
            drop_first (bool): Whether to drop the first category in one-hot encoding to avoid collinearity. default is True.
            scale_numeric (bool): Whether to scale numeric columns (not implemented in current version). default is False.
        """
        self.drop_first = drop_first
        self.scale_numeric = scale_numeric
        self.transformer = None
        self.encoding_maps = {}
        self.fitted_columns = []  # Stores the expected columns after transformation for schema enforcement

    @staticmethod
    def identify_column_types(x: pd.DataFrame):
        """
        Identify and classify columns in the input DataFrame into binary, multi-class categorical, and numeric types.

        Classification logic:
            - Binary columns: Columns with exactly 2 unique values (excluding nulls), considered for binary encoding.
            - Multi-class categorical columns: Columns with more than 2 and up to 20 unique values, suitable for one-hot encoding.
            - Numeric columns: Columns with numeric dtype (int or float), non-null, and present in the DataFrame.
        The method uses both dtype and the count of unique values as heuristics to robustly classify columns for clinical datasets.
        Columns with at least one non-null value are retained to maintain medical data integrity.

        Parameters
        ----------
        x : pd.DataFrame
            Input DataFrame containing raw clinical features.

        Returns
        -------
        Tuple[List[str], List[str], List[str]]
            Lists of binary columns, multi-class categorical columns, and numeric columns respectively.
        """
        categorical_cols = [
            col for col in x.columns
            if x[col].dtypes == 'object' or (x[col].nunique() <= 10 and x[col].dtypes in ['int64', 'float64', 'int32', 'float32'])
        ]
        binary_cols = [col for col in categorical_cols if x[col].nunique() == 2]
        binary_cols = [col for col in binary_cols if x[col].notnull().sum() > 0 and col in x.columns]
        multi_cols = [col for col in categorical_cols if 2 < x[col].nunique() <= 20]
        numeric_cols = x.select_dtypes(include=[np.number]).columns.tolist()
        if 'age' not in numeric_cols and 'age' in x.columns:
            numeric_cols.append('age')
        numeric_cols = [col for col in numeric_cols if col in x.columns and x[col].notnull().sum() > 0]
        # Filter columns with at least one non-null value to maintain medical data integrity
        multi_cols = [col for col in multi_cols if x[col].notnull().sum() > 0]
        # Ensure columns exist in the DataFrame
        multi_cols = [col for col in multi_cols if col in x.columns]
        numeric_cols = [col for col in numeric_cols if col in x.columns]
        logger.info(f"Identified columns -> Binary: {binary_cols}, Multi: {multi_cols}, Numeric: {numeric_cols}")
        logger.info(f"[identify_column_types] Returning binary={binary_cols}, multi={multi_cols}, numeric={numeric_cols}")
        return binary_cols, multi_cols, numeric_cols

    def build_encoding_pipelines(self, binary_cols, multi_cols, numeric_cols):
        """
        Construct sklearn pipelines for binary, multi-class, and numeric features.

        Parameters
        ----------
        binary_cols : List[str]
            Columns with exactly 2 unique values.

        multi_cols : List[str]
            Columns with 3–20 categories.

        numeric_cols : List[str]
            Columns with continuous/numeric data.

        Returns
        -------
        dict
            Dictionary mapping 'binary', 'multi', and 'num' to corresponding pipeline and column list.
        """
        transformers = {}
        self.encoding_maps = {}
        if binary_cols:
            binary_pipeline = Pipeline(steps=[
                ("imputer", SimpleImputer(strategy="most_frequent")),
                ("ordinal", OrdinalEncoder())
            ])
            transformers["binary"] = (binary_pipeline, binary_cols)
        if multi_cols:
            onehot_params = {
                "drop": 'first' if self.drop_first else None,
                "sparse_output": False,
                "handle_unknown": "ignore",
            }
            # Removed verbose_feature_names_out for compatibility
            multi_pipeline = Pipeline(steps=[
                ("imputer", SimpleImputer(strategy="most_frequent")),
                ("onehot", OneHotEncoder(**onehot_params))
            ])
            transformers["multi"] = (multi_pipeline, multi_cols)
        if numeric_cols:
            num_pipeline = Pipeline(steps=[
                ("imputer", SimpleImputer(strategy="median"))
            ])
            transformers["num"] = (num_pipeline, numeric_cols)
        # Logging after pipeline construction
        logger.info(f"[build_encoding_pipelines] Binary pipeline columns: {binary_cols}")
        logger.info(f"[build_encoding_pipelines] Multi-class pipeline columns: {multi_cols}")
        logger.info(f"[build_encoding_pipelines] Numeric pipeline columns: {numeric_cols}")
        return transformers

    def fit(self, x: pd.DataFrame, log_id: str = "global") -> "MedicalDataCleaner":
        """
        Fit the encoding pipelines on the input DataFrame.

        Parameters
        ----------
        x : pd.DataFrame
            Raw clinical dataset to be encoded.
        log_id : str, default="global"
            Unique identifier for logging purposes.

        Returns
        -------
        MedicalDataCleaner
            Fitted instance of the encoder.

        Raises
        ------
        Exception
            If an error occurs during fitting, it is logged and the encoder proceeds with passthrough.
        """
        logger.info(f"[{log_id}] 🚀 Starting fit process for MedicalDataCleaner.")
        try:
            # Ensure functional isolation of input
            # No mutation is performed on X during fit; copying is unnecessary.
            # Identify column types
            binary_cols, multi_cols, numeric_cols = self.identify_column_types(x)
            if not (binary_cols or multi_cols or numeric_cols):
                data_quality_logger.error(f"[{log_id}] [Encoding Status] No valid columns found for encoding during fit. Using passthrough transformer.")
                logger.warning(f"[{log_id}] [Fallback] No valid columns found for encoding. Using passthrough transformer.")
                self.transformer = ColumnTransformer(transformers=[], remainder="passthrough")
                return self
            logger.info(f"[{log_id}] [Encoding Status] Pipeline binary encoding: {binary_cols}")
            logger.info(f"[{log_id}] [Encoding Status] Pipeline one-hot encoding: {multi_cols}")
            logger.info(f"[{log_id}] [Encoding Status] Pipeline numeric columns (scaled={self.scale_numeric}): {numeric_cols}")
            # Build transformers
            transformers = self.build_encoding_pipelines(binary_cols, multi_cols, numeric_cols)
            # Fit pipelines and collect encoding maps
            if "binary" in transformers:
                binary_pipeline, binary_cols = transformers["binary"]
                binary_pipeline.fit(x[binary_cols])
                self.encoding_maps.update({col: binary_pipeline.named_steps["ordinal"].categories_ for col in binary_cols})
            if "multi" in transformers:
                multi_pipeline, multi_cols = transformers["multi"]
                multi_pipeline.fit(x[multi_cols])
                self.encoding_maps.update({col: multi_pipeline.named_steps["onehot"].categories_ for col in multi_cols})
            # Compose ColumnTransformer
            self.transformer = ColumnTransformer(
                transformers=[(name, pipe, cols) for name, (pipe, cols) in transformers.items()],
                remainder="passthrough"
            )
            self.transformer.fit(x)
            logger.info(f"[{log_id}] [fit] Transformer fitted on data with shape: {x.shape}")
            logger.info(f"[{log_id}] [Encoding Status] ✅ Fit process completed successfully.")
            return self
        except Exception as error:
            logger.exception(f"[{log_id}] [Encoding Status] Error during fit process: {error}")
            return self

    def transform(self, x: pd.DataFrame, log_id: str = "global") -> pd.DataFrame:
        """
        Apply the fitted transformers to transform the dataset.

        Parameters
        ----------
        x : pd.DataFrame
            Clinical dataset to be encoded.
        log_id : str, default="global"
            Unique identifier for logging purposes.

        Returns
        -------
        pd.DataFrame
            Transformed dataset.

        Raises
        ------
        RuntimeError
            If the encoder has not been fitted prior to transform.
        """
        logger.info(f"[{log_id}] [Encoding Status] 🚀 Starting transform process for MedicalDataCleaner.")
        try:
            # Ensure functional isolation of input
            # x is assumed to be unmutated during transform; copying skipped.
            if self.transformer is None:
                data_quality_logger.error(f"[{log_id}] [Encoding Status] Attempted to transform before fitting the encoder. Possible pipeline misuse.")
                logger.exception(f"[{log_id}] [Encoding Status] Attempted to transform before fitting the encoder. Possible pipeline misuse.")
                raise RuntimeError("The transformer has not been fitted yet. Call fit() before transform().")
            x_transformed = self.transformer.transform(x)
            df_transformed = pd.DataFrame(x_transformed, index=x.index)
            df_transformed = df_transformed.copy()
            if hasattr(self.transformer, "get_feature_names_out"):
                df_transformed.columns = self.transformer.get_feature_names_out()
            else:
                df_transformed.columns = [f"feature_{i}" for i in range(df_transformed.shape[1])]
            # --- Begin: Ensure all expected fitted columns are present after transform ---
            if not self.fitted_columns:
                self.fitted_columns = list(x.columns)
            for col in self.fitted_columns:
                if col not in df_transformed.columns:
                    df_transformed[col] = 0
                    logger.warning(f"[{log_id}] [Encoding Enforcement] Added missing expected column: {col}")
            # --- End: Ensure all expected fitted columns are present ---
            logger.info(f"[{log_id}] [Encoding Status] ✅ Transform process completed successfully.")
            logger.info(f"[{log_id}] [Encoding Status] Transformed dataframe shape: {df_transformed.shape}")
            logger.info(f"[{log_id}] [Encoding Status] Number of columns after transform: {df_transformed.shape[1]}")
            return df_transformed
        except Exception as error:
            logger.exception(f"[{log_id}] [Encoding Status] Error during transform process: {error}")
            return pd.DataFrame()

    def fit_transform(self, x: pd.DataFrame, log_id: str = "global") -> pd.DataFrame:
        """
        Fit and transform the dataset using encoding pipelines.

        Parameters
        ----------
        x : pd.DataFrame
            Dataset to fit and encode.
        log_id : str, default="global"
            Unique identifier for logging purposes.

        Returns
        -------
        pd.DataFrame
            Encoded dataset with preserved index.
        """
        logger.info(f"[{log_id}] [Encoding Status] 🛠️ Starting fit_transform process for MedicalDataCleaner.")
        try:
            # Ensure functional isolation of input
            x = safe_copy_for_preprocessing(x)
            self.fit(x, log_id=log_id)
            df_transformed = self.transform(x, log_id=log_id)
            logger.info(f"[{log_id}] [Encoding Status] ✅ fit_transform process completed successfully.")
            logger.info(f"[{log_id}] [Encoding Status] Columns after fit_transform: {df_transformed.shape[1]}")
            logger.info(f"[{log_id}] [fit_transform] Final transformed DataFrame shape: {df_transformed.shape}")
            return df_transformed
        except Exception as error:
            logger.exception(f"[{log_id}] [Encoding Status] Error during fit_transform process: {error}")
            return pd.DataFrame()


logger.info("[global] ✅ MedicalDataCleaner initialized and ready.")


def encode_categoricals(df: pd.DataFrame, exclude_columns: list = None, log_id: str = "global") -> pd.DataFrame:
    """
    Encode categorical features while preserving medically critical columns.
    """
    # Setup config and required columns
    from utils.config_loader import get_config
    config = get_config()
    if exclude_columns is None:
        exclude_columns = []
    target_column = config.get("target_column", "target")
    # Remove ambiguous exclude_columns usage
    if target_column in exclude_columns:
        exclude_columns.remove(target_column)
    protected_columns = [col for col in config.get("preprocessing", {}).get("protected_columns", []) if col != target_column]
    if "target" in df.columns and "target" not in protected_columns:
        protected_columns.append("target")
    # Make local copy
    df = safe_copy_for_preprocessing(df)
    # Validate schema after copy, before any transformation
    validate_noncontextual_schema(
        df,
        schema_path_or_dict="schemas/post-cleaning.yaml",
        dataset_name="categorical_encoding"
    )
    # Back up protected columns
    for col in protected_columns:
        backup_col = f"{col}_copy"
        if col in df.columns and backup_col not in df.columns:
            df[backup_col] = df[col]
            logger.info(f"[{log_id}] [Leakage Protection] Column '{col}' backed up as '{backup_col}'")
    # Preserve age/sex/target if not already protected
    if "age" in df.columns and "age" not in protected_columns:
        df["age_preserved"] = df["age"]
    if "sex" in df.columns and "sex" not in protected_columns:
        df["sex_preserved"] = df["sex"]
    if target_column in df.columns and target_column not in protected_columns:
        df[f"{target_column}_preserved"] = df[target_column]
    # Ensure target_copy exists
    if target_column in df.columns and f"{target_column}_copy" not in df.columns:
        df[f"{target_column}_copy"] = df[target_column]
    # Prepare input for encoding
    encode_columns = [col for col in df.columns if col not in exclude_columns and col != target_column]
    df_proc = df.loc[:, encode_columns]
    # Int type fix for sex/categorical features
    if "sex" in df_proc.columns:
        df_proc["sex"] = df_proc["sex"].astype("Int64")
    for col in ["cp", "restecg", "slope", "thal", "ca"]:
        if col in df_proc.columns and pd.api.types.is_float_dtype(df_proc[col]):
            df_proc[col] = df_proc[col].astype("Int64")
    # Ensure critical features present
    critical_features = ["age", "trestbps", "chol", "diabetes", "smoker"]
    for feature in critical_features:
        if feature in df.columns and feature not in df_proc.columns:
            df_proc[feature] = df[feature]
    # Log columns before encoding
    logger.info(f"[{log_id}] 🚨 [Pre-Encoding] Columns before encoding: {df.columns.tolist()}")
    # Fit and encode
    cleaner = MedicalDataCleaner()
    df_encoded = cleaner.fit_transform(df_proc, log_id=log_id)
    # Log columns after encoding
    logger.info(f"[{log_id}] 🚨 [Post-Encoding] Columns after encoding: {df_encoded.columns.tolist()}")
    # Remove _copy_copy/_preserved columns
    df_encoded = df_encoded.loc[:, ~df_encoded.columns.str.contains(r'_copy_copy|_preserved')]
    # Ensure target present
    if "target" not in df_encoded.columns and "target_copy" in df_encoded.columns:
        if isinstance(df_encoded["target_copy"], pd.Series):
            df_encoded["target"] = df_encoded["target_copy"]
    # Drop temp preservation columns
    for col in ['age_preserved', 'sex_preserved', f'{target_column}_preserved']:
        if col in df_encoded.columns:
            df_encoded.drop(columns=[col], inplace=True)
    # Remove orphaned encoded backups
    orphaned_encoded_backups = [
        col for col in df_encoded.columns
        if col.endswith("__target_copy") and "target" in df_encoded.columns
    ]
    if orphaned_encoded_backups:
        df_encoded.drop(columns=orphaned_encoded_backups, inplace=True)
    # Restore exclude_columns
    for col in exclude_columns:
        if col in df.columns:
            df_encoded[col] = df[col].values
    # Drop redundant columns at the end if present
    drop_redundant = ["target_copy_copy", "binary__target_copy_copy", "num__target_copy_copy"]
    df_encoded.drop(columns=[col for col in drop_redundant if col in df_encoded.columns], inplace=True)
    # Log after restoring protected columns
    logger.info(f"[{log_id}] [Restore] Protected columns (target, age, sex) restored if missing.")
    logger.info(f"[{log_id}] ✅ Final columns after encoding: {list(df_encoded.columns)}")
    logger.info(f"[{log_id}] [Stage: Post-Encoding] Number of columns: {df_encoded.shape[1]}")
    logger.info(f"[{log_id}] [encode_categoricals] Returning DataFrame with shape: {df_encoded.shape}")
    return df_encoded


#
# 🚫 هذا الجزء معلق مؤقتًا — مخصص لتوسعة مستقبلية في توصيات نمط الحياة والسكتة.
# غير مستخدم حاليًا ضمن نظام توصية ضغط الدَم المعتمد على hypertension_data.csv فقط.
def encode_diabetes_data(df: pd.DataFrame, log_id: str = "global") -> pd.DataFrame:
    """
    Placeholder for diabetes dataset encoding.
    """
    logger.info(f"[{log_id}] encode_diabetes_data called, but not implemented.")
    return df


def encode_hypertension_data(df: pd.DataFrame, risk_scoring_enabled: bool = True, log_id: str = "global") -> pd.DataFrame:
    """
    Specialized encoder for hypertension datasets.
    """
    from utils.config_loader import get_config
    config = get_config()
    df = safe_copy_for_preprocessing(df)
    df.columns = df.columns.str.lower()
    # Validate schema after copy, before any transformation
    validate_noncontextual_schema(
        df,
        schema_path_or_dict="schemas/post-cleaning.yaml",
        dataset_name="hypertension_encoding",
    )
    exclude_columns = [
        'oldpeak', 'thalach', 'chol', 'trestbps', 'sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'ca', 'thal'
    ]
    if 'risk_level' in exclude_columns:
        exclude_columns.remove('risk_level')
    target_column = config.get("target_column", "target")
    protected_columns = ["age", "sex", "target"]
    # Backup protected columns
    for col in protected_columns:
        if col in df.columns and f"{col}_preserved" not in df.columns:
            df[f"{col}_preserved"] = df[col]
    # Always backup target column to target_column_copy at the start
    if target_column in df.columns and f"{target_column}_copy" not in df.columns:
        logger.info(f"[{log_id}] [Backup] Backing up target column '{target_column}' to '{target_column}_copy'")
        df[f"{target_column}_copy"] = df[target_column]
    if "target_train_copy" in df.columns and "target_test_copy" not in df.columns:
        df["target_test_copy"] = np.nan
    elif "target_test_copy" in df.columns and "target_train_copy" not in df.columns:
        df["target_train_copy"] = np.nan

    # 🚫 لا اشتقاق أو استعادة أو توليد لأي عمود سياقي أو مشتق هنا

    # Encode categoricals (فقط الأعمدة الأصلية/الأساسية)
    df_encoded = encode_categoricals(df, exclude_columns=exclude_columns, log_id=log_id)
    logger.info(f"[{log_id}] [encode_hypertension_data] Encoding complete. Encoded shape: {df_encoded.shape}")

    # Unified restore block for protected columns (excluding context columns)
    columns_to_restore = [
        "age", "sex", "trestbps", "chol", "thalach",
        "chol_flag", "risk_score",  # هذه أعمدة مسموحة فقط إذا كانت raw وليست مشتقة من سياق!
        "target_copy"
    ]
    for col in columns_to_restore:
        if col in df.columns and col not in df_encoded.columns:
            df_encoded[col] = df[col]
            logger.warning(f"[{log_id}] [Restore] Restored missing column: {col}")
    # Ensure backups after encoding
    if target_column in df_encoded.columns and f"{target_column}_copy" not in df_encoded.columns:
        df_encoded[f"{target_column}_copy"] = df_encoded[target_column]
    if "target_train_copy" in df_encoded.columns and "target_test_copy" not in df_encoded.columns:
        df_encoded["target_test_copy"] = np.nan
    elif "target_test_copy" in df_encoded.columns and "target_train_copy" not in df_encoded.columns:
        df_encoded["target_train_copy"] = np.nan

    # Risk scoring (اختياري فقط إذا متاح كـ transformer مستقل للأعمدة الأصلية وليس مشتق من أعمدة سياقية)
    try:
        if risk_scoring_enabled and "age" in df_encoded.columns:
            df_encoded = RiskScoreTransformer().transform(df_encoded)
    except Exception as e:
        logger.warning(f"[{log_id}] [Fallback] Risk scoring skipped due to: {e}")
    # Verification step: ensure risk_score column was added
    if "risk_score" not in df_encoded.columns:
        logger.warning(f"[{log_id}] [Validation] risk_score column was not added by RiskScoreTransformer.")

    # Restore preserved critical columns if missing after encoding
    for col in protected_columns:
        if f"{col}_preserved" in df.columns and col not in df_encoded.columns:
            df_encoded[col] = df[f"{col}_preserved"]
    # Clean up preservation columns
    for col in protected_columns:
        preserved_col = f"{col}_preserved"
        if preserved_col in df_encoded.columns:
            df_encoded.drop(columns=[preserved_col], inplace=True)

    # Ensure all final columns are logged after all modifications
    logger.info(f"[{log_id}] ✅ Final columns after encoding: {list(df_encoded.columns)}")
    # [Columns Trace] Add warning log before returning
    logger.warning(f"[{log_id}] [Columns Trace] Columns at this stage: {df_encoded.columns.tolist()}")
    audit_columns(df_encoded, "Encoding")
    return df_encoded

def build_encoder():
    """
    Factory function to build a new instance of MedicalDataCleaner.

    Returns
    -------
    MedicalDataCleaner or None
        Instance if successful, else None with error logged.
    """
    try:
        return MedicalDataCleaner()
    except (TypeError, ValueError) as e:
        logger.exception(f"[Encoding Status] Failed to build MedicalDataCleaner instance: {e}")
        return None


def self_test_encoding(log_id: str = "global"):
    """
    Run internal self-tests on encoding logic using synthetic data.

    Returns
    -------
    None
    """
    df = pd.DataFrame({
        "gender": ["male", "female", "male"],
        "cp": [1, 2, 3],
        "age": [45, 54, 60],
        "target": [1, 0, 1]
    })
    try:
        # Test encode_categoricals
        result = encode_categoricals(df, log_id=log_id)
        assert "target" in result.columns
        logger.info(f"[{log_id}] [Encoding Status] ✅ [SelfTest] encode_categoricals passed.")
        # Test MedicalDataCleaner fit, transform, restore
        cleaner = MedicalDataCleaner()
        cleaner.fit(df, log_id=log_id)
        logger.info(f"[{log_id}] [Encoding Status] ✅ [SelfTest] fit passed.")
        transformed = cleaner.transform(df, log_id=log_id)
        assert not transformed.empty
        logger.info(f"[{log_id}] [Encoding Status] ✅ [SelfTest] transform passed.")
        # Test restore logic (simulate restoring target column)
        if "target" not in transformed.columns and "target_copy" in transformed.columns:
            transformed["target"] = transformed["target_copy"]
        assert "target" in transformed.columns or "target" in result.columns
        logger.info(f"[{log_id}] [Encoding Status] ✅ [SelfTest] restore passed.")
    except Exception as error:
        logger.exception(f"[{log_id}] [Encoding Status] ❌ [SelfTest] encode_categoricals or MedicalDataCleaner failed: {error}")


__all__ = [
    "MedicalDataCleaner",
    "encode_categoricals",
    "encode_features",
    "encode_hypertension_data",
    "build_encoder",
    "self_test_encoding",
    "encode_diabetes_data"
]
