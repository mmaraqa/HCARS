from utils.config_loader import load_config
from utils.constants import (
    assign_feature_id_by_binned,
    get_medical_plan,
    plan_as_dict,
    MEDICAL_RECOMMENDATION_PLAN,
    CONTEXT_TO_RECOMMENDATION_MAP,
    FEATURE_ID_BINNED_MAP,
    CONTEXT_COLUMNS,
    normalize_label,
    BINNED_CONTEXT_COLUMNS,
    make_binned_key,
)



import pandas as pd

# --- Helper: coerce top_k to a safe integer (handles None / strings / templated values) ---
from utils.config_loader import load_global_config
from utils.constants import get_top_n_eval

# ---- Add cap_topk_per_patient import ----
from pipeline.helpers import cap_topk_per_patient

def _fallback_topk() -> int:
    try:
        cfg = load_global_config() or {}
        return int(get_top_n_eval(cfg))
    except (TypeError, ValueError, KeyError):
        return 5


def _coerce_top_k(top_k):
    """Return a safe integer for top_k. Accepts None/str/int/float; falls back to config or 5.
    Avoids broad exception clauses by handling only expected conversion/lookup errors.
    """
    if top_k is None:
        return _fallback_topk()

    if isinstance(top_k, str):
        # Try direct int cast first
        try:
            return int(top_k)
        except ValueError:
            # Extract first integer inside string (e.g., "${recommendation.top_n_eval}")
            import re
            nums = re.findall(r"\d+", top_k)
            if nums:
                return int(nums[0])
            return _fallback_topk()

    # Numeric-like (float/np types) or other
    try:
        return int(top_k)
    except (TypeError, ValueError):
        return _fallback_topk()

# --- Diagnostics helper: save list of patients handled via cold-start ---
def save_cold_start_patients(pids: list[int] | list[str], out_path: str) -> None:
    import json, os
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(sorted(list(map(str, pids))), f, ensure_ascii=False, indent=2)

def extract_plan_details(rec, contextual_columns=None, context_vals=None):
    """
    يحول أي توصية إلى dict جاهز فيه action, advice, explanation, source.
    تسلسل الاحتراف (باستخدام مفاتيح قياسية):
      1) MEDICAL_RECOMMENDATION_PLAN  ← tuple5: (bp_category, chol_category, risk_level, fbs_cat, cp_cat)
      2) CONTEXT_TO_RECOMMENDATION_MAP ← key string من 6 أعمدة أساسية (CONTEXT_COLUMNS)
      3) FEATURE_ID_BINNED_MAP         ← triad: (bp_bin4, chol_bins, age_q3) عبر make_binned_key
      4) plan_as_dict(rec)              ← fallback يدوي آمن

    Parameters
    ----------
    rec : str | dict
        معرّف التوصية أو خطة جاهزة.
    contextual_columns : list[str] | None
        أسماء الأعمدة السياقية المقابلة لقيم `context_vals`.
    context_vals : tuple | list | None
        قيم السياق المرتبة بالتطابق مع contextual_columns.
    """
    selected_plan = None

    # اشتقاق قواميس للسياق إن أمكن
    ctx_dict = None
    if contextual_columns and context_vals is not None:
        if isinstance(context_vals, (list, tuple)) and len(contextual_columns) == len(context_vals):
            ctx_dict = {c: v for c, v in zip(contextual_columns, context_vals)}

    # 1) MEDICAL_RECOMMENDATION_PLAN عبر tuple5 إذا توفرت الأعمدة الخمسة
    if ctx_dict is not None:
        needed5 = ["bp_category", "chol_category", "risk_level", "fbs_cat", "cp_cat"]
        if all(k in ctx_dict for k in needed5):
            tuple5 = tuple((ctx_dict.get(k, "any") if pd.notnull(ctx_dict.get(k, None)) else "any") for k in needed5)
            selected_plan = MEDICAL_RECOMMENDATION_PLAN.get(tuple5)

    # 2) CONTEXT_TO_RECOMMENDATION_MAP عبر مفتاح 6 أعمدة (CONTEXT_COLUMNS)
    if selected_plan is None and ctx_dict is not None and all(k in ctx_dict for k in CONTEXT_COLUMNS):
        full_key = "__".join(normalize_label(ctx_dict.get(c, "any")) for c in CONTEXT_COLUMNS)
        selected_plan = CONTEXT_TO_RECOMMENDATION_MAP.get(full_key)

    # 3) FEATURE_ID_BINNED_MAP عبر ثلاثي binning (bp_bin4, chol_bins, age_q3)
    if selected_plan is None and ctx_dict is not None and all(k in ctx_dict for k in BINNED_CONTEXT_COLUMNS):
        tri_key = make_binned_key(
            str(ctx_dict.get("bp_bin4", "")).strip(),
            str(ctx_dict.get("chol_bins", "")).strip(),
            str(ctx_dict.get("age_q3", "")).strip(),
        )
        selected_plan = FEATURE_ID_BINNED_MAP.get(tri_key)

    # 4) Fallback: تحويل rec مباشرة إلى خطة
    if selected_plan is None:
        selected_plan = plan_as_dict(rec)
    else:
        selected_plan = plan_as_dict(selected_plan)

    return pd.Series({
        "feature_id": selected_plan.get("action", "manual_review"),
        "reason": selected_plan.get("advice") or selected_plan.get("explanation"),
        "explanation": selected_plan.get("explanation"),
        "source": selected_plan.get("source"),
        "status": "cold_start_safe_default",
    })
import os

# --- إعدادات التوصية الافتراضية من config ---
config = load_config()
fallbacks = config['recommendation'].get('safe_fallback_recommendations', ['lifestyle_monitoring'])
fallback_score_cf = config['recommendation'].get('fallback_score_cf', 0.05)
score_threshold_enabled = config['recommendation'].get('score_threshold_enabled', False)
score_threshold = config['recommendation'].get('score_threshold', 0.1)

# --- إعداد الأعمدة النهائية للإخراج من config أو الافتراضي ---
output_columns = config['recommendation'].get('cold_start_output_columns', [
    "patient_id", "feature_id", "feature_id_binned", "context_feature_id", "score_cf", "reason"
])

def merge_contextual_columns(cold_start_df, logger=None):
    context_cols = ["patient_id", "feature_id", "feature_id_binned", "context_feature_id"]
    try:
        contextual_unique = pd.read_csv("outputs/tmp/df_contextualized.csv", usecols=context_cols)
        contextual_unique = contextual_unique.drop_duplicates(subset=["patient_id", "feature_id"])
        cold_start_df = pd.merge(
            cold_start_df,
            contextual_unique,
            on=["patient_id", "feature_id"],
            how="left"
        )
    except (FileNotFoundError, pd.errors.EmptyDataError, OSError, KeyError) as e:
        if logger is not None:
            logger.warning(f"[cold_start_handler] ⚠️ Could not merge contextual columns from df_contextualized.csv: {e}")
        # في حال فشل الدمج لأي سبب، ضع الأعمدة بقيمة manual_review
        for col in context_cols[2:]:
            cold_start_df[col] = "manual_review"

    # --- تعديل القيم اليدوية أو المفقودة إلى توصية آمنة افتراضية ---
    # إذا بقيت قيم manual_review أو قيم فارغة في الأعمدة السياقية، غيرها إلى safe default
    # توثيق: هذا الجزء يضمن عدم وجود manual_review أو قيم فارغة في الأعمدة السياقية، ويحولها إلى توصية آمنة افتراضية
    mask_manual_or_missing = (
        cold_start_df["feature_id_binned"].isnull() |
        (cold_start_df["feature_id_binned"] == "manual_review") |
        cold_start_df["context_feature_id"].isnull() |
        (cold_start_df["context_feature_id"] == "manual_review")
    )
    if mask_manual_or_missing.any():
        if logger is not None:
            logger.warning(
                f"[cold_start_handler] ⚠️ Overriding {mask_manual_or_missing.sum()} rows with missing/manual_review contextual columns to smart fallback medical plan."
            )
        # تطبيق توصية طبية ذكية لكل صف مع تفاصيل إضافية
        def _apply_medical_plan_fallback(row):
            # توثيق: تسلسل الاحتراف لجلب التوصية (MEDICAL_RECOMMENDATION_PLAN > CONTEXT_TO_RECOMMENDATION_MAP > FEATURE_ID_BINNED_MAP > manual_review)
            # استخدام أسماء محلية مميزة لتجنب ظلال الأسماء مع النطاق الخارجي
            local_values = []
            for col_name in CONTEXT_COLUMNS:
                val = row.get(col_name, None)
                local_values.append(val if pd.notnull(val) else "any")
            ctx_tuple_local = tuple(local_values)

            selected_plan_local = MEDICAL_RECOMMENDATION_PLAN.get(ctx_tuple_local)
            if selected_plan_local is None:
                # fallback: CONTEXT_TO_RECOMMENDATION_MAP (أول 3 أعمدة)
                ctx3_local = tuple(ctx_tuple_local[:3])
                selected_plan_local = CONTEXT_TO_RECOMMENDATION_MAP.get(ctx3_local)
                if selected_plan_local is None:
                    # fallback: FEATURE_ID_BINNED_MAP (أول 3 أعمدة)
                    selected_plan_local = FEATURE_ID_BINNED_MAP.get(ctx3_local)
            if selected_plan_local is None:
                # Try binned triad (bp_bin4, chol_bins, age_q3) if available in row
                try:
                    tri_key_local = make_binned_key(
                        str(row.get("bp_bin4", "")).strip(),
                        str(row.get("chol_bins", "")).strip(),
                        str(row.get("age_q3", "")).strip(),
                    )
                    selected_plan_local = FEATURE_ID_BINNED_MAP.get(tri_key_local)
                except (KeyError, ValueError, TypeError) as err:
                    if logger is not None:
                        logger.debug(f"[cold_start_handler] make_binned_key triad failed: {err}")
                    selected_plan_local = None

            if selected_plan_local is None:
                # fallback: get_medical_plan أو manual_review
                selected_plan_local = plan_as_dict(get_medical_plan(*ctx_tuple_local))
            else:
                selected_plan_local = plan_as_dict(selected_plan_local)

            return pd.Series({
                "feature_id": selected_plan_local.get("action", "manual_review"),
                "feature_id_binned": "default",
                "context_feature_id": "default",
                "reason": selected_plan_local.get("advice") or selected_plan_local.get("explanation"),
                "explanation": selected_plan_local.get("explanation"),
                "source": selected_plan_local.get("source"),
                "status": "cold_start_safe_default"  # عمود مصدر التوصية
            })

        # تأكد من الأعمدة المطلوبة
        needed_cols = ["feature_id", "feature_id_binned", "context_feature_id", "reason", "explanation", "source", "status"]
        for col in needed_cols:
            if col not in cold_start_df.columns:
                if col == "status":
                    cold_start_df[col] = "cold_start_safe_default"  # عمود مصدر التوصية
                else:
                    cold_start_df[col] = None
        cold_start_df.loc[mask_manual_or_missing, needed_cols] = \
            cold_start_df.loc[mask_manual_or_missing].apply(_apply_medical_plan_fallback, axis=1)
        # إذا لم يوجد score_cf أو كان NaN، عيّن القيمة الافتراضية 0.05
        if "score_cf" in cold_start_df.columns:
            score_mask = mask_manual_or_missing & (cold_start_df["score_cf"].isnull())
            cold_start_df.loc[score_mask, "score_cf"] = 0.05
        else:
            cold_start_df["score_cf"] = 0.05

    # إزالة أي صفوف manual_review أو صفوف بها أعمدة سياقية مفقودة/غير صالحة بعد تطبيق fallback
    # Remove any manual_review rows and rows with missing/invalid contextual columns after fallback application
    manual_mask_final = (
        (cold_start_df["feature_id_binned"].isnull()) |
        (cold_start_df["feature_id_binned"] == "manual_review") |
        (cold_start_df["context_feature_id"].isnull()) |
        (cold_start_df["context_feature_id"] == "manual_review") |
        (cold_start_df["feature_id"] == "manual_review")
    )
    cold_start_df = cold_start_df[~manual_mask_final].copy()

    # ترتيب الأعمدة النهائية (أضف الأعمدة الجديدة فقط إن لم تكن موجودة)
    final_cols = ["patient_id", "feature_id", "feature_id_binned", "context_feature_id"]
    for col in ["score_cf", "score", "reason", "explanation", "source", "status"]:
        if col in cold_start_df.columns and col not in final_cols:
            final_cols.append(col)
    if "status" not in final_cols and "status" in cold_start_df.columns:
        final_cols.append("status")
    cold_start_df = cold_start_df[final_cols]

    # تطبيق score_threshold إذا كان مفعّلًا
    if score_threshold_enabled and 'score_cf' in cold_start_df.columns:
        below_thresh_mask = cold_start_df['score_cf'] < score_threshold
        if below_thresh_mask.any():
            if logger:
                logger.warning(f"[cold_start_handler] ⚠️ Removing {below_thresh_mask.sum()} rows below score_threshold={score_threshold}. Adding fallback for affected patients.")
            removed_patients = set(cold_start_df.loc[below_thresh_mask, 'patient_id'].unique())
            cold_start_df = cold_start_df[~below_thresh_mask]
            # أضف fallback لكل مريض تم حذفه بسبب threshold
            fallback_rows = []
            for pid in removed_patients:
                for fb in fallbacks:
                    fallback_rows.append({
                        "patient_id": pid,
                        "feature_id": fb,
                        "feature_id_binned": "default",
                        "context_feature_id": "default",
                        "score_cf": fallback_score_cf,
                        "reason": "score_below_threshold"
                    })
            if fallback_rows:
                cold_start_df = pd.concat([cold_start_df, pd.DataFrame(fallback_rows)], ignore_index=True)

    # تحقق نهائي: يجب ألا يبقى أي manual_review أو قيم فارغة في الأعمدة السياقية (توثيق أكاديمي)
    manual_mask = (
        cold_start_df["feature_id_binned"].isnull() |
        (cold_start_df["feature_id_binned"] == "manual_review") |
        cold_start_df["context_feature_id"].isnull() |
        (cold_start_df["context_feature_id"] == "manual_review")
    )
    if manual_mask.any() and logger is not None:
        logger.warning(
            f"[cold_start_handler] ❗ After safe default override, still found {manual_mask.sum()} cases with missing/manual_review feature_id_binned/context_feature_id. "
            f"Sample: {cold_start_df[manual_mask][['patient_id','feature_id','feature_id_binned','context_feature_id']].head(10).to_dict(orient='records')}"
        )

    # إزالة التكرارات بناءً على الأعمدة المحددة قبل الإرجاع
    cold_start_df = cold_start_df.drop_duplicates(subset=["patient_id", "feature_id", "score_cf", "feature_id_binned", "context_feature_id"])
    # إزالة التكرارات بناءً على patient_id وfeature_id (الإبقاء على الصف الأخير فقط)
    cold_start_df = cold_start_df.drop_duplicates(subset=["patient_id", "feature_id"], keep="last")

    # --- إضافة المرضى المفقودين لتوصية افتراضية آمنة ---
    try:
        contextualized_path = "outputs/tmp/df_contextualized.csv"
        all_patients = pd.read_csv(contextualized_path, usecols=["patient_id"])["patient_id"].unique()
        existing_patients = cold_start_df["patient_id"].unique()
        missing_patients = set(all_patients) - set(existing_patients)
        if missing_patients:
            if logger is not None:
                logger.warning(f"[cold_start_handler] ⚠️ Adding {len(missing_patients)} patients with forced safe default due to no recommendations. Sample: {list(missing_patients)[:5]}")
            forced_rows = []
            try:
                contextual_unique = pd.read_csv(contextualized_path)
            except (FileNotFoundError, pd.errors.EmptyDataError, OSError):
                contextual_unique = None
            for pid in missing_patients:
                # إذا توفر df_contextualized.csv، استخرج الأعمدة السياقية لذلك المريض
                context_row = None
                if isinstance(contextual_unique, pd.DataFrame) and "patient_id" in contextual_unique.columns:
                    matched = contextual_unique.loc[contextual_unique["patient_id"] == pid]
                    if not matched.empty:
                        context_row = matched.iloc[0]
                # توثيق: تسلسل الاحتراف لجلب التوصية (MEDICAL_RECOMMENDATION_PLAN > CONTEXT_TO_RECOMMENDATION_MAP > FEATURE_ID_BINNED_MAP > manual_review)
                if context_row is not None:
                    ctx_tuple = tuple(context_row.get(col_name, "any") if pd.notnull(context_row.get(col_name, None)) else "any" for col_name in CONTEXT_COLUMNS)
                else:
                    ctx_tuple = tuple("any" for _ in CONTEXT_COLUMNS)
                selected_plan = MEDICAL_RECOMMENDATION_PLAN.get(ctx_tuple)
                if selected_plan is None:
                    ctx3 = tuple(ctx_tuple[:3])
                    selected_plan = CONTEXT_TO_RECOMMENDATION_MAP.get(ctx3)
                if selected_plan is None:
                    ctx3 = tuple(ctx_tuple[:3])
                    selected_plan = FEATURE_ID_BINNED_MAP.get(ctx3)
                if selected_plan is None:
                    selected_plan = plan_as_dict(get_medical_plan(*ctx_tuple))
                else:
                    selected_plan = plan_as_dict(selected_plan)
                forced_rows.append({
                    "patient_id": pid,
                    "feature_id": selected_plan.get("action", "manual_review"),
                    "feature_id_binned": "default",
                    "context_feature_id": "default",
                    "score_cf": fallback_score_cf,
                    "reason": selected_plan.get("advice") or selected_plan.get("explanation"),
                    "explanation": selected_plan.get("explanation"),
                    "source": selected_plan.get("source")
                })

            if forced_rows:
                cold_start_df = pd.concat([cold_start_df, pd.DataFrame(forced_rows)], ignore_index=True)
    except (FileNotFoundError, pd.errors.EmptyDataError, OSError) as e:
        if logger is not None:
            logger.warning(f"[cold_start_handler] ❌ Error adding forced safe default rows: {e}")

    # ترتيب الأعمدة النهائية حسب output_columns (مع تجاهل الأعمدة غير الموجودة)
    # إضافة explanation وsource إذا لم تكن موجودة
    if "status" not in cold_start_df.columns:
        cold_start_df["status"] = "cold_start_safe_default"
    for col in ["explanation", "source"]:
        if col not in cold_start_df.columns:
            cold_start_df[col] = None
    final_cols = [col for col in output_columns if col in cold_start_df.columns]
    for col in ["explanation", "source", "status"]:
        if col not in final_cols:
            final_cols.append(col)
    cold_start_df = cold_start_df[final_cols]
    # إذا كان الداتا فريم فارغًا، تأكد أن الأعمدة تحتوي عمود status بالقيمة الافتراضية
    if cold_start_df.empty:
        for col in ["status"]:
            if col not in cold_start_df.columns:
                cold_start_df[col] = []
        # إعادة تعيين الأعمدة إذا كانت فارغة
        for col in final_cols:
            if col not in cold_start_df.columns:
                cold_start_df[col] = []
        cold_start_df = cold_start_df[final_cols]
    return cold_start_df

def contextual_cold_start(df, contextual_columns, top_k, output_cols, logger=None, log_id=None, patient_ids=None, weights=None) -> pd.DataFrame:
    """
    Generate contextual cold-start recommendations.

    ملاحظة: يتم الآن توليد feature_id حصراً عبر القاموس المركزي assign_feature_id_by_binned بما يحقق التوافق التام مع جميع الأعمدة السياقية الجديدة.

    Note:
    The score column name is standardized as 'score_cf' to ensure consistency with the configuration
    and integration with other system components.

    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe containing patient and feature data.
    contextual_columns : list  str
        List  columns to use for contextual grouping.
    top_k : int
        Number of top features to select per context.
    output_cols : list str
        List columns to include in the output dataframe.
    logger : logging.Logger or None, optional
        Logger instance for logging messages.
    log_id : str or None, optional
        Identifier for the log context.
    patient_ids : list or None, optional
        List of patient IDs to filter the recommendations for. If None, use all patients.
    weights : dict or None, optional
        Mapping of contextual keys to multiplicative weights for feature frequency aggregation.
        Expected keys are strings of the form "<column>=<value>" (e.g., "risk_level=high").
        If provided, group feature frequencies are computed as weighted sums; otherwise uniform counts are used.

    Returns
    -------
    pd.DataFrame
        DataFrame containing recommendations with columns specified in output_columns.
    """
    top_k = _coerce_top_k(top_k)
    if logger:
        logger.info(f"[{log_id}] [contextual_cold_start] Using top_k={top_k} (int)")
    # تحديث عمود feature_id من القاموس المركزي الجديد قبل أي معالجة
    df = assign_feature_id_by_binned(df, log=logger, log_id=log_id)
    if logger:
        logger.info(f"[{log_id}] feature_id unique: {df['feature_id'].nunique()} | feature_id_binned unique: {df['feature_id_binned'].nunique()}")
        logger.info(f"[{log_id}] feature_id sample: {df['feature_id'].unique()[:5]}")
        logger.info(f"[{log_id}] feature_id_binned sample: {df['feature_id_binned'].unique()[:5]}")
        logger.info(f"[{log_id}] context_feature_id sample: {df['context_feature_id'].unique()[:5]}")
    if patient_ids is None or (isinstance(patient_ids, list) and len(patient_ids) == 0):
        warning_msg = f"[{log_id}] No patient_ids provided or empty list; returning empty DataFrame."
        if logger:
            logger.warning(warning_msg)
            logger.info(f"[{log_id}] Returning empty DataFrame with columns: {output_cols}")
        else:
            print(warning_msg)
            print(f"[{log_id}] Returning empty DataFrame with columns: {output_cols}")
        # عمود مصدر التوصية
        df_empty = pd.DataFrame(columns=output_cols + ["status"])
        if "status" not in df_empty.columns:
            df_empty["status"] = []
        # تأكد أن الأعمدة النهائية تحتوي "status"
        final_cols = [col for col in output_cols if col in df_empty.columns]
        if "status" not in final_cols:
            final_cols.append("status")
        df_empty = df_empty[final_cols]
        return df_empty

    # Check for duplicated patient_ids and log if any
    if isinstance(patient_ids, list):
        from collections import Counter
        patient_id_counts = Counter(patient_ids)
        duplicated = {pid: count for pid, count in patient_id_counts.items() if count > 1}
        if duplicated:
            dup_msg = f"[{log_id}] Duplicate patient_ids detected with counts: {duplicated}"
            if logger:
                logger.warning(dup_msg)
            else:
                print(dup_msg)

    print(f"[{log_id}] Received patient_ids: {len(patient_ids)}")
    if logger:
        logger.info(f"[{log_id}] Received patient_ids: {len(patient_ids)}")
        logger.info(f"[{log_id}] First 5 patient_ids received: {patient_ids[:5]}")
    else:
        print(f"[{log_id}] First 5 patient_ids received: {patient_ids[:5]}")

    # تحقق من وجود الأعمدة السياقية في الداتا فريم
    missing_context_cols = [col for col in contextual_columns if col not in df.columns]
    if missing_context_cols:
        if logger:
            logger.warning(f"[{log_id}] Missing contextual columns: {missing_context_cols}. Falling back to global top features.")
        else:
            print(f"[{log_id}] Missing contextual columns: {missing_context_cols}. Falling back to global top features.")
        print(f"[{log_id}] Returning empty DataFrame with columns: {output_cols}")
        if logger:
            logger.info(f"[{log_id}] Returning empty DataFrame with columns: {output_cols}")
        # عمود مصدر التوصية
        df_empty = pd.DataFrame(columns=output_cols + ["status"])
        if "status" not in df_empty.columns:
            df_empty["status"] = []
        final_cols = [col for col in output_cols if col in df_empty.columns]
        if "status" not in final_cols:
            final_cols.append("status")
        df_empty = df_empty[final_cols]
        return df_empty

    # حذف الصفوف التي تحتوي على قيم مفقودة في الأعمدة السياقية أو الأعمدة الأساسية
    df_clean = df.dropna(subset=contextual_columns + ["patient_id", "feature_id"])

    # إذا تم تمرير patient_ids، قم بتصفية الداتا لتشمل فقط هؤلاء المرضى
    if patient_ids is not None:
        df_clean = df_clean[df_clean["patient_id"].isin(patient_ids)]

    unique_patients_after_filter = df_clean["patient_id"].nunique()
    if unique_patients_after_filter == 0:
        warning_msg = f"[{log_id}] After filtering with patient_ids, no matching patient_id found in data; returning empty DataFrame."
        if logger:
            logger.warning(warning_msg)
            logger.warning(f"[{log_id}] The input patient_ids list contains IDs not present in the data after filtering.")
            logger.info(f"[{log_id}] Returning empty DataFrame with columns: {output_columns}")
        else:
            print(warning_msg)
            print(f"[{log_id}] The input patient_ids list contains IDs not present in the data after filtering.")
            print(f"[{log_id}] Returning empty DataFrame with columns: {output_columns}")
        # عمود مصدر التوصية
        df_empty = pd.DataFrame(columns=output_columns + ["status"])
        if "status" not in df_empty.columns:
            df_empty["status"] = []
        final_cols = [col for col in output_columns if col in df_empty.columns]
        if "status" not in final_cols:
            final_cols.append("status")
        df_empty = df_empty[final_cols]
        return df_empty
    else:
        info_msg = f"[{log_id}] Number of unique patients after filtering in contextual_cold_start: {unique_patients_after_filter}"
        print(info_msg)
        if logger:
            logger.info(info_msg)
            logger.info(f"[{log_id}] Patient_ids list processed successfully with {unique_patients_after_filter} patients.")

    # تجميع حسب الأعمدة السياقية
    grouped = df_clean.groupby(contextual_columns)

    group_count = len(grouped)
    if logger:
        logger.info(f"[{log_id}] Number of contextual groups: {group_count}")
    else:
        print(f"[{log_id}] Number of contextual groups: {group_count}")

    rows = []
    for context_vals, group_df in grouped:
        # Weighted feature frequencies (optional): if `weights` is provided, use it; otherwise uniform weights
        if weights and isinstance(weights, dict):
            # Build a weight per row based on provided mapping of contextual columns -> weight factors
            def _ctx_weight(r):
                w = 1.0
                for col in contextual_columns:
                    key = f"{col}={r.get(col, None)}"
                    if key in weights:
                        w *= float(weights[key])
                return w
            w_series = group_df.apply(_ctx_weight, axis=1)
            tmp = group_df.assign(__w=w_series)
            weighted = tmp.groupby("feature_id")["__w"].sum()
            total_w = float(weighted.sum()) if float(weighted.sum()) > 0 else 1.0
            feature_scores = (weighted / total_w).to_dict()
        else:
            feature_scores = group_df["feature_id"].value_counts(normalize=True).to_dict()
        top_features = sorted(feature_scores.items(), key=lambda x: -x[1])[:top_k]

        # بناء نص السبب مع قيم السياق
        if isinstance(context_vals, tuple):
            context_str = "|".join(f"{col}={val}" for col, val in zip(contextual_columns, context_vals))
        else:
            # في حالة وجود عمود سياقي واحد فقط
            context_str = f"{contextual_columns[0]}={context_vals}"
        reason_prefix = f"contextual_cold_start|{context_str}"

        # لكل مريض في هذه المجموعة، نضيف التوصيات
        unique_patients = group_df["patient_id"].unique()
        for pid in unique_patients:
            for fid, score_cf in top_features:
                # توثيق: تسلسل الاحتراف لجلب تفاصيل التوصية (MEDICAL_RECOMMENDATION_PLAN > CONTEXT_TO_RECOMMENDATION_MAP > FEATURE_ID_BINNED_MAP > manual_review)
                plan_details = extract_plan_details(fid, contextual_columns=contextual_columns, context_vals=context_vals)
                row = {
                    "patient_id": pid,
                    "feature_id": plan_details["feature_id"],
                    "score_cf": score_cf,
                    "reason": f"{reason_prefix}",
                    "explanation": plan_details["explanation"],
                    "source": plan_details["source"],
                    "status": plan_details["status"]  # عمود مصدر التوصية
                }
                rows.append(row)

    df_out = pd.DataFrame(rows)
    # إذا كان الداتا فريم فارغًا، تأكد من وجود عمود status بالقيمة الافتراضية
    if df_out.empty:
        df_out = pd.DataFrame(columns=output_cols + ["status"])
        if "status" not in df_out.columns:
            df_out["status"] = []
    # إزالة التكرارات بناءً على patient_id وfeature_id (الإبقاء على الصف الأخير فقط)
    df_out = df_out.drop_duplicates(subset=["patient_id", "feature_id"], keep="last")

    unique_patients_count = df_out["patient_id"].nunique() if not df_out.empty else 0
    recommendations_count = len(df_out)
    print(f"[{log_id}] Contextual cold start generated {recommendations_count} recommendations for {unique_patients_count} unique patients.")
    if logger:
        logger.info(f"[{log_id}] Contextual cold start generated {recommendations_count} recommendations for {unique_patients_count} unique patients.")
    else:
        print(f"[{log_id}] Contextual cold start generated {recommendations_count} recommendations for {unique_patients_count} unique patients.")

    # --- دمج الأعمدة السياقية من df الأصلي مع النتائج ---
    # تحديد الأعمدة السياقية المراد جلبها
    context_cols_to_add = ['feature_id_binned', 'context_feature_id']
    # تحميل df_contextualized الأصلي (أو استخدم نسخة منه إن كانت محملة سابقاً)
    try:
        contextualized_data_path = os.path.join(os.path.dirname(__file__), "../outputs/tmp/df_contextualized.csv")
        df_contextualized = pd.read_csv(contextualized_data_path)
        df_contextualized = assign_feature_id_by_binned(df_contextualized)
        df_contextualized = df_contextualized[['patient_id', 'feature_id'] + context_cols_to_add].drop_duplicates()
        df_out = df_out.merge(
            df_contextualized,
            on=['patient_id', 'feature_id'],
            how='left'
        )
    except (FileNotFoundError, pd.errors.EmptyDataError, OSError, KeyError) as ex:
        if logger:
            logger.warning(f"[{log_id}] ❌ Could not merge contextual columns: {ex}")
        else:
            print(f"[{log_id}] ❌ Could not merge contextual columns: {ex}")

    # إعادة ترتيب الأعمدة للتوافق مع مخرجات النظام
    preferred_col_order = ["patient_id", "feature_id", "feature_id_binned", "context_feature_id", "score_cf", "reason", "explanation", "source", "status"]
    df_out = df_out[[col for col in preferred_col_order if col in df_out.columns]]

    if logger:
        # توثيق القيم الفريدة للأعمدة السياقية
        logger.info(f"[{log_id}] feature_id_binned unique after merge: {df_out['feature_id_binned'].nunique()}")
        logger.info(f"[{log_id}] context_feature_id unique after merge: {df_out['context_feature_id'].nunique()}")
        manual_review_rows = df_out[(df_out['feature_id_binned'].isnull()) | (df_out['feature_id_binned'] == 'manual_review')]
        if not manual_review_rows.empty:
            logger.warning(f"[{log_id}] Rows with manual_review or missing feature_id_binned: {len(manual_review_rows)}")

    print(f"[{log_id}] Returning recommendations with columns: {df_out.columns.tolist()} for {len(df_out)} rows.")
    if logger:
        logger.info(f"[{log_id}] Returning recommendations with columns: {df_out.columns.tolist()} for {len(df_out)} rows.")

    df_out = merge_contextual_columns(df_out, logger=logger)
    # إزالة التكرارات بناءً على الأعمدة المحددة قبل الإرجاع
    df_out = df_out.drop_duplicates(subset=["patient_id", "feature_id", "score_cf", "feature_id_binned", "context_feature_id"])
    # إزالة التكرارات بناءً على patient_id وfeature_id (الإبقاء على الصف الأخير فقط)
    df_out = df_out.drop_duplicates(subset=["patient_id", "feature_id"], keep="last")
    # ترتيب الأعمدة النهائية حسب output_cols (مع تجاهل الأعمدة غير الموجودة)
    # إضافة explanation وsource إذا لم تكن موجودة
    for col in ["explanation", "source"]:
        if col not in df_out.columns:
            df_out[col] = None
    # عمود مصدر التوصية
    if "status" not in df_out.columns:
        df_out["status"] = "cold_start_safe_default"  # عمود مصدر التوصية
    final_cols = [col for col in output_cols if col in df_out.columns]
    for col in ["explanation", "source", "status"]:
        if col not in final_cols and col in df_out.columns:
            final_cols.append(col)
    df_out = df_out[final_cols]

    # --- Ensure unique (patient, feature) and apply Top-K capping per patient ---
    df_out = df_out.drop_duplicates(subset=["patient_id", "feature_id"])
    df_out = cap_topk_per_patient(
        df_out, k=top_k, patient_col="patient_id", feature_col="feature_id", score_col="score_cf"
    )

    # --- Ensure status and source columns with defaults ---
    if "status" not in df_out.columns:
        df_out["status"] = "cold_start_safe_default"
    else:
        df_out["status"] = df_out["status"].fillna("cold_start_safe_default")

    if "source" not in df_out.columns:
        df_out["source"] = "cold_start_contextual"
    else:
        df_out["source"] = df_out["source"].fillna("cold_start_contextual")

    return df_out

def run_cold_start(logger=None, log_id=None, patient_ids=None, contextual_columns=None, top_k=None) -> pd.DataFrame:
    """
    Generate cold-start recommendations using preprocessed data.

    ملاحظة: يتم الآن توليد feature_id حصراً عبر القاموس المركزي assign_feature_id_by_binned بما يحقق التوافق التام مع جميع الأعمدة السياقية الجديدة.

    Note:
    This function generates recommendations only for entirely new patients (with no prior interactions).
    Patients with existing interactions should never receive cold-start recommendations.
    The recommendations here serve as a safe default for guidance only and are not final recommendations.

    This function supports two modes:
    - Global cold start (default): If contextual_columns is None or empty, generate global top features recommendations.
    - Contextual cold start: If contextual_columns is provided and non-empty, generate recommendations grouped by those contextual columns.

    Parameters
    ----------
    logger : logging.Logger or None
        Logger instance for logging messages.
    log_id : str or None
        Identifier for the log context.
    patient_ids : list or None, optional
        List of patient IDs to generate recommendations for. If None, generate for all patients.
    contextual_columns : list of str or None, optional
        List of contextual columns to use for grouping recommendations. If provided and non-empty,
        contextual cold start recommendations will be generated.
    top_k : int or None, optional
        Number of top features to select. If None, falls back to cfg cold_start.top_n or recommendation.top_n_eval.

    Returns
    -------
    pd.DataFrame with columns ['patient_id', 'feature_id', 'score_cf', 'reason']

    Examples
    --------
    run_cold_start(logger, log_id, patient_ids, contextual_columns=['age_group', 'sex'])
    run_cold_start(logger, log_id, patient_ids)  # global cold start as before
    """
    output_cols = ['patient_id', 'feature_id', 'score_cf', 'reason', 'explanation', 'source']
    if patient_ids is None or (isinstance(patient_ids, list) and len(patient_ids) == 0):
        warning_msg = f"[{log_id}] No patient_ids provided or empty list; returning empty DataFrame."
        if logger:
            logger.warning(warning_msg)
            logger.info(f"[{log_id}] Returning empty DataFrame with columns: {output_cols}")
        else:
            print(warning_msg)
            print(f"[{log_id}] Returning empty DataFrame with columns: {output_cols}")
        df_out = pd.DataFrame(columns=output_cols + ["status"])
        if "status" not in df_out.columns:
            df_out["status"] = []
        final_cols = [col for col in output_cols if col in df_out.columns]
        if "status" not in final_cols:
            final_cols.append("status")
        df_out = df_out[final_cols]
        return df_out

    # Check for duplicated patient_ids and log if any
    if isinstance(patient_ids, list):
        from collections import Counter
        patient_id_counts = Counter(patient_ids)
        duplicated = {pid: count for pid, count in patient_id_counts.items() if count > 1}
        if duplicated:
            dup_msg = f"[{log_id}] Duplicate patient_ids detected with counts: {duplicated}"
            if logger:
                logger.warning(dup_msg)
            else:
                print(dup_msg)

    if logger:
        logger.info(f"[{log_id}] Received patient_ids: {len(patient_ids)}")
        logger.info(f"[{log_id}] First 5 patient_ids received: {patient_ids[:5]}")
        logger.info(f"[{log_id}] Patient_ids list received and processing started.")
    else:
        print(f"[{log_id}] Received patient_ids: {len(patient_ids)}")
        print(f"[{log_id}] First 5 patient_ids received: {patient_ids[:5]}")
        print(f"[{log_id}] Patient_ids list received and processing started.")

    config_local = load_config()
    cs_cfg = config_local.get("cold_start", {})
    rec_cfg = config_local.get("recommendation", {})

    # If caller provided top_k, use it; otherwise derive from config
    if top_k is None:
        _topk_raw = cs_cfg.get("top_n", rec_cfg.get("top_n_eval", cs_cfg.get("top_k", 5)))
    else:
        _topk_raw = top_k

    top_k = _coerce_top_k(_topk_raw)
    if logger:
        logger.info(f"[{log_id}] [run_cold_start] Using top_k={top_k} (int) from raw={_topk_raw}")
    data_path = config_local["data_paths"]["hypertension"]

    # Load the dataset
    df = pd.read_csv(data_path)
    # تحديث عمود feature_id من القاموس المركزي الجديد قبل أي معالجة
    df = assign_feature_id_by_binned(df, log=logger, log_id=log_id)
    if logger:
        logger.info(f"[{log_id}] feature_id unique: {df['feature_id'].nunique()} | feature_id_binned unique: {df['feature_id_binned'].nunique()}")
        logger.info(f"[{log_id}] feature_id sample: {df['feature_id'].unique()[:5]}")
        logger.info(f"[{log_id}] feature_id_binned sample: {df['feature_id_binned'].unique()[:5]}")
        logger.info(f"[{log_id}] context_feature_id sample: {df['context_feature_id'].unique()[:5]}")

    # Diagnostics: save list of patients handled via cold-start if enabled
    diag_cfg = config_local.get("diagnostics", {})
    if diag_cfg.get("write_patients_no_cf", True) and isinstance(patient_ids, list) and len(patient_ids) > 0:
        try:
            save_cold_start_patients(patient_ids, "outputs/CF/diagnostics/patients_cold_start.json")
        except Exception as _ex:
            if logger:
                logger.warning(f"[{log_id}] Could not save patients_cold_start.json: {_ex}")
            else:
                print(f"[{log_id}] Could not save patients_cold_start.json: {_ex}")

    if contextual_columns and isinstance(contextual_columns, list) and len(contextual_columns) > 0:
        if logger:
            logger.info(f"[{log_id}] Using contextual cold start with columns: {contextual_columns}")
        else:
            print(f"[{log_id}] Using contextual cold start with columns: {contextual_columns}")
        weights = cs_cfg.get("context_weights", None)
        df_out = contextual_cold_start(df, contextual_columns, top_k, output_cols, logger=logger, log_id=log_id, patient_ids=patient_ids, weights=weights)
        # إزالة التكرارات بناءً على patient_id وfeature_id (الإبقاء على الصف الأخير فقط)
        df_out = df_out.drop_duplicates(subset=["patient_id", "feature_id"], keep="last")
        final_cols = [col for col in output_cols if col in df_out.columns]
        if "status" not in final_cols and "status" in df_out.columns:
            final_cols.append("status")
        df_out = df_out[final_cols]

        # --- Ensure unique (patient, feature) and apply Top-K capping per patient ---
        df_out = df_out.drop_duplicates(subset=["patient_id", "feature_id"])
        df_out = cap_topk_per_patient(
            df_out, k=top_k, patient_col="patient_id", feature_col="feature_id", score_col="score_cf"
        )

        # --- Ensure status and source columns with defaults ---
        if "status" not in df_out.columns:
            df_out["status"] = "cold_start_safe_default"
        else:
            df_out["status"] = df_out["status"].fillna("cold_start_safe_default")

        if "source" not in df_out.columns:
            df_out["source"] = "cold_start_contextual"
        else:
            df_out["source"] = df_out["source"].fillna("cold_start_contextual")

        return df_out
    else:
        if logger:
            logger.info(f"[{log_id}] Using global cold start (no contextual columns provided)")
        else:
            print(f"[{log_id}] Using global cold start (no contextual columns provided)")

        # Count frequency of each feature_id globally
        feature_counts = df["feature_id"].value_counts(normalize=True).to_dict()

        # Get top features globally (or use the available ones if < top_k)
        top_features = sorted(feature_counts.items(), key=lambda x: -x[1])[:top_k]

        if logger:
            logger.info(f"[{log_id}] Number of top features selected globally: {len(top_features)}")
        else:
            print(f"[{log_id}] Number of top features selected globally: {len(top_features)}")

        rows = []
        for pid in patient_ids:
            for fid, score_cf in top_features:
                # توثيق: تسلسل احترافي لجلب تفاصيل التوصية (MEDICAL_RECOMMENDATION_PLAN > CONTEXT_TO_RECOMMENDATION_MAP > FEATURE_ID_BINNED_MAP > manual_review)
                plan_details = extract_plan_details(fid)
                row = {
                    "patient_id": pid,
                    "feature_id": plan_details["feature_id"],
                    "score_cf": score_cf,
                    "reason": "cold_start_safe_default",
                    "explanation": plan_details["explanation"],
                    "source": plan_details["source"],
                    "status": plan_details["status"]  # عمود مصدر التوصية
                }
                rows.append(row)

        df_out = pd.DataFrame(rows)

        if df_out.empty:
            if logger:
                logger.info(f"[{log_id}] df_out is empty after building recommendations; returning empty DataFrame with columns: {output_cols}")
            else:
                print(f"[{log_id}] df_out is empty after building recommendations; returning empty DataFrame with columns: {output_cols}")
            df_out = pd.DataFrame(columns=output_cols + ["status"])
            if "status" not in df_out.columns:
                df_out["status"] = []
        else:
            # تأكد من الأعمدة المطلوبة
            for col in output_cols:
                if col not in df_out.columns:
                    df_out[col] = None
            if "status" not in df_out.columns:
                df_out["status"] = "cold_start_safe_default"  # عمود مصدر التوصية
            df_out = df_out.loc[:, [col for col in output_cols if col in df_out.columns] + (["status"] if "status" in df_out.columns else [])]

        df_out = merge_contextual_columns(df_out, logger=logger)

        if logger:
            logger.info(f"[{log_id}] Cold start generated {len(df_out)} recommendations for {df_out['patient_id'].nunique()} unique patients.")
            logger.info(f"[{log_id}] Returning recommendations with columns: {df_out.columns.tolist()} for {df_out.shape[0]} rows.")
            logger.info(f"[{log_id}] Patient_ids list processed successfully with {df_out['patient_id'].nunique()} patients.")
        else:
            print(f"[{log_id}] Cold start generated {len(df_out)} recommendations for {df_out['patient_id'].nunique()} unique patients.")
            print(f"[{log_id}] Returning recommendations with columns: {df_out.columns.tolist()} for {df_out.shape[0]} rows.")
            print(f"[{log_id}] Patient_ids list processed successfully with {df_out['patient_id'].nunique()} patients.")

        # إزالة التكرارات بناءً على الأعمدة المحددة قبل الإرجاع
        df_out = df_out.drop_duplicates(subset=["patient_id", "feature_id", "score_cf", "feature_id_binned", "context_feature_id"])
        # إزالة التكرارات بناءً على patient_id وfeature_id (الإبقاء على الصف الأخير فقط)
        df_out = df_out.drop_duplicates(subset=["patient_id", "feature_id"], keep="last")
        for col in ["explanation", "source"]:
            if col not in df_out.columns:
                df_out[col] = None
        final_cols = [col for col in output_cols if col in df_out.columns]
        if "status" not in final_cols and "status" in df_out.columns:
            final_cols.append("status")
        df_out = df_out[final_cols]

        # --- Ensure unique (patient, feature) and apply Top-K capping per patient ---
        df_out = df_out.drop_duplicates(subset=["patient_id", "feature_id"])
        df_out = cap_topk_per_patient(
            df_out, k=top_k, patient_col="patient_id", feature_col="feature_id", score_col="score_cf"
        )

        # --- Ensure status and source columns with defaults ---
        if "status" not in df_out.columns:
            df_out["status"] = "cold_start_safe_default"
        else:
            df_out["status"] = df_out["status"].fillna("cold_start_safe_default")

        if "source" not in df_out.columns:
            df_out["source"] = "cold_start_contextual"
        else:
            df_out["source"] = df_out["source"].fillna("cold_start_contextual")

        return df_out

# ---------------------------
# Unified public interface for cold start
# ---------------------------

def build_cold_start_recs(df: pd.DataFrame, cfg: dict, patient_ids=None, contextual_columns=None, logger=None, log_id=None) -> pd.DataFrame:
    """
    Unified entrypoint to produce cold-start recommendations with standardized output columns.
    - Respects cfg['cold_start'].get('top_n') or cfg['recommendation'].get('top_n_eval').
    - Writes diagnostics patients list if cfg['diagnostics']['write_patients_no_cf'] is True.
    - Supports optional contextual weighting via cfg['cold_start']['context_weights'].
    """
    if patient_ids is None:
        patient_ids = []
    cs_cfg = cfg.get("cold_start", {})
    rec_cfg = cfg.get("recommendation", {})
    _topk_raw = cs_cfg.get("top_n", rec_cfg.get("top_n_eval", cs_cfg.get("top_k", 5)))
    top_k = _coerce_top_k(_topk_raw)
    if logger:
        logger.info(f"[{log_id}] [build_cold_start_recs] Using top_k={top_k} (int) from raw={_topk_raw}")
    weights = cs_cfg.get("context_weights", None)

    # Ensure feature_id is present/standardized
    df = assign_feature_id_by_binned(df, log=logger, log_id=log_id)

    # Diagnostics
    diag_cfg = cfg.get("diagnostics", {})
    if diag_cfg.get("write_patients_no_cf", True) and isinstance(patient_ids, list) and len(patient_ids) > 0:
        try:
            save_cold_start_patients(patient_ids, "outputs/CF/diagnostics/patients_cold_start.json")
        except Exception as _ex:
            if logger:
                logger.warning(f"[{log_id}] Could not save patients_cold_start.json: {_ex}")

    output_cols = ['patient_id', 'feature_id', 'score_cf', 'reason', 'explanation', 'source']

    if contextual_columns and isinstance(contextual_columns, list) and len(contextual_columns) > 0:
        return contextual_cold_start(df, contextual_columns, top_k, output_cols, logger=logger, log_id=log_id, patient_ids=patient_ids, weights=weights)

    # Global cold start branch
    # Count feature frequencies globally
    feature_counts = df["feature_id"].value_counts(normalize=True).to_dict()
    top_features = sorted(feature_counts.items(), key=lambda x: -x[1])[:top_k]

    rows = []
    for pid in (patient_ids or []):
        for fid, score_cf in top_features:
            plan_details = extract_plan_details(fid)
            rows.append({
                "patient_id": pid,
                "feature_id": plan_details["feature_id"],
                "score_cf": score_cf,
                "reason": "cold_start_safe_default",
                "explanation": plan_details["explanation"],
                "source": plan_details["source"],
                "status": plan_details["status"],
            })
    out = pd.DataFrame(rows)
    if out.empty:
        out = pd.DataFrame(columns=output_cols + ["status"])  # keep schema
    else:
        for col in output_cols:
            if col not in out.columns:
                out[col] = None
        if "status" not in out.columns:
            out["status"] = "cold_start_safe_default"
        out = out.loc[:, [c for c in output_cols if c in out.columns] + (["status"] if "status" in out.columns else [])]

    # --- Ensure unique (patient, feature) and apply Top-K capping per patient ---
    out = out.drop_duplicates(subset=["patient_id", "feature_id"])
    out = cap_topk_per_patient(
        out, k=top_k, patient_col="patient_id", feature_col="feature_id", score_col="score_cf"
    )

    # --- Ensure status and source columns with defaults ---
    if "status" not in out.columns:
        out["status"] = "cold_start_safe_default"
    else:
        out["status"] = out["status"].fillna("cold_start_safe_default")

    if "source" not in out.columns:
        out["source"] = "cold_start_contextual"
    else:
        out["source"] = out["source"].fillna("cold_start_contextual")

    return out