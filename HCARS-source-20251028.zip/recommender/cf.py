import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from pipeline.helpers import split_train_val_test, generate_unique_log_id, coverage_ge_k, cap_topk_per_patient, finalize_recommendation_output
from recommender.cold_start_handler import run_cold_start
from utils.config_loader import load_config
from pipeline.core import prepare_data, check_schema  # تعديل: استيراد prepare_data و check_schema من core.py
from utils.logging_utils import setup_logger
from utils.constants import assign_feature_id_by_binned, get_top_n_eval
from utils.context_utils import ensure_feature_id_binned_and_context

# --- استيراد الدوال الموحدة لجلب التوصية ---
from utils.constants import plan_as_dict
# Context-aware re-ranking helpers will use config toggles
from functools import lru_cache
from typing import Dict, Any
import random

# ---- Cached plan mapping to reduce repeated work ----
@lru_cache(maxsize=1024)
def _plan_as_dict_cached(rec_str: str) -> dict:
    return plan_as_dict(rec_str)

# ------------------------------------------------------------
# دالة مساعدة لاستخراج تفاصيل الخطة الطبية كـ dict جاهز
def extract_plan_details(rec):
   """
   يحول أي توصية إلى dict جاهز فيه action, advice, explanation, source.
   # تسلسل جلب التوصية: PLAN -> CONTEXT -> BINNED -> FALLBACK
   """
   key = "" if rec is None else str(rec).strip()
   plan = _plan_as_dict_cached(key)
   assert isinstance(plan, dict), f"plan_as_dict output is not dict for {rec}: {plan}"
   return pd.Series({
       "feature_id": plan.get("action", "manual_review"),
       "reason": plan.get("advice") or plan.get("explanation"),
       "explanation": plan.get("explanation"),
       "source": plan.get("source")
   })


# ============================================================
# جميع القيم الديناميكية (الإعدادات والفلاتر) تؤخذ فقط من config.yaml
# ولا يوجد أي ثابت ديناميكي (top_n, score_threshold, ... إلخ) إلا من config.
# يمكن تعديل أي قيمة من config.yaml فقط بدون أي تغيير برمجي هنا.
# ============================================================



# --- Optional clipping helper driven by config.recommendation.clip_scores ---
def _maybe_clip_scores(df: pd.DataFrame, score_col: str, cfg: dict, logger=None, log_id=None) -> pd.DataFrame:
    try:
        if df is None or score_col not in df.columns:
            return df
        rec_cfg = (cfg or {}).get("recommendation", {})
        if not rec_cfg.get("clip_scores", True):
            return df
        over1 = int((df[score_col] > 1).sum())
        under0 = int((df[score_col] < 0).sum())
        if logger:
            logger.info(f"[{log_id}] Clipping {score_col} to [0,1]: >1 before={over1}, <0 before={under0}")
        df[score_col] = df[score_col].clip(lower=0.0, upper=1.0)
    except Exception as err:
        if logger:
            logger.warning(f"[{log_id}] ⚠️ clip failed for {score_col}: {err}")
    return df

# --- Helper: coerce top-n/k values from config or strings to safe int ---

def _coerce_int(value, default=5):
    try:
        if value is None:
            return int(default)
        if isinstance(value, str):
            try:
                return int(value)
            except ValueError:
                import re
                nums = re.findall(r"\d+", value)
                if nums:
                    return int(nums[0])
                return int(default)
        return int(value)
    except (TypeError, ValueError):
        return int(default)

# --- Score calibration helpers (per-patient) to stabilize ranking & nDCG ---
def _calibrate_scores_minmax(s: pd.Series, eps: float = 1e-6) -> pd.Series:
    s = pd.to_numeric(s, errors="coerce").fillna(0.0)
    lo, hi = float(s.min()), float(s.max())
    if hi <= lo + 1e-12:
        # all equal -> add tiny deterministic jitter to break ties
        return (s * 0.0) + 0.5 + np.linspace(-eps, eps, num=len(s), endpoint=True)
    out = (s - lo) / max(hi - lo, 1e-12)
    return out + np.linspace(-eps, eps, num=len(s), endpoint=True)

def _calibrate_scores_standard(s: pd.Series, eps: float = 1e-6) -> pd.Series:
    s = pd.to_numeric(s, errors="coerce").astype(float).fillna(0.0)
    mu = float(s.mean())
    sd = float(s.std(ddof=0))
    if sd <= 1e-12:
        # All values (nearly) equal → return zeros with tiny deterministic jitter to break ties
        jitter_series = pd.Series(np.linspace(-eps, eps, num=len(s), endpoint=True), index=s.index, dtype=float)
        return pd.Series(0.0, index=s.index, dtype=float) + jitter_series

    # Z-score then logistic squashing to ~[0,1]
    z = (s - mu) / sd
    squashed = 1.0 / (1.0 + np.exp(-(z.to_numpy(dtype=float))))
    jitter = np.linspace(-eps, eps, num=len(s), endpoint=True)
    return pd.Series(squashed + jitter, index=s.index, dtype=float)

def _apply_score_calibration(df: pd.DataFrame, score_col: str = "score_cf") -> pd.DataFrame:
    """
    Calibrate CF scores per patient to improve rank stability and break ties.
    Uses config['cf']['score_calibration'] if present, otherwise defaults to minmax.
    """
    try:
        if df is None or score_col not in df.columns:
            return df
        # Use module-level 'config' already loaded in this file
        sc_cfg = (config.get("cf", {}).get("score_calibration", {}) or {})
        method = str(sc_cfg.get("method", "minmax")).lower()
        eps = float(sc_cfg.get("epsilon_jitter", 1e-6))
        if method == "standard":
            df[score_col] = (
                df.groupby(PATIENT_COL, group_keys=False)[score_col]
                  .transform(lambda s: _calibrate_scores_standard(s, eps))
            )
        elif method == "none":
            return df
        else:  # "minmax" or unknown -> default to minmax
            df[score_col] = (
                df.groupby(PATIENT_COL, group_keys=False)[score_col]
                  .transform(lambda s: _calibrate_scores_minmax(s, eps))
            )
    except (KeyError, TypeError, ValueError, AttributeError) as _cal_ex:
        try:
            logger = setup_logger("cf", "logs/cf.log")
            logger.warning(f"[score_calibration] Skipped due to: {_cal_ex}")
        except (OSError, ValueError) as _log_ex:
            # Ignore logging setup issues quietly
            _ = _log_ex
    return df


# --- Context-aware reranking helper ---

def _apply_context_rerank(df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    """
    Lightweight, safe context-aware reranking.
    Combines CF score with a small contextual boost when enabled in config:
      cfg['cf']['context_rerank'] = {
        'enabled': bool,
        'alpha': float,                # weight for original CF score
        'same_family_boost': float,    # boost if feature_id_binned == context_feature_id
        'cold_start_penalty': float    # optional penalty for cold-start rows
      }
    Requirements: columns 'score_cf' and ideally 'feature_id_binned', 'context_feature_id'.
    The final score overwrites 'score_cf' to keep downstream logic unchanged.
    """
    try:
        if df is None or df.empty:
            return df
        if "score_cf" not in df.columns:
            return df
        rrcfg = (cfg.get("cf", {}).get("context_rerank", {}) or {})
        if not bool(rrcfg.get("enabled", False)):
            return df

        alpha = float(rrcfg.get("alpha", 0.85))
        same_family_boost = float(rrcfg.get("same_family_boost", 0.15))
        cs_penalty = float(rrcfg.get("cold_start_penalty", 0.0))

        # Ensure numeric score_cf
        df["score_cf"] = pd.to_numeric(df["score_cf"], errors="coerce").fillna(0.0)

        # Contextual boost if family matches current context
        if {"feature_id_binned", "context_feature_id"}.issubset(df.columns):
            same_family = (df["feature_id_binned"].astype(str) == df["context_feature_id"].astype(str)).astype(float)
            boost = same_family * same_family_boost
        else:
            boost = 0.0

        # Optional penalty for cold-start rows to favor CF when both exist
        if "status" in df.columns and cs_penalty != 0.0:
            is_cs = df["status"].astype(str).eq("cold_start_safe_default").astype(float)
            boost = boost - (is_cs * abs(cs_penalty))

        # Blend and clip
        df["score_cf"] = (alpha * df["score_cf"]) + ((1.0 - alpha) * boost)
        df["score_cf"] = df["score_cf"].clip(0.0, 1.0)
        return df
    except (KeyError, TypeError, ValueError, AttributeError) as _rr_ex:
        try:
            logger = setup_logger("cf", "logs/cf.log")
            logger.warning(f"[context_rerank] Skipped due to: {_rr_ex}")
        except (OSError, ValueError) as _log_ex:
            _ = _log_ex  # ignore logging setup issues quietly
        return df


# ============================================================
# جميع القيم الديناميكية (الإعدادات والفلاتر) تؤخذ فقط من config.yaml
# ولا يوجد أي ثابت ديناميكي (top_n, score_threshold, ... إلخ) إلا من config.
# يمكن تعديل أي قيمة من config.yaml فقط بدون أي تغيير برمجي هنا.
# ============================================================
config = load_config()  # تحميل config في رأس الملف

# إعداد متغيرات التوصية من config (يتم استخدامها فقط من config["recommendation"])
return_all_recommendations = config["recommendation"].get("return_all_recommendations", False)
score_threshold_enabled = config["recommendation"].get("score_threshold_enabled", False)
score_threshold = config["recommendation"].get("score_threshold", 0.1)
top_n = _coerce_int(config["recommendation"].get("top_n_eval", 5), default=5)
per_patient_topn_cap = _coerce_int(config["recommendation"].get("per_patient_topn_cap"), default=0)
min_score_per_patient = config["recommendation"].get("min_score_per_patient")  # keep as float

# Development/diagnostics tuning (optional; controlled via config.development)
dev_cfg = config.get("development", {})
relax_threshold = bool(dev_cfg.get("relax_score_threshold", False))
score_threshold_dev = dev_cfg.get("score_threshold_dev", 0.0)

# Expand raw candidate pool per patient before final cap (improves coverage)
# If not provided, default to max(2*top_n, 20)
raw_pool_cap = _coerce_int(config.get("cf", {}).get("raw_pool_cap"), default=max(2 * int(top_n), 20))

# Canonical column names (read from config with safe fallbacks)
cols_cfg = config.get("global", {}).get("columns", {})
PATIENT_COL = cols_cfg.get("patient", "patient_id")
FEATURE_COL = cols_cfg.get("feature", "feature_id")
RESPONSE_COL = cols_cfg.get("response", "true_response")

def run_collaborative_filtering():
    """
    Main collaborative filtering + cold start recommendation pipeline.

    جميع الفلاتر والإعدادات (top_n, score_threshold, score_threshold_enabled, return_all_recommendations, ...إلخ)
    تؤخذ فقط من config.yaml (المفتاح ["recommendation"] أو ["output_columns"]["cf"])،
    ويمكن تعديلها من ملف الإعدادات بدون أي تعديل برمجي هنا.
    لا يوجد أي ثابت ديناميكي أو قيمة افتراضية تُستخدم إلا من config.

    كل الأعمدة النهائية (output_columns) يتم ترتيبها وتسلسلها فقط حسب config["output_columns"]["cf"]
    مع إضافة الأعمدة السياقية (feature_id_binned, context_feature_id) وreason بوضوح إذا لم تكن موجودة بالفعل فقط مرة واحدة.

    this function runs a hybrid recommendation pipeline combining collaborative filtering (CF) and cold start handling.
    patients with a number of interactions greater than or equal to min_ratings are recommended via CF.
    patients with fewer interactions receive recommendations from the cold start handler.
    the final recommendations are merged and schema-checked before returning.

    the function ensures clinically that cold start recommendations are only exported for new patients
    who do not have CF recommendations, preventing any patient from receiving duplicate recommendations.

    تسجّل كل خطوة أساسية (إعداد، تقسيم، حساب التفاعل، بناء التوصيات، الدمج، تصدير) في الـ logger و/أو print بما يكشف أي توقف أو غياب توصيات أو سوء توزيع المرضى.

    Returns:
        final_recommendations (pd.DataFrame): The merged recommendations from CF and cold start methods.
        used_cold_start (bool): True if cold start recommendations were used (either fallback or partial), False otherwise.
        recommendation_stats (dict): إحصائيات حول المرضى والتوزيع النهائي.
    """
    log_id = generate_unique_log_id()
    logger = setup_logger("cf", "logs/cf.log")  # تعديل: الحصول على logger محلي داخل الدالة
    np.random.seed(config.get("random_seed", 42))
    random.seed(config.get("random_seed", 42))

    min_ratings = config.get("cf", {}).get("min_ratings", 5)  # جديد: تحميل min_ratings من config
    # Safe top-k for cold-start derived from config (handles templated/str values)
    top_k_cs = _coerce_int(get_top_n_eval(config), default=5)
    logger.info(f"[{log_id}] [cf] Using cold-start top_k={top_k_cs}")
    patient_col = PATIENT_COL
    feature_col = FEATURE_COL
    response_col = RESPONSE_COL

    data_path = config["data_paths"]["hypertension"]
    df_contextualized = pd.read_csv(data_path)

    # تحديث بيانات التوصية سياقياً لضمان تطابق الأعمدة السياقية مع المنظومة الحديثة
    df_contextualized = assign_feature_id_by_binned(df_contextualized, log=logger, log_id=log_id)
    # Ensure family/context keys exist before any downstream ranking or merges
    try:
        df_contextualized = ensure_feature_id_binned_and_context(
            df_contextualized, log=logger, log_id=log_id
        )
    except (ValueError, KeyError, TypeError) as _ex:
        logger.warning(f"[{log_id}] ensure_feature_id_binned_and_context skipped on df_contextualized: {_ex}")

    print(f"[{log_id}] Loaded data with total patients: {df_contextualized[patient_col].nunique()}")
    logger.info(f"[{log_id}] ✅ Starting CF pipeline with {len(df_contextualized)} records and {df_contextualized[patient_col].nunique()} unique patients.")

    logger.info(f"[{log_id}] [cf] feature_id unique: {df_contextualized['feature_id'].unique()[:5]}")
    logger.info(f"[{log_id}] [cf] feature_id_binned unique: {df_contextualized['feature_id_binned'].unique()[:5]}")
    logger.info(f"[{log_id}] [cf] context_feature_id unique: {df_contextualized['context_feature_id'].unique()[:5]}")

    # تعديل: تجهيز البيانات باستخدام prepare_data وتمرير log_id وlogger
    df_contextualized = prepare_data(df_contextualized, log_id=log_id, logger=logger)

    # تعديل: فحص schema باستخدام check_schema وتمرير log_id وlogger
    check_schema(df_contextualized, required_columns=[patient_col, feature_col, response_col], log_id=log_id, logger=logger)

    # تعديل: تقسيم البيانات
    df_train, df_val, df_test = split_train_val_test(df_contextualized, config=config)

    print(f"[{log_id}] After splitting: train patients = {df_train[patient_col].nunique()}, val patients = {df_val[patient_col].nunique()}, test patients = {df_test[patient_col].nunique()}")
    logger.info(f"[{log_id}] ✅ Dataset split: train={len(df_train)}, val={len(df_val)}, test={len(df_test)} with unique patients train={df_train[patient_col].nunique()}, val={df_val[patient_col].nunique()}, test={df_test[patient_col].nunique()}")

    # تعديل: تجهيز البيانات بعد التقسيم لكل مجموعة
    df_train = prepare_data(df_train, log_id=log_id, logger=logger)
    try:
        df_train = ensure_feature_id_binned_and_context(df_train, log=logger, log_id=f"{log_id}__train")
    except (ValueError, KeyError, TypeError) as _ex:
        logger.warning(f"[{log_id}] ensure_feature_id_binned_and_context skipped on df_train: {_ex}")
    df_val = prepare_data(df_val, log_id=log_id, logger=logger)
    try:
        df_val = ensure_feature_id_binned_and_context(df_val, log=logger, log_id=f"{log_id}__val")
    except (ValueError, KeyError, TypeError) as _ex:
        logger.warning(f"[{log_id}] ensure_feature_id_binned_and_context skipped on df_val: {_ex}")
    df_test = prepare_data(df_test, log_id=log_id, logger=logger)
    try:
        df_test = ensure_feature_id_binned_and_context(df_test, log=logger, log_id=f"{log_id}__test")
    except (ValueError, KeyError, TypeError) as _ex:
        logger.warning(f"[{log_id}] ensure_feature_id_binned_and_context skipped on df_test: {_ex}")

    # تعديل: فحص schema لكل مجموعة بعد التجهيز
    check_schema(df_train, required_columns=[patient_col, feature_col, response_col], log_id=log_id, logger=logger)
    check_schema(df_val, required_columns=[patient_col, feature_col, response_col], log_id=log_id, logger=logger)
    check_schema(df_test, required_columns=[patient_col, feature_col, response_col], log_id=log_id, logger=logger)

    # حساب عدد التفاعلات لكل مريض في df_train
    patient_interaction_counts = df_train.groupby(patient_col)[response_col].count()
    eligible_patients = patient_interaction_counts[patient_interaction_counts >= min_ratings].index.tolist()
    cold_patients = patient_interaction_counts[patient_interaction_counts < min_ratings].index.tolist()

    print(f"[{log_id}] Number of eligible patients for CF (>= {min_ratings} interactions): {len(eligible_patients)}")
    print(f"[{log_id}] Number of cold start patients (< {min_ratings} interactions): {len(cold_patients)}")
    logger.info(f"[{log_id}] ℹ️ Patients with >= {min_ratings} interactions: {len(eligible_patients)}")
    logger.info(f"[{log_id}] ℹ️ Patients with < {min_ratings} interactions (cold start): {len(cold_patients)}")

    used_cold_start = False

    # بناء مصفوفة التفاعل فقط للمرضى المؤهلين — باستخدام CSR sparse
    df_eligible = df_train[df_train[patient_col].isin(eligible_patients)].copy()
    # فهارس المستخدمين والعناصر
    users = df_eligible[patient_col].unique()
    items = df_eligible[feature_col].unique()
    user_index: Dict[Any, int] = {u: i for i, u in enumerate(users)}
    item_index: Dict[Any, int] = {it: i for i, it in enumerate(items)}

    row_idx = df_eligible[patient_col].map(user_index).to_numpy()
    col_idx = df_eligible[feature_col].map(item_index).to_numpy()
    vals = df_eligible[response_col].astype(float).to_numpy()

    r_matrix = csr_matrix((vals, (row_idx, col_idx)), shape=(len(users), len(items)))

    # Identify zero-vector patients before similarity (ensure boolean ndarray)
    row_sums = np.asarray(r_matrix.sum(axis=1)).ravel()
    zero_vec_mask = np.asarray(row_sums == 0, dtype=bool)
    zero_idx = np.where(zero_vec_mask)[0]
    zero_vector_patients = [users[i] for i in zero_idx]
    if len(zero_vector_patients) > 0:
        logger.info(f"[{log_id}] ℹ️ {len(zero_vector_patients)} zero-vector patients removed from CF similarity and routed to cold-start.")

    # احتفظ فقط بالصفوف غير الصفرية للحساب
    nonzero_user_indices = np.where(~zero_vec_mask)[0]
    if nonzero_user_indices.size == 0 or r_matrix.shape[1] == 0:
        logger.warning(f"[{log_id}] ⚠️ No non-zero interaction rows or no features remaining for CF. Running cold start for all patients.")
        patients_for_cold_start = list(df_train[patient_col].unique())
        cold_start_df = run_cold_start(patient_ids=patients_for_cold_start, log_id=log_id, logger=logger, top_k=top_k_cs)
        cold_start_df["status"] = "cold_start_safe_default"
        output_columns = list(config["output_columns"]["cf"])
        if "score" in cold_start_df.columns and "score_cf" not in cold_start_df.columns:
            cold_start_df = cold_start_df.rename(columns={"score": "score_cf"})
        cold_start_df = _maybe_clip_scores(cold_start_df, "score_cf", config, logger=logger, log_id=log_id)
        final_cold_cols = list(output_columns)
        for col in ["reason", "explanation", "source"]:
            if col not in final_cold_cols:
                final_cold_cols.append(col)
        cols_exist = [c for c in final_cold_cols if c in cold_start_df.columns]
        cold_start_df = cold_start_df[cols_exist].reset_index(drop=True)
        used_cold_start = True
        empty_stats = {
            "total_patients": len(df_train[patient_col].unique()),
            "patients_with_recommendations": 0,
            "patients_missing_recommendations": len(df_train[patient_col].unique()),
            "reason_distribution": {},
            "sample_missing_patients": list(df_train[patient_col].unique())[:10]
        }
        return cold_start_df, used_cold_start, empty_stats

    r_nz = r_matrix[nonzero_user_indices]
    users_nz = users[nonzero_user_indices]

    # Row-normalize for cosine
    row_norms = np.sqrt(r_nz.multiply(r_nz).sum(axis=1)).A1
    row_norms[row_norms == 0.0] = 1.0
    r_norm = r_nz.multiply(1.0 / row_norms[:, None])

    # user-user cosine similarity via sparse dot
    sim = r_norm @ r_norm.T  # (nu_nz x nu_nz) sparse matrix

    # تجميع التوصيات: weighted sum من الجيران الأعلى
    k = int(config.get("cf", {}).get("neighbors", 10))
    records = []
    # للتسريع: مصفوفة العناصر كثيفة للوصول السريع عند الضرب — حسب الحاجة
    r_items_dense = r_matrix.toarray() if (len(users_nz) * len(items) <= 2_000_000) else None

    for u_row, u_id in enumerate(users_nz):
        # استخلاص صف التشابه للمستخدم الحالي
        s_row = sim.getrow(u_row).toarray().ravel()
        # تجاهل التشابه الذاتي
        if s_row.size:
            s_row[u_row] = 0.0
        # أعلى k جيران
        if k < s_row.size:
            neigh_idx = np.argpartition(-s_row, k)[:k]
        else:
            neigh_idx = np.where(s_row > 0)[0]
        weights = s_row[neigh_idx]
        norm = float(weights.sum())
        if norm <= 0.0 or neigh_idx.size == 0:
            continue

        # حساب الدرجات المرجّحة لعناصر جميع الميزات
        if r_items_dense is not None:
            scores_vec = (weights @ r_items_dense[nonzero_user_indices[neigh_idx], :]) / norm
        else:
            # ضرب مرجّح على دفعات صغيرة لتجنّب الكثافة
            scores_vec = np.zeros(r_matrix.shape[1], dtype=float)
            for w, idx in zip(weights, neigh_idx):
                scores_vec += w * r_matrix[nonzero_user_indices[idx], :].toarray().ravel()
            scores_vec /= norm

        # تطبيق منطق top-n هنا (لمنع انفجار الحجم) عندما return_all_recommendations=False
        # نستخدم cap خام أوسع (raw_pool_cap) لتحسين التغطية قبل القصّ النهائي
        cap_for_records = scores_vec.size if return_all_recommendations else int(raw_pool_cap)
        if cap_for_records < scores_vec.size:
            top_items_idx = np.argpartition(-scores_vec, cap_for_records)[:cap_for_records]
        else:
            top_items_idx = np.argsort(-scores_vec)

        for it_j in top_items_idx:
            score = float(scores_vec[it_j])
            records.append((u_id, items[it_j], score))

    # تحويل النتائج إلى DataFrame طويل
    scores_long = pd.DataFrame.from_records(records, columns=[patient_col, feature_col, "score_cf"]) if records else pd.DataFrame(columns=[patient_col, feature_col, "score_cf"])
    # Drop any incomplete rows early to avoid NaN leaks
    scores_long = scores_long.dropna(subset=[patient_col, feature_col, "score_cf"])
    scores_long = _maybe_clip_scores(scores_long, "score_cf", config, logger=logger, log_id=log_id)
    # Stable, tiny tie-breaker per (patient, feature) rank to improve nDCG when scores tie
    try:
        _tie = scores_long.groupby(patient_col)[feature_col].transform(lambda s: pd.factorize(s.astype(str))[0])
        # Add a tiny epsilon that cannot affect ordering when scores differ, but breaks exact ties deterministically
        scores_long["score_cf"] = scores_long["score_cf"].astype(float) + (_tie.astype(float) * 1e-12)
    except Exception as _tb_ex:
        if logger:
            logger.warning(f"[{log_id}] Tie-breaker injection skipped: {_tb_ex}")
    # === تطبيق score threshold إذا مفعل ===
    if score_threshold_enabled:
        # Allow development-time relaxation of threshold to widen candidate pool
        thr = float(score_threshold_dev) if relax_threshold else float(score_threshold)
        mask_below: pd.Series = scores_long["score_cf"].lt(thr)
        n_below = int(mask_below.sum())
        if n_below > 0:
            logger.info(f"[{log_id}] ℹ️ Filtering {n_below} CF rows below score_threshold={'DEV ' if relax_threshold else ''}{thr}.")
        scores_long = scores_long.loc[~mask_below]
    # === منطق top-n أو جميع التوصيات حسب الإعدادات ===
    if not return_all_recommendations:
        scores_long = (
            scores_long.sort_values(by=[patient_col, "score_cf"], ascending=[True, False])
            .groupby(patient_col)
            .head(int(raw_pool_cap))
            .reset_index(drop=True)
        )
    else:
        scores_long = scores_long.sort_values(by=[patient_col, "score_cf"], ascending=[True, False]).reset_index(drop=True)
        if isinstance(per_patient_topn_cap, int) and per_patient_topn_cap > 0:
            scores_long = scores_long.groupby(patient_col).head(per_patient_topn_cap).reset_index(drop=True)

    # تطبيق حد أدنى لاحق للسكور إن طُلب (بعد الفرز)
    if isinstance(min_score_per_patient, (int, float)):
        pre_cnt = len(scores_long)
        scores_long = scores_long[scores_long["score_cf"] >= float(min_score_per_patient)].reset_index(drop=True)
        post_cnt = len(scores_long)
        if pre_cnt != post_cnt:
            logger.info(f"[{log_id}] ℹ️ Applied min_score_per_patient={min_score_per_patient}: {pre_cnt} -> {post_cnt}")

    top_recommendations_cf = scores_long.reset_index(drop=True)
    top_recommendations_cf["status"] = "collaborative_filtering"
    # --- Expand/limit raw candidate pool per patient (idempotent) and calibrate scores before finalize/cap ---
    try:
        _cfg_cf = config.get("cf", {}) or {}
        _raw_cap = int(_cfg_cf.get("raw_pool_cap", max(2 * int(top_n), 20)))
    except (TypeError, ValueError, KeyError) as cfg_ex:
        logger.warning(f"[{log_id}] ⚠️ Unable to parse cf.raw_pool_cap, using default: {cfg_ex}")
        _raw_cap = max(2 * int(top_n), 20)
    if _raw_cap and _raw_cap > 0 and "score_cf" in top_recommendations_cf.columns:
        top_recommendations_cf = (
            top_recommendations_cf
            .sort_values([patient_col, "score_cf"], ascending=[True, False])
            .groupby(patient_col, group_keys=False)
            .head(_raw_cap)
            .reset_index(drop=True)
        )
        logger.info(f"[{log_id}] 🔧 Raw candidate cap (pre-finalize): {_raw_cap}; frame={top_recommendations_cf.shape}")
    # Calibrate scores per patient to break ties & stabilize ranking (improves nDCG)
    if "score_cf" in top_recommendations_cf.columns:
        top_recommendations_cf = _apply_score_calibration(top_recommendations_cf, score_col="score_cf")
    # --- Post-generation cleanup for CF-only frame: deduplicate and optional per-patient cap ---
    try:
        # First, deduplicate CF recommendations on (patient, feature)
        top_recommendations_cf = finalize_recommendation_output(top_recommendations_cf)
    except (KeyError, ValueError, TypeError, AttributeError) as ex_finalize_cf:
        logger.warning(f"[{log_id}] ⚠️ CF finalize_recommendation_output failed: {ex_finalize_cf}")

    # Apply per-patient Top-K cap (distinct from top_n used earlier) if configured
    try:
        k_cap_cfg = config.get("recommendation", {}).get("per_patient_topn_cap", 0)
        k_cap = int(k_cap_cfg) if str(k_cap_cfg).strip() not in ("", "None") else 0
    except Exception as ex_cap:
        logger.warning(f"[{log_id}] ⚠️ Could not parse per_patient_topn_cap: {ex_cap}; defaulting to 0 (no cap)")
        k_cap = 0

    if isinstance(k_cap, int) and k_cap > 0:
        top_recommendations_cf = cap_topk_per_patient(
            top_recommendations_cf,
            k=k_cap,
            patient_col=patient_col,
            feature_col=feature_col,
            score_col="score_cf",
        )
        logger.info(f"[{log_id}] 🎯 Applied per-patient Top-{k_cap} cap on CF frame (post-dedup). Current shape: {top_recommendations_cf.shape}")
    logger.info(f"[{log_id}] 🔎 CF candidate expansion summary — raw_pool_cap={int(raw_pool_cap)}, ui_cap={int(k_cap) if isinstance(k_cap, int) else 0}, top_n_eval={int(top_n)}")
    # Extend cold-start candidate list with zero-vector patients that were excluded from CF similarity
    zero_vector_patients = set(zero_vector_patients) if isinstance(zero_vector_patients, list) else set()

    # Quick CF diagnostics: coverage and score distribution
    if patient_col in df_train.columns:
        cf_patients_total = int(pd.Index(df_train[patient_col]).nunique())
    else:
        cf_patients_total = 0
    if patient_col in top_recommendations_cf.columns:
        cf_patients_with_rec = int(pd.Index(top_recommendations_cf[patient_col]).nunique())
    else:
        cf_patients_with_rec = 0
    denominator = max(1, cf_patients_total)
    cf_pat_coverage = cf_patients_with_rec / denominator

    if not top_recommendations_cf.empty:
        q = top_recommendations_cf["score_cf"].quantile([0.1, 0.25, 0.5, 0.75, 0.9]).to_dict()
        logger.info(f"[{log_id}] ℹ️ CF coverage: {cf_pat_coverage:.2%}; score_cf percentiles: {q}")

    print(f"[{log_id}] CF recommendations generated: {len(top_recommendations_cf)} rows for {top_recommendations_cf[patient_col].nunique()} patients.")
    logger.info(f"[{log_id}] ✅ CF generated {len(top_recommendations_cf)} recommendations.")
    logger.info(f"[{log_id}] ℹ️ Number of patients with CF recommendations: {top_recommendations_cf[patient_col].nunique()}")
    logger.info(f"[{log_id}] ℹ️ Number of patients eligible for cold start recommendations: {len(cold_patients)}")

    # === تسجيل المرضى المستبعدين بسبب threshold أو الفلترة ===
    excluded_patients = set(df_train[patient_col].unique()) - set(top_recommendations_cf[patient_col].unique())
    if excluded_patients:
        logger.warning(f"[{log_id}] ⚠️ The following patients did not get recommendations (reason: threshold/filtering): {list(excluded_patients)[:10]} ... total: {len(excluded_patients)}")

    # تعديل: حساب المرضى الذين لم يحصلوا على توصيات CF لتزويدهم بتوصيات cold start
    all_patient_ids = set(df_train[patient_col].unique())
    patients_with_cf = set(top_recommendations_cf[patient_col].unique())
    patients_for_cold_start = list((all_patient_ids - patients_with_cf) | zero_vector_patients)
    # Diagnostics: write list of patients routed to cold-start (optional, controlled by config.diagnostics)
    try:
        if config.get("diagnostics", {}).get("write_patients_no_cf", True):
            import json, os
            os.makedirs("outputs/CF/diagnostics", exist_ok=True)
            with open("outputs/CF/diagnostics/patients_no_cf.json", "w", encoding="utf-8") as f:
                json.dump(sorted(list(map(str, patients_for_cold_start))), f, ensure_ascii=False, indent=2)
    except (OSError, ValueError, TypeError) as ex:
        logger.warning(f"[{log_id}] ⚠️ Could not write patients_no_cf.json: {ex}")

    logger.info(f"[{log_id}] ℹ️ Total patients in training: {len(all_patient_ids)}, patients with CF recommendations: {len(patients_with_cf)}, patients for cold start: {len(patients_for_cold_start)}")
    print(f"[{log_id}] Patients for cold start: {len(patients_for_cold_start)}")

    # توصيات cold start للمرضى الباردين فقط
    if patients_for_cold_start:
        logger.info(f"[{log_id}] ℹ️ Running cold start for {len(patients_for_cold_start)} cold patients.")
        # ملاحظة: يجب تعديل run_cold_start في cold_start_handler.py لقبول patient_ids
        cold_start_df = run_cold_start(patient_ids=patients_for_cold_start, log_id=log_id, logger=logger, top_k=top_k_cs)
        cold_start_df["status"] = "cold_start_safe_default"
        output_columns = list(config["output_columns"]["cf"])
        if "score" in cold_start_df.columns and "score_cf" not in cold_start_df.columns:
            cold_start_df = cold_start_df.rename(columns={"score": "score_cf"})
        cold_start_df = _maybe_clip_scores(cold_start_df, "score_cf", config, logger=logger, log_id=log_id)
        # التأكد من عدم تكرار الأعمدة
        final_cold_cols = list(output_columns)
        for col in ["reason", "explanation", "source"]:
            if col not in final_cold_cols:
                final_cold_cols.append(col)
        cols_exist = [c for c in final_cold_cols if c in cold_start_df.columns]
        cold_start_df = cold_start_df[cols_exist]
        cold_start_df = cold_start_df.reset_index(drop=True)
        # إذا كان هناك توصيات لم تستوف threshold أو شروط أخرى، سجلها في عمود reason
        logger.info(f"[{log_id}] ✅ Cold start generated {len(cold_start_df)} recommendations.")
        print(f"[{log_id}] Cold start recommendations generated: {len(cold_start_df)} rows for {cold_start_df[patient_col].nunique()} patients.")
        used_cold_start = True
    else:
        output_columns = list(config["output_columns"]["cf"])
        cold_start_df = pd.DataFrame(columns=output_columns + ["reason", "explanation", "source"])
        logger.info(f"[{log_id}] ℹ️ No cold start recommendations generated as no cold patients found.")
        print(f"[{log_id}] No cold start recommendations generated as no cold patients found.")

    # إزالة توصيات cold_start للمرضى الذين لديهم توصيات CF
    cf_patients = set(top_recommendations_cf[patient_col].unique())
    before_filtering = len(cold_start_df)
    cold_start_df = cold_start_df[~cold_start_df[patient_col].isin(cf_patients)]
    cold_start_df = cold_start_df.reset_index(drop=True)
    after_filtering = len(cold_start_df)
    logger.info(f"[{log_id}] ℹ️ Filtered cold start recommendations to exclude patients with CF recommendations: {before_filtering} -> {after_filtering}")

    print(f"[{log_id}] Before merging: CF recommendations rows = {len(top_recommendations_cf)}, cold start recommendations rows = {len(cold_start_df)}")
    logger.info(f"[{log_id}] ℹ️ Before merging: CF recommendations rows = {len(top_recommendations_cf)}, Cold Start recommendations rows = {len(cold_start_df)}")

    # === إضافة: دمج الأعمدة السياقية من df_contextualized مع توصيات CF وCold Start ===
    output_columns = list(config["output_columns"]["cf"])  # متغير موحد لجميع الأعمدة المطلوبة
    context_cols = [patient_col, feature_col, "feature_id_binned", "context_feature_id"]
    subset_cols = [patient_col, feature_col]
    contextual_unique = df_contextualized.drop_duplicates(subset=subset_cols)
    # دمج السياق مع توصيات CF
    top_recommendations_cf = pd.merge(
        top_recommendations_cf,
        contextual_unique[context_cols],
        on=[patient_col, feature_col],
        how="left"
    )
    # Safety: if for any reason family/context columns are missing post-merge, build them now
    if not {"feature_id_binned", "context_feature_id"}.issubset(top_recommendations_cf.columns):
        try:
            top_recommendations_cf = ensure_feature_id_binned_and_context(
                top_recommendations_cf, log=logger, log_id=f"{log_id}__cf_frame"
            )
        except (ValueError, KeyError, TypeError) as _ex:
            logger.warning(f"[{log_id}] ensure_feature_id_binned_and_context skipped on CF frame: {_ex}")
    # Context-aware reranking on CF frame only (does not touch CS before filtering)
    try:
        top_recommendations_cf = _apply_context_rerank(
            top_recommendations_cf,
            cfg=config,
        )
    except Exception as _rr1:
        logger.warning(f"[{log_id}] Context rerank on CF frame skipped: {_rr1}")
    # دمج السياق مع توصيات Cold Start إذا وجدت
    if not cold_start_df.empty:
        cold_start_df = pd.merge(
            cold_start_df,
            contextual_unique[context_cols],
            on=[patient_col, feature_col],
            how="left"
        )
    # دمج التوصيات النهائية
    final_recommendations = pd.concat([top_recommendations_cf, cold_start_df], ignore_index=True)
    # Safety: ensure family/context keys exist on the combined frame (CF + CS) before rerank
    if not {"feature_id_binned", "context_feature_id"}.issubset(final_recommendations.columns):
        try:
            final_recommendations = ensure_feature_id_binned_and_context(
                final_recommendations, log=logger, log_id=f"{log_id}__combined"
            )
        except (ValueError, KeyError, TypeError) as _ex:
            logger.warning(f"[{log_id}] ensure_feature_id_binned_and_context skipped on combined frame: {_ex}")
    # Optional second pass reranking on the combined frame (CF + CS), guarded by config
    try:
        if not top_recommendations_cf.empty and not cold_start_df.empty:
            final_recommendations = _apply_context_rerank(
                final_recommendations,
                cfg=config,
            )
    except Exception as _rr2:
        logger.warning(f"[{log_id}] Combined-frame rerank skipped: {_rr2}")
    # مبدئيًا: اترك الدمج كما هو، واعتمد إزالة التكرارات والـ Top-K عبر أداة الـ Validator لاحقًا.
    # --- تحويل توصيات final_recommendations إلى تفاصيل الخطة الطبية ---
    # تسلسل جلب التوصية: PLAN -> CONTEXT -> BINNED -> FALLBACK
    mapped = final_recommendations[feature_col].apply(lambda v: extract_plan_details(v))
    for c in ["reason", "explanation", "source"]:
        final_recommendations[c] = mapped[c]
    # Keep feature_id from mapping only if it is not manual_review; otherwise preserve the existing feature_id
    new_feat = mapped["feature_id"].where(mapped["feature_id"].ne("manual_review"), final_recommendations[feature_col])
    final_recommendations[feature_col] = new_feat
    logger.info(f"[{log_id}] ✅ Duplicates removed after merging. Final recommendations shape: {final_recommendations.shape}")
    logger.info(f"[{log_id}] ℹ️ Merged recommendations count: CF={len(top_recommendations_cf)}, Cold Start={len(cold_start_df)}, Total={len(final_recommendations)}")
    print(f"[{log_id}] After merging: total recommendations rows = {len(final_recommendations)}, unique patients = {final_recommendations[patient_col].nunique()}")

    # ترتيب الأعمدة النهائية مع تضمين الأعمدة السياقية و"reason" و"explanation" و"source" (مرة واحدة فقط)
    final_columns = list(output_columns)
    for col in ["feature_id_binned", "context_feature_id"]:
        if col not in final_columns:
            final_columns.append(col)
    for col in ["reason", "explanation", "source"]:
        if col not in final_columns:
            final_columns.append(col)
    if "status" not in final_columns:
        final_columns.append("status")
    # أي توصية لم تُحدد لها reason (بقيت فارغة لأي سبب) يجب أن توضح السبب
    if "reason" in final_recommendations.columns:
        final_recommendations["reason"] = final_recommendations["reason"].fillna("no_reason_specified")
    final_recommendations = final_recommendations[final_columns]

    # === Finalize output: deduplicate (patient, feature) and optionally cap Top-K per patient from config ===
    final_recommendations = finalize_recommendation_output(final_recommendations)

    # === Coverage stats (unique (patient, feature)) computed from the FINAL frame ===
    # Initialize coverage variables with safe defaults to avoid "referenced before assignment" warnings
    n_patients_cov: int = 0
    pct_ge_k: float = 0.0
    min_recs: int = 0
    max_recs: int = 0
    avg_recs: float = 0.0
    try:
        n_patients_cov, pct_ge_k, min_recs, max_recs, avg_recs = coverage_ge_k(
            final_recommendations,
            k=top_n,
            patient_col=patient_col,
            feature_col=feature_col
        )
        logger.info(f"[{log_id}] 📈 Coverage (final): patients={n_patients_cov}, min={min_recs}, max={max_recs}, avg={avg_recs:.2f}, pct_with_≥{top_n}={pct_ge_k:.2%}")
    except (KeyError, ValueError, TypeError) as ex_cov:
        logger.warning(f"[{log_id}] ⚠️ Coverage computation failed on final output: {ex_cov}")

    # تسجيل القيم الفريدة للأعمدة السياقية بعد الدمج
    logger.info(f"[{log_id}] [cf] Unique feature_id values after merge: {final_recommendations['feature_id'].unique()[:5]}")
    logger.info(f"[{log_id}] [cf] Unique feature_id_binned values after merge: {final_recommendations['feature_id_binned'].unique()[:5]}")
    logger.info(f"[{log_id}] [cf] Unique context_feature_id values after merge: {final_recommendations['context_feature_id'].unique()[:5]}")

    # تسجيل الحالات التي بقيت manual_review أو فارغة
    manual_mask = (
        final_recommendations['feature_id_binned'].isnull() |
        (final_recommendations['feature_id_binned'] == 'manual_review') |
        final_recommendations['context_feature_id'].isnull() |
        (final_recommendations['context_feature_id'] == 'manual_review')
    )
    if manual_mask.any():
        manual_cases = final_recommendations[manual_mask][["patient_id", "feature_id", "feature_id_binned", "context_feature_id"]].head(10).to_dict(orient="records")
        logger.warning(f"[{log_id}] [cf] Found {manual_mask.sum()} cases with missing or manual_review feature_id_binned/context_feature_id. Sample: {manual_cases}")

    # تحقق من السكيمة النهائية
    check_schema(final_recommendations, required_columns=final_columns, log_id=log_id, logger=logger)

    if final_recommendations.empty:
        logger.warning(f"[{log_id}] ⚠️ No recommendations generated from either CF or cold start methods. Returning empty DataFrame.")
        print(f"[{log_id}] WARNING: final_recommendations is empty. Columns count: {len(final_columns)}, Columns names: {final_columns}")
        # إرجاع DataFrame فارغ بالأعمدة المطلوبة
        empty_df = pd.DataFrame(columns=final_columns)
        empty_stats = {
            "total_patients": len(df_train[patient_col].unique()),
            "patients_with_recommendations": 0,
            "patients_missing_recommendations": len(df_train[patient_col].unique()),
            "reason_distribution": {},
            "sample_missing_patients": list(df_train[patient_col].unique())[:10]
        }
        return empty_df, used_cold_start, empty_stats

    if used_cold_start:
        logger.info(f"[{log_id}] ✅ Total recommendations after merging with cold start: {len(final_recommendations)}")
    else:
        logger.info(f"[{log_id}] ✅ Total recommendations from CF only: {len(final_recommendations)}")

    # --- سجل توزيع الأسباب لتسهيل التحليل في Streamlit ---
    reason_dist = final_recommendations['reason'].value_counts().to_dict()
    logger.info(f"[{log_id}] Recommendation reason distribution: {reason_dist}")

    # Align logs with the FINAL output
    final_patients = set(final_recommendations[patient_col].unique())
    cf_patients_set = set(top_recommendations_cf[patient_col].unique())
    cold_only_patients = final_patients - cf_patients_set
    logger.info(f"[{log_id}] 🔹 عدد المرضى بتوصيات CF حقيقية (في الناتج النهائي): {len(cf_patients_set)}")
    logger.info(f"[{log_id}] 🔸 عدد المرضى بتوصيات cold_start فقط (في الناتج النهائي): {len(cold_only_patients)}")
    logger.info(f"[{log_id}] 🔢 نسبة توصيات cold_start: { (len(cold_only_patients) / max(1, len(final_patients))) :.2%} من المرضى")

    # --- سجل المرضى الذين لم يحصلوا على أي توصية بعد كل الفلترة ---
    patients_with_recommendations = set(final_recommendations[patient_col].unique())
    all_patients = set(df_train[patient_col].unique())
    missing_patients = all_patients - patients_with_recommendations
    if missing_patients:
        logger.warning(
            f"[{log_id}] ⚠️ {len(missing_patients)} patients did NOT receive any recommendation after all filters. "
            f"Sample: {list(missing_patients)[:10]}"
        )
    # --- بناء dict إحصائي شامل لإرجاعه بجانب النتائج ---
    recommendation_stats = {
        "total_patients": len(all_patients),
        "patients_with_recommendations": len(patients_with_recommendations),
        "patients_missing_recommendations": len(missing_patients),
        "reason_distribution": reason_dist,
        "sample_missing_patients": list(missing_patients)[:10],
        "coverage": {
            "k": int(top_n),
            "n_patients_covered": int(n_patients_cov),
            "pct_patients_ge_k": float(pct_ge_k),
            "min_recs": int(min_recs),
            "max_recs": int(max_recs),
            "avg_recs": float(avg_recs)
        },
        "cf_vs_cold_start": {
            "patients_with_cf": len(cf_patients_set),
            "patients_cold_only": len(cold_only_patients),
            "pct_cold_only": (len(cold_only_patients) / max(1, len(final_patients)))
        }
    }

    logger.info(f"[{log_id}] ✅ CF coverage tuning applied (raw_pool_cap={int(raw_pool_cap)}, relax_threshold={bool(relax_threshold)})")
    return final_recommendations, used_cold_start, recommendation_stats