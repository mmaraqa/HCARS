# -*- coding: utf-8 -*-
"""
hybrid.py — وحدات CF+CBF هجينة موثوقة سريريًا:
- توحيد المخطط
- معايرة احتمالية (Isotonic مع fallback للهوية)
- أوزان مجموعات (اختياري)
- دمج scores مع ضبط بالـ sim_norm
- بوابات سريرية مسبقة
- تنويع وفكّ تعادلات
- Top-K + سبب هجين
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, Iterable, List, Optional, Tuple, Hashable
import numpy as np
import pandas as pd

# Add re import near top with other imports
import re

# ---------- Hybrid advice / constants ----------
from utils.constants import (
    clean_source_text,
    get_guideline_tags,
    pick_constant_for_feature,
    pick_lifestyle_defaults,
    ADVICE_FALLBACK,
    is_pharmacologic_feature,   # NEW
    is_lifestyle_feature,       # NEW
)

import json
# Thresholds & bucketing constants (same package)
from utils import constants

# ---------- Logger Setup ----------

import logging
logger = logging.getLogger("hybrid")
if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | hybrid | %(message)s"))
    logger.addHandler(_handler)
logger.setLevel(logging.INFO)

# --- File logging: persist to logs/hybrid.log with rotation ---
import os
from logging.handlers import RotatingFileHandler

try:
    _LOG_DIR = "logs"
    os.makedirs(_LOG_DIR, exist_ok=True)
    _hyb_log_path = os.path.join(_LOG_DIR, "hybrid.log")

    # Avoid adding duplicate file handlers (idempotent import/exec)
    _has_hybrid_fh = False
    for _h in logger.handlers:
        if isinstance(_h, RotatingFileHandler):
            bf = getattr(_h, "baseFilename", None)
            if isinstance(bf, str) and os.path.basename(bf) == "hybrid.log":
                _has_hybrid_fh = True
                break

    if not _has_hybrid_fh:
        _file_handler = RotatingFileHandler(
            _hyb_log_path,
            maxBytes=2_000_000,  # ~2MB
            backupCount=5,
            encoding="utf-8"
        )
        _file_handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | hybrid | %(message)s"))
        _file_handler.setLevel(logging.INFO)
        logger.addHandler(_file_handler)

    # Prevent double-propagation if root logger has handlers
    logger.propagate = False
    logger.setLevel(logging.INFO)
except (OSError, ValueError) as _log_ex:
    # Fail-safe: keep console logging only
    logger.debug("hybrid.py: file logging setup skipped: %s", _log_ex)


# Precompiled regexes for provenance/diagnostic phrases (used in _is_provenance_phrase)
PROVENANCE_PATTERNS = [
    r"exact/context match",
    r"exact match",
    r"context match",
    r"knn",
    r"nearest",
    r"\bcbf\b",
    r"تطابق\s+مباشر/سياقي",
    r"توصية\s+قائمة\s+على\s+أقرب\s+سياقات\s+مشابهة",
    r"سياقات\s+مشابهة",
]
PROVENANCE_REGEXES = []
for _pat in PROVENANCE_PATTERNS:
    try:
        PROVENANCE_REGEXES.append(re.compile(_pat, re.IGNORECASE))
    except re.error:
        # Skip invalid patterns defensively
        pass


# ================== String Cleaning Helper ==================
def _clean_str_series(series_in: pd.Series) -> pd.Series:
    # Convert to string then blank out placeholders like 'nan', 'none', 'null'
    ser = series_in.astype("string")
    ser = ser.str.strip()
    # remove placeholder tokens
    ser = ser.replace({r"^(?i:na|nan|none|null)$": ""}, regex=True)
    # remove any trailing ", true"/", false" artifacts
    ser = ser.str.replace(r"(?:,\s*)?(?:true|false)\s*$", "", regex=True)
    # collapse duplicate whitespace
    ser = ser.str.replace(r"\s{2,}", " ", regex=True)
    return ser.fillna("")

# ================== الإعداد ==================

@dataclass
class HybridConfig:
    key_cols: Tuple[str, str] = ("patient_id", "feature_id")

    cf_score_col: str = "score_cf"
    cbf_score_col: str = "score_cbf"
    cbf_sim_col: str = "sim_norm"

    # لم نعد نعتمد على أعمدة سياقية خارجية (bp/chol/risk) في منطق الهجين
    bp_col: str = "bp_category"  # تبقى للأرشفة فقط إن وُجدت
    chol_col: str = "chol_category"
    risk_col: str = "risk_level"
    age_group_col: Optional[str] = "age_group"

    cf_reason_col: str = "reason_cf"
    cbf_reason_col: str = "reason_cbf"
    cf_expl_col: str = "explanation_cf"
    cbf_expl_col: str = "explanation_cbf"
    cbf_expl_clin_col: str = "explanation_clinical_cbf"
    cf_source_col: str = "source_cf"
    cbf_source_col: str = "source_cbf"

    # Unified provenance fields
    status_cf_col: str = "status_cf"
    source_cbf_norm_col: str = "source_cbf_norm"
    source_unified_col: str = "source_unified"

    # probability/score/rank column names
    p_cf_col: str = "p_cf"
    p_cbf_col: str = "p_cbf"
    hybrid_score_col: str = "hybrid_score"
    hybrid_rank_col: str = "rank_hybrid"

    # blending & modulation settings
    global_weight_cf: float = 0.50
    sim_mod_intercept: float = 0.5
    sim_mod_slope: float = 0.5  # g(sim) = 0.5..1.0 حين sim∈[0..1]

    # similarity thresholds (for YAML-driven boost/damp of CBF)
    sim_boost_threshold: float = 0.70
    sim_boost_factor: float = 1.10
    sim_damp_threshold: float = 0.30
    sim_damp_factor: float = 0.90

    rrf_k: int = 60

    # diversification controls
    max_per_bin: Optional[int] = None
    bin_col: Optional[str] = None
    prefer_reason_order: Tuple[str, ...] = ("context_key_match", "knn_recommendation", "knn_fallback")

    # regex patterns (non-capturing) to silence pandas warnings
    pharm_pattern: str = (
        r"(?:statin|ace|arb|amlodipine|losartan|lisinopril|valsartan|metoprolol|beta|thiazide|diuretic|hydrochloro)"
    )
    lifestyle_pattern: str = r"(?:diet|exercise|weight|salt|sodium|smoking|lifestyle|monitor|sleep)"

    # clinical gate toggles
    gateA_block_pharm: bool = True
    gateD_downweight_pharm: bool = True
    gateE_low_sim_threshold: float = 0.15

    # New fields for group weight and prior configuration
    group_tau: float = 20.0
    balance_prior_enabled: bool = False
    balance_prior_alpha: float = 0.0
# ================== مساعدات ==================

def _normalize_cf_status(text: str) -> str:
    # Handle real NaNs and placeholder strings
    if text is None or (isinstance(text, float) and pd.isna(text)):
        return ""
    txt = str(text).strip().lower()
    if txt in {"", "nan", "none", "null"}:
        return ""
    if "cold" in txt or "default" in txt:
        return "cold_start_safe_default"
    if "collab" in txt or "collaborative" in txt or "matrix" in txt:
        return "collaborative_filtering"
    return ""

def _normalize_cbf_source(text: str) -> str:
    if text is None or (isinstance(text, float) and pd.isna(text)):
        return ""
    txt = str(text).strip().lower()
    if txt in {"", "nan", "none", "null"}:
        return ""
    if "context" in txt or "exact" in txt or "match" in txt:
        return "CBF (exact/context match)"
    if "fallback" in txt:
        return "CBF (fallback)"
    if "knn" in txt or "nearest" in txt:
        return "CBF (kNN)"
    if "cbf" in txt or "content" in txt or "similar" in txt:
        return "CBF (kNN)"
    return ""



# ================== مساعدات ==================

def _to_num(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce")

def _contains(series: pd.Series, pattern: str) -> pd.Series:
    return series.astype(str).str.contains(pattern, case=False, regex=True, na=False)

def _safe_bool(s: pd.Series) -> pd.Series:
    return s.fillna(False)

def _group_key(df: pd.DataFrame, cfg: HybridConfig) -> pd.Series:
    cols = [c for c in [cfg.bp_col, cfg.chol_col] if c in df.columns]
    if not cols:
        return pd.Series(["__ALL__"] * len(df), index=df.index)
    return df[cols].astype(str).agg("|".join, axis=1)


# ================== 1) توحيد المخطط ==================

def unify_schema(
    df_cf: pd.DataFrame,
    df_cbf: pd.DataFrame,
    df_ctx: Optional[pd.DataFrame],  # kept for backward-compat; currently unused
    cfg: HybridConfig,
) -> pd.DataFrame:
    _ = df_ctx  # suppress 'unused parameter' linter warning
    pid, fid = cfg.key_cols

    # CF
    cf_map = {
        "patient_id": pid,
        "feature_id": fid,
        "score_cf": cfg.cf_score_col,
        "reason": cfg.cf_reason_col,
        "explanation": cfg.cf_expl_col,
        "explanation_clinical": "explanation_clinical_cf",
        "source": cfg.cf_source_col,
        "status": cfg.status_cf_col,
        "true_response": "true_response",
        "feature_id_binned": "feature_id_binned",
        "context_feature_id": "context_feature_id",
    }
    cf_keep = [v for k, v in cf_map.items() if k in df_cf.columns]
    df_cf_u = df_cf.rename(columns={k: v for k, v in cf_map.items() if k in df_cf.columns})
    df_cf_u = df_cf_u[cf_keep].copy() if cf_keep else pd.DataFrame(columns=[pid, fid])

    # CBF
    cbf_map = {
        "patient_id": pid,
        "feature_id": fid,
        "score_cbf": cfg.cbf_score_col,
        "sim_norm": cfg.cbf_sim_col,
        "similarity": "similarity",
        "max_similarity": "max_similarity",
        "reason": cfg.cbf_reason_col,
        "explanation": cfg.cbf_expl_col,
        "explanation_clinical": cfg.cbf_expl_clin_col,
        "source": cfg.cbf_source_col,
        "bp_category": cfg.bp_col,
        "chol_category": cfg.chol_col,
        "risk_level": cfg.risk_col,
        "age_group": cfg.age_group_col if cfg.age_group_col else "age_group",
        "true_response": "true_response",
    }
    cbf_keep = [v for k, v in cbf_map.items() if k in df_cbf.columns]
    df_cbf_u = df_cbf.rename(columns={k: v for k, v in cbf_map.items() if k in df_cbf.columns})
    df_cbf_u = df_cbf_u[cbf_keep].copy() if cbf_keep else pd.DataFrame(columns=[pid, fid])

    base = pd.merge(df_cf_u, df_cbf_u, on=[pid, fid], how="outer", suffixes=("_cf", "_cbf"))
    # --- HARD GUARD: drop sensitive labels from the unified frame to prevent leakage
    for _sens in ("true_response", "target", "y_true", "label", "ground_truth"):
        if _sens in base.columns:
            base = base.drop(columns=[_sens])

    # لا نربط أعمدة سياقية هنا بعد الآن (تبقى الإطار كما هو)

    # --- Normalize provenance fields (CF status & CBF source) and build unified source string ---
    if cfg.status_cf_col in base.columns:
        base[cfg.status_cf_col] = _clean_str_series(base[cfg.status_cf_col]).map(_normalize_cf_status)

    # Prefer reason_cbf then source_cbf for normalization
    if cfg.cbf_reason_col in base.columns or cfg.cbf_source_col in base.columns:
        raw_reason = _clean_str_series(base.get(cfg.cbf_reason_col, pd.Series("", index=base.index)))
        raw_source = _clean_str_series(base.get(cfg.cbf_source_col, pd.Series("", index=base.index)))
        cbf_text = raw_reason.where(raw_reason.astype(bool), raw_source)
        base[cfg.source_cbf_norm_col] = cbf_text.map(_normalize_cbf_source)

    # Build unified source text e.g., "(CF) collaborative_filtering | (CBF) exact/context match"
    def _build_unified_source(row: pd.Series) -> str:
        parts: List[str] = []
        s_cf = row.get(cfg.status_cf_col, "")
        if isinstance(s_cf, str) and s_cf:
            parts.append(f"(CF) {s_cf}")
        s_cbf = row.get(cfg.source_cbf_norm_col, "")
        if isinstance(s_cbf, str) and s_cbf:
            parts.append(s_cbf)  # already normalized to include "CBF (...)" variants
        return " | ".join(p for p in parts if p)

    base[cfg.source_unified_col] = base.apply(_build_unified_source, axis=1)
    # Drop rows where unified text would contain '(CF) nan' artifact (defensive), and blank it instead
    base[cfg.source_unified_col] = base[cfg.source_unified_col].str.replace(r"\(CF\)\s*nan\s*\|\s*", "", regex=True).str.replace(r"\s*\|\s*\Z", "", regex=True)
    # Normalize unified source text
    base[cfg.source_unified_col] = base[cfg.source_unified_col].map(clean_source_text)

    return base


# ================== 2) المعايرة ==================

def fit_isotonic_calibrator(scores: pd.Series, labels: pd.Series) -> Callable[[pd.Series], np.ndarray]:
    try:
        from sklearn.isotonic import IsotonicRegression  # type: ignore
    except ImportError:
        # Identity calibrator, preserve NaNs
        return lambda z: _to_num(z).values

    x = _to_num(scores)
    y = _to_num(labels).fillna(0).astype(int)
    mask = x.notna() & y.notna()
    if mask.sum() < 20:
        # Identity calibrator, preserve NaNs
        return lambda z: _to_num(z).values

    iso = IsotonicRegression(out_of_bounds="clip")
    iso.fit(x[mask].values, y[mask].values)

    def _cal(z: pd.Series) -> np.ndarray:
        zz = _to_num(z)
        out = np.full(len(zz), np.nan, dtype=float)
        m2 = zz.notna().values
        if m2.any():
            out[m2] = np.clip(iso.predict(zz[m2].values), 0.0, 1.0)
        return out

    return _cal


def fit_calibrators_from_eval(
    eval_cf: Optional[pd.DataFrame],
    eval_cbf: Optional[pd.DataFrame],
    cfg: HybridConfig,
    isotonic_min_samples: int = 20,
) -> Tuple[Callable[[pd.Series], np.ndarray], Callable[[pd.Series], np.ndarray]]:
    # CF
    if (
        eval_cf is not None
        and cfg.cf_score_col in eval_cf.columns
        and "true_response" in eval_cf.columns
        and len(eval_cf) >= isotonic_min_samples
    ):
        cal_cf = fit_isotonic_calibrator(eval_cf[cfg.cf_score_col], eval_cf["true_response"])
    else:
        cal_cf = lambda z: _to_num(z).values

    # CBF
    if (
        eval_cbf is not None
        and cfg.cbf_score_col in eval_cbf.columns
        and "true_response" in eval_cbf.columns
        and len(eval_cbf) >= isotonic_min_samples
    ):
        cal_cbf = fit_isotonic_calibrator(eval_cbf[cfg.cbf_score_col], eval_cbf["true_response"])
    else:
        cal_cbf = lambda z: _to_num(z).values

    return cal_cf, cal_cbf


# ================== 3) أوزان المجموعات (اختياري) ==================

def compute_group_weights(
    eval_cf: Optional[pd.DataFrame],
    eval_cbf: Optional[pd.DataFrame],
    cfg: HybridConfig,
    metric: str = "ndcg",
    k: int = 5,
) -> Tuple[Dict[str, Tuple[float, float]], float, float]:
    def _score(eval_df: pd.DataFrame, score_col: str) -> Dict[str, float]:
        if eval_df is None or score_col not in eval_df.columns or "true_response" not in eval_df.columns:
            return {}
        d = eval_df.copy()
        d["gkey"] = _group_key(d, cfg)
        pid = cfg.key_cols[0]
        d = d.sort_values(["gkey", pid, score_col], ascending=[True, True, False])
        d["rank"] = d.groupby(["gkey", pid]).cumcount() + 1

        met = (metric or "ndcg").lower()
        if met == "precision":
            # Precision@k per group = mean of labels in top-k within each group
            topk = d[d["rank"] <= k].copy()
            by_group = topk.groupby("gkey")["true_response"].mean().to_dict()
            return {g: float(v) for g, v in by_group.items()}

        # Default: ndcg-like (use DCG proxy due to missing ideal normalization)
        d["dcg"] = (pd.to_numeric(d["true_response"], errors="coerce").fillna(0).astype(int) / np.log2(d["rank"] + 1))
        agg = d[d["rank"] <= k].groupby("gkey")["dcg"].sum().to_dict()
        return agg

    cf_meas = _score(eval_cf, cfg.cf_score_col)
    cbf_meas = _score(eval_cbf, cfg.cbf_score_col)
    groups = set(cf_meas.keys()) | set(cbf_meas.keys())
    if not groups:
        return {}, 0.5, 0.5

    weights: Dict[str, Tuple[float, float]] = {}
    for gkey in groups:
        v_cf = cf_meas.get(gkey, 0.0)
        v_cbf = cbf_meas.get(gkey, 0.0)
        s = v_cf + v_cbf
        if s <= 0:
            weights[gkey] = (0.5, 0.5)
        else:
            w_cf = float(v_cf / s)
            w_cbf = 1.0 - w_cf
            weights[gkey] = (w_cf, w_cbf)

    # --- Bayesian shrinkage of group weights toward global CF weight ---
    # Estimate per-group sample sizes from eval frames (use max count across CF/CBF for stability)
    def _group_counts(eval_df: Optional[pd.DataFrame]) -> Dict[str, int]:
        if eval_df is None or cfg.cf_score_col not in eval_df.columns or "true_response" not in eval_df.columns:
            # We'll still allow counts from CBF eval below; this is a coarse guard
            pass
        if eval_df is None or len(eval_df) == 0:
            return {}
        dcnt = eval_df.copy()
        dcnt["gkey"] = _group_key(dcnt, cfg)
        return dcnt.groupby("gkey").size().to_dict()

    counts_cf = _group_counts(eval_cf)
    counts_cbf = _group_counts(eval_cbf)

    try:
        tau = float(getattr(cfg, "group_tau", 20.0))
    except (TypeError, ValueError):
        tau = 20.0
    w_global = float(cfg.global_weight_cf)

    for gkey in list(weights.keys()):
        w_cf_emp = float(weights[gkey][0])  # empirical CF weight for this group
        n_g = max(int(counts_cf.get(gkey, 0)), int(counts_cbf.get(gkey, 0)))
        # Bayesian shrinkage toward global CF weight
        w_cf_smoothed = (n_g / (n_g + tau)) * w_cf_emp + (tau / (n_g + tau)) * w_global
        w_cf = float(np.clip(w_cf_smoothed, 0.0, 1.0))
        w_cbf = float(1.0 - w_cf)
        weights[gkey] = (w_cf, w_cbf)

    # --- balance prior towards 0.5 + soft clamps ---
    try:
        # Try to read nested dict (if cfg carries a raw config dict), else fall back to cfg attributes
        hyb_cfg = getattr(cfg, "hybrid_config_dict", {}) if hasattr(cfg, "hybrid_config_dict") else {}
        bal_cfg = (hyb_cfg.get("hybrid", {}) or {}).get("balance_prior", {}) or {}
        balance_enabled = bool(bal_cfg.get("enabled", getattr(cfg, "balance_prior_enabled", False)))
        alpha = float(bal_cfg.get("alpha", getattr(cfg, "balance_prior_alpha", 0.0)))
    except (AttributeError, TypeError, ValueError, KeyError):
        balance_enabled = bool(getattr(cfg, "balance_prior_enabled", False))
        alpha = float(getattr(cfg, "balance_prior_alpha", 0.0))

    alpha = float(np.clip(alpha, 0.0, 1.0))

    if balance_enabled and alpha > 0.0:
        # Pull every group's CF weight softly toward 0.5
        for gk in list(weights.keys()):
            w_cf = float(weights[gk][0])
            w_cf = (1.0 - alpha) * w_cf + alpha * 0.5
            w_cf = float(np.clip(w_cf, 0.0, 1.0))
            weights[gk] = (w_cf, 1.0 - w_cf)

    # soft clamp to avoid dominance: keep CF within [0.35, 0.65]
    lo, hi = 0.35, 0.65
    for gk in list(weights.keys()):
        w_cf = float(np.clip(weights[gk][0], lo, hi))
        weights[gk] = (w_cf, 1.0 - w_cf)

    # Recompute global weights after smoothing
    w_cf_global = float(np.mean([w[0] for w in weights.values()])) if weights else 0.5
    w_cbf_global = 1.0 - w_cf_global
    logger.info("[HYB] Group weights computed using metric='%s' over %d groups. Global CF=%.3f, CBF=%.3f",
                metric, len(weights), w_cf_global, w_cbf_global)
    return weights, w_cf_global, w_cbf_global


# ================== 4) الدمج ==================

def reciprocal_rank_fusion(rank_cf: Optional[int], rank_cbf: Optional[int], k_const: int) -> float:
    score = 0.0
    if rank_cf is not None and np.isfinite(rank_cf):
        score += 1.0 / (k_const + rank_cf)
    if rank_cbf is not None and np.isfinite(rank_cbf):
        score += 1.0 / (k_const + rank_cbf)
    return score

def apply_calibrators(df: pd.DataFrame, cal_cf: Callable, cal_cbf: Callable, cfg: HybridConfig) -> pd.DataFrame:
    d = df.copy()
    # CF
    d[cfg.p_cf_col] = np.nan
    if cfg.cf_score_col in d.columns:
        s_cf = _to_num(d[cfg.cf_score_col])
        m_cf = s_cf.notna()
        if m_cf.any():
            out_cf = pd.Series(cal_cf(s_cf[m_cf]), index=d.index[m_cf])
            d.loc[m_cf, cfg.p_cf_col] = out_cf.values
    # CBF
    d[cfg.p_cbf_col] = np.nan
    if cfg.cbf_score_col in d.columns:
        s_cbf = _to_num(d[cfg.cbf_score_col])
        m_cbf = s_cbf.notna()
        if m_cbf.any():
            out_cbf = pd.Series(cal_cbf(s_cbf[m_cbf]), index=d.index[m_cbf])
            d.loc[m_cbf, cfg.p_cbf_col] = out_cbf.values
    return d

def blend_scores(
    df_u: pd.DataFrame,
    cal_cf: Callable[[pd.Series], np.ndarray],
    cal_cbf: Callable[[pd.Series], np.ndarray],
    cfg: HybridConfig,
    group_weights: Optional[Dict[str, Tuple[float, float]]] = None,
    w_cf_global: Optional[float] = None,
) -> pd.DataFrame:
    d = apply_calibrators(df_u, cal_cf, cal_cbf, cfg)

    # Diagnostics: record active modulation/threshold params (no shadowing, no unresolved refs)
    log = logger if isinstance(logger, logging.Logger) else None
    if log is not None:
        try:
            log.debug(
                "[HYB] sim_mod: intercept=%.2f slope=%.2f | thresholds: boost_thr=%.2f boost=%.2f damp_thr=%.2f damp=%.2f",
                float(cfg.sim_mod_intercept), float(cfg.sim_mod_slope),
                float(getattr(cfg, "sim_boost_threshold", 0.70)), float(getattr(cfg, "sim_boost_factor", 1.10)),
                float(getattr(cfg, "sim_damp_threshold", 0.30)), float(getattr(cfg, "sim_damp_factor", 0.90))
            )
        except (TypeError, ValueError, AttributeError):
            pass

    sim_src = d[cfg.cbf_sim_col] if cfg.cbf_sim_col in d.columns else pd.Series([np.nan] * len(d), index=d.index)
    sim_series = pd.to_numeric(sim_src, errors="coerce")
    sim_gain = (cfg.sim_mod_intercept + cfg.sim_mod_slope * sim_series.fillna(0.0)).clip(0.0, 1.5)

    base_w_cf = cfg.global_weight_cf if (w_cf_global is None) else float(w_cf_global)
    if group_weights:
        gk = _group_key(d, cfg)
        w_cf_series = gk.map({k: v[0] for k, v in group_weights.items()}).fillna(base_w_cf)
    else:
        w_cf_series = pd.Series([base_w_cf] * len(d), index=d.index)

    # Optional cap: prevent CF from fully dominating due to noisy group weights
    w_cf_series = pd.to_numeric(w_cf_series, errors="coerce").fillna(cfg.global_weight_cf).clip(upper=0.80)

    w_cbf_series = 1.0 - w_cf_series
    # --- Safety clamp: ensure CBF keeps a non-trivial contribution ---
    min_cbf = 0.20
    w_cbf_series = w_cbf_series.clip(lower=min_cbf)
    w_cf_series  = 1.0 - w_cbf_series

    # ---- Dynamic CBF local reweight (sim-aware) ----
    # Use configured similarity column if present; otherwise fall back to 'sim_norm'
    _sim_src = d[cfg.cbf_sim_col] if cfg.cbf_sim_col in d.columns else d.get("sim_norm")
    if not isinstance(_sim_src, pd.Series):
        _sim_src = pd.Series(_sim_src, index=d.index)
    _sim = pd.to_numeric(_sim_src, errors="coerce").fillna(0.0)

    # High/low similarity masks using constants/cfg thresholds
    _high_sim_mask = _sim >= float(getattr(constants, "SIM_HIGH_MIN", 0.70))
    _low_sim_mask  = _sim <  float(getattr(cfg, "sim_damp_threshold", 0.30))

    # Current weights as arrays (with robust defaults)
    _w_cf  = pd.to_numeric(w_cf_series,  errors="coerce").fillna(0.5).to_numpy()
    _w_cbf = pd.to_numeric(w_cbf_series, errors="coerce").fillna(0.5).to_numpy()

    # Factors (boost and damp) from cfg with safe fallbacks
    _boost_factor = float(getattr(cfg, "sim_boost_factor", 1.10))
    _damp_factor  = float(getattr(cfg, "sim_damp_factor", 0.90))

    # Adjust CBF weight up for high similarity, down for very low similarity
    _w_cbf_adj = _w_cbf.copy()
    if np.any(_high_sim_mask):
        _w_cbf_adj[_high_sim_mask] *= _boost_factor
    if np.any(_low_sim_mask):
        _w_cbf_adj[_low_sim_mask]  *= _damp_factor

    # Renormalize safely
    _w_sum = _w_cf + _w_cbf_adj
    _w_sum[_w_sum <= 0] = 1.0  # guard divide-by-zero

    w_cf_series  = (_w_cf      / _w_sum).clip(0.0, 1.0)
    w_cbf_series = (_w_cbf_adj / _w_sum).clip(0.0, 1.0)

    p_cf_raw = _to_num(d[cfg.p_cf_col])
    p_cf = p_cf_raw.fillna(0.0)
    p_cbf_raw = _to_num(d[cfg.p_cbf_col])
    p_cbf = p_cbf_raw.fillna(0.0)

    # --- Floor for calibrated CBF probability to avoid near-zero collapse when eval is tiny ---
    try:
        min_floor = float(getattr(cfg, "min_floor", 0.05))
    except (TypeError, ValueError):
        min_floor = 0.05
    p_cbf = p_cbf.clip(lower=min_floor)

    # --- Similarity-based modulation for CBF (boost high, damp low; both capped) ---
    try:
        sim_boost_threshold = float(getattr(cfg, "sim_boost_threshold", 0.70))
        sim_boost_factor = float(getattr(cfg, "sim_boost_factor", 1.10))
    except (TypeError, ValueError):
        sim_boost_threshold, sim_boost_factor = 0.70, 1.10
    try:
        sim_damp_threshold = float(getattr(cfg, "sim_damp_threshold", 0.30))
        sim_damp_factor = float(getattr(cfg, "sim_damp_factor", 0.90))
    except (TypeError, ValueError):
        sim_damp_threshold, sim_damp_factor = 0.30, 0.90

    boost_mask = sim_series > sim_boost_threshold
    damp_mask  = sim_series < sim_damp_threshold

    if boost_mask.any():
        p_cbf = np.minimum(1.0, p_cbf * np.where(boost_mask, sim_boost_factor, 1.0))
    if damp_mask.any():
        p_cbf = np.clip(p_cbf * np.where(damp_mask, sim_damp_factor, 1.0), 0.0, 1.0)

    d[cfg.hybrid_score_col] = (w_cf_series * p_cf) + (w_cbf_series * sim_gain * p_cbf)
    d["weight_cf"] = w_cf_series
    d["weight_cbf"] = w_cbf_series
    # confidence = absolute disagreement between calibrated sources; only when both exist
    conf = pd.Series(np.nan, index=d.index, dtype="float64")
    both_mask = p_cf_raw.notna() & p_cbf_raw.notna()
    conf.loc[both_mask] = (p_cf_raw.loc[both_mask] - p_cbf_raw.loc[both_mask]).abs()
    d["confidence"] = conf

    return d


# ================== 5) بوابات سريرية ==================

def apply_clinical_gates(df_in, cfg):
    from utils.constants import is_pharmacologic_feature, is_lifestyle_feature  # ensure available

    d = df_in.copy()
    if "clinical_flags" not in d.columns:
        d["clinical_flags"] = ""

    # --- helper to append a clinical flag once ---
    def _add_flag(mask: pd.Series, label: str):
        if not isinstance(mask, pd.Series) or mask.empty:
            return
        idx = mask[mask].index
        if len(idx) == 0:
            return
        d.loc[idx, "clinical_flags"] = (
            d.loc[idx, "clinical_flags"].astype(str) + ";" + label
        ).str.strip(";")

    # Common numeric series we will reuse
    conf_series = pd.to_numeric(d.get("confidence", np.nan), errors="coerce").fillna(0.0)
    p_cf_series = pd.to_numeric(d.get("p_cf", np.nan), errors="coerce")
    advice_type_ser = d.get("advice_type", pd.Series("", index=d.index)).astype(str).str.lower().str.strip()

    # Common feature and score series
    fid_col = getattr(cfg, "key_cols", ("patient_id","feature_id"))[1]
    fid_ser = d.get(fid_col, pd.Series("", index=d.index)).astype(str).str.lower()
    score_col = getattr(cfg, "hybrid_score_col", "hybrid_score")
    score_ser = pd.to_numeric(d.get(score_col, np.nan), errors="coerce").fillna(0.0)

    # Lifestyle detector mask
    lifestyle_mask = fid_ser.apply(is_lifestyle_feature)

    # ---- Gate E: downweight when similarity is low; respect optional treat_nan_as_low ----
    sim_col = getattr(cfg, "cbf_sim_col", "sim_norm")
    sim_series = pd.to_numeric(d.get(sim_col, np.nan), errors="coerce")
    thr = float(getattr(cfg, "gateE_low_sim_threshold", 0.15))
    treat_nan_as_low = False
    if "_gateE_treat_nan_as_low" in d.columns and len(d) > 0:
        try:
            treat_nan_as_low = bool(d["_gateE_treat_nan_as_low"].iloc[0])
        except (IndexError, TypeError, ValueError):
            treat_nan_as_low = False

    low_sim_mask = sim_series.lt(thr)
    if treat_nan_as_low:
        low_sim_mask = low_sim_mask | sim_series.isna()

    if low_sim_mask.any():
        score_col = getattr(cfg, "hybrid_score_col", "hybrid_score")
        d.loc[low_sim_mask, score_col] = pd.to_numeric(d.get(score_col, 0), errors="coerce").fillna(0.0) * 0.97
        d.loc[low_sim_mask, "clinical_flags"] = (
            d.loc[low_sim_mask, "clinical_flags"].astype(str) + ";low_similarity_downweight"
        ).str.lstrip(";")

    # ---- Gate P: slight upweight for pharmacologic when CBF truly absent ----
    pid, fid = getattr(cfg, "key_cols", ("patient_id", "feature_id"))
    pharm_mask = d.get(fid, pd.Series("", index=d.index)).astype(str).apply(is_pharmacologic_feature)

    # مصادر الاشتقاق
    p_cbf_series = pd.to_numeric(d.get("p_cbf", np.nan), errors="coerce").fillna(0.0)
    sim_series   = pd.to_numeric(d.get(getattr(cfg, "cbf_sim_col", "sim_norm"), np.nan), errors="coerce").fillna(0.0)
    src_unified  = d.get("source_unified", pd.Series("", index=d.index)).astype(str)

    # cbf_present الأصلي (إن وُجد)
    cbf_present_series = pd.to_numeric(d.get("cbf_present", 0), errors="coerce").fillna(0).astype(int)

    # fallback اشتقاقي: يعتبر وجود CBF إن ظهر أيّ من:
    #   p_cbf > 0.02  OR  sim_norm > 0  OR  وجود "CBF(" في المصدر الموحّد
    derived_cbf_present = (
        (p_cbf_series.gt(0.02)) |
        (sim_series.gt(0.0)) |
        (src_unified.str.contains(r"CBF\s*\(", regex=True, na=False))
    ).astype(int)

    # خذ الأقصى بين الأصلي والمُشتَقّ (idempotent)
    cbf_present_series = np.maximum(cbf_present_series, derived_cbf_present)

    # Gate-P يُفعَّل فقط إذا "لا يوجد CBF حقّاً" + تشابه واحتمال فعلياً صفر
    no_cbf_true = (cbf_present_series.eq(0) & p_cbf_series.le(0.0) & sim_series.le(0.0))

    score_col = getattr(cfg, "hybrid_score_col", "hybrid_score")
    boost_mask = no_cbf_true & pharm_mask
    if boost_mask.any():
        d.loc[boost_mask, score_col] = pd.to_numeric(d.get(score_col, 0), errors="coerce").fillna(0.0) * 1.05
        d.loc[boost_mask, "clinical_flags"] = (
            d.loc[boost_mask, "clinical_flags"].astype(str) + ";gateP_noCBF_slight_upweight"
        ).str.lstrip(";")

    # (اختياري تشخيصياً) احتفظنا بسلسلة cbf_present النهائية لمن يحتاجها downstream
    d["cbf_present"] = cbf_present_series

    # ---- Gate R: high risk / high BP phenotype → annotate context ----
    risk_ser = d.get(getattr(cfg, "risk_col", "risk_level"), pd.Series("", index=d.index)).astype(str).str.lower()
    bp_ser   = d.get(getattr(cfg, "bp_col", "bp_category"), pd.Series("", index=d.index)).astype(str).str.lower()
    gateR_mask = risk_ser.str.contains(r"\b(?:high|very\s*high|stage\s*2)\b", regex=True, na=False) | \
                 bp_ser.str.contains(r"stage\s*2|crisis|severe", regex=True, na=False)
    _add_flag(gateR_mask, "gateR_high_risk")

    # ---- Gate C: high CF–CBF disagreement → monitoring needed (no score change) ----
    try:
        thr_conf = float(getattr(constants, "CONFIDENCE_HIGH_MIN", 0.35))
    except (TypeError, ValueError, AttributeError):
        thr_conf = 0.35
    gateC_mask = conf_series.ge(thr_conf) & p_cf_series.notna() & p_cbf_series.notna()
    _add_flag(gateC_mask, "gateC_high_disagreement")

    # ---- Gate M: monitoring recommended when (high disagreement) OR (very low similarity) ----
    low_sim_mask_hard = sim_series.lt(float(getattr(cfg, "sim_damp_threshold", 0.30)))
    gateM_mask = gateC_mask | low_sim_mask_hard
    _add_flag(gateM_mask, "gateM_monitoring_needed")

    # ---- Gate L: labs recommended (explicit lab advice or tags) ----
    gt_ser = d.get("guideline_tags", pd.Series("", index=d.index)).astype(str)
    gateL_mask = advice_type_ser.eq("lab_order") | gt_ser.str.contains(r"creatinine|egfr|potassium|lipid|a1c|uacr|electrolyte|renal", case=False, regex=True, na=False)
    _add_flag(gateL_mask, "gateL_labs_recommended")

    # ---- Gate S: safety review when advice_type or text hints at safety/contraindication ----
    safety_regexes = getattr(constants, "ADVICE_REGEX", {}).get("safety", [])
    text_blob = (
        d.get("advice_text", pd.Series("", index=d.index)).astype(str) + " | " +
        d.get("hybrid_reason", pd.Series("", index=d.index)).astype(str) + " | " +
        d.get("hybrid_sources", pd.Series("", index=d.index)).astype(str)
    ).str.lower()
    gateS_mask = advice_type_ser.eq("safety")

    for pat_rx in safety_regexes:
        try:
            # Convert any capturing groups `(` to non-capturing `(?:` unless it's already a special group.
            pat_nc = re.sub(r"\((?!\?[:=!<])", r"(?:", str(pat_rx))
            gateS_mask = gateS_mask | text_blob.str.contains(pat_nc, regex=True, flags=re.IGNORECASE, na=False)
        except re.error:
            continue
    _add_flag(gateS_mask, "gateS_safety_review")

    # ---- Gate H: high-similarity CBF marker (diagnostic only) ----
    high_sim_mask = sim_series.ge(float(getattr(constants, "SIM_HIGH_MIN", 0.70)))
    cbf_has_prob  = p_cbf_series.notna()
    _add_flag(high_sim_mask & cbf_has_prob, "gateH_cbf_high_similarity")

    # ---- Gate X: explicit conflict flag passthrough (if already computed upstream) ----
    if "conflict_flag" in d.columns:
        _add_flag(d["conflict_flag"].astype(bool), "gateX_conflict")

    # ---- Optional: CBF-weak (flag only; no score change) ----
    cbf_weak_enabled = False
    cbf_weak_min = 0.30
    if "_cbf_weak_enabled" in d.columns and len(d) > 0:
        try:
            cbf_weak_enabled = bool(d["_cbf_weak_enabled"].iloc[0])
        except (IndexError, TypeError, ValueError):
            cbf_weak_enabled = False
    if "_cbf_weak_min" in d.columns and len(d) > 0:
        try:
            cbf_weak_min = float(d["_cbf_weak_min"].iloc[0])
        except (IndexError, TypeError, ValueError):
            cbf_weak_min = 0.30

    if cbf_weak_enabled:
        p_cbf_series = pd.to_numeric(d.get("p_cbf", np.nan), errors="coerce")
        cbf_present_series = pd.to_numeric(d.get("cbf_present", 0), errors="coerce").fillna(0).astype(int)
        weak_mask = (cbf_present_series == 1) & p_cbf_series.lt(cbf_weak_min)
        if weak_mask.any():
            d.loc[weak_mask, "clinical_flags"] = (
                d.loc[weak_mask, "clinical_flags"].astype(str) + ";cbf_weak"
            ).str.lstrip(";")

    # ---- Gate B: baseline counseling when score reasonable and similarity not extremely low ----
    gateB_mask = score_ser.ge(0.40) & sim_series.ge(float(getattr(cfg, "sim_damp_threshold", 0.30)))
    _add_flag(gateB_mask, "gateB_baseline_counsel")

    # ---- Gate L2: explicit lifestyle counseling for lifestyle features ----
    _add_flag(lifestyle_mask, "gateL_lifestyle_counsel")

    # ---- Gate A2: adherence support for pharmacologic features with solid score ----
    gateA2_mask = pharm_mask & score_ser.ge(0.50)
    _add_flag(gateA2_mask, "gateA_adherence_support")

    # ---- Gate F: follow-up when uncertainty (low disagreement) and mid scores OR very low similarity ----
    gateF_mask = (conf_series.lt(0.15) & score_ser.between(0.30, 0.60, inclusive="both")) | sim_series.lt(float(getattr(cfg, "sim_damp_threshold", 0.30)))
    _add_flag(gateF_mask, "gateF_follow_up")

    # ---- Gate EDU: patient education when non-pharmacologic/non-lifestyle and moderate score ----
    non_pl_mask = (~pharm_mask) & (~lifestyle_mask) & score_ser.ge(0.35)
    _add_flag(non_pl_mask, "gateEdu_patient_education")

    # finalize helper: normalize no-flags to meaningful fallbacks, then 'none'
    empty_mask = d["clinical_flags"].astype(str).str.strip().eq("")
    if empty_mask.any():
        # Prefer lifestyle counsel if feature is lifestyle
        fill_lstyle = empty_mask & lifestyle_mask
        d.loc[fill_lstyle, "clinical_flags"] = "gateL_lifestyle_counsel"

        # Then education if still empty and non-pharm/non-lifestyle with moderate score
        still_empty = d["clinical_flags"].astype(str).str.strip().eq("")
        fill_edu = still_empty & (~pharm_mask) & (~lifestyle_mask) & score_ser.ge(0.35)
        d.loc[fill_edu, "clinical_flags"] = "gateEdu_patient_education"

        # Finally, any remaining empties become 'none'
        still_empty2 = d["clinical_flags"].astype(str).str.strip().eq("")
        d.loc[still_empty2, "clinical_flags"] = "none"

    try:
        d["clinical_flag_count"] = d["clinical_flags"].apply(
            lambda s: 0 if str(s).strip().lower() == "none" else str(s).count(";") + 1
        )
    except (TypeError, ValueError):
        d["clinical_flag_count"] = 0

    # diagnostic log (expanded)
    try:
        n_none  = int(d["clinical_flags"].astype(str).str.strip().str.lower().eq("none").sum())
        n_low   = int((sim_series.lt(thr)).sum())
        n_gate_p = int(boost_mask.sum())
        n_disag = int((conf_series.ge(thr_conf) & p_cf_series.notna() & p_cbf_series.notna()).sum())
        n_mon   = int(gateM_mask.sum())
        n_labs  = int(gateL_mask.sum())
        n_safe  = int(gateS_mask.sum())
        n_highsim = int((high_sim_mask & cbf_has_prob).sum())
        n_base  = int(gateB_mask.sum())
        n_lsty  = int(lifestyle_mask.sum())
        n_adhr  = int(gateA2_mask.sum())
        n_fup   = int(gateF_mask.sum())
        n_edu   = int(non_pl_mask.sum())
        logger.info(
            "[HYB] Clinical flags — none=%d | low_similarity_downweight=%d | gateP_noCBF=%d | disagreement=%d | monitoring=%d | labs=%d | safety=%d | cbf_highsim=%d | baseline=%d | lifestyle=%d | adherence=%d | follow_up=%d | education=%d",
            n_none, n_low, n_gate_p, n_disag, n_mon, n_labs, n_safe, n_highsim, n_base, n_lsty, n_adhr, n_fup, n_edu,
        )
    except (TypeError, ValueError, KeyError):
        pass

    return d

def diversify_and_tiebreak(df: pd.DataFrame, cfg: HybridConfig) -> pd.DataFrame:
    d = df.copy()
    pid, _ = cfg.key_cols

    reason_rank = {r: i for i, r in enumerate(cfg.prefer_reason_order)}

    def _reason_priority(r: pd.Series) -> int:
        r_cbf = str(r.get(cfg.cbf_reason_col, "") or "")
        r_cf = str(r.get(cfg.cf_reason_col, "") or "")
        val = r_cbf if r_cbf else r_cf
        return reason_rank.get(val, len(reason_rank) + 1)

    d["reason_priority"] = d.apply(_reason_priority, axis=1)
    d = d.sort_values([pid, cfg.hybrid_score_col, "reason_priority"], ascending=[True, False, True])

    if cfg.max_per_bin is not None and cfg.bin_col and cfg.bin_col in d.columns:
        sel_idx: List[Hashable] = []
        for _, grp in d.groupby(pid, sort=False):
            counts: Dict[str, int] = {}
            for idx, row_i in grp.iterrows():
                b = str(row_i[cfg.bin_col])
                if counts.get(b, 0) < cfg.max_per_bin:
                    sel_idx.append(idx)
                    counts[b] = counts.get(b, 0) + 1
        d = d.loc[sel_idx].copy()

    return d


# ================== 7) Top-K + RRF احتياطي ==================

def _ranks_within_model(df: pd.DataFrame, score_col: str, cfg: HybridConfig) -> pd.Series:
    pid = cfg.key_cols[0]
    if score_col not in df.columns:
        return pd.Series([np.nan] * len(df), index=df.index)
    tmp = df[[pid, score_col]].copy()
    tmp["rank_tmp"] = tmp.groupby(pid)[score_col].rank(ascending=False, method="first")
    return tmp["rank_tmp"]

def topk_per_patient(df: pd.DataFrame, k: int, cfg: HybridConfig, use_rrf_when_missing: bool = True) -> pd.DataFrame:
    d = df.copy()
    pid = cfg.key_cols[0]

    if use_rrf_when_missing:
        r_cf = _ranks_within_model(d, cfg.cf_score_col, cfg)
        r_cbf = _ranks_within_model(d, cfg.cbf_score_col, cfg)
        if _to_num(d[cfg.hybrid_score_col]).fillna(0).max() <= 0 and (r_cf.notna().any() or r_cbf.notna().any()):
            d["rrf"] = [
                reciprocal_rank_fusion(
                    int(r_cf.iloc[i]) if pd.notna(r_cf.iloc[i]) else None,
                    int(r_cbf.iloc[i]) if pd.notna(r_cbf.iloc[i]) else None,
                    cfg.rrf_k,
                )
                for i in range(len(d))
            ]
            d = d.sort_values([pid, "rrf"], ascending=[True, False])
        else:
            d = d.sort_values([pid, cfg.hybrid_score_col], ascending=[True, False])
    else:
        d = d.sort_values([pid, cfg.hybrid_score_col], ascending=[True, False])

    d[cfg.hybrid_rank_col] = d.groupby(pid).cumcount() + 1
    return d[d[cfg.hybrid_rank_col] <= k].copy()


# ================== Helper: Ensure at least one CBF in Top-K if available ==================

def ensure_one_cbf_if_available(df_top: pd.DataFrame,
                                *,
                                patient_col: str = "patient_id",
                                source_col: str = "advice_source",
                                rank_col: str = "rank_hybrid",
                                score_col: str = "hybrid_score",
                                cbf_pattern: str = r"\bCBF\b",
                                score_thr: float = 0.30) -> pd.DataFrame:
    """
    Ensure that each patient's Top-K contains at least one CBF-backed item if a qualifying CBF
    candidate exists above score_thr. This is a diversity safeguard; it does not increase K.
    - If a patient's current Top-K has zero CBF items but there exists a CBF item for that
      patient within df_top (typically the already-filtered frame), replace the last-ranked
      item with the best-scoring CBF candidate.
    - Uses simple pattern match on `source_col` to detect CBF. Adjust `cbf_pattern` or
      pass a stricter column if available.
    """
    if df_top is None or df_top.empty:
        return df_top
    d = df_top.copy()
    required_cols = {patient_col, source_col, rank_col, score_col}
    if not required_cols.issubset(set(d.columns)):
        return d

    src_is_cbf = d[source_col].astype(str).str.contains(cbf_pattern, case=False, regex=True, na=False)
    # Work per patient
    for pid, grp in d.groupby(patient_col, sort=False):
        has_cbf_in_top = src_is_cbf.loc[grp.index].any()
        if has_cbf_in_top:
            continue
        # Candidates within this patient's rows that look like CBF and pass score threshold
        cand_idx = grp.index[
            src_is_cbf.loc[grp.index] & (pd.to_numeric(grp[score_col], errors="coerce").fillna(0.0) >= score_thr)
        ]
        if len(cand_idx) == 0:
            continue
        # Choose best CBF candidate
        best_cbf_idx = grp.loc[cand_idx].sort_values(score_col, ascending=False).index[0]
        # Replace the last-ranked item (largest rank) with the best CBF candidate
        last_idx = grp.sort_values(rank_col, ascending=False).index[0]
        d.loc[last_idx] = d.loc[best_cbf_idx]
    return d


# ================== 8) أسباب/مصادر هجينة ==================

def attach_hybrid_reason(df: pd.DataFrame, cfg: HybridConfig, tag: str = "blend") -> pd.DataFrame:
    d = df.copy()
    alpha_series = d.get("weight_cf", pd.Series(cfg.global_weight_cf, index=d.index))
    has_rrf = d.get("rrf", pd.Series(np.nan, index=d.index)).notna()

    # Weighted driver: compare weighted contributions instead of raw probabilities
    p_cf_series = pd.to_numeric(d.get(cfg.p_cf_col, np.nan), errors="coerce")
    p_cbf_series = pd.to_numeric(d.get(cfg.p_cbf_col, np.nan), errors="coerce")
    has_cf = p_cf_series.notna()
    has_cbf = p_cbf_series.notna()

    coverage = np.where(has_cf & has_cbf, "CF+CBF",
                 np.where(has_cf, "CF_only",
                 np.where(has_cbf, "CBF_only", "unknown")))

    cf_comp  = (d.get("weight_cf", pd.Series(cfg.global_weight_cf, index=d.index)).astype(float)
                * p_cf_series.fillna(0.0)).fillna(0.0)
    w_cbf_eff = (d.get("weight_cbf", pd.Series(1.0 - cfg.global_weight_cf, index=d.index)).astype(float)
                 * pd.to_numeric(d.get(cfg.cbf_sim_col, 1.0), errors="coerce").fillna(1.0)).fillna(0.0)
    cbf_comp = (w_cbf_eff * p_cbf_series.fillna(0.0)).fillna(0.0)

    driver = np.where(cbf_comp > cf_comp, "driver=CBF", "driver=CF")

    d["hybrid_reason"] = [
        f"{tag}[α={float(alpha_series.iloc[i]):.2f}] {coverage[i]}; {driver[i]}; {'rrf=yes' if has_rrf.iloc[i] else 'rrf=no'}"
        for i in range(len(d))
    ]

    # Prefer the unified provenance column if present; otherwise build from cleaned components
    if cfg.source_unified_col in d.columns:
        d["hybrid_sources"] = _clean_str_series(d[cfg.source_unified_col].astype("string"))
    else:
        src_cf = _clean_str_series(d.get(cfg.cf_source_col, pd.Series("", index=d.index)).astype("string"))
        # If we already normalized CBF into source_cbf_norm_col, prefer it; else clean the raw cbf source
        if cfg.source_cbf_norm_col in d.columns:
            src_cbf_norm = _clean_str_series(d[cfg.source_cbf_norm_col].astype("string"))
        else:
            src_cbf_norm = _clean_str_series(d.get(cfg.cbf_source_col, pd.Series("", index=d.index)).astype("string"))

        d["hybrid_sources"] = [
            " | ".join([p for p in (src_cf.iloc[i] if src_cf.iloc[i] else "",
                                     src_cbf_norm.iloc[i] if src_cbf_norm.iloc[i] else "") if p])
            for i in range(len(d))
        ]

    # --- Align hybrid_sources with actual coverage: drop CF/CBF tag if its probability is NaN ---
    try:
        pc = pd.to_numeric(d.get(cfg.p_cf_col), errors="coerce")
        pb = pd.to_numeric(d.get(cfg.p_cbf_col), errors="coerce")
        hs = d["hybrid_sources"].astype(str)
        # If CF absent on this row, remove the CF portion like '(CF) ... | '
        mask_no_cf = pc.isna() & hs.str.contains(r"\(CF\)", regex=True)
        if mask_no_cf.any():
            d.loc[mask_no_cf, "hybrid_sources"] = (
                hs.loc[mask_no_cf]
                .str.replace(r"\(CF\)[^|]*\|\s*", "", regex=True)
                .str.replace(r"\s*\|\s*$", "", regex=True)
            )
        # If CBF absent on this row, remove the CBF portion like ' | CBF (...)'
        mask_no_cbf = pb.isna() & hs.str.contains(r"CBF\s*\(", regex=True)
        if mask_no_cbf.any():
            hs2 = d["hybrid_sources"].astype(str)
            d.loc[mask_no_cbf, "hybrid_sources"] = (
                hs2.loc[mask_no_cbf]
                .str.replace(r"\s*\|\s*CBF\s*\([^|]*\)$", "", regex=True)
                .str.replace(r"^CBF\s*\([^|]*\)\s*\|\s*", "", regex=True)
            )
    except (TypeError, ValueError, KeyError, AttributeError):
        pass

    return d


# ================== Advice attachment & helpers ==================

# --- Collector: gather all relevant text signals for advice typing ---
def _collect_advice_text_fields(row: pd.Series) -> str:
    parts = []
    def _push(val):
        if val is None:
            return
        s = str(val).strip()
        if s:
            parts.append(s.lower())
    # Provenance/reasons/explanations
    for col in (
        "feature_id", "hybrid_reason", "hybrid_sources", "source_unified",
        "reason_cf", "reason_cbf", "explanation_cf", "explanation_cbf",
        "explanation_clinical_cbf", "advice_source", "advice_text",
    ):
        if col in row.index:
            _push(row.get(col))
    # guideline_tags (JSON/list/pipe)
    if "guideline_tags" in row.index:
        gt = row.get("guideline_tags")
        try:
            if isinstance(gt, str) and gt.strip().startswith("["):
                arr = json.loads(gt)
                _push(" ".join([str(x) for x in arr]))
            else:
                _push(gt)
        except (json.JSONDecodeError, TypeError, ValueError):
            _push(gt)
    return " | ".join(parts)

def _bucketize_confidence(x: Optional[float]) -> str:
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "na"
    if x < 0.10:
        return "low"
    if x < 0.25:
        return "med"
    return "high"

def _bucketize_sim(x: Optional[float]) -> str:
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "na"
    if x < 0.20:
        return "low"
    if x < 0.50:
        return "med"
    return "high"

def attach_hybrid_advice(df: pd.DataFrame, cfg: HybridConfig) -> pd.DataFrame:
    d = df.copy()

    def _is_provenance_phrase(txt: str) -> bool:
        """Return True if the text looks like a provenance/diagnostic phrase, not a patient-facing advice.
        We filter common English/Arabic boilerplate such as 'exact/context match' and 'kNN' markers.
        """
        if txt is None:
            return True
        txt_norm = str(txt).strip().lower()
        if txt_norm == "":
            return True
        for rx in PROVENANCE_REGEXES:
            if rx.search(txt_norm):
                return True
        # Heuristic: very short parenthetical diagnostic strings like "(kNN)" or "(exact)"
        if len(txt_norm) <= 8 and txt_norm.startswith("(") and txt_norm.endswith(")"):
            return True
        return False

    def _pick(row: pd.Series) -> Tuple[str, str, str, str, bool, str]:
        fid = str(row.get("feature_id", "")).strip().lower()

        # Normalize/clean provenance
        src = str(row.get(cfg.cbf_source_col, "") or "").strip()
        src_norm = clean_source_text(src)
        tags = get_guideline_tags(src_norm, feature_id=fid)

        # Explanations (prefer clinical CBF text)
        expl_cbf_raw = str(row.get("explanation_clinical_cbf", "") or row.get("explanation_cbf", "") or "").strip()
        expl_cf_raw = str(row.get("explanation_cf", "") or "").strip()

        # Drop explanations that are actually provenance/diagnostic phrases (e.g., "kNN", "exact/context match")
        expl_cbf = "" if _is_provenance_phrase(expl_cbf_raw) else expl_cbf_raw
        expl_cf = "" if _is_provenance_phrase(expl_cf_raw) else expl_cf_raw

        # probabilities & similarity
        p_cf = pd.to_numeric(row.get(cfg.p_cf_col, np.nan), errors="coerce")
        p_cbf = pd.to_numeric(row.get(cfg.p_cbf_col, np.nan), errors="coerce")
        sim = pd.to_numeric(row.get(cfg.cbf_sim_col, np.nan), errors="coerce")

        # 1) CBF guideline text (exact/kNN) if available
        if expl_cbf and (src_norm in {"CBF (exact/context match)", "CBF (kNN)"} or src_norm.startswith("CBF")):
            if is_pharmacologic_feature(fid):
                a_type = "pharmacologic"
            elif is_lifestyle_feature(fid):
                a_type = "lifestyle"
            else:
                a_type = "neutral"
            return expl_cbf, a_type, "CBF_guideline", json.dumps(tags, ensure_ascii=False), False, ""

        # 2) constants by feature_id
        const_txt = pick_constant_for_feature(fid)
        if const_txt:
            if is_pharmacologic_feature(fid):
                a_type = "pharmacologic"
            elif is_lifestyle_feature(fid):
                a_type = "lifestyle"
            else:
                a_type = "neutral"
            return const_txt, a_type, "constants", json.dumps(tags, ensure_ascii=False), False, ""

        # 3) CF reason (if present)
        if expl_cf:
            if is_pharmacologic_feature(fid):
                a_type = "pharmacologic"
            elif is_lifestyle_feature(fid):
                a_type = "lifestyle"
            else:
                a_type = "neutral"
            return expl_cf, a_type, "CF_reason", json.dumps(tags, ensure_ascii=False), False, ""

        # 4) Lifestyle defaults
        lifestyles = pick_lifestyle_defaults()
        if lifestyles:
            return lifestyles[0], "lifestyle", "constants", json.dumps(tags, ensure_ascii=False), False, ""

        # 5) Fallback neutral + optional conflict
        conflict = False
        note = ""
        if pd.notna(p_cf) and pd.notna(p_cbf):
            try:
                if abs(float(p_cf) - float(p_cbf)) >= 0.20 and (pd.isna(sim) or float(sim) < 0.20):
                    conflict, note = True, "High CF–CBF disagreement with low similarity."
            except (TypeError, ValueError):
                pass
        return ADVICE_FALLBACK, "neutral", "fallback", json.dumps(tags, ensure_ascii=False), conflict, note


    # Row-wise apply
    out = d.apply(_pick, axis=1, result_type="expand")
    # Ensure correct column naming for 6 outputs from _pick
    if getattr(out, "shape", None) and out.shape[1] == 6:
        out.columns = [
            "advice_text",
            "advice_type",
            "advice_source",
            "guideline_tags",
            "conflict_flag",
            "conflict_note",
        ]
    elif getattr(out, "shape", None) and out.shape[1] == 5:
        # Backward-compat: if conflict_note was omitted, create it as empty
        out.columns = [
            "advice_text",
            "advice_type",
            "advice_source",
            "guideline_tags",
            "conflict_flag",
        ]
        out["conflict_note"] = ""
        out = out[
            [
                "advice_text",
                "advice_type",
                "advice_source",
                "guideline_tags",
                "conflict_flag",
                "conflict_note",
            ]
        ]
    else:
        # Last resort: coerce to expected schema to avoid pipeline failure
        expected_cols = [
            "advice_text",
            "advice_type",
            "advice_source",
            "guideline_tags",
            "conflict_flag",
            "conflict_note",
        ]
        out = out.reindex(columns=range(6))
        out.columns = expected_cols

    d = pd.concat([d, out], axis=1)

    # --- Backfill guideline_tags from provenance if empty/[] ---
    try:
        if "guideline_tags" in d.columns:
            def _needs_backfill(x_val):
                if pd.isna(x_val):
                    return True
                s_val = str(x_val).strip()
                return (s_val == "") or (s_val == "[]") or (s_val == "[ ]")

            src_series = None
            # Prefer normalized CBF source; then raw CBF source; then unified provenance
            if getattr(cfg, "source_cbf_norm_col", "source_cbf_norm") in d.columns:
                src_series = d[cfg.source_cbf_norm_col].map(clean_source_text)
            elif getattr(cfg, "cbf_source_col", "source_cbf") in d.columns:
                src_series = d[cfg.cbf_source_col].map(clean_source_text)
            elif getattr(cfg, "source_unified_col", "source_unified") in d.columns:
                src_series = d[cfg.source_unified_col].map(clean_source_text)

            if src_series is not None:
                mask_backfill = d["guideline_tags"].map(_needs_backfill)
                if mask_backfill.any():
                    # use both provenance and feature_id to derive robust tags
                    fid_series = d.get("feature_id", pd.Series("", index=d.index)).astype(str).str.strip().str.lower()
                    inferred = src_series.combine(fid_series, lambda s_val, fid_val: json.dumps(get_guideline_tags(s_val, feature_id=fid_val), ensure_ascii=False))
                    d.loc[mask_backfill, "guideline_tags"] = inferred[mask_backfill]
    except (TypeError, ValueError, AttributeError, KeyError):
        pass

    # --- Backfill advice_text if empty/NaN (robust, provenance-safe) ---
    mask_empty_advice = _is_empty_like_series(d.get("advice_text", pd.Series("", index=d.index)))
    if mask_empty_advice.any():
        # 1) Try pulling from non-provenance explanations in priority order
        def _strip_provenance(ser: pd.Series) -> pd.Series:
            s2 = ser.astype(str).fillna("")
            # blank typical provenance/diagnostic boilerplate
            for _rx in PROVENANCE_REGEXES:
                try:
                    if isinstance(_rx, re.Pattern):
                        # Compiled pattern already carries flags; don't pass flags again.
                        s2 = s2.mask(s2.str.contains(_rx, regex=True, na=False), "")
                    else:
                        # Raw string pattern: we can safely use IGNORECASE.
                        s2 = s2.mask(s2.str.contains(_rx, regex=True, flags=re.IGNORECASE, na=False), "")
                except re.error:
                    continue
            # Heuristic: very short parenthetical diagnostic strings like "(kNN)"
            s2 = s2.mask(s2.str.len().le(8) & s2.str.startswith("(") & s2.str.endswith(")"), "")
            return s2.str.strip()

        expl_candidates: list[pd.Series] = [
            _strip_provenance(d.get("explanation_clinical_cbf", pd.Series("", index=d.index))),
            _strip_provenance(d.get("explanation_cbf", pd.Series("", index=d.index))),
            _strip_provenance(d.get("explanation_cf", pd.Series("", index=d.index))),
        ]
        merged_expl = pd.Series([""] * len(d), index=d.index, dtype="string")
        for ser_cand in expl_candidates:
            s_use = ser_cand.astype(str).fillna("").str.strip()
            merged_expl = merged_expl.where(merged_expl.astype(bool), s_use)

        fill_from_expl = mask_empty_advice & merged_expl.astype(str).str.strip().ne("")
        if fill_from_expl.any():
            d.loc[fill_from_expl, "advice_text"] = merged_expl[fill_from_expl]
            # If advice_type is still blank here, infer via classifier later; keep source as-is

        # 2) Lifestyle templates keyed by feature_id (Arabic concise guidance)
        lifestyle_templates = {
            "increase_exercise": "زِد النشاط البدني الهوائي إلى ≥150 دقيقة/أسبوع (أو ≥75 دقيقة شدة عالية) مع يومين مقاومة أسبوعيًا.",
            "reduce_salt": "خفّض الصوديوم إلى أقل من 1500 ملغ/اليوم أو على الأقل خفّض 1000 ملغ/اليوم؛ قلّل الأطعمة المُصنّعة.",
            "weight_loss": "استهدف خفض الوزن 5–10% مع عجز حراري ~500–750 كcal/اليوم؛ دعم غذائي وسلوكي.",
            "limit_alcohol": "حدّ الكحول: الرجال ≤2 وحدات/اليوم، النساء ≤1؛ تجنّب الشرب النّهَمي.",
            "smoking_cessation": "أوقِف التدخين؛ اعرض بدائل النيكوتين/فارينيكلين مع استشارة سلوكية.",
            "dash_diet": "اتبِع حمية DASH: فواكه/خضروات، حبوب كاملة، ألبان قليلة الدسم؛ خفّض الدهون المشبعة.",
        }
        fid_series = d.get("feature_id", pd.Series("", index=d.index)).astype(str).str.lower().str.strip()
        mapped_txt = fid_series.map(lifestyle_templates).fillna("")
        fill_from_map = mask_empty_advice & mapped_txt.str.strip().ne("")
        if fill_from_map.any():
            d.loc[fill_from_map, "advice_text"] = mapped_txt[fill_from_map]
            # Ensure coherent typing/source for mapped lifestyle rows if blank
            blank_type = d.get("advice_type", pd.Series("", index=d.index)).astype(str).str.strip().eq("")
            blank_src  = d.get("advice_source", pd.Series("", index=d.index)).astype(str).str.strip().eq("")
            d.loc[fill_from_map & blank_type, "advice_type"] = "lifestyle"
            d.loc[fill_from_map & blank_src,  "advice_source"] = "constants"

        # 2b) Derive advice from clinical_flags when advice_text is still empty
        flags_ser = d.get("clinical_flags", pd.Series("", index=d.index)).astype(str).str.lower()

        # Templates keyed by specific gates (short, medically appropriate)
        _flag_templates: dict[str, tuple[str, str]] = {
            "gatel_lifestyle_counsel": (
                "lifestyle",
                "التزم بتغييرات نمط الحياة: تقليل الصوديوم، نشاط بدني منتظم (≥150 دقيقة/أسبوع)، إنقاص وزن 5–10%، وإيقاف التدخين."
            ),
            "gatef_follow_up": (
                "follow_up",
                "حدّد زيارة متابعة خلال 2–4 أسابيع لتقييم ضغط الدم والالتزام وتعديل الخطة عند الحاجة."
            ),
            "gatem_monitoring_needed": (
                "monitoring",
                "راقِب ضغط الدم منزليًا (HBPM) بقياسَيْن صباحًا ومساءً لمدّة 7 أيام (مع تجاهل يوم القياس الأول) واحسب المتوسط."
            ),
            "gatel_labs_recommended": (
                "lab_order",
                "اطلب التحاليل المناسبة: كرياتينين/ eGFR، بوتاسيوم، صوديوم، ودهون شاملة ± A1C حسب السياق السريري."
            ),
            "gates_safety_review": (
                "safety",
                "راجع السلامة: تداخلات دوائية محتملة، وظائف الكُلى/البوتاسيوم، واستبعاد موانع الاستعمال قبل أي تعديل علاجي."
            ),
            "gateedu_patient_education": (
                "education",
                "قدّم تثقيفًا موجّهًا حول ضغط الدم، أهداف العلاج، والتشاركية في القرار لتحسين الفهم والالتزام."
            ),
        }

        # --- Combo guard: if both lifestyle counsel and follow-up flags exist, ensure advice_text is filled ---
        if mask_empty_advice.any():
            _has_lifestyle = flags_ser.str.contains("gatel_lifestyle_counsel", na=False)
            _has_followup  = flags_ser.str.contains("gatef_follow_up", na=False)
            combo_mask = mask_empty_advice & _has_lifestyle & _has_followup
            if combo_mask.any():
                # Prefer lifestyle template by feature_id; else provide a short follow-up text
                fid_series = d.get("feature_id", pd.Series("", index=d.index)).astype(str).str.lower().str.strip()
                lifestyle_templates = {
                    "increase_exercise": "زِد النشاط البدني الهوائي إلى ≥150 دقيقة/أسبوع (أو ≥75 دقيقة شدة عالية) مع يومين مقاومة أسبوعيًا.",
                    "reduce_salt": "خفّض الصوديوم إلى أقل من 1500 ملغ/اليوم أو على الأقل خفّض 1000 ملغ/اليوم؛ قلّل الأطعمة المُصنّعة.",
                    "weight_loss": "استهدف خفض الوزن 5–10% مع عجز حراري ~500–750 كcal/اليوم؛ دعم غذائي وسلوكي.",
                    "limit_alcohol": "حدّ الكحول: الرجال ≤2 وحدات/اليوم، النساء ≤1؛ تجنّب الشرب النّهَمي.",
                    "smoking_cessation": "أوقِف التدخين؛ اعرض بدائل النيكوتين/فارينيكلين مع استشارة سلوكية.",
                    "dash_diet": "اتبِع حمية DASH: فواكه/خضروات، حبوب كاملة، ألبان قليلة الدسم؛ خفّض الدهون المشبعة.",
                }
                mapped_txt = fid_series.map(lifestyle_templates).fillna("")
                # If no lifestyle template mapped, use a concise follow-up text
                fallback_followup = "حدّد زيارة متابعة خلال 2–4 أسابيع لتقييم ضغط الدم والالتزام وتعديل الخطة عند الحاجة."
                to_fill = mapped_txt.where(mapped_txt.str.strip().ne(""), fallback_followup)
                adv_txt = d["advice_text"]
                empty_adv = _is_empty_like_series(adv_txt)
                fix_mask = combo_mask & empty_adv
                d.loc[fix_mask, "advice_text"] = to_fill[fix_mask]
                # Normalize advice_type/advice_source if still blank/neutral/other
                atype_ser = d.get("advice_type", pd.Series("", index=d.index)).astype(str).str.strip().str.lower()
                asrc_ser  = d.get("advice_source", pd.Series("", index=d.index)).astype(str).str.strip()
                atype_blank = atype_ser.isin(["", "neutral", "other"])
                d.loc[fix_mask & atype_blank, "advice_type"] = "lifestyle"
                d.loc[fix_mask & asrc_ser.eq(""), "advice_source"] = "clinical_flags"
                # Update mask_empty_advice for remaining rows
                mask_empty_advice = _is_empty_like_series(d.get("advice_text", pd.Series("", index=d.index)))

        # Apply flag-based backfill with simple priority (first match wins)
        if mask_empty_advice.any():
            fc = flags_ser.fillna("")
            # Ordered priority to favor actionable items
            _ordered_flags = [
                "gates_safety_review",
                "gatel_labs_recommended",
                "gatem_monitoring_needed",
                "gatef_follow_up",
                "gatel_lifestyle_counsel",
                "gateedu_patient_education",
            ]
            for _flag in _ordered_flags:
                if _flag in _flag_templates:
                    _atype, _txt = _flag_templates[_flag]
                    _mask_flag = mask_empty_advice & fc.str.contains(_flag, na=False)
                    if _mask_flag.any():
                        d.loc[_mask_flag, "advice_text"] = _txt
                        # Set advice_type only if still blank/neutral/other
                        _atype_blank = d.get("advice_type", pd.Series("", index=d.index)).astype(str).str.strip().isin(["", "neutral", "other"])
                        d.loc[_mask_flag & _atype_blank, "advice_type"] = _atype
                        # Default advice_source if still blank
                        _asrc_blank = d.get("advice_source", pd.Series("", index=d.index)).astype(str).str.strip().eq("")
                        d.loc[_mask_flag & _asrc_blank, "advice_source"] = "clinical_flags"
                        # update mask_empty_advice for remaining rows
                        mask_empty_advice = d["advice_text"].astype(str).str.strip().eq("")

        # 3) Last fallback to generic text if still empty
        still_empty = d["advice_text"].astype(str).str.strip().eq("")
        if still_empty.any():
            d.loc[still_empty, "advice_text"] = ADVICE_FALLBACK

        # Normalize types to strings (no NaN literals in CSV)
        for _c in ("advice_text", "advice_type", "advice_source"):
            if _c in d.columns:
                d[_c] = d[_c].fillna("").astype(str)

    # Buckets
    d["confidence_bucket"] = d["confidence"].apply(_bucketize_confidence)
    d["sim_bucket"] = pd.to_numeric(d.get(cfg.cbf_sim_col), errors="coerce").fillna(0.0).apply(_bucketize_sim)

    return d


# ================== 9) end-to-end ==================

# ----------- Pre-TopK hybrid frame builder -----------
def hybrid_preframe(
    df_cf: pd.DataFrame,
    df_cbf: pd.DataFrame,
    df_ctx: Optional[pd.DataFrame],  # kept for backward-compat; currently unused
    eval_cf: Optional[pd.DataFrame],
    eval_cbf: Optional[pd.DataFrame],
    *,
    cfg: HybridConfig,
    use_group_weights: bool,
    isotonic_min_samples: int,
) -> pd.DataFrame:
    """
    Build the *pre-filter / pre-TopK* hybrid frame for academic evaluation:
    unify → calibrate → (optional) group-weights → blend → gates → diversify.
    Returns a DataFrame ready for Top-K, but with *all* candidates preserved.
    """
    _ = df_ctx  # suppress 'unused' warning
    df_u = unify_schema(df_cf, df_cbf, df_ctx, cfg)
    logger.info("[HYB] [pre] Unified schema: rows=%d, cols=%d", len(df_u), df_u.shape[1])

    cal_cf, cal_cbf = fit_calibrators_from_eval(eval_cf, eval_cbf, cfg, isotonic_min_samples=isotonic_min_samples)
    logger.info("[HYB] [pre] Calibrators ready (iso_min=%d).", isotonic_min_samples)

    if use_group_weights:
        group_w, w_cf_g, _ = compute_group_weights(eval_cf, eval_cbf, cfg, metric="ndcg", k=5)
        logger.info("[HYB] [pre] Weights => CF=%.3f | CBF=%.3f (grouped=yes)", w_cf_g, 1.0 - w_cf_g)
    else:
        group_w, w_cf_g = {}, cfg.global_weight_cf
        logger.info("[HYB] [pre] Weights => CF=%.3f | CBF=%.3f (grouped=no)", w_cf_g, 1.0 - w_cf_g)

    df_h = blend_scores(df_u, cal_cf, cal_cbf, cfg, group_weights=group_w, w_cf_global=w_cf_g)
    logger.info("[HYB] [pre] Blended scores computed (rows=%d).", len(df_h))
    df_h = apply_clinical_gates(df_h, cfg)
    logger.info("[HYB] [pre] Clinical gates applied.")
    df_h = diversify_and_tiebreak(df_h, cfg)
    logger.info("[HYB] [pre] Diversify & tiebreak done.")
    return df_h

def attach_context_columns(df: pd.DataFrame,
                           df_ctx: pd.DataFrame,
                           contextual_cols: list[str],
                           on: str = "patient_id") -> pd.DataFrame:
    """Left-join contextual columns to df on patient_id so gates/advice can work even for CF-only rows."""
    if df_ctx is None or df_ctx.empty:
        return df
    keep_cols = [on] + [c for c in contextual_cols if c in df_ctx.columns]
    ctx = df_ctx[keep_cols].drop_duplicates(subset=[on])
    out = df.merge(ctx, how="left", on=on, suffixes=("", "_ctx"))
    # If both exist, prefer original; otherwise fill from *_ctx
    for c in contextual_cols:
        if c not in out.columns and f"{c}_ctx" in out.columns:
            out[c] = out[f"{c}_ctx"]
        elif c in out.columns and f"{c}_ctx" in out.columns:
            out[c] = out[c].fillna(out[f"{c}_ctx"])
    # Drop helper columns
    drop_cols = [f"{c}_ctx" for c in contextual_cols if f"{c}_ctx" in out.columns]
    if drop_cols:
        out = out.drop(columns=drop_cols, errors="ignore")
    return out


def build_source_unified(df: pd.DataFrame,
                         cf_status_col: str,
                         cbf_source_col: str,
                         out_col: str = "source_unified") -> pd.DataFrame:
    """Create a unified provenance column like '(CF) collaborative_filtering | CBF (kNN)'."""
    d = df.copy()
    cf_raw = d.get(cf_status_col, pd.Series("", index=d.index)).fillna("").astype(str)

    def _cf_tag(x: str) -> str:
        t = x.strip().lower()
        if not t or t in {"nan", "none", "null"}:
            return ""
        if "collaborative" in t:
            return "(CF) collaborative_filtering"
        return "(CF) cold_start_safe_default"

    cf_norm = cf_raw.map(_cf_tag)
    cbf_raw = d.get(cbf_source_col, pd.Series("", index=d.index)).fillna("").astype(str)
    cbf_norm = cbf_raw.map(clean_source_text)

    unified = []
    for i in range(len(d)):
        a = cf_norm.iloc[i]
        b = cbf_norm.iloc[i]
        if a and b:
            unified.append(f"{a} | {b}")
        elif a:
            unified.append(a)
        elif b:
            unified.append(b)
        else:
            unified.append("")
    d[out_col] = unified
    return d

def ensure_columns(df: pd.DataFrame, cols: Iterable[str]) -> pd.DataFrame:
    d = df.copy()
    for col_name in cols:
        if col_name not in d.columns:
            d[col_name] = np.nan
    return d


def finalize_hybrid_outputs(d: pd.DataFrame, cfg) -> pd.DataFrame:
    out = d.copy()

    # تغطية المصادر: has_cf / has_cbf (بدل Null)
    pc_raw = pd.to_numeric(out.get(cfg.p_cf_col),  errors="coerce")
    pb_raw = pd.to_numeric(out.get(cfg.p_cbf_col), errors="coerce")
    out["has_cf"]  = pc_raw.notna().astype(int)
    out["has_cbf"] = pb_raw.notna().astype(int)

    # احتمالات بلا Null (0.0 عند الغياب) — مع الحفاظ على has_* كإشارة تغطية
    out[cfg.p_cf_col]  = pc_raw.fillna(0.0).clip(0.0, 1.0)
    out[cfg.p_cbf_col] = pb_raw.fillna(0.0).clip(0.0, 1.0)

    # الثقة: |p_cf - p_cbf| (لا Null)
    conf = pd.to_numeric(out.get("confidence"), errors="coerce")
    if conf.isna().any():
        conf = (out[cfg.p_cf_col] - out[cfg.p_cbf_col]).abs()
    out["confidence"] = conf.clip(0.0, 1.0)

    # دلاء الثقة (high/med/low فقط)
    ch = float(getattr(constants, "CONFIDENCE_HIGH_MIN", 0.35))
    cm = float(getattr(constants, "CONFIDENCE_MED_MIN", 0.15))
    out["confidence_bucket"] = "low"
    out.loc[out["confidence"] >= ch, "confidence_bucket"] = "high"
    out.loc[(out["confidence"] >= cm) & (out["confidence"] < ch), "confidence_bucket"] = "med"

    # sim_bucket بلا "na"
    if "sim_norm" in out.columns:
        sim = pd.to_numeric(out["sim_norm"], errors="coerce").fillna(0.0).clip(0.0, 1.0)
        sh = float(getattr(constants, "SIM_HIGH_MIN", 0.70))
        sm = float(getattr(constants, "SIM_MED_MIN", 0.50))
        out["sim_bucket"] = "low"
        out.loc[sim >= sh, "sim_bucket"] = "high"
        out.loc[(sim >= sm) & (sim < sh), "sim_bucket"] = "med"
        out["sim_norm"] = sim

    # clinical_flags بلا Null
    if "clinical_flags" not in out.columns:
        out["clinical_flags"] = "none"
    else:
        out["clinical_flags"] = out["clinical_flags"].fillna("none").replace("", "none")

    # conflict_flag منطقي: موجودين المصدرين + فجوة كبيرة
    thr = float(getattr(constants, "CONFLICT_DELTA_MIN", 0.35))
    out["conflict_flag"] = False
    gap = (out[cfg.p_cf_col] - out[cfg.p_cbf_col]).abs()
    cond = (out["has_cf"].eq(1) & out["has_cbf"].eq(1) & (gap >= thr))
    out.loc[cond, "conflict_flag"] = True

    # تنظيف hybrid_sources ليتطابق مع has_* (لا CF/CBF إذا ما فيه مصدر فعليًا)
    if "hybrid_sources" in out.columns:
        hs = out["hybrid_sources"].astype(str)
        no_cf_mask = out["has_cf"].eq(0) & hs.str.contains(r"\(CF\)", regex=True, na=False)
        out.loc[no_cf_mask, "hybrid_sources"] = hs.loc[no_cf_mask] \
            .str.replace(r"\(CF\)[^|]*\|\s*", "", regex=True) \
            .str.replace(r"\s*\|\s*$", "", regex=True)
        hs = out["hybrid_sources"].astype(str)
        no_cbf_mask = out["has_cbf"].eq(0) & hs.str.contains(r"CBF\s*\(", regex=True, na=False)
        out.loc[no_cbf_mask, "hybrid_sources"] = hs.loc[no_cbf_mask] \
            .str.replace(r"CBF\s*\([^|]*\)\s*\|\s*", "", regex=True) \
            .str.replace(r"\s*\|\s*$", "", regex=True)

    # نصيحة/وسوم — بلا Null
    for col in ["advice_text","advice_type","advice_source"]:
        if col in out.columns:
            out[col] = out[col].fillna("").astype(str)
    if "guideline_tags" in out.columns:
        out["guideline_tags"] = out["guideline_tags"].fillna("[]").replace("", "[]")

    # status — بلا Null
    out["status"] = out.get("status", "ok")
    out["status"] = out["status"].fillna("ok").replace("", "ok")

    return out

# ================== Helpers: Emptiness, Sanitization, Deduplication ==================
import numpy as np
import pandas as pd

def _is_empty_like_series(sr: pd.Series) -> pd.Series:
    """
    يعتبر NaN، فراغ، و النصوص الشائعة للفراغ ('nan','none','null','na','n/a') كفراغ.
    """
    s = sr.astype(str).fillna("").str.strip()
    return (s.eq("")) | (s.str.lower().isin({"nan", "none", "null", "na", "n/a"}))

def sanitize_advice_and_types(df: pd.DataFrame) -> pd.DataFrame:
    """
    يضمن عدم بقاء advice_text فارغ/NaN/'nan'، وتطبيع advice_type/advice_source/guideline_tags.
    """
    if df is None or df.empty:
        return df
    d = df.copy()

    # advice_text — اعتبر 'nan'/'none'/'null' فراغًا ثم املأ Fallback
    if "advice_text" in d.columns:
        empty_mask = _is_empty_like_series(d["advice_text"])
        d.loc[empty_mask, "advice_text"] = "Follow-up: schedule a review and reinforce lifestyle adherence."

    # advice_type — قصر القيم على الطيف المسموح وإلا 'other'
    if "advice_type" in d.columns:
        allowed = {
            "lifestyle","pharmacologic","diagnostic","monitoring","lab_order",
            "referral","education","adherence","safety","device","follow_up","vaccination","other"
        }
        d["advice_type"] = d["advice_type"].astype(str).str.strip().str.lower()
        d.loc[~d["advice_type"].isin(allowed), "advice_type"] = "other"

    # advice_source/guideline_tags — تطبيع بلا Null
    if "advice_source" in d.columns:
        d["advice_source"] = d["advice_source"].fillna("").astype(str).str.strip()
    if "guideline_tags" in d.columns:
        d["guideline_tags"] = d["guideline_tags"].fillna("[]").astype(str)

    return d


def dedup_keep_best(df: pd.DataFrame,
                    key_cols=("patient_id","feature_id"),
                    score_col="hybrid_score") -> pd.DataFrame:
    """
    إزالة التكرارات على المفاتيح والإبقاء على الأعلى hybrid_score (ثم الأقل rank_hybrid إن وُجد).
    """
    if df is None or df.empty:
        return df
    d = df.copy()
    if not all(k in d.columns for k in key_cols) or score_col not in d.columns:
        return d

    sort_cols = [score_col]
    ascending = [False]
    if "rank_hybrid" in d.columns:
        d["__rank_h__"] = pd.to_numeric(d["rank_hybrid"], errors="coerce")
        sort_cols.append("__rank_h__")
        ascending.append(True)

    d = d.sort_values(by=sort_cols, ascending=ascending, kind="stable")
    d = d.drop_duplicates(subset=list(key_cols), keep="first")
    d.drop(columns=["__rank_h__"], errors="ignore", inplace=True)
    return d

def hybrid_end_to_end(
    df_cf: pd.DataFrame,
    df_cbf: pd.DataFrame,
    df_ctx: Optional[pd.DataFrame],  # kept for backward-compat; currently unused
    eval_cf: Optional[pd.DataFrame],
    eval_cbf: Optional[pd.DataFrame],
    *,
    k: int,
    cfg: HybridConfig,
    use_group_weights: bool,
    isotonic_min_samples: int,
    return_pre: bool = False,
) -> pd.DataFrame:
    """
    End-to-end hybrid pipeline.
    - If return_pre=False (default): return Top-K-only DataFrame (legacy behavior).
    - If return_pre=True: return (df_pre, df_top) where df_pre is the pre-filter/pre-TopK frame.
    """
    # 1) Build pre-filter/pre-TopK frame
    df_pre = hybrid_preframe(
        df_cf=df_cf, df_cbf=df_cbf, df_ctx=df_ctx,
        eval_cf=eval_cf, eval_cbf=eval_cbf,
        cfg=cfg, use_group_weights=use_group_weights,
        isotonic_min_samples=isotonic_min_samples,
    )

    # 2) Top-K selection
    df_top = topk_per_patient(df_pre, k=k, cfg=cfg, use_rrf_when_missing=True)
    logger.info("[HYB] Top-%d selected: rows=%d, patients=%d",
                k, len(df_top), df_top[cfg.key_cols[0]].nunique())

    # 3) Unified provenance
    df_top = build_source_unified(
        df_top,
        cf_status_col=cfg.status_cf_col,
        cbf_source_col=cfg.cbf_source_col,
        out_col=cfg.source_unified_col
    )

    # 4) Attach reasons and advice
    df_top = attach_hybrid_reason(df_top, cfg)
    logger.info("[HYB] Reasons attached.")
    df_top = attach_hybrid_advice(df_top, cfg)
    # Classify/normalize advice types for richer, non-binary taxonomy
    df_top = enrich_advice_types(df_top)

    # 5) Ensure required columns for downstream selection
    for col in [
        "source_unified",
        "clinical_flags",
        "advice_text","advice_type","advice_source","guideline_tags",
        "conflict_flag","confidence_bucket","sim_bucket","conflict_note",
    ]:
        if col not in df_top.columns:
            df_top[col] = pd.NA

    keep = list({
        *cfg.key_cols,
        cfg.hybrid_score_col, cfg.hybrid_rank_col,
        cfg.p_cf_col, cfg.p_cbf_col, "weight_cf", "weight_cbf", "confidence",
        cfg.cbf_sim_col, cfg.bp_col, cfg.chol_col, cfg.risk_col,
        cfg.cf_reason_col, cfg.cbf_reason_col,
        cfg.cf_expl_col, cfg.cbf_expl_col, cfg.cbf_expl_clin_col,
        cfg.cf_source_col, cfg.cbf_source_col,
        cfg.status_cf_col, cfg.source_cbf_norm_col, cfg.source_unified_col,
        "clinical_flags",
        "hybrid_reason", "hybrid_sources",
        "advice_text", "advice_type", "advice_source", "guideline_tags",
        "conflict_flag", "conflict_note", "confidence_bucket", "sim_bucket",
        "true_response", "feature_id_binned", "context_feature_id",
    })
    df_top = ensure_columns(df_top, keep)[keep].copy()

    # Normalize/null-free finishing pass to keep outputs consistent for downstream use
    df_top = finalize_hybrid_outputs(df_top, cfg)
    # --- Sanitize advice and types, and deduplicate ---
    df_top = sanitize_advice_and_types(df_top)
    df_top = dedup_keep_best(df_top)

    if return_pre:
        # Preserve DataFrame return type for callers; stash preframe metadata for diagnostics
        try:
            df_top.attrs["preframe_rows"] = int(len(df_pre))
            df_top.attrs["preframe_cols"] = int(df_pre.shape[1])
        except (TypeError, ValueError, AttributeError, KeyError):
            # If attrs assignment fails due to unexpected object types or missing attributes, skip silently.
            pass
    return df_top
#
# -------------------- Advice typing (module-level) --------------------

def _textify(*vals) -> str:
    parts = []
    for v in vals:
        if v is None:
            continue
        s = str(v).strip()
        if s:
            parts.append(s)
    return " | ".join(parts).lower()

# --- Classifier: Regex → Keywords → feature_id fallback ---
def classify_advice_type(row: pd.Series) -> str:
    txt = _collect_advice_text_fields(row)

    # 1) Strong regex rules by priority
    regex_table = getattr(constants, "ADVICE_REGEX", {})
    priority = getattr(constants, "ADVICE_TYPE_PRIORITY", list(regex_table.keys()))
    for cat in (priority if priority else regex_table.keys()):
        for pat in regex_table.get(cat, []):
            try:
                if re.search(pat, txt, flags=re.IGNORECASE):
                    return cat
            except re.error:
                continue

    # 2) Keyword rules
    for cat, words in getattr(constants, "ADVICE_KEYWORDS", {}).items():
        for w in words:
            if w and (w.lower() in txt):
                return str(cat).lower()

    # 3) feature_id heuristics
    fid = str(row.get("feature_id", "")).lower()
    if any(k in fid for k in ["abpm", "hbpm", "monitor"]):
        return "monitoring"
    if any(k in fid for k in ["ace", "arb", "thiazide", "amlodipine", "beta", "spironolactone", "drug", "medicat"]):
        return "pharmacologic"
    if any(k in fid for k in ["salt", "diet", "weight", "exercise", "smoking", "alcohol", "dash", "sleep"]):
        return "lifestyle"
    return "other"

# --- Enricher with smart override policy ---
def enrich_advice_types(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return df
    d = df.copy()

    if "advice_type" not in d.columns:
        d["advice_type"] = pd.NA

    # Predict per-row using the new classifier
    pred = d.apply(classify_advice_type, axis=1)

    allowed = set(getattr(constants, "ADVICE_TYPES", [
        "lifestyle","pharmacologic","diagnostic","monitoring","lab_order",
        "referral","education","adherence","safety","device","follow_up","vaccination","other"
    ]))

    cur = d["advice_type"].astype(str).str.strip().str.lower().replace({"nan": "", "none": ""})

    # Take prediction if current is empty/other/NaN
    take_pred_mask = (cur.eq("")) | (cur.eq("other")) | (cur.isna())
    # Override narrow types when classifier yields a stronger expanded category
    pred_l = pred.astype(str).str.lower()
    override_mask = cur.isin({"lifestyle","pharmacologic"}) & pred_l.isin(allowed) & (pred_l != cur)

    final = cur.where(~(take_pred_mask | override_mask), pred_l)
    final = final.where(final.isin(allowed), "other")

    d["advice_type"] = final

    for c in ("advice_text","advice_source","guideline_tags"):
        if c in d.columns:
            d[c] = d[c].fillna("").astype(str)
    return d