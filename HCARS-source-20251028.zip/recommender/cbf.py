
# ---------- Utility: Get all context columns ----------
def get_all_context_cols(context_cols, secondary_context_cols):
    return context_cols + secondary_context_cols

# ---------- Logger Setup ----------
import logging

logger = logging.getLogger("cbf")
if not logger.handlers:
    logger.addHandler(logging.StreamHandler())
logger.setLevel(logging.INFO)

# --- External imports ---
import pandas as pd
_pd = pd  # alias used by helper closures (e.g., _with_plan_payload)
import numpy as np

# --- Helper: Read exact_match_cap from config safely ---
def _read_exact_match_cap_from_cfg(cfg: dict, default: float = 0.98) -> float:
    """
    Read scoring.cbf_mix.exact_match_cap from config with validation and sensible fallback.
    Clamped to (0, 1].
    """
    try:
        mix = (((cfg or {}).get("scoring") or {}).get("cbf_mix") or {})
        cap = float(mix.get("exact_match_cap", default))
        if not (0.0 < cap <= 1.0):
            raise ValueError("exact_match_cap out of range")
        return cap
    except (TypeError, ValueError, AttributeError):
        return float(default)
from pipeline.helpers import HCARSUtils  # align config access with CF
# Robust, future-proof categorical dtype check
from pandas.api.types import CategoricalDtype

# One-time flag for policy diagnostics in ensure_cbf_scores
_CBF_ENSURE_POLICY_LOGGED_ONCE = False

# ========= CBF scoring: similarity x priors (continuous) =========
from typing import Optional as _Optional, Dict as _Dict, Any as _Any

def _clip01(x: "pd.Series", lo: float = 0.0, hi: float = 1.0) -> "pd.Series":
    """Clip a numeric pandas Series to [lo, hi] with NaNs -> lo."""
    s = pd.to_numeric(x, errors="coerce").fillna(lo)
    return s.clip(lower=lo, upper=hi)

def _ensure_sim_column(
    df: "pd.DataFrame",
    *,
    sim_candidates: list[str],
    out_col: str,
    logger_obj=None,
    log_id: str = "CBF",
) -> "pd.DataFrame":
    """
    Ensure a similarity column exists. Try candidates in order, or create zeros if none exist.
    - sim_candidates: e.g., ["sim_agg", "sim_cbf_raw", "cosine_sim", "knn_sim"]
    - out_col: the column to standardize to (e.g., "sim_cbf_raw")
    - logger_obj: logger instance for warnings (optional)
    """
    for c in sim_candidates:
        if c in df.columns:
            if out_col != c:
                df[out_col] = df[c]
            return df
    if out_col not in df.columns:
        df[out_col] = 0.0
        if logger_obj is not None:
            try:
                logger_obj.warning(
                    f"[{log_id}] [CBF] No similarity column found among {sim_candidates}; initialized '{out_col}' to 0.0."
                )
            except (TypeError, ValueError, AttributeError):
                # Logging failed; ignore gracefully
                return df
    return df

def _diagnose_score_distribution(df: "pd.DataFrame", score_col: str, logger_obj=None, log_id: str = "CBF") -> None:
    """Log quick diagnostics for a score column: unique count, mean/std, and quantiles."""
    if score_col not in df.columns or len(df) == 0:
        return
    try:
        s = pd.to_numeric(df[score_col], errors="coerce")
        n_unique = int(s.nunique(dropna=True))
        mean = float(s.mean()); std = float(s.std(ddof=0))
        q = s.quantile([0.0, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0]).to_dict()
        if logger_obj is not None:
            logger_obj.info(f"[{log_id}] [CBF] score '{score_col}': n_unique={n_unique}, mean={mean:.4f}, std={std:.4f}, quantiles={{{', '.join(f'{k}:{v:.3f}' for k, v in q.items())}}}")
    except (TypeError, ValueError, KeyError, AttributeError) as _ex:
        if logger_obj is not None:
            logger_obj.warning(f"[{log_id}] [CBF] score diagnostics failed for '{score_col}': {_ex}")

def compute_cbf_mixed_scores(
    df: "pd.DataFrame",
    cfg: _Optional[_Dict[str, _Any]],
    *,
    reason_col: str = "reason",
    sim_candidates: list[str] = None,
    sim_col: str = "sim_cbf_raw",
    score_col: str = "score_cbf",
    logger_obj=None,
    log_id: str = "CBF",
) -> "pd.DataFrame":
    """
    Compute a continuous CBF score by mixing normalized similarity with reason->score priors:
        score_cbf = w_similarity * sim_norm + w_reason * prior
    Then calibrate per-patient (minmax/standard/none) and add tiny jitter to break ties.
    Keeps:
      - 'mapped_reason_score' (prior)  و  'score_cbf_precal' (قبل المعايرة) للشفافية.
    """
    if df is None or len(df) == 0:
        return df

    # 0) تأكّد من عمود التشابه
    sim_candidates = sim_candidates or ["sim_agg", "cosine_sim", "knn_sim", "similarity"]
    df = _ensure_sim_column(df, sim_candidates=sim_candidates, out_col=sim_col, logger_obj=logger_obj, log_id=log_id)

    # 1) احصل على priors + floors من constants
    try:
        from utils.constants import get_cbf_scoring_policy  # local import
        score_map, _thr, floors = get_cbf_scoring_policy(cfg)  # type: ignore
    except (KeyError, TypeError, ValueError, ImportError):
        score_map = {
            "recommended": 1.0,
            "context_key_match": 0.95,
            "similarity_fallback_high": 0.85,
            "similarity_fallback_medium": 0.65,
            "similarity_fallback_low": 0.50,
            "knn_recommendation": 0.75,
            "manual_review": 0.0,
        }
        floors = {
            "unknown_reason_score": 0.55,
            "min_floor": 0.05,
            "exact_match_cap": 0.98,
            "sim_clip_min": 0.0,
            "sim_clip_max": 1.0,
        }

    # Read mix/weights/prior mods from config
    s = (cfg.get("scoring", {}) if isinstance(cfg, dict) else {}) or {}
    mix = (s.get("cbf_mix", {}) if isinstance(s, dict) else {}) or {}

    # 2) قصّ التشابه وحد أقصى قبل التطبيع
    sim_min = float((floors.get("sim_clip_min", 0.0)))
    sim_max = float((floors.get("sim_clip_max", 1.0)))
    exact_cap = float((floors.get("exact_match_cap", 0.98)))

    # read reasons for exact-like cap
    _reasons = df.get(reason_col)
    try:
        _reasons = _reasons.astype(str).str.lower().fillna("")
    except (AttributeError, TypeError, ValueError):
        _reasons = pd.Series([""] * len(df), index=df.index)

    # raw similarity as numeric
    sim_raw = pd.to_numeric(df.get(sim_col, 0.0), errors="coerce").fillna(sim_min)

    # apply exact-match cap for recommended/context_key_match BEFORE clipping/normalization
    _is_exact = _reasons.isin(["recommended", "context_key_match"]).astype(bool)
    sim_raw = sim_raw.where(~_is_exact, sim_raw.clip(upper=max(min(exact_cap, sim_max), sim_min)))

    # hard clip to [sim_min..sim_max]
    sim_raw = sim_raw.clip(lower=sim_min, upper=sim_max)

    # normalize to [0..1]
    if sim_max > sim_min + 1e-12:
        sim_norm = (sim_raw - sim_min) / (sim_max - sim_min)
    else:
        sim_norm = pd.Series(0.5, index=df.index)
    df["sim_norm"] = sim_norm

    # 3) prior من reason (لا تستبدل النهائي)
    try:
        pri = df[reason_col].map(score_map).fillna(0.0)
    except (KeyError, TypeError, ValueError):
        pri = pd.Series([0.0] * len(df), index=df.index)
    # --- Dynamic mapped_reason_score based on similarity ---
    prior = pd.to_numeric(pri, errors="coerce").fillna(0.0)
    base = float(mix.get("prior_mod_base", 0.5))   # مساهمة ثابتة
    gain = float(mix.get("prior_mod_gain", 0.5))   # مساهمة التشابه
    # ضبط آمن للحدود
    if base < 0.0: base = 0.0
    if gain < 0.0: gain = 0.0
    if base + gain > 1.0:
        scale = 1.0 / (base + gain)
        base *= scale; gain *= scale
    df["mapped_reason_score"] = prior * (base + (gain * df["sim_norm"]))

    # 4) المزج
    w_sim = float(mix.get("w_similarity", 0.6))
    w_pri = float(mix.get("w_reason", 0.4))
    df["score_cbf_precal"] = (w_sim * df["sim_norm"]) + (w_pri * df["mapped_reason_score"])

    # 5) لا نعاير هنا؛ تجرى المعايرة في postprocess_scores_cbf لمنع التكرار
    df[score_col] = df["score_cbf_precal"]

    _diagnose_score_distribution(df, score_col, logger_obj=logger_obj, log_id=log_id)
    return df

def _sim_to_prob(_sim: float, _slope: float, _mid: float) -> float:
    """Logistic mapping sim∈[0,1] → prob∈[0,1]. Safe against bad inputs."""
    try:
        import math as _math
        x = 0.0 if _sim is None else float(_sim)
        if x < 0.0: x = 0.0
        if x > 1.0: x = 1.0
        return 1.0 / (1.0 + _math.exp(-_slope * (x - _mid)))
    except (TypeError, ValueError, OverflowError, ArithmeticError):
        try:
            return float(_sim or 0.0)
        except (TypeError, ValueError):
            return 0.0

def ensure_cbf_scores(
    df: pd.DataFrame,
    config: dict,
    *,
    reason_col: str = "reason",
    sim_col: str = "similarity",
    raw_col: str | None = "score_cbf_raw",
    base_col: str | None = "score_cbf_base",
    out_col: str = "score_cbf",
    logger_obj=None,
    log_id: str = "CBF",
    add_diag: bool = True,
) -> pd.DataFrame:
    """
    Unified source-of-truth for CBF scoring.
      - Ensures presence of:
          sim_cbf_raw  : copy of raw similarity for diagnostics
          score_cbf_raw: raw score derived from similarity (or base score fallback) BEFORE any calibration
          score_cbf    : final score after mapping/mix, capped safely (no forced 1.0)
    """
    if not isinstance(df, pd.DataFrame) or df.empty:
        return df

    s_cfg = (config.get("scoring") or {}) if isinstance(config, dict) else {}
    mix = (s_cfg.get("cbf_mix") or {})
    w_sim = float(mix.get("w_similarity", 0.8))
    w_reason = float(mix.get("w_reason", 0.2))

    stp = (s_cfg.get("sim_to_prob") or {})
    slope = float(stp.get("slope", 6.0))
    midpoint = float(stp.get("midpoint", 0.65))

    unknown_reason_score = float(s_cfg.get("unknown_reason_score", 0.55))
    min_floor = float(s_cfg.get("min_floor", 0.05))
    jitter_eps = float(s_cfg.get("epsilon_jitter", 1e-6))
    sim_min = float(s_cfg.get("sim_clip_min", 0.0))
    sim_max = float(s_cfg.get("sim_clip_max", 1.0))
    exact_cap = _read_exact_match_cap_from_cfg(s_cfg, 0.98)
    accept_thr = float(s_cfg.get("accept_threshold", 0.50)) if "accept_threshold" in s_cfg else None

    out = df.copy()

    # Normalize reasons (for exact-match capping)
    try:
        _reasons_series = out[reason_col].astype(str).str.lower()
    except (KeyError, AttributeError, TypeError, ValueError):
        _reasons_series = None

    # 1) Resolve raw similarity and persist as sim_cbf_raw
    sim_series = None
    for c in [sim_col, raw_col]:
        if c and c in out.columns:
            try:
                sim_series = pd.to_numeric(out[c], errors="coerce")
                break
            except (TypeError, ValueError, KeyError):
                continue
    if sim_series is None:
        sim_series = pd.Series(np.nan, index=out.index, dtype=float)
    if "sim_cbf_raw" not in out.columns:
        out["sim_cbf_raw"] = sim_series

    # 2) Clip similarity and cap exact-like BEFORE logistic
    sim_norm_input = sim_series.clip(sim_min, sim_max)
    if isinstance(_reasons_series, pd.Series):
        _is_exact_like = _reasons_series.isin(["recommended", "context_key_match", "contextual_rule"]).astype(bool)
        sim_norm_input = sim_norm_input.where(~_is_exact_like, other=sim_norm_input.clip(upper=max(min(exact_cap, sim_max), sim_min)))

    # 3) Logistic mapping sim→prob
    def _sim_to_prob_local(x: float) -> float:
        try:
            xx = 0.0 if x is None or np.isnan(x) else float(x)
            if xx < 0.0: xx = 0.0
            if xx > 1.0: xx = 1.0
            return 1.0 / (1.0 + np.exp(-slope * (xx - midpoint)))
        except (TypeError, ValueError, ArithmeticError, OverflowError):
            try:
              return float(x or 0.0)
            except (TypeError, ValueError):
              return 0.0
    try:
        sim_prob = sim_norm_input.fillna(0.0).apply(_sim_to_prob_local).astype(float)
    except (TypeError, ValueError, ArithmeticError):
        sim_prob = pd.Series(0.0, index=out.index, dtype=float)

    # 4) reason prior from base_col else unknown_reason_score
    if base_col and base_col in out.columns:
        try:
            base_series = pd.to_numeric(out[base_col], errors="coerce")
        except (KeyError, TypeError, ValueError):
            base_series = pd.Series(np.nan, index=out.index, dtype=float)
    else:
        base_series = pd.Series(np.nan, index=out.index, dtype=float)
    mapped_reason_score = base_series.fillna(unknown_reason_score).astype(float)

    # 5) Raw score BEFORE any calibration: sim first, fallback to base
    score_cbf_raw = pd.to_numeric(out.get(sim_col, np.nan), errors="coerce").fillna(mapped_reason_score)
    score_cbf_raw = score_cbf_raw.clip(lower=sim_min, upper=sim_max)
    if isinstance(_reasons_series, pd.Series):
        _cap_mask = _reasons_series.isin(["recommended", "context_key_match", "contextual_rule"]).astype(bool)
        score_cbf_raw = score_cbf_raw.where(~_cap_mask, other=np.minimum(score_cbf_raw, float(exact_cap)))
    out["score_cbf_raw"] = score_cbf_raw.astype(float)

    # 6) Weighted mix → final score
    try:
        score = (w_sim * sim_prob) + (w_reason * mapped_reason_score)
    except (TypeError, ValueError):
        score = pd.Series(0.0, index=out.index, dtype=float)

    # 7) Final clip + exact-cap + jitter
    try:
        score = score.clip(lower=min_floor, upper=1.0)
        if isinstance(_reasons_series, pd.Series):
            _upper_cap = pd.Series(1.0, index=out.index, dtype=float)
            _cap_mask = _reasons_series.isin(["recommended", "context_key_match", "contextual_rule", "knn_recommendation"]).astype(bool)
            _upper_cap = _upper_cap.where(~_cap_mask, other=float(exact_cap))
            score = np.minimum(score, _upper_cap)
        else:
            score = np.minimum(score, float(exact_cap))
        score = score + np.random.uniform(0.0, jitter_eps, size=len(score))
        out[out_col] = score.astype(float)
    except (TypeError, ValueError, KeyError, AttributeError, ArithmeticError) as _ex:
        if logger_obj is not None:
            try:
                logger_obj.warning(f"[{log_id}] ensure_cbf_scores post-process failed: {_ex}")
            except (TypeError, ValueError, AttributeError):
                pass
        out[out_col] = pd.Series(0.0, index=out.index, dtype=float)

    if add_diag:
        out["sim_norm"] = ((sim_norm_input - sim_min) / (sim_max - sim_min)) if (sim_max > sim_min + 1e-12) else pd.Series(0.5, index=out.index)
        out["sim_prob"] = sim_prob
        out["mapped_reason_score"] = mapped_reason_score
        if accept_thr is not None:
            try:
                out["accepted@thr"] = (pd.to_numeric(out[out_col], errors="coerce") >= accept_thr).astype(int)
            except (TypeError, ValueError, KeyError, AttributeError):
                pass

    # Light diagnostics
    try:
        s = pd.to_numeric(out[out_col], errors="coerce")
        if logger_obj is not None and hasattr(logger_obj, "info"):
            q = s.quantile([0.0, 0.25, 0.5, 0.75, 0.9, 1.0]).round(4).to_dict()
            logger_obj.info(f"[{log_id}] score diagnostics {out_col}: n={len(s)}, q={{{', '.join(f'{k}:{float(v)}' for k, v in q.items())}}}")
    except (TypeError, ValueError, KeyError, AttributeError):
        pass

    return out
def _is_categorical(obj) -> bool:
    """Robust categorical dtype check across pandas versions."""
    try:
        return isinstance(getattr(obj, "dtype", None), CategoricalDtype)
    except (AttributeError, TypeError):
        return False

# --- Score clipping/rounding helper (keeps rows; aligns with CF policy) ---
def _clip_round_scores(df: pd.DataFrame, col: str) -> pd.DataFrame:
    try:
        if df is None or col not in df.columns:
            return df
        # Clip to [0,1] and round to 6 decimals to remove float artifacts like 1.0000000000000004
        df[col] = df[col].clip(0.0, 1.0).round(6)
    except (TypeError, ValueError, KeyError, AttributeError) as _err:
        # Non-fatal: logging already configured; avoid raising here to keep pipeline resilient
        logger.warning(f"[CBF] clip/round failed for {col}: {_err}")
    return df

# === CBF score calibration utilities (aligned with CF) ===
def _calibrate_scores_minmax(s: pd.Series, eps: float = 1e-6) -> pd.Series:
    s = pd.to_numeric(s, errors="coerce").fillna(0.0)
    lo, hi = float(s.min()), float(s.max())
    n = int(len(s))
    if n == 0:
        return s
    if hi <= lo + 1e-12:
        # كل القيم متساوية → كسر تعادلات بجيتّر صغير
        return pd.Series(np.full(n, 0.5, dtype=float), index=s.index) + np.linspace(-eps, eps, num=n, endpoint=True)
    out = (s - lo) / (hi - lo)
    return out + np.linspace(-eps, eps, num=n, endpoint=True)

def _calibrate_scores_standard(s: pd.Series, eps: float = 1e-6) -> pd.Series:
    s = pd.to_numeric(s, errors="coerce").fillna(0.0)
    mu, sd = float(s.mean()), float(s.std(ddof=0))
    n = int(len(s))
    if n == 0:
        return s
    if sd <= 1e-12:
        return pd.Series(np.zeros(n, dtype=float), index=s.index) + np.linspace(-eps, eps, num=n, endpoint=True)
    z = (s - mu) / sd
    # squash إلى [0,1] تقريبًا عبر سيغمويد
    sig = 1.0 / (1.0 + np.exp(-z))
    return pd.Series(sig, index=s.index) + np.linspace(-eps, eps, num=n, endpoint=True)

def _apply_score_calibration(
    df: pd.DataFrame,
    score_col: str = "score_cbf",
    patient_col: str = "patient_id",
) -> pd.DataFrame:
    """Apply per-patient score calibration (minmax/standard/none) with tiny jitter to break ties.
    Reads settings from config.cbf.score_calibration.{method, epsilon_jitter}.
    """
    if df is None or not isinstance(df, pd.DataFrame) or score_col not in df.columns:
        return df
    try:
        cfg = HCARSUtils.load_config()
    except (ImportError, OSError, ValueError):
        cfg = {}
    method = (cfg.get("cbf", {}).get("score_calibration", {}) or {}).get("method", "minmax")
    eps = float((cfg.get("cbf", {}).get("score_calibration", {}) or {}).get("epsilon_jitter", 1e-6))
    if method == "standard":
        df[score_col] = df.groupby(patient_col, group_keys=False)[score_col].transform(lambda s: _calibrate_scores_standard(s, eps))
    elif method == "minmax":
        df[score_col] = df.groupby(patient_col, group_keys=False)[score_col].transform(lambda s: _calibrate_scores_minmax(s, eps))
    # else: method == "none" → لا تعديل
    return df


# ======= Contextual rerank for CBF (optional, after calibration) =======
def apply_context_rerank_cbf(
    df: pd.DataFrame,
    cfg: dict,
    *,
    patient_col: str = "patient_id",
    family_col: str = "feature_id_binned",
    ctx_family_col: str = "context_feature_id",
    score_col: str = "score_cbf",
    log_id: str = "CBF",
) -> pd.DataFrame:
    """
    Optional contextual re-ranking for CBF, aligned with CF:
      new_score = alpha * score_cbf + (1 - alpha) * context_bonus
    where context_bonus = same_family_boost if feature_id_binned == context_feature_id else 0.

    Controlled by config:
      cbf.context_rerank.enabled: bool
      cbf.context_rerank.alpha: float in [0,1]
      cbf.context_rerank.same_family_boost: float (usually 0.10–0.20)
    """
    if not isinstance(df, pd.DataFrame) or df.empty:
        return df

    # Read context rerank settings (always reference rerank_cfg to avoid "unused" warnings)
    try:
        rerank_cfg = ((cfg.get("cbf", {}) or {}).get("context_rerank", {}) or {}) if isinstance(cfg, dict) else {}
    except (AttributeError, TypeError, ValueError):
        rerank_cfg = {}
    enabled = bool(rerank_cfg.get("enabled", False))

    # If disabled, still log the effective cfg to make use of rerank_cfg and aid diagnostics
    if not enabled:
        try:
            logger.debug(f"[{log_id}] [CBF][rerank] Disabled or empty config; effective context_rerank cfg={rerank_cfg}")
        except (TypeError, ValueError, KeyError):
            pass
        return df

    # Optional presence check for patient_col (diagnostic + silences unused-parameter warnings)
    try:
        if isinstance(patient_col, str) and patient_col and patient_col not in df.columns:
            logger.debug(f"[{log_id}] [CBF][rerank] patient_col '{patient_col}' not found in df; proceeding without patient-specific grouping.")
    except (TypeError, ValueError, KeyError, AttributeError):
        # Non-fatal; purely diagnostic
        pass

    # Defaults
    try:
        alpha = float(rerank_cfg.get("alpha", 0.85))
    except (TypeError, ValueError):
        alpha = 0.85
    try:
        same_family_boost = float(rerank_cfg.get("same_family_boost", 0.15))
    except (TypeError, ValueError):
        same_family_boost = 0.15

    # Ensure family/context IDs exist before rerank
    try:
        df = ensure_feature_id_binned_and_context(df, log=logger, log_id=f"[{log_id}][rerank]")
    except (TypeError, ValueError, KeyError) as _ex:
        logger.warning(f"[{log_id}] [CBF][rerank] ensure_feature_id_binned_and_context skipped: {_ex}")

    # Guard required columns
    req_cols = [score_col, family_col, ctx_family_col]
    if not all(col in df.columns for col in req_cols):
        missing = [c for c in req_cols if c not in df.columns]
        logger.warning(f"[{log_id}] [CBF][rerank] Missing columns {missing}; skipping contextual rerank.")
        return df

    # Compute context bonus: +same_family_boost if family matches
    try:
        fam = df[family_col].astype(str)
        ctx = df[ctx_family_col].astype(str)
        same_fam = (fam == ctx).astype(float)
        context_bonus = same_fam * same_family_boost
    except (TypeError, ValueError, KeyError) as _ex:
        logger.warning(f"[{log_id}] [CBF][rerank] Failed computing context bonus: {_ex}")
        return df


    # Blend scores
    try:
        base = pd.to_numeric(df[score_col], errors="coerce").fillna(0.0)
        new_score = alpha * base + (1.0 - alpha) * context_bonus
        df[score_col] = new_score
        df = _clip_round_scores(df, score_col)
        logger.info(f"[{log_id}] [CBF][rerank] Applied contextual rerank: alpha={alpha}, same_family_boost={same_family_boost}")
    except (TypeError, ValueError, ArithmeticError) as _ex:
        logger.warning(f"[{log_id}] [CBF][rerank] Failed applying contextual rerank: {_ex}")

    return df

def postprocess_scores_cbf(
    df_in: pd.DataFrame,
    score_col: str = "score_cbf",
    patient_col: str = "patient_id",
) -> pd.DataFrame:
    """
    Per-patient min–max normalization and stable sorting by score (desc).
    Safe no-op if inputs/columns are missing.
    """
    if not isinstance(df_in, pd.DataFrame) or df_in.empty or (score_col not in df_in.columns):
        return df_in
    df = df_in.copy()
    # Ensure numeric
    df.loc[:, score_col] = pd.to_numeric(df[score_col], errors="coerce")
    # Per-patient min–max
    if patient_col in df.columns:
        def _minmax(_s_local: pd.Series) -> pd.Series:
            _s_num = pd.to_numeric(_s_local, errors="coerce")
            try:
                _lo_local = float(_s_num.min())
                _hi_local = float(_s_num.max())
            except (TypeError, ValueError):
                return _s_num.fillna(0.0)
            if not (_hi_local > _lo_local):
                return _s_num.fillna(0.0)
            return (_s_num - _lo_local) / (_hi_local - _lo_local)
        try:
            df.loc[:, score_col] = df.groupby(patient_col, group_keys=False)[score_col].apply(_minmax)
        except (KeyError, TypeError, ValueError, AttributeError):
            # Global min–max fallback
            x = pd.to_numeric(df[score_col], errors="coerce")
            lo, hi = float(x.min()), float(x.max())
            if hi > lo:
                df.loc[:, score_col] = (x - lo) / (hi - lo)
            else:
                df.loc[:, score_col] = x.fillna(0.0)
    # Stable sorting
    try:
        if patient_col in df.columns:
            df = df.sort_values([patient_col, score_col], ascending=[True, False])
        else:
            df = df.sort_values(score_col, ascending=False)
    except (KeyError, TypeError, ValueError, AttributeError):
        pass
    return df
# --- Similarity→probability & optional isotonic model application (with safe fallbacks) ---
from utils.context_utils import ensure_feature_id_binned_and_context as _ensure_fam_ctx
from utils.context_utils import sanitize_feature_id as _sanitize_fid
from utils.constants import canonicalize_feature_id as _canon_fid

def pick_cbf_recommendation(
    context: dict,
    dictionary: pd.DataFrame,
    *,
    k: int = 5,
    min_similarity: float = 0.60,
    reason_if_strong: str = "knn_recommendation",
    reason_if_weak: str = "knn_fallback",
    logger_obj=None,
    log_id: str = "CBF",
    cfg: dict | None = None,
) -> dict:
    """
    Lightweight Hamming-based KNN over CONTEXT_COLUMNS.
    Returns a payload with: feature_id, reason, similarity (avg_sim), score_cbf_raw (logistic(sim)),
    plus placeholders (explanation/source) filled by pipeline later.
    """
    from utils.constants import CONTEXT_COLUMNS as _CTX
    if not isinstance(dictionary, pd.DataFrame) or dictionary.empty:
        return {}

    # Normalize required columns and ensure family/context IDs (safe no-op if already present)
    df = dictionary.copy()
    for c in _CTX:
        if c in df.columns:
            df[c] = df[c].astype(str).str.strip().str.lower().str.replace(" ", "_", regex=False)
    try:
        df = _ensure_fam_ctx(df, log=logger_obj, log_id=f"{log_id}[pick]")
    except (TypeError, ValueError, KeyError, AttributeError):
        pass

    # Normalize incoming context
    ctx_norm = {c: str(context.get(c, "unknown")).strip().lower().replace(" ", "_") for c in _CTX if c in df.columns}
    if not ctx_norm:
        return {}

    # Hamming similarity
    try:
        matches = sum([(df[c] == ctx_norm.get(c, "unknown")).astype(int) for c in ctx_norm.keys()])
        sim = matches / float(len(ctx_norm))
    except (KeyError, TypeError, ValueError, ArithmeticError):
        sim = pd.Series(0.0, index=df.index)
    df["__sim__"] = sim

    topk = df.sort_values("__sim__", ascending=False).head(max(int(k), 1))
    if topk.empty:
        return {}

    # Majority vote + tie-break by higher mean sim
    from collections import Counter
    cnt = Counter(topk["feature_id"])
    sim_means = topk.groupby("feature_id")["__sim__"].mean().to_dict()
    best_feat, _ = max(cnt.items(), key=lambda it: (it[1], float(sim_means.get(it[0], 0.0))))
    # Canonicalize
    try:
        best_feat = _sanitize_fid(best_feat) or best_feat
        best_feat = _canon_fid(str(best_feat)) or str(best_feat)
    except (TypeError, ValueError, AttributeError):
        best_feat = str(best_feat)

    # Compute raw score via the same logistic as ensure_cbf_scores (using config)
    s_cfg = (cfg.get("scoring") or {}) if isinstance(cfg, dict) else {}
    stp = (s_cfg.get("sim_to_prob") or {})
    slope = float(stp.get("slope", 6.0))
    midpoint = float(stp.get("midpoint", 0.65))
    try:
        sim_val = float(topk["__sim__"].mean())
    except (TypeError, ValueError, AttributeError):
        sim_val = 0.0
    try:
        score_raw = 1.0 / (1.0 + np.exp(-slope * (max(0.0, min(1.0, sim_val)) - midpoint)))
    except (TypeError, ValueError, ArithmeticError, OverflowError):
        score_raw = float(sim_val)

    reason = reason_if_strong if sim_val >= float(min_similarity) else reason_if_weak
    payload = {
        "feature_id": best_feat,
        "reason": reason,
        # expose similarity in both names for downstream/audit
        "similarity": float(sim_val),
        "sim_cbf_raw": float(sim_val),
        "max_similarity": float(sim_val),
        # raw logistic mapping kept for transparency (may be unused by pipeline)
        "score_cbf_raw": float(score_raw),
        "explanation": "",
        "explanation_clinical": "",
        "advice": "",
        "source": "",
    }
    # Optional logging
    if logger_obj is not None and hasattr(logger_obj, "debug"):
        try:
            logger_obj.debug(f"[{log_id}] pick_cbf_recommendation → {payload}")
        except (TypeError, ValueError, AttributeError):
            pass
    return payload

from typing import List, Dict, Any, Optional, Tuple, Protocol, runtime_checkable
from pipeline.helperscbf import recommend_by_similarity
from pipeline.helperscbf import find_best_contextual_recommendation

from pipeline.helperscbf import (
    aggregate_contextual_groupings,
    make_context_key,
)
from pipeline.helperscbf import populate_narratives, assert_narrative_consistency

# --- Similarity→probability & optional isotonic model application (with safe fallbacks) ---
try:
    from pipeline.helperscbf import prob_from_similarity, apply_isotonic_if_available  # type: ignore
except (ImportError, AttributeError):
    def prob_from_similarity(sim: float, cfg: dict | None = None) -> float:
        """Logistic mapping of similarity ∈[0,1] → probability-like score; fallback if helpers unavailable."""
        try:
            import math
            if cfg is None:
                cfg = {}
            stp = (cfg.get("sim_to_prob", {}) if isinstance(cfg, dict) else {})
            slope = float(stp.get("slope", 12.0))
            mid   = float(stp.get("midpoint", 0.80))
            x = 0.0 if sim is None else float(sim)
            x = 0.0 if x < 0.0 else (1.0 if x > 1.0 else x)
            return 1.0 / (1.0 + math.exp(-slope * (x - mid)))
        except (TypeError, ValueError, ArithmeticError):
            # Fallback to raw similarity if inputs are invalid or math fails
            try:
                return float(sim or 0.0)
            except (TypeError, ValueError):
                return 0.0


    def apply_isotonic_if_available(df, score_col: str, model_path: str, logger_obj=None):
        """Fallback no-op when helpers are unavailable."""
        if logger_obj is not None:
            try:
                logger_obj.debug(
                    "[CBF][fallback] Isotonic unavailable; skipping calibration. score_col=%s, model_path=%s",
                    score_col, model_path,
                )
            except (TypeError, ValueError, AttributeError):
                pass
        return df

from utils.constants import (
    CONTEXT_TO_RECOMMENDATION_MAP,
    FEATURE_ID_BINNED_MAP,
    MEDICAL_RECOMMENDATION_PLAN,
    CONTEXT_COLUMNS,
    SECONDARY_CONTEXT_COLUMNS,
)

from utils.constants import downcast_context
from utils.context_utils import normalize_context_value as normalize_context_value_ext

# === Unified context/family ID utilities ===
from utils.context_utils import ensure_feature_id_binned_and_context

# استيراد توحيد الميزة
from utils.context_utils import sanitize_feature_id
from utils.constants import canonicalize_feature_id

# ---- Debug/guard rails from config ----
from utils.config_loader import load_global_config

# === Debug/guard rails loaded from config ===
try:
    _GLOBAL_CFG = load_global_config()
except (ImportError, OSError, ValueError):
    _GLOBAL_CFG = {}

_DEBUG_CFG = _GLOBAL_CFG.get("debug", {}) if isinstance(_GLOBAL_CFG, dict) else {}
_EXPORT_FULL_CONTEXT_COMBOS = bool(_DEBUG_CFG.get("export_full_context_combinations", False))
_MAX_CONTEXT_COMBOS = int(_DEBUG_CFG.get("max_context_combos", 1_000_000))
_MAX_CONFLICT_LOGS = int(_DEBUG_CFG.get("max_conflict_logs", 200))
_EXPORT_MODEL_CONTEXT_LIST = bool((_DEBUG_CFG.get("export_model_contexts", False)) or (_DEBUG_CFG.get("export_model_context_list", False)))

# --- Helper: Downcast context columns to category for memory and groupby ---

def _cast_context_to_category(df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    """Downcast context columns to 'category' to reduce memory; enables observed=True groupby."""
    for c in cols:
        if c in df.columns and not _is_categorical(df[c]):
            try:
                df[c] = df[c].astype("category")
            except (TypeError, ValueError):
                pass
    return df

class _ConflictLogger:
    """Throttle conflict logs."""
    def __init__(self, max_logs: int) -> None:
        self._max = max_logs
        self._n = 0
    def warn(self, logger_obj, msg: str, *args) -> None:
        if self._n < self._max:
            logger_obj.warning(msg, *args)
            self._n += 1
        elif self._n == self._max:
            logger_obj.warning("[CBF][Conflict] Further conflict logs suppressed after %d entries…", self._max)
            self._n += 1

_CONFLICT_LOG = _ConflictLogger(_MAX_CONFLICT_LOGS)

 # ---------- Local, signature-free KNN fallback (categorical Hamming) ----------
from collections import Counter

def _local_knn_fallback(ctx: dict,
                        df_train: pd.DataFrame,
                        context_cols: list,
                        k: int = 5,
                        sim_metric: str = "hamming",
                        knn_min_similarity: float = 0.60) -> Optional[dict]:
    """Signature-agnostic KNN fallback using simple Hamming similarity on categorical context cols.
    Returns a dict {recommendation, details, match_level} or None if df_train empty.
    """
    if not isinstance(df_train, pd.DataFrame) or df_train.empty:
        return None
    k = int(max(int(k), 1))
    # Honor sim_metric parameter (currently only 'hamming' implemented); log if different
    if str(sim_metric).lower() != "hamming":
        logger.info("[CBF][_local_knn_fallback] Unsupported sim_metric=%s; falling back to 'hamming'", sim_metric)
    # Ensure needed columns exist
    cols = [c for c in context_cols if c in df_train.columns]
    if not cols or "feature_id" not in df_train.columns:
        return None
    # Normalize a copy to avoid changing self.df
    tmp = df_train[cols + ["feature_id"]].copy()
    for c in cols:
        try:
            tmp[c] = tmp[c].astype(str).str.strip().str.lower().str.replace(" ", "_", regex=False)
        except (AttributeError, TypeError, ValueError):
            tmp[c] = tmp[c].astype(str)
    # Normalize context
    ctx_norm = {c: str(ctx.get(c, "unknown")).strip().lower().replace(" ", "_") for c in cols}
    # Compute Hamming similarity: matches / len(cols)
    try:
        matches = sum([(tmp[c] == ctx_norm[c]).astype(int) for c in cols])
        sim = matches / float(len(cols))
    except (KeyError, TypeError, ValueError, ArithmeticError):
        # Fallback: 0 similarity
        sim = pd.Series(0.0, index=tmp.index)
    tmp["__sim__"] = sim
    # Take top-k by similarity (stable sort, highest first)
    topk = tmp.sort_values("__sim__", ascending=False).head(k)
    if topk.empty:
        return None
    # Majority vote on feature_id among top-k; break ties by higher average similarity per feature
    cnt = Counter(topk["feature_id"])
    # Pre-compute mean similarity per feature to avoid Series-to-float ambiguity
    sim_means = topk.groupby("feature_id")["__sim__"].mean().to_dict()
    best_feat, _ = max(
        cnt.items(),
        key=lambda it: (
            it[1],
            float(sim_means.get(it[0], 0.0))
        ),
    )
    # Canonicalize/sanitize the chosen feature
    try:
        _best_feat_canon = sanitize_feature_id(best_feat)
    except (TypeError, ValueError, AttributeError):
        _best_feat_canon = None
    best_feat = _best_feat_canon or best_feat
    details = {
        "k": k,
        "sim_metric": str(sim_metric),
        "topk_size": int(len(topk)),
        "avg_sim": float(topk["__sim__"].mean()),
        "best_feat_support": int(cnt[best_feat]),
    }

    # NEW: ترقية fallback إلى knn_recommendation عند avg_sim الكافي
    match_level = "knn_recommendation" if float(details["avg_sim"]) >= float(knn_min_similarity) else "knn_fallback"
    return {"recommendation": best_feat, "details": f"local_knn hamming: {details}", "match_level": match_level}

def safe_context_combos_diagnostics(df: pd.DataFrame, agg_table: pd.DataFrame, logger_obj, full_cols: List[str] = None) -> None:
    """
    Logs estimated coverage of context combinations without full Cartesian expansion.
    Respects config flags; avoids memory spikes.
    """
    try:
        context_cols = list(CONTEXT_COLUMNS) + list(SECONDARY_CONTEXT_COLUMNS)
        _cast_context_to_category(df, context_cols.copy())
        # Use existing estimator if available, else compute quickly
        try:
            total_est, _sizes = _estimate_total_context_combinations(df, context_cols)
        except NameError:
            # Fallback estimator
            sizes: List[int] = []
            for c in context_cols:
                if c in df.columns:
                    try:
                        sizes.append(int(df[c].nunique(dropna=True)))
                    except (TypeError, ValueError):
                        sizes.append(0)
                else:
                    sizes.append(0)
            total_est = 1
            for s in sizes:
                total_est *= max(int(s), 1)

        use_cols = full_cols if full_cols is not None else [c for c in context_cols if c in agg_table.columns]
        try:
            covered = int(agg_table[use_cols].drop_duplicates().shape[0]) if use_cols else int(agg_table.drop_duplicates().shape[0])
        except (KeyError, ValueError, TypeError):
            covered = int(agg_table.drop_duplicates().shape[0])

        uncovered = max(total_est - covered, 0)
        logger_obj.info("[CBF][Context Combos] Estimated total combinations: %s, Covered: %s, Uncovered: %s",
                        total_est, covered, uncovered)

        if _EXPORT_FULL_CONTEXT_COMBOS and total_est <= _MAX_CONTEXT_COMBOS:
            # لا ننفّذ التوسيع فعليًا لتجنّب OOM—فقط نسجّل القرار.
            logger_obj.info("[CBF][Context Combos] Full grid expansion ENABLED by config but intentionally skipped to avoid memory pressure.")
        else:
            if _EXPORT_FULL_CONTEXT_COMBOS and total_est > _MAX_CONTEXT_COMBOS:
                logger_obj.warning("[CBF][Context Combos] Skipping full expansion: estimated %s exceeds cap %s.",
                                   total_est, _MAX_CONTEXT_COMBOS)
            else:
                logger_obj.info("[CBF][Debug] Skipped full context combination expansion (disabled by config).")
    except MemoryError as e:
        logger_obj.warning("[CBF][Context Combos] MemoryError during diagnostics: %s", e)
    except (KeyError, ValueError, TypeError) as e:
        logger_obj.warning("[CBF][Context Combos] Non-fatal error during diagnostics: %s", e)


# ---------- إدارة دمج/إضافة التوصيات بالقاموس ----------
import os
def add_or_update_recommendation(agg_table, context_row, feature_id, context_cols, secondary_context_cols, log_path="outputs/CBF/manual_updates_log.csv"):
    """
    Adds or updates a recommendation in the aggregation table (agg_table).
    Logs all manual updates for audit trail.
    """
    all_context_cols = get_all_context_cols(context_cols, secondary_context_cols)
    context_key = make_context_key({col: context_row[col] for col in all_context_cols}, context_columns=all_context_cols)
    exists = (agg_table['context_key'] == context_key) & (agg_table['feature_id'] == feature_id)
    if hasattr(exists, "any") and exists.any():
        agg_table.loc[exists, 'score_cbf'] = 0.98
        agg_table.loc[exists, 'status'] = 'manual_update'
    else:
        new_row = {col: context_row[col] for col in all_context_cols}
        new_row.update({
            "feature_id": feature_id,
            "score_cbf": 0.98,
            "status": "manual_update",
            "context_key": context_key
        })
        agg_table = pd.concat([agg_table, pd.DataFrame([new_row])], ignore_index=True)
    # سجل كل تعديل يدوي بملف تتبع
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    with open(log_path, "a") as f:
        f.write(f"{context_key},{feature_id},manual_update\n")
    return agg_table

# ---------- تصدير السياقات المتضاربة ----------
def export_conflicting_contexts(agg_table, context_cols, secondary_context_cols, out_path="outputs/CBF/conflicting_contexts.csv"):
    """
    Exports all context combinations with conflicting recommendations (more than one feature_id per context).
    """
    all_context_cols = get_all_context_cols(context_cols, secondary_context_cols)
    conflicts = (
        agg_table.groupby(all_context_cols)["feature_id"].nunique().reset_index()
    )
    conflicts = conflicts[conflicts["feature_id"] > 1]
    if not conflicts.empty:
        conflict_keys = conflicts[all_context_cols]
        result = agg_table.merge(conflict_keys, on=all_context_cols, how="inner")
        result.to_csv(out_path, index=False)
    else:
        # إذا لا يوجد تعارض، أنشئ ملف فارغ
        pd.DataFrame(columns=all_context_cols+["feature_id"]).to_csv(out_path, index=False)

# ---------- حل التضارب تلقائيًا ----------
def resolve_conflicts_in_agg_table(agg_table, context_cols, secondary_context_cols):
    """
    For each context with conflicting feature_id, keep only the most frequent or flag as manual_review if no clear majority.
    """
    # نبحث عن تضارب (context تكرار >1 feature_id)
    all_context_cols = get_all_context_cols(context_cols, secondary_context_cols)
    grouped = agg_table.groupby(all_context_cols)["feature_id"].nunique().reset_index()
    conflict_keys = grouped[grouped["feature_id"] > 1][all_context_cols]
    resolved = []
    for _, ctx in conflict_keys.iterrows():
        comp = (agg_table[all_context_cols] == pd.Series(ctx.values, index=all_context_cols))
        if isinstance(comp, pd.DataFrame):
            mask = comp.all(axis=1)
        else:
            mask = comp
        sub = agg_table[mask]
        counts = sub["feature_id"].value_counts()
        if counts.iloc[0] > 1:  # يوجد ميّزة الأكثرية
            main_feature = counts.idxmax()
            # حافظ فقط على الأكثرية، علم البقية بmanual_review
            for idx, row in sub.iterrows():
                if row["feature_id"] == main_feature:
                    resolved.append(agg_table.loc[idx])
                else:
                    r = agg_table.loc[idx].copy()
                    r["feature_id"] = "manual_review"
                    r["status"] = "conflict_manual_review"
                    resolved.append(r)
        else:
            # لا يوجد أكثرية واضحة، كلهم manual_review
            for idx, row in sub.iterrows():
                r = agg_table.loc[idx].copy()
                r["feature_id"] = "manual_review"
                r["status"] = "conflict_manual_review"
                resolved.append(r)
        # احذف الصفوف الأصلية المؤقتة (سيتم استبدالها لاحقًا)
        agg_table = agg_table.drop(sub.index)
    # أعد الصفوف المحلولة
    if resolved:
        agg_table = pd.concat([agg_table, pd.DataFrame(resolved)], ignore_index=True)
    return agg_table

# ---------- Context Normalization Utility ----------

def normalize_context_value(val):
    if val is None:
        return "any"
    return str(val).strip().lower().replace(" ", "_")

# --------- Feature Normalization Utility ----------
def normalize_feature_value(val: object) -> str:
    """
    Normalize a feature value to a canonical, lowercase, underscore-separated token.
    Returns 'unknown' for empty/None/NaN-like strings.
    """
    s = "" if val is None else str(val)
    s = s.strip()
    if s == "":
        return "unknown"
    s_lower = s.lower()
    if s_lower in ("none", "nan", "na", "null"):
        return "unknown"
    return s_lower.replace(" ", "_")


# ---------- Manual-review contextual fallback mapping ----------

def map_manual_to_real_feature(row: pd.Series, context_cols=None):
    """Map a manual_review to a concrete feature_id using clinical maps.
    Order: MEDICAL_RECOMMENDATION_PLAN (full ctx) -> CONTEXT_TO_RECOMMENDATION_MAP (first 3) -> FEATURE_ID_BINNED_MAP (first 3).
    Returns tuple: (feature_id, reason, explanation, source, status)
    """
    if context_cols is None:
        context_cols = CONTEXT_COLUMNS

    # Build normalized full-context tuple
    ctx_tuple = tuple(normalize_context_value(row.get(c, "any")) for c in context_cols)

    plan = MEDICAL_RECOMMENDATION_PLAN.get(ctx_tuple)
    if plan is None:
        ctx3 = tuple(ctx_tuple[:3])
        plan = CONTEXT_TO_RECOMMENDATION_MAP.get(ctx3) or FEATURE_ID_BINNED_MAP.get(ctx3)

    if plan:
        if isinstance(plan, dict):
            action = plan.get("action") or plan.get("feature_id") or "manual_review"
            reason = "final_fallback"
            expl = plan.get("explanation")
            src = plan.get("source")
        else:
            action = str(plan)
            reason = "final_fallback"
            expl = None
            src = None
        return action, reason, expl, src, "contextual_fallback"

    # No plan found at any level
    return "manual_review", None, None, None, "no_map"


def finalize_feature_id(df_rec: pd.DataFrame, context_cols=None) -> pd.DataFrame:
    """Apply contextual fallback to rows whose feature_id == 'manual_review'.
    This produces a concrete feature_id when possible before writing CSVs.
    """
    if "feature_id" not in df_rec.columns:
        return df_rec

    mask = df_rec["feature_id"].astype(str).eq("manual_review")
    if not mask.any():
        return df_rec

    mapped = df_rec.loc[mask].apply(
        lambda r: pd.Series(
            map_manual_to_real_feature(r, context_cols),
            index=["feature_id", "reason", "explanation", "source", "status"],
        ),
        axis=1,
    )
    for col in mapped.columns:
        df_rec.loc[mask, col] = mapped[col]

    # Normalize after mapping
    df_rec["feature_id"] = df_rec["feature_id"].astype(str).apply(normalize_feature_value)
    return df_rec


core_keys = ["patient_id"] + list(CONTEXT_COLUMNS)

class CBFRecommender:
    """
    Content-Based Recommendation System (CBF) – Advanced, Context-Aware.
    Uses context grouping, KNN fallback, robust encoding, and clinical traceability.

    Parameters
    ----------
    config : dict
        System-wide configuration (as loaded from config.yaml).
    """

    def __init__(self, config: Dict[str, Any]) -> None:
        self.config: Dict[str, Any] = config
        # Always use CONTEXT_COLUMNS from constants for consistency
        self.context_cols: List[str] = list(CONTEXT_COLUMNS)
        self.secondary_context_cols: List[str] = list(SECONDARY_CONTEXT_COLUMNS)
        self.is_fitted: bool = False
        self.df: Optional[pd.DataFrame] = None
        self.agg_table: Optional[pd.DataFrame] = None
        self.context_encoders: Optional[dict] = None
        # map: tuple(CONTEXT_COLUMNS) -> top feature_id (mode)
        self.agg_map: Dict[tuple, str] = {}
        # تتبع الأعمدة السياقية الأساسية والثانوية
        logger.info(f"[CBF][Config] Using context columns: {self.context_cols}")
        logger.info(f"[CBF][Config] Using secondary context columns: {self.secondary_context_cols}")
        self.all_context_cols = get_all_context_cols(self.context_cols, self.secondary_context_cols)

    def fit(
        self,
        df: pd.DataFrame,
        group_rare_contexts: bool = False,
        min_context_size: Optional[int] = 1
    ) -> None:
        """
        Fit/prepare the CBF recommender: encode context, aggregate, group rare contexts if needed.

        Parameters
        ----------
        df : pd.DataFrame
            Contextualized data including all context and feature columns.
        group_rare_contexts : bool
            If True, merge rare context combinations into a 'rare' group.
        min_context_size : int or None
            Minimum frequency for a context to be kept as-is. If None or 0, disables grouping.
        """
        import os
        logger.info(f"[CBF][fit] ====== Started fitting CBFRecommender on {len(df)} rows ======")
        assert isinstance(df, pd.DataFrame), f"Input df must be a pandas DataFrame, got {type(df)}"
        df_train = df.copy()

        # Normalize only the 6 core context columns (no Cartesian expansion)
        for c in CONTEXT_COLUMNS:
            if c in df_train.columns:
                df_train.loc[:, c] = df_train[c].apply(normalize_context_value_ext)
            else:
                df_train.loc[:, c] = "unknown"

        # Normalize feature_id early and ensure string
        df_train["feature_id"] = df_train["feature_id"].astype(str).apply(normalize_feature_value)

        # Ensure family/context IDs exist before any potential contextual rerank
        try:
            df_train = ensure_feature_id_binned_and_context(df_train, log=logger, log_id="[CBF][fit]")
        except (TypeError, ValueError, KeyError, AttributeError) as _ex:
            logger.warning("[CBF][fit] ensure_feature_id_binned_and_context skipped: %s", _ex)
        # Memory-aware downcast of context columns
        try:
            downcast_context(df_train, CONTEXT_COLUMNS)
        except (TypeError, ValueError, KeyError):
            pass

        # Optional rare-context grouping driven by parameters
        try:
            do_grouping = bool(group_rare_contexts) and (min_context_size is not None) and int(min_context_size) > 1
        except (TypeError, ValueError):
            do_grouping = False
        if do_grouping:
            logger.info("[CBF][fit] Grouping rare contexts: min_context_size=%s", min_context_size)
            try:
                df_train = aggregate_contextual_groupings(
                    df_train,
                    CONTEXT_COLUMNS,
                    min_freq=int(min_context_size),
                    logger=logger,
                )
            except (KeyError, ValueError, TypeError) as exc_group:
                logger.warning("[CBF][fit] Rare-context grouping skipped due to %s: %s", type(exc_group).__name__, exc_group)
        else:
            logger.info("[CBF][fit] Rare-context grouping disabled (group_rare_contexts=%s, min_context_size=%s)", group_rare_contexts, min_context_size)

        # Aggregate by CONTEXT_COLUMNS → top-1 feature (mode) per context; if no mode, mark manual_review
        agg = (
            df_train
            .groupby(CONTEXT_COLUMNS, observed=True, sort=False)["feature_id"]
            .agg(lambda s: s.mode().iloc[0] if not s.mode().empty else "manual_review")
            .reset_index()
        )

        # Build fast lookup map (tuple key)
        self.agg_map = {tuple(r[c] for c in CONTEXT_COLUMNS): r["feature_id"] for _, r in agg.iterrows()}

        # Keep a copy of the aggregation table for auditing
        self.agg_table = agg.copy()

        # Export covered context combinations (controllable by config.debug.export_model_contexts)
        try:
            debug_dir = "outputs/debug"
            # Prefer instance config; fall back to _GLOBAL_CFG for backward-compat
            _local_debug = (self.config.get("debug", {}) if isinstance(self.config, dict) else {})
            export_model_ctx = bool(
                _local_debug.get("export_model_contexts", False)
                or ((_GLOBAL_CFG.get("debug", {}) or {}).get("export_model_contexts", False))
            )
            if export_model_ctx:
                os.makedirs(debug_dir, exist_ok=True)
                covered_path = os.path.join(debug_dir, "context_combinations_in_model.csv")
                agg[CONTEXT_COLUMNS + ["feature_id"]].drop_duplicates().to_csv(covered_path, index=False)
                logger.info(f"[CBF][fit] Exported {len(agg)} context-mode pairs to {covered_path}")
            else:
                logger.debug("[CBF][fit] export_model_contexts=False → skipping model context export.")
        except (OSError, TypeError, ValueError) as exc_export:
            logger.warning("[CBF][fit] Could not export context combinations: %s", exc_export)

        self.df = df_train
        self.is_fitted = True
        logger.info(f"✅ Fitted (non-Cartesian): {len(self.agg_map)} unique contexts in map. Table shape: {self.agg_table.shape}")

    def recommend(self, context_row: pd.Series, top_n: int = 3, knn_k: int = 5, sim_metric: str = "hamming", allow_exact: bool = True) -> List[Dict[str, Any]]:
        """
        Recommend best feature(s) for a new patient/context.

        Parameters
        ----------
         self : CBFRecommender
            Instance of the recommender.

        context_row : pd.Series
            Single patient/context row with all necessary context columns.
        top_n : int
            Number of top recommendations to return.
        knn_k : int
            Number of nearest contexts for KNN fallback.
        sim_metric : str
            Similarity metric ("hamming", "cosine", etc.).
        allow_exact : bool
            Whether to allow exact context matches (via aggregation map). Defaults to True. Set to False in strict evaluation (LOCO/GroupKFold) to avoid leakage.

        Returns
        -------
        List[Dict[str, Any]]
            List of recommendations with details, explanations, and traceability.
        """
        logger.info(f"[CBF][recommend] ====== Starting recommendation for context: {context_row.to_dict()} ======")
        assert self.is_fitted, "Call fit() before recommend()."
        assert isinstance(context_row, pd.Series), f"context_row must be pd.Series, got {type(context_row)}"

        # Normalize input row on the 6 core context columns only
        ctx = {}
        for c in CONTEXT_COLUMNS:
            val = context_row.get(c, "unknown")
            ctx[c] = normalize_context_value_ext(val)
        key = tuple(ctx[c] for c in CONTEXT_COLUMNS)

        # Config-driven gate to allow/disable exact matches globally
        try:
            _allow_exact_cfg = bool(((self.config.get("cbf", {}) or {}).get("allow_exact_in_recommend", True)))
        except (AttributeError, TypeError, ValueError):
            _allow_exact_cfg = True
        allow_exact_eff = bool(allow_exact) and _allow_exact_cfg

        # Helper to enrich with clinical plan (unified selector with fallback)
        def _with_plan_payload(fid: str, reason: str, match_type: str, status: str) -> Dict[str, Any]:
            # Narratives are populated later via helperscbf.populate_narratives(); no plan fetch here to avoid unused variables.

            # Sanitize via canonical dictionary, then normalize as a final fallback
            try:
                _fid_sanit = sanitize_feature_id(fid)
            except (TypeError, ValueError, AttributeError):
                _fid_sanit = None
            fid_out = _fid_sanit if _fid_sanit else fid

            return {
                "feature_id": normalize_feature_value(fid_out),
                "score_cbf": None,
                # Keep canonical reason; do not backfill from plan_info to avoid confusion.
                "reason": reason if reason is not None else "",
                # Leave narratives empty here; they will be populated by helperscbf.populate_narratives()
                "explanation": "",
                "advice": "",
                "explanation_clinical": "",
                "source": "",
                "match_type": match_type,
                "status": status,
            }

        # 1) Exact context match from aggregation map → recommended (score 1.0)
        candidates = []
        if allow_exact_eff and key in self.agg_map:
            feat = self.agg_map[key]
            try:
                feat = sanitize_feature_id(feat) or feat
            except (TypeError, ValueError, AttributeError):
                pass
            logger.info("[CBF][recommend] Exact context match → %s", feat)
            candidates.append({
                **_with_plan_payload(
                    feat,
                    "context_key_match",
                    "Exact",
                    "context_key_match",
                ),
                "sim_cbf_raw": 1.0,
                "similarity": 1.0,
                "max_similarity": 1.0,
            })

        # 2) Contextual rule-based match → recommended (score 1.0)
        try:
            best_ctx = find_best_contextual_recommendation(
                context=ctx,
                dictionary=self.df if isinstance(self.df, pd.DataFrame) else pd.DataFrame(),
                secondary_cols=list(SECONDARY_CONTEXT_COLUMNS),
                target_col="feature_id",
                config=self.config,
                verbose=False,
            )
            if isinstance(best_ctx, dict):
                _feat2_raw = best_ctx.get("recommendation", "manual_review")
                try:
                    feat2 = sanitize_feature_id(_feat2_raw) or _feat2_raw
                except (TypeError, ValueError, AttributeError):
                    feat2 = _feat2_raw
                feat2 = normalize_feature_value(feat2)
                if feat2 != "manual_review":
                    candidates.append({
                        **_with_plan_payload(
                            feat2,
                            "context_key_match",
                            best_ctx.get("match_level", "contextual_rule"),
                            "contextual_rule"
                        ),
                        "sim_cbf_raw": 0.90,
                        "similarity": 0.90,
                    })
        except (KeyError, ValueError, TypeError) as exc_ctx:
            logger.warning("[CBF][recommend] best-context resolution skipped due to %s: %s", type(exc_ctx).__name__, exc_ctx)

        # Similarity params from config
        try:
            sim_cfg = (self.config or {}).get("cbf", {}).get("similarity", {})
            knn_k_eff = int(sim_cfg.get("k", knn_k))
            min_sim = float(sim_cfg.get("min_similarity", 0.7))
        except (AttributeError, TypeError, ValueError):
            knn_k_eff, min_sim = knn_k, 0.7

        # Track if a high-quality similarity (KNN-like) candidate was produced
        has_knn_sim = False
        sim_feat_id = None
        # 3) Similarity-based recommendation (preferred over local KNN fallback)
        try:
            sim = recommend_by_similarity(
                context=ctx,
                dictionary=self.df if isinstance(self.df, pd.DataFrame) else pd.DataFrame(),
                target_col="feature_id",
                k=max(int(knn_k_eff), 1),
                min_similarity=min_sim,
                verbose=False,
            )
            if isinstance(sim, dict):
                _feat3_raw = sim.get("recommendation", "manual_review")
                try:
                    feat3 = sanitize_feature_id(_feat3_raw) or _feat3_raw
                except (TypeError, ValueError, AttributeError):
                    feat3 = _feat3_raw
                feat3 = normalize_feature_value(feat3)
                if feat3 != "manual_review":
                    # Robustly parse similarity from details
                    try:
                        import re as _re
                        _det = str(sim.get("details", ""))
                        _m = _re.search(r"avg_sim[:=]\s*([0-9]*\.?[0-9]+)", _det)
                        simv = float(_m.group(1)) if _m else 0.80
                    except (ValueError, TypeError, AttributeError, ImportError, NameError):
                        simv = 0.80
                    # Choose reason label based on configured KNN similarity threshold
                    try:
                        knn_min_sim_eff = float(((self.config.get("cbf", {}) or {}).get("knn", {}) or {}).get("min_similarity", min_sim))
                    except (TypeError, ValueError, AttributeError):
                        knn_min_sim_eff = float(min_sim)
                    if simv >= knn_min_sim_eff:
                        reason_lbl = "knn_recommendation"
                        has_knn_sim = True
                        sim_feat_id = feat3
                    elif simv >= max(knn_min_sim_eff - 0.10, 0.0):
                        reason_lbl = "similarity_fallback_high"
                    elif simv >= max(knn_min_sim_eff - 0.20, 0.0):
                        reason_lbl = "similarity_fallback_medium"
                    else:
                        reason_lbl = "similarity_fallback_low"
                    candidates.append({
                        **_with_plan_payload(
                            feat3,
                            reason_lbl,
                            sim.get("match_level", reason_lbl),
                            "similarity"
                        ),
                        "sim_cbf_raw": simv,
                        "similarity": simv,
                    })
        except (KeyError, ValueError, TypeError) as exc_sim:
            logger.warning("[CBF][recommend] similarity step skipped due to %s: %s", type(exc_sim).__name__, exc_sim)

        # 4) Local KNN fallback — only if no knn-level similarity candidate was found
        # Effective min similarity for local KNN fallback from config (fallback to min_sim from similarity cfg)
        try:
            knn_min_sim_eff = float(((self.config.get("cbf", {}) or {}).get("knn", {}) or {}).get("min_similarity", min_sim))
        except (TypeError, ValueError, AttributeError):
            knn_min_sim_eff = float(min_sim)
        try:
            df_train_safe = self.df if isinstance(self.df, pd.DataFrame) else pd.DataFrame()
            knn = _local_knn_fallback(
                ctx,
                df_train_safe,
                CONTEXT_COLUMNS,
                max(int(knn_k_eff), 1),
                sim_metric=sim_metric,
                knn_min_similarity=knn_min_sim_eff,
            )
            if isinstance(knn, dict):
                _feat4_raw = knn.get("recommendation", "manual_review")
                try:
                    feat4 = sanitize_feature_id(_feat4_raw) or _feat4_raw
                except (TypeError, ValueError, AttributeError):
                    feat4 = _feat4_raw
                feat4 = normalize_feature_value(feat4)
                if feat4 != "manual_review":
                    # If we already have a knn-level similarity pick for the same feature, skip adding fallback
                    if has_knn_sim and (sim_feat_id == feat4):
                        logger.debug("[CBF][recommend] Skipping local KNN fallback: identical to knn-level similarity candidate (%s).", feat4)
                    else:
                        try:
                            import re as _re
                            _m = _re.search(r"avg_sim\'?[:=]\s*([0-9]*\.?[0-9]+)", str(knn.get("details", "")))
                            simv = float(_m.group(1)) if _m else 0.70
                        except (ValueError, TypeError, AttributeError, ImportError, NameError):
                            simv = 0.70
                        candidates.append({
                            **_with_plan_payload(
                                feat4,
                                "knn_fallback",
                                "knn_fallback",
                                "knn"
                            ),
                            "sim_cbf_raw": simv,
                            "similarity": simv,
                        })
        except (KeyError, ValueError, TypeError) as exc_knn:
            logger.warning("[CBF][recommend] local knn fallback skipped due to %s: %s", type(exc_knn).__name__, exc_knn)

        # --- Consolidate candidates: score, gate, sort, return ---
        if candidates:
            df_cand = pd.DataFrame(candidates)
            if "sim_cbf_raw" not in df_cand.columns:
                df_cand["sim_cbf_raw"] = 0.0
            df_cand = ensure_cbf_scores(
                df_cand,
                self.config,
                reason_col="reason",
                sim_col="sim_cbf_raw",
                logger_obj=logger,
                log_id="CBF[recommend]",
            )
            # --- Ensure similarity audit columns exist (for CSV exports) ---
            if "similarity" not in df_cand.columns and "sim_cbf_raw" in df_cand.columns:
                df_cand["similarity"] = df_cand["sim_cbf_raw"]

            # Ensure normalized similarity exists (if ensure_cbf_scores did not add it)
            if "sim_norm" not in df_cand.columns:
                try:
                    _s_cfg = (self.config.get("scoring") or {}) if isinstance(self.config, dict) else {}
                    _sim_min = float(_s_cfg.get("sim_clip_min", 0.0))
                    _sim_max = float(_s_cfg.get("sim_clip_max", 1.0))
                except (TypeError, ValueError, AttributeError):
                    _sim_min, _sim_max = 0.0, 1.0
                _x = pd.to_numeric(df_cand.get("similarity", df_cand.get("sim_cbf_raw", 0.0)), errors="coerce").fillna(_sim_min)
                _rng = (_sim_max - _sim_min) if (_sim_max > _sim_min + 1e-12) else 1.0
                df_cand["sim_norm"] = (_x.clip(_sim_min, _sim_max) - _sim_min) / _rng

            # Max similarity for this (single-patient) recommendation call
            try:
                _max_sim_val = float(pd.to_numeric(df_cand.get("similarity", df_cand.get("sim_cbf_raw", 0.0)), errors="coerce").max())
            except (TypeError, ValueError, AttributeError):
                _max_sim_val = float("nan")
            df_cand["max_similarity"] = _max_sim_val
            # Clinical gating (if available/enabled)
            try:
                from utils.context_utils import filter_candidates_by_clinical_gating as _gate  # type: ignore
                df_cand = _gate(pd.Series(ctx), df_cand, self.config, logger=logger)
            except (ImportError, KeyError, TypeError, ValueError) as e:
                logger.warning("[CBF][recommend] gating failed non-fatally: %s", e)
            # --- Fill narratives from the unified source of truth and enforce consistency ---
            try:
                df_cand = populate_narratives(df_cand)
            except Exception as _pop_ex:
                logger.warning("[CBF][recommend] populate_narratives failed (non-fatal): %s", _pop_ex)
            try:
                df_cand = assert_narrative_consistency(df_cand, logger)
            except Exception as _cons_ex:
                logger.warning("[CBF][recommend] assert_narrative_consistency failed (non-fatal): %s", _cons_ex)

            # Extra guard: if reason indicates knn/context but source contains 'fallback', correct labels
            try:
                if "reason" in df_cand.columns and "source" in df_cand.columns:
                    _r = df_cand["reason"].astype(str).str.lower()
                    _s = df_cand["source"].astype(str).str.lower()
                    _mask_knn = _r.eq("knn_recommendation")
                    _mask_ctx = _r.eq("context_key_match")
                    _mask_fb  = _s.str.contains("fallback", na=False)
                    if (_mask_fb & (_mask_knn | _mask_ctx)).any():
                        logger.error("[CBF] Inconsistent source under knn/context; fixing label.")
                        df_cand.loc[_mask_knn & _mask_fb, "source"] = "CBF (kNN)"
                        df_cand.loc[_mask_ctx & _mask_fb, "source"] = "CBF (exact/context match)"
            except Exception as _guard_ex:
                logger.warning("[CBF][recommend] narrative guard failed (non-fatal): %s", _guard_ex)
            # If a strong KNN recommendation exists, reduce the dominance of exact match in this context
            try:
                # Reuse the same threshold used earlier for KNN similarity
                try:
                    knn_min_sim_eff_local = float(((self.config.get("cbf", {}) or {}).get("knn", {}) or {}).get("min_similarity", 0.60))
                except (AttributeError, TypeError, ValueError):
                    knn_min_sim_eff_local = 0.60
                has_strong_knn = False
                if {"reason", "sim_cbf_raw"}.issubset(df_cand.columns):
                    _knn_mask = df_cand["reason"].astype(str).eq("knn_recommendation")
                    _sim_ok = pd.to_numeric(df_cand.get("sim_cbf_raw", 0.0), errors="coerce").fillna(0.0) >= knn_min_sim_eff_local
                    has_strong_knn = bool((_knn_mask & _sim_ok).any())
            except (TypeError, ValueError, KeyError, AttributeError):
                has_strong_knn = False

            # Priority-aware ordering: prefer stronger reasons, then higher score, then higher similarity, then stable feature_id
            if has_strong_knn:
                priority_map = {
                    "knn_recommendation": 0,
                    "context_key_match": 2,
                    "similarity_fallback_high": 2,
                    "similarity_fallback_medium": 3,
                    "similarity_fallback_low": 4,
                    "knn_fallback": 5,
                    "manual_review": 6,
                }
            else:
                priority_map = {
                    "context_key_match": 0,
                    "knn_recommendation": 1,
                    "similarity_fallback_high": 2,
                    "similarity_fallback_medium": 3,
                    "similarity_fallback_low": 4,
                    "knn_fallback": 5,
                    "manual_review": 6,
                }
            if "reason" in df_cand.columns:
                try:
                    df_cand["reason_priority"] = df_cand["reason"].map(priority_map).fillna(9).astype(int)
                except (TypeError, ValueError):
                    df_cand["reason_priority"] = 9
            else:
                df_cand["reason_priority"] = 9

            df_cand = (
                df_cand.sort_values(["reason_priority", "score_cbf", "sim_cbf_raw", "feature_id"], ascending=[True, False, False, True])
                       .drop_duplicates(subset=["feature_id"])
                       .head(max(int(top_n), 1))
            )

            recs = df_cand.to_dict(orient="records")

            keep_keys = {
                "feature_id",
                "reason",
                "sim_cbf_raw",
                "similarity",
                "sim_norm",
                "max_similarity",
                "score_cbf",
                "source",
                "explanation",
                "explanation_clinical",
                "advice",
            }
            out = []
            for rec in recs:
                safe_rec = {k: rec.get(k) for k in keep_keys}
                # ضمان وجود الحقول الرقمية حتى لو غابت
                if safe_rec.get("sim_cbf_raw") is None:
                    safe_rec["sim_cbf_raw"] = 0.0
                if safe_rec.get("score_cbf") is None:
                    safe_rec["score_cbf"] = 0.0
                if "explanation_clinical" not in safe_rec or safe_rec.get("explanation_clinical") is None:
                    safe_rec["explanation_clinical"] = ""
                if "advice" not in safe_rec or safe_rec.get("advice") is None:
                    safe_rec["advice"] = ""
                out.append(safe_rec)
            return out
        # 5) Manual review (score 0.0)
        return [_with_plan_payload(
            "manual_review",
            "manual_review",
            "manual_review",
            "manual_review"
        )]


    # --- Helper: estimate total context combinations ---
def _estimate_total_context_combinations(df: pd.DataFrame, cols: list) -> Tuple[int, List[int]]:
    sizes: List[int] = []
    for c in cols:
        if c in df.columns:
            try:
                sizes.append(int(df[c].nunique(dropna=True)))
            except (TypeError, ValueError):
                sizes.append(0)
        else:
            sizes.append(0)
    total = 1
    for s in sizes:
        total *= max(s, 1)
    return total, sizes


# ======= دالة مساعدة لتصدير وتتبع التكرارات =======
def export_and_log_duplicates(df, all_context_cols, out_path, logger_instance, tag=""):
    dups = df[df.duplicated(all_context_cols, keep=False)]
    if not dups.empty:
        dups.to_csv(out_path, index=False)
        logger_instance.warning(f"[CBF][Duplicates][{tag}] Exported duplicated rows by {all_context_cols} to {out_path}")
        logger_instance.info(f"[CBF][Duplicates][{tag}] Duplicates file {out_path} contains {len(dups)} rows.")
    else:
        logger_instance.info(f"[CBF][Duplicates][{tag}] No duplicated rows by {all_context_cols}.")




# ======= Utility: Export uncovered context keys =======
def export_uncovered_context_keys(df: pd.DataFrame, all_context_cols: list, out_path: str) -> None:
    """
    Export uncovered context combinations (not present in CONTEXT_TO_RECOMMENDATION_MAP) for auditing.
    Each row includes the context, fallback explanation, and suggested action.
    """
    combos = df[all_context_cols].drop_duplicates()
    if "feature_id" in combos.columns:
        combos["feature_id"] = combos["feature_id"].astype(str).apply(normalize_feature_value)
    from utils.constants import CONTEXT_TO_RECOMMENDATION_MAP
    uncovered = []
    for _, context_row in combos.iterrows():
        # Normalize all context columns before building context_key
        norm_row = {col: normalize_context_value(context_row[col]) for col in all_context_cols}
        context_key = "_".join(norm_row[col] for col in all_context_cols)
        logger.info(f"[CBF][Normalization] Lookup context_key: {context_key}")
        if context_key not in CONTEXT_TO_RECOMMENDATION_MAP:
            logger.warning(f"No recommendation found for context key: {context_key}. Using fallback/manual_review.")
            uncovered.append({
                **{col: norm_row[col] for col in all_context_cols},
                "fallback": "manual_review",
                "explanation": f"No direct recommendation for context: {context_key}. Manual review required."
            })
    pd.DataFrame(uncovered).to_csv(out_path, index=False)
    logger.info(f"[CBF][Audit] Exported uncovered context keys to {out_path} with {len(uncovered)} rows.")

# ======= Utility: Export covered context keys for auditing =======
def export_covered_context_keys(agg_table: pd.DataFrame, all_context_cols: list, out_path: str) -> None:
    """
    Export the set of unique context combinations covered in the aggregation table to a CSV file, for manual auditing.
    """
    combos = agg_table[all_context_cols].drop_duplicates()
    if "feature_id" in combos.columns:
        combos["feature_id"] = combos["feature_id"].astype(str).apply(normalize_feature_value)
    combos.to_csv(out_path, index=False)
    logger.info(f"[CBF][Audit] Exported covered context keys to {out_path} with {len(combos)} rows.")


@runtime_checkable
class _CBFLike(Protocol):
    context_cols: List[str]
    df: Optional[pd.DataFrame]
    def fit(
        self,
        df: pd.DataFrame,
        group_rare_contexts: bool = False,
        min_context_size: Optional[int] = 1
    ) -> None: ...
    def recommend(
        self,
        context_row: pd.Series,
        top_n: int = 3,
        knn_k: int = 5,
        sim_metric: str = "hamming",
        allow_exact: bool = True
    ) -> List[Dict[str, Any]]: ...

# Ensure these are included in __all__:
# "ensure_cbf_scores", "postprocess_scores_cbf", "pick_cbf_recommendation"
__all__ = [
    "compute_cbf_mixed_scores",
    "apply_context_rerank_cbf",
    "postprocess_scores_cbf",
    "train_and_recommend",
    "ensure_cbf_scores",
    "CBFRecommender",
    "finalize_feature_id",
    "apply_isotonic_if_available",
    "pick_cbf_recommendation",
]

# ======= External API for pipeline =======
def train_and_recommend(df: pd.DataFrame, config: Dict[str, Any], patient_context_row: pd.Series, **kwargs) -> List[Dict[str, Any]]:
    """
    API for pipeline/cbf_pipeline.py.
    Trains CBF, returns recommendations for a new context.

    Parameters
    ----------
    df : pd.DataFrame
        Contextualized input data.
    config : dict
        Configuration loaded from config.yaml.
    patient_context_row : pd.Series
        Context row for recommendation.

    Returns
    -------
    list of dict: Recommendations.
    """
    logger.info(f"[CBF][train_and_recommend] ====== Started training and recommendation on {len(df)} rows. ======")
    assert isinstance(df, pd.DataFrame), f"df must be pd.DataFrame, got {type(df)}"
    assert isinstance(patient_context_row, pd.Series), f"patient_context_row must be pd.Series, got {type(patient_context_row)}"
    cbf = CBFRecommender(config)
    # Lightweight runtime guard without triggering static "unreachable" warnings
    missing_members = [attr for attr in ("fit", "recommend", "context_cols") if not hasattr(cbf, attr)]
    if missing_members:
        raise TypeError(f"CBFRecommender missing required members: {missing_members}")
    cbf_typed: _CBFLike = cbf
    try:
        cbf_typed.fit(df, **kwargs)
        recs = cbf_typed.recommend(patient_context_row)
    except (KeyError, ValueError) as e:
        logger.error(f"Data mismatch error: {e}")
        raise
    df_recs = pd.DataFrame(recs)
    if "score_cbf" in df_recs.columns:
        df_recs = _clip_round_scores(df_recs, "score_cbf")
    # --------- تطبيع feature_id بعد التوصيات مباشرة ---------
    df_recs["feature_id"] = df_recs["feature_id"].astype(str).apply(normalize_feature_value)
    try:
        df_recs["feature_id"] = df_recs["feature_id"].map(canonicalize_feature_id).fillna(df_recs["feature_id"])
    except (TypeError, ValueError, AttributeError, KeyError):
        # keep pipeline resilient if canonicalization fails
        pass
    # --------- Contextual fallback: convert manual_review to concrete feature_id when possible ---------
    try:
        df_recs = finalize_feature_id(df_recs, context_cols=cbf_typed.context_cols)
    except (KeyError, ValueError) as e:
        logger.error(f"Data mismatch error: {e}")
        raise

    # Ensure required similarity columns exist for downstream CSV (df_cbf_recommendations.csv)
    if "similarity" not in df_recs.columns and "sim_cbf_raw" in df_recs.columns:
        df_recs["similarity"] = df_recs["sim_cbf_raw"]
    if "sim_norm" not in df_recs.columns:
        try:
            _s_cfg = (config.get("scoring") or {}) if isinstance(config, dict) else {}
            _sim_min = float(_s_cfg.get("sim_clip_min", 0.0))
            _sim_max = float(_s_cfg.get("sim_clip_max", 1.0))
        except (TypeError, ValueError, AttributeError):
            _sim_min, _sim_max = 0.0, 1.0
        _x = pd.to_numeric(df_recs.get("similarity", df_recs.get("sim_cbf_raw", 0.0)), errors="coerce").fillna(_sim_min)
        _rng = (_sim_max - _sim_min) if (_sim_max > _sim_min + 1e-12) else 1.0
        df_recs["sim_norm"] = (_x.clip(_sim_min, _sim_max) - _sim_min) / _rng
    if "max_similarity" not in df_recs.columns:
        try:
            df_recs["max_similarity"] = float(pd.to_numeric(df_recs.get("similarity", df_recs.get("sim_cbf_raw", 0.0)), errors="coerce").max())
        except (TypeError, ValueError, KeyError, AttributeError):
            df_recs["max_similarity"] = np.nan

    # Priority-aware ordering for pipeline output (consistency with CBFRecommender.recommend)
    if "reason" in df_recs.columns:
        _priority_map = {
            "context_key_match": 0,
            "knn_recommendation": 1,
            "similarity_fallback_high": 2,
            "similarity_fallback_medium": 3,
            "similarity_fallback_low": 4,
            "knn_fallback": 5,
            "manual_review": 6,
        }
        try:
            df_recs["reason_priority"] = df_recs["reason"].map(_priority_map).fillna(9).astype(int)
            if {"reason_priority", "score_cbf"}.issubset(df_recs.columns):
                df_recs = df_recs.sort_values(["reason_priority", "score_cbf"], ascending=[True, False])
        except (TypeError, ValueError, KeyError):
            pass

    # --- Guard: downgrade weak context_key_match by support ---
    try:
        cfg_cbf = (config or {}).get("model_settings", {}).get("cbf", {}) or {}
        min_sup = int(cfg_cbf.get("context_key_match_min_support", 3))
        ctx_cols = list(cbf_typed.context_cols) if hasattr(cbf_typed, "context_cols") else []
        if ctx_cols and {"feature_id", "reason"}.issubset(df_recs.columns):
            base = cbf_typed.df if isinstance(cbf_typed.df, pd.DataFrame) else pd.DataFrame()
            have_cols = [c for c in ctx_cols + ["feature_id"] if c in getattr(base, "columns", [])]
            if len(have_cols) == len(ctx_cols) + 1 and not base.empty:
                support_map = (
                    base.groupby(ctx_cols + ["feature_id"]).size().rename("support").reset_index()
                )
                df_recs = df_recs.merge(support_map, on=ctx_cols + ["feature_id"], how="left")
                df_recs["support"] = df_recs["support"].fillna(0).astype(int)
                weak_mask = (df_recs["reason"] == "context_key_match") & (df_recs["support"] < min_sup)
                if weak_mask.any():
                    df_recs.loc[weak_mask, "reason"] = "similarity_fallback_high"
    except (TypeError, ValueError, KeyError, AttributeError) as _exc:
        logger.warning("[CBF] downgrade weak context_key_match skipped due to %s", _exc)

    # Ensure sim_cbf_raw column exists for downstream scoring/audit
    if "sim_cbf_raw" not in df_recs.columns:
        try:
            import numpy as _np
            df_recs["sim_cbf_raw"] = _np.nan
        except (ImportError, AttributeError, TypeError, ValueError, KeyError):
            df_recs["sim_cbf_raw"] = None
    # --- تتبع التكرارات قبل حذفها ---
    n_before = len(df_recs)
    n_dups_before = df_recs.duplicated(subset=cbf_typed.context_cols + ["feature_id"]).sum()
    logger.info(f"[CBF][DropDuplicates][Recommendations][BeforeDrop] Rows: {n_before}, Duplicates by {cbf_typed.context_cols + ['feature_id']}: {n_dups_before}")
    export_and_log_duplicates(df_recs, cbf_typed.context_cols + ["feature_id"], "outputs/CBF/duplicated_recommendations.csv", logger, tag="recommendations")
    df_recs = df_recs.drop_duplicates(subset=cbf_typed.context_cols + ["feature_id"])
    n_after = len(df_recs)
    n_removed = n_before - n_after
    logger.info(f"[CBF][DropDuplicates][Recommendations][AfterDrop] Dropped {n_removed} duplicates using columns: {cbf_typed.context_cols + ['feature_id']}. Rows before: {n_before}, after: {n_after}")
    remain_dups = df_recs.duplicated(subset=cbf_typed.context_cols + ["feature_id"]).sum()
    logger.info(f"[CBF][DropDuplicates][Recommendations][AfterDrop] Remaining duplicates: {remain_dups}")
    # Auto-export uncovered context keys after training/recommendation
    debug_dir = "outputs/debug"
    import os
    os.makedirs(debug_dir, exist_ok=True)
    uncovered_path = os.path.join(debug_dir, "uncovered_context_combinations.csv")
    try:
        export_uncovered_context_keys(df, cbf_typed.context_cols, uncovered_path)
    except (KeyError, ValueError) as e:
        logger.error(f"Data mismatch error: {e}")
        raise
    logger.info(f"[CBF][train_and_recommend] ====== Finished training and recommendation. Returned {len(df_recs)} recommendations. ======")
    return [{str(k): v for k, v in rec.items()} for rec in df_recs.to_dict(orient="records")]


# --------- Improved feature_id mismatch logging ---------
def handle_feature_id_mismatch(rec_feature_id, true_feature_id, patient_id):
    if rec_feature_id != true_feature_id:
        if rec_feature_id == "manual_review":
            logger.warning(f"Manual review needed for patient {patient_id} (true={true_feature_id})")
        else:
            logger.error(f"Feature mismatch for patient {patient_id}: rec={rec_feature_id}, true={true_feature_id}")
