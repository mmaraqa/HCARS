"""
safe_copy.py

📌 Provides a secure and traceable method for copying DataFrames within clinical-grade pipelines.

Adheres to:
    ✅ ISO/IEC 25010 (Quality: Maintainability, Performance, Security)
    ✅ ISO/IEC 27001 (Data Integrity & Confidentiality)
    ✅ ISO 13485 (Regulatory-grade traceability for clinical systems)
    ✅ ISO/IEC 29119 (Testability, Logging, Auditing for software quality)

This module standardizes DataFrame copying to reduce risk in place mutations
and supports traceable, context-aware usage throughout preprocessing and modeling phases.

Author: Hypertension Recommender System
"""

import pandas as pd
from utils.logging_utils import setup_logger
from utils.column_audit import audit_columns
from context.fallback import FallbackRestorer
import uuid

# Initialize logger for safe copy operations
safe_copy_logger = setup_logger("safe_copy_logger", "logs/safe_copy.log")


def safe_copy(df: pd.DataFrame, context: str = "unspecified", log_id: str = None) -> pd.DataFrame:
    """
    Create a deep copy of a DataFrame with contextual logging for clinical traceability.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame to be copied.
    context : str, optional
        Descriptive label for where this copy is being made (e.g., 'pre-cleaning', 'post-imputation').
    log_id : str, optional
        Unique identifier for logging traceability.

    Returns
    -------
    pd.DataFrame
        A deep copy of the original DataFrame.

    Raises
    ------
    TypeError
        If the input is not a pandas DataFrame.

    Examples
    --------
    >>> new_df = safe_copy(df, context="post-feature-engineering")
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]

    # Duck-typing guard to avoid static "unreachable" warnings while still enforcing DataFrame-like input
    try:
        _ = df.columns  # type: ignore[attr-defined]
    except Exception as e:
        safe_copy_logger.error(f"[{log_id}] [Data Integrity] ❌ Attempted to copy a non-DataFrame-like object (missing 'columns') | Context: {context}")
        raise TypeError("Input to safe_copy must be a pandas DataFrame (has no 'columns' attribute).") from e

    copied_df = df.copy(deep=True)
    copied_df = FallbackRestorer.restore_derived_clinical_columns(copied_df)
    audit_columns(copied_df, stage=f"safe_copy::{context}", log_id=log_id)
    safe_copy_logger.debug(f"[{log_id}] ✅ Columns in safe copy ({context}): {copied_df.columns.tolist()}")
    safe_copy_logger.info(f"[{log_id}] [Leakage Protection] ✅ DataFrame safely copied | Context: {context} | Shape: {copied_df.shape}")
    return copied_df


# For imputation steps: copy without restoring clinical/contextual columns.
def safe_copy_for_imputation(df: pd.DataFrame, context: str = "imputation", log_id: str = None) -> pd.DataFrame:
    """
    Create a deep copy of a DataFrame for imputation steps only,
    without restoring any clinical/contextual columns.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame to be copied.
    context : str, optional
        Descriptive label for where this copy is being made.
    log_id : str, optional
        Unique identifier for logging traceability.

    Returns
    -------
    pd.DataFrame
        A deep copy of the original DataFrame.
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]

    # Duck-typing guard to avoid static "unreachable" warnings while still enforcing DataFrame-like input
    try:
        _ = df.columns  # type: ignore[attr-defined]
    except Exception as e:
        safe_copy_logger.error(f"[{log_id}] [Data Integrity] ❌ Attempted to copy a non-DataFrame-like object (missing 'columns') | Context: {context}")
        raise TypeError("Input to safe_copy_for_imputation must be a pandas DataFrame (has no 'columns' attribute).") from e

    copied_df = df.copy(deep=True)
    audit_columns(copied_df, stage=f"safe_copy_for_imputation::{context}", log_id=log_id)
    safe_copy_logger.debug(f"[{log_id}] ✅ [imputation] Columns in safe copy: {copied_df.columns.tolist()}")
    safe_copy_logger.info(f"[{log_id}] [Leakage Protection] ✅ DataFrame safely copied for imputation | Context: {context} | Shape: {copied_df.shape}")
    return copied_df


def safe_copy_for_preprocessing(df: pd.DataFrame, context: str = "preprocessing", log_id: str = None) -> pd.DataFrame:
    """
    Create a deep copy of a DataFrame for preprocessing steps only,
    without restoring any clinical/contextual columns (pure copy for preprocessing).

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame to be copied.
    context : str, optional
        Descriptive label for where this copy is being made.
    log_id : str, optional
        Unique identifier for logging traceability.

    Returns
    -------
    pd.DataFrame
        A deep copy of the original DataFrame.
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]

    # Duck-typing guard to avoid static "unreachable" warnings while still enforcing DataFrame-like input
    try:
        _ = df.columns  # type: ignore[attr-defined]
    except Exception as e:
        safe_copy_logger.error(f"[{log_id}] [Data Integrity] ❌ Attempted to copy a non-DataFrame-like object (missing 'columns') | Context: {context}")
        raise TypeError("Input to safe_copy_for_preprocessing must be a pandas DataFrame (has no 'columns' attribute).") from e

    copied_df = df.copy(deep=True)
    audit_columns(copied_df, stage=f"safe_copy_for_preprocessing::{context}", log_id=log_id)
    safe_copy_logger.debug(f"[{log_id}] ✅ [preprocessing] Columns in safe copy: {copied_df.columns.tolist()}")
    safe_copy_logger.info(f"[{log_id}] [Leakage Protection] ✅ DataFrame safely copied for preprocessing | Context: {context} | Shape: {copied_df.shape}")
    return copied_df


def backup_protected_columns(df, protected_cols, log_id: str = None):
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    df_copy = safe_copy(df, context="backup_protected_columns", log_id=log_id)
    audit_columns(df_copy, stage="backup_protected_columns::full_frame", log_id=log_id)

    # Determine which protected columns exist before slicing to prevent KeyError
    existing_cols = [col for col in protected_cols if col in df_copy.columns]
    missing = [col for col in protected_cols if col not in df_copy.columns]

    if missing:
        safe_copy_logger.warning(f"[{log_id}] ⚠️ Some protected columns are missing in backup: {missing}")

    # Audit only if some protected columns exist
    if existing_cols:
        audit_columns(df_copy[existing_cols], stage="backup_protected_columns::only_protected", log_id=log_id)
        backup = df_copy[existing_cols]
    else:
        # Return an empty DataFrame with the requested protected column names for interface stability
        backup = pd.DataFrame(columns=protected_cols)

    return backup
