import pandas as pd
import os
from utils.config_loader import load_global_config
from utils.validation import validate_loaded_dataset
from context.schema_validator import FeatureEngineeringValidator
from utils.logging_utils import setup_logger

pipeline_logger = setup_logger("pipeline_logger", "logs/pipeline.log")
data_quality_logger = setup_logger("data_quality_logger", "logs/data_quality.log")

pipeline_logger.info("📦 loader.py module loaded and ready for dataset operations.")

"""
loader.py
==========
This module handles robust and validated loading of clinical datasets used in:
"Hybrid Context-Aware Recommendation System for Hypertension Problem" (HCARS thesis).

It supports loading from structured configuration, with fault-tolerant diagnostics, and extensible design
for new data sources. This module ensures clean integration into the preprocessing and modeling pipelines
for hypertension, diabetes, and stroke risk modeling.
"""

config = load_global_config()
DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data'))

if not os.path.exists(DATA_DIR):
    raise FileNotFoundError(f"Data directory not found: {DATA_DIR}")

def resolve_dataset_path(filename: str) -> str:
    """
    Resolve the absolute path of the dataset file.

    Parameters:
        filename (str): The dataset filename or absolute path.

    Returns:
        str: The absolute path to the dataset file.

    Raises:
        FileNotFoundError: If the dataset file does not exist at the resolved path.
    """
    if os.path.isabs(filename):
        path = filename
    else:
        path = os.path.join(DATA_DIR, filename)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Dataset file not found: {path}")
    return path

def log_dataset_info(df: pd.DataFrame, filename: str, verbose: bool):
    """
    Log dataset shape and columns if verbose mode is enabled.

    Parameters:
        df (pd.DataFrame): The loaded dataset DataFrame.
        filename (str): The dataset filename.
        verbose (bool): Flag to enable detailed logging.
    """
    if verbose:
        pipeline_logger.info(f"[INFO] Loaded '{filename}' with shape {df.shape}")
        pipeline_logger.info(f"[INFO] Columns: {list(df.columns)}")


class DatasetLoader:
    def __init__(self, filename, verbose=False, log_id=None):
        """
        initialize DatasetLoader with filename and verbosity.

        Parameters:
            filename (str): The dataset filename or absolute path.
            verbose (bool): Whether to log detailed dataset info.
            log_id (str): Optional log identifier for traceability.
        """
        self.filename = filename
        self.verbose = verbose
        self.df = None
        self.load_dataset(log_id=log_id)

    def load_dataset(self, log_id=None):
        """
        Load the dataset with verbose diagnostics and error protection.

        Parameters:
            log_id (str): Optional log identifier for traceability.

        Raises:
            Exception: Propagates exceptions raised during loading or validation.
        """
        if log_id is None:
            import uuid
            log_id = uuid.uuid4().hex[:8]
        try:
            pipeline_logger.info(f"[{log_id}] 🔄 [LOADER] Starting to load dataset from: {self.filename}")
            path = resolve_dataset_path(self.filename)
            self.df = pd.read_csv(path)
            if self.df.empty:
                pipeline_logger.error(f"[{log_id}] ❌ [LOADER] Dataset '{self.filename}' is empty.")
                raise ValueError(f"Dataset '{self.filename}' is empty.")
            # [Leakage Protection] Ensure 'target' and 'age' are not missing
            critical_cols = ["target", "age"]
            for col in critical_cols:
                if col not in self.df.columns:
                    data_quality_logger.critical(f"[{log_id}] [Leakage Protection] Critical column missing: '{col}' in dataset '{self.filename}'")
                    raise ValueError(f"Missing critical column: '{col}' in dataset '{self.filename}'")
            pipeline_logger.info(f"[{log_id}] ✅ [LOADER] Loaded dataset from: {path}")

            from utils.config_loader import load_schema
            schema = load_schema("schemas/clean_hypertension_data.yaml")
            validate_loaded_dataset(self.df, schema, dataset_name="hypertension_data")

            log_dataset_info(self.df, self.filename, self.verbose)
            from context.router import engineer_features
            from utils.risk_score_transformer import RiskScoreTransformer

            # Apply feature engineering before consistency check
            self.df = engineer_features(
                df=self.df,
                disease="hypertension",
                risk_transformer=RiskScoreTransformer()
            )

            # Now validate required columns after transformation
            FeatureEngineeringValidator.check_column_consistency(self.df, stage=f"loaded_{self.filename}", expected=[])
            # Additional check: Ensure all expected context columns exist after feature engineering
            expected_context_cols = ["bp_category", "chol_category", "risk_level", "age_group"]
            for col in expected_context_cols:
                if col not in self.df.columns:
                    data_quality_logger.error(f"[{log_id}] [Context Validation] Missing context column '{col}' after feature engineering in dataset '{self.filename}'")
                    raise ValueError(f"Missing expected context column: '{col}'")
        except FileNotFoundError as fnf:
            pipeline_logger.error(f"[{log_id}] ❌ File not found during dataset load: {fnf}")
            raise
        except pd.errors.EmptyDataError as ede:
            pipeline_logger.error(f"[{log_id}] ❌ Pandas could not read any data from file: {ede}")
            raise
        except pd.errors.ParserError as pe:
            pipeline_logger.error(f"[{log_id}] ❌ Failed to parse dataset '{self.filename}': {pe}")
            raise
        except Exception as e:
            pipeline_logger.exception(f"[{log_id}] ❌ Unexpected error while loading dataset '{self.filename}': {e}")
            raise

    def get_data(self):
        """
        Retrieve the loaded dataset DataFrame.

        Returns:
            pd.DataFrame: The loaded dataset.
        """
        return self.df


def load_diabetes_data(verbose=False, log_id=None):
    """
    load the diabetes dataset as specified in the config.

    Parameters:
        verbose (bool): Whether to print dataset info.
        log_id (str): Optional log identifier for traceability.

    Returns:
        pd.DataFrame: Loaded diabetes dataset.
    """
    filename = config["data_paths"].get("diabetes", "diabetes_data.csv")
    loader = DatasetLoader(filename, verbose, log_id=log_id)
    return loader.get_data()

def load_hypertension_data(verbose=False, log_id=None):
    """
    load the hypertension dataset as specified in the config.

    Parameters:
        verbose (bool): Whether to print dataset info.
        log_id (str): Optional log identifier for traceability.

    Returns:
        pd.DataFrame: Loaded hypertension dataset.
    """
    filename = "hypertension_data.csv"
    loader = DatasetLoader(filename, verbose, log_id=log_id)
    return loader.get_data()

def load_stroke_data(verbose=False, log_id=None):
    """
    load the stroke dataset as specified in the config.

    Parameters:
        verbose (bool): Whether to print dataset info.
        log_id (str): Optional log identifier for traceability.

    Returns:
        pd.DataFrame: Loaded stroke dataset.
    """
    filename = config["data_paths"].get("stroke", "stroke_data.csv")
    loader = DatasetLoader(filename, verbose, log_id=log_id)
    return loader.get_data()

def load_all_datasets(verbose=False, log_id=None) -> dict[str, pd.DataFrame]:
    """
    load all datasets based on filenames specified in config.

    Parameters:
        verbose (bool): Whether to print dataset info.
        log_id (str): Optional log identifier for traceability.

    Returns:
        dict[str, pd.DataFrame]: Dictionary mapping dataset names to loaded DataFrames.
    """
    return {
        'diabetes': load_diabetes_data(verbose=verbose, log_id=log_id),
        'hypertension': load_hypertension_data(verbose=verbose, log_id=log_id),
        'stroke': load_stroke_data(verbose=verbose, log_id=log_id)
    }

def load_data(dataset_name: str, verbose: bool = False, log_id=None) -> pd.DataFrame:
    """
    Load a specific cleaned dataset by name.

    Parameters:
        dataset_name (str): one of 'hypertension', 'diabetes', 'stroke'
        verbose (bool): whether to print dataset info
        log_id (str): Optional log identifier for traceability.

    Returns:
        pd.DataFrame: loaded cleaned DataFrame

    Raises:
        ValueError: If dataset_name is not supported.
    """
    dataset_map = {
        'hypertension': lambda v, lid: DatasetLoader("hypertension_data.csv", v, log_id=lid).get_data(),
        'diabetes': load_diabetes_data,
        'stroke': load_stroke_data
    }

    if dataset_name not in dataset_map:
        pipeline_logger.error(f"[{log_id}] ❌ Unsupported dataset name requested: {dataset_name}")
        raise ValueError(f"Unsupported dataset name: {dataset_name}") from None

    # Pass log_id for all
    return dataset_map[dataset_name](verbose, lid=log_id)
