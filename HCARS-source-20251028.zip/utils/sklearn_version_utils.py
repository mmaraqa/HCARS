"""
sklearn_version_utils.py
=========================
أدوات متخصصة لضمان توافق إصدار scikit-learn مع أنظمة الذكاء الاصطناعي السريرية.
تتضمن التحقق من دعم الميزات الأساسية لتشفير السياق والتفسير السريري للنماذج.
"""
import sklearn
from packaging import version

def is_verbose_feature_names_out_supported(logger=None) -> bool:
    """
    Check if the current scikit-learn version supports the
    'verbose_feature_names_out' parameter in OneHotEncoder.

    Returns:
        bool: True if supported, False otherwise.
    """
    try:
        sklearn_version = version.parse(sklearn.__version__)
        if logger:
            logger.info(f"🩺 [Compatibility Check] 'verbose_feature_names_out' supported: {sklearn_version >= version.parse('1.2.0')}")
        return sklearn_version >= version.parse("1.2.0")
    except Exception as e:
        if logger:
            logger.error(f"❌ [SKLEARN VERSION CHECK] Failed to parse sklearn version: {e}")
        else:
            print(f"❌ [SKLEARN VERSION CHECK] فشل في تحليل إصدار scikit-learn: {e} - يرجى التأكد من توافق البيئة السريرية.")
        return False

def get_sklearn_version() -> str:
    """
    Get the current scikit-learn version.

    Returns:
        str: scikit-learn version.
    """
    return sklearn.__version__

def log_sklearn_version(logger):
    """
    Log the current scikit-learn version for transparency.

    Parameters:
        logger: Logger object to use.
    """
    # ✅ سجل الإصدار المستخدم لمطابقة بيئة التشغيل مع المتطلبات السريرية.
    message = f"ℹ️ [SKLEARN VERSION] scikit-learn version in use: {sklearn.__version__}"
    if logger:
        logger.info(message)
    else:
        raise ValueError("Logger must be provided to log sklearn version.")

def validate_sklearn_for_contextual_pipeline(logger=None):
    """
    Ensure that the current sklearn version supports all required features
    for context-aware encoding, especially for OneHotEncoder and pipeline stability.
    Raises warning or logs errors if compatibility issues are found.
    """
    try:
        current_version = version.parse(sklearn.__version__)
        if current_version < version.parse("1.2.0"):
            warning_msg = (
                f"⚠️ [SKLEARN CHECK] scikit-learn version {sklearn.__version__} "
                f"does not support 'verbose_feature_names_out'. This may impact context-aware encoders "
                f"used in clinical decision pipelines. Upgrade to >= 1.2.0 recommended."
            )
            if logger:
                logger.warning(warning_msg)
            else:
                print(f"⚠️ [تحذير بيئة سريرية] {warning_msg} يرجى تحديث المكتبة لضمان دقة التفسير والتوصيات.")
        else:
            ok_msg = f"✅ [SKLEARN CHECK] scikit-learn version {sklearn.__version__} is fully compatible."
            if logger:
                logger.info(ok_msg)
            else:
                print(f"ℹ️ [تأكيد بيئة سريرية] {ok_msg} البيئة مناسبة للتشغيل السريري.")
    except Exception as e:
        err_msg = f"❌ [SKLEARN VALIDATION ERROR] Failed to check sklearn compatibility: {e}"
        if logger:
            logger.error(err_msg)
        else:
            print(f"❌ [خطأ في التحقق السريري] {err_msg} يرجى مراجعة إعدادات البيئة.")
