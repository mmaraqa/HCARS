# utils/evaluation.py — core metrics + full/unique/LOCO evaluators (post‑export friendly)
from __future__ import annotations
from typing import Iterable, List, Tuple, Dict, Any, Optional, Set

import numpy as np
import pandas as pd

try:
    # For optional config-driven evaluation (post‑export), yaml is convenient but not mandatory.
    import yaml  # type: ignore
except ImportError:  # pragma: no cover
    yaml = None  # soft dependency; we won't raise unless user asks for config-based eval

from utils.constants import CONTEXT_COLUMNS  # fixed keys for LOCO grouping

# ---- Guards & constants ----
REQUIRED_COLS: Set[str] = {"patient_id", "feature_id", "true_response", "score_cbf"}


def _guard_eval_frame(df: pd.DataFrame) -> None:
    if not isinstance(df, pd.DataFrame):
        raise TypeError("evaluation expects a pandas DataFrame")
    missing = REQUIRED_COLS.difference(df.columns)
    if missing:
        raise ValueError(f"evaluation: missing required columns: {sorted(missing)}")


def _coerce_scores(df: pd.DataFrame, score_col: str = "score_cbf") -> pd.Series:
    s = pd.to_numeric(df[score_col], errors="coerce").astype(float)
    return s.clip(0.0, 1.0).fillna(0.0)

# ---- Strict evaluation preparation helper ----

def prepare_scores_for_eval(df: pd.DataFrame, score_col: str = "score_cbf") -> pd.DataFrame:
    """Strict sanitizer for evaluation frames.
    - Validates required columns (REQUIRED_COLS)
    - Coerces `score_col` to numeric, clips to [0,1], fills NaN with 0.0
    Returns a *copy* ready for ranking-based metrics.
    """
    _guard_eval_frame(df)
    out = df.copy()
    out[score_col] = _coerce_scores(out, score_col)
    return out


# ---- Core metrics (single-query) ----

def precision_at_k(y_true: Iterable, y_pred: Iterable, k: int = 5) -> float:
    y_true_set = set(y_true)
    k = max(1, int(k))
    topk = list(y_pred)[:k]
    return float(len(y_true_set.intersection(topk))) / float(k)


def recall_at_k(y_true: Iterable, y_pred: Iterable, k: int = 5) -> float:
    y_true_set = set(y_true)
    if len(y_true_set) == 0:
        return 0.0
    topk = list(y_pred)[: max(1, int(k))]
    return float(len(y_true_set.intersection(topk))) / float(len(y_true_set))


def average_precision_at_k(y_true: Iterable, y_scores: List[Tuple[object, float]], k: int = 5) -> float:
    y_true_set = set(y_true)
    if len(y_true_set) == 0:
        return 0.0
    hits, ap = 0, 0.0
    for i, (it, _) in enumerate(y_scores[: max(1, int(k))], start=1):
        if it in y_true_set:
            hits += 1
            ap += hits / i
    denom = min(int(k), len(y_true_set))
    return float(ap / max(1, denom))


def dcg_at_k(scores: Iterable[float], k: int = 5) -> float:
    arr = list(scores)[: max(1, int(k))]
    return float(sum(((2.0 ** s) - 1.0) / np.log2(i + 2.0) for i, s in enumerate(arr)))


def ndcg_at_k(y_true: Iterable, y_scores: List[Tuple[object, float]], k: int = 5) -> float:
    y_true_set = set(y_true)
    rel = [1.0 if it in y_true_set else 0.0 for it, _ in y_scores]
    dcg = dcg_at_k(rel, k)
    ideal = sorted(rel, reverse=True)
    idcg = dcg_at_k(ideal, k)
    return float(dcg / idcg) if idcg > 0 else 0.0


# ---- Helpers ----

def _rank_pairs(df: pd.DataFrame, score_col: str) -> List[Tuple[object, float]]:
    ranked = df.sort_values(score_col, ascending=False)
    return [(it, float(sc)) for it, sc in zip(ranked["feature_id"], ranked[score_col])]


def _per_patient_metrics(df: pd.DataFrame, k: int, score_col: str) -> Dict[str, float]:
    _guard_eval_frame(df)
    df = df.copy()
    df[score_col] = _coerce_scores(df, score_col)

    p_list: List[float] = []
    r_list: List[float] = []
    ap_list: List[float] = []
    ndcg_list: List[float] = []

    for pid, g in df.groupby("patient_id", sort=False):
        y_true = set(g.loc[g["true_response"] == 1, "feature_id"].astype(str))
        y_scores = _rank_pairs(g, score_col)
        y_pred = [it for it, _ in y_scores]
        p_list.append(precision_at_k(y_true, y_pred, k))
        r_list.append(recall_at_k(y_true, y_pred, k))
        ap_list.append(average_precision_at_k(y_true, y_scores, k))
        ndcg_list.append(ndcg_at_k(y_true, y_scores, k))

    def _avg(xs: List[float]) -> float:
        return float(np.mean(xs)) if len(xs) else 0.0

    return {
        "precision@k": _avg(p_list),
        "recall@k": _avg(r_list),
        "MAP@k": _avg(ap_list),
        "nDCG@k": _avg(ndcg_list),
        "queries": float(len(p_list)),
    }


# ---- Pre-filter ranking writer (per-patient/per-context) ----

def ranking_at_k(
    df_pre: pd.DataFrame,
    k: int = 5,
    score_col: str = "score_cbf",
    truth_col: str = "true_response",
    group_key: tuple | str = ("patient_id",),
    replicate_per_row: bool = False,
):
    """
    Iterate a pre-filter frame and yield (kind, payload):
      - ("loco", DataFrame) with one row per group_key containing@K metrics
      - ("rows", DataFrame) per-group rows with replicated metrics (optional)
    df_pre must contain `score_col` and `truth_col`.
    """
    if isinstance(group_key, str):
        group_key = (group_key,)

    def _py_scalar(x):
        # Convert NumPy scalar to plain Python scalar; leave tuples/others unchanged
        if isinstance(x, np.generic):  # covers NumPy scalar types (e.g., np.int64, np.float64)
            return x.item()
        return x

    rows: list[dict] = []
    for g_vals, gdf in df_pre.groupby(list(group_key), dropna=False):
        gdf = gdf.copy()
        gdf[score_col] = pd.to_numeric(gdf[score_col], errors="coerce").fillna(0.0)
        gdf[truth_col] = pd.to_numeric(gdf[truth_col], errors="coerce").fillna(0).astype(int)

        n_candidates = int(len(gdf))
        n_pos = int(gdf[truth_col].sum())
        gdf = gdf.sort_values(score_col, ascending=False)

        # Build ranked lists for metric helpers
        y_true = set(gdf.loc[gdf[truth_col] == 1, "feature_id"].astype(str))
        y_scores = [(it, float(sc)) for it, sc in zip(gdf["feature_id"], gdf[score_col])]
        y_pred = [it for it, _ in y_scores]

        prec = precision_at_k(y_true, y_pred, k)
        rec  = recall_at_k(y_true, y_pred, k)
        mapk = average_precision_at_k(y_true, y_scores, k)
        ndcg = ndcg_at_k(y_true, y_scores, k)

        rec_row: Dict[str, Any] = {
            "k": int(k),
            "n_candidates": n_candidates,
            "n_positives": n_pos,
            f"precision@{k}": float(prec),
            f"recall@{k}": float(rec),
            f"map@{k}": float(mapk),
            f"ndcg@{k}": float(ndcg),
        }
        if isinstance(g_vals, tuple):
            for i, c in enumerate(group_key):
                rec_row[str(c)] = _py_scalar(g_vals[i])
        else:
            rec_row[str(group_key[0])] = _py_scalar(g_vals)
        rows.append(rec_row)

        if replicate_per_row:
            met = {
                f"precision@{k}": float(prec),
                f"recall@{k}": float(rec),
                f"map@{k}": float(mapk),
                f"ndcg@{k}": float(ndcg),
            }
            gdf_rows = gdf.assign(**met)
            gdf_rows["_replicate_key"] = "|".join(map(str, [rec_row.get(c, "") for c in group_key]))
            yield "rows", gdf_rows

    loco_df = pd.DataFrame(rows)
    yield "loco", loco_df


def summarize_loco(loco_df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate LOCO per-patient rows into a small summary frame."""
    if loco_df is None or loco_df.empty:
        return pd.DataFrame([{"n_patients": 0}])
    # Detect the first matching @K suffix from columns, default to 5
    k = 5
    for col in loco_df.columns:
        if col.startswith("precision@"):
            try:
                k = int(col.split("@", 1)[1])
                break
            except (ValueError, TypeError, AttributeError, IndexError):
                pass
    out = {
        "n_patients": int(len(loco_df)),
        f"precision@{k}_mean": float(loco_df[f"precision@{k}"].mean()),
        f"recall@{k}_mean":   float(loco_df[f"recall@{k}"].mean()),
        f"map@{k}_mean":      float(loco_df[f"map@{k}"].mean()),
        f"ndcg@{k}_mean":     float(loco_df[f"ndcg@{k}"].mean()),
        f"precision@{k}_median": float(loco_df[f"precision@{k}"].median()),
        f"recall@{k}_median":   float(loco_df[f"recall@{k}"].median()),
        f"map@{k}_median":      float(loco_df[f"map@{k}"].median()),
        f"ndcg@{k}_median":     float(loco_df[f"ndcg@{k}"].median()),
    }
    return pd.DataFrame([out])


# ---- Public evaluators ----

def evaluate_cbf_full(df: pd.DataFrame, k: int = 5, score_col: str = "score_cbf") -> Dict[str, float]:
    """Evaluate on the full recommendations frame as-is (duplicates allowed)."""
    return _per_patient_metrics(df, k, score_col)


def _dedupe_per_patient(df: pd.DataFrame, score_col: str) -> pd.DataFrame:
    # Keep the highest score per (patient_id, feature_id)
    tmp = df.copy()
    tmp[score_col] = _coerce_scores(tmp, score_col)
    tmp = tmp.sort_values(["patient_id", "feature_id", score_col], ascending=[True, True, False])
    return tmp.drop_duplicates(subset=["patient_id", "feature_id"], keep="first")


def evaluate_cbf_unique(df: pd.DataFrame, k: int = 5, score_col: str = "score_cbf") -> Dict[str, float]:
    """Evaluate after removing duplicate (patient, feature_id) rows, keeping top-scored."""
    deduped = _dedupe_per_patient(df, score_col)
    return _per_patient_metrics(deduped, k, score_col)


def evaluate_cbf_loco(
    df: pd.DataFrame,
    k: int = 5,
    score_col: str = "score_cbf",
    context_cols: Optional[List[str]] = None,
) -> pd.DataFrame:
    """LOCO over context keys (no retraining here, ranking-only breakdown).
    Returns a DataFrame with metrics per held-out context key and a final averaged row.
    """
    _guard_eval_frame(df)
    df = df.copy()
    df[score_col] = _coerce_scores(df, score_col)

    ctx_cols = list(context_cols or CONTEXT_COLUMNS)
    for c in ctx_cols:
        if c not in df.columns:
            raise KeyError(f"LOCO requires context column '{c}' in the evaluation frame")

    # Build context key
    key = df[ctx_cols].astype(str).agg("|".join, axis=1)
    df = df.assign(__ctx_key__=key)

    rows = []
    for ctx_key, g in df.groupby("__ctx_key__", sort=False):
        # Evaluate on this subset (as a held-out context segment)
        metrics = _per_patient_metrics(g, k, score_col)
        metrics.update({"context_key": ctx_key})
        rows.append(metrics)

    out = pd.DataFrame(rows)
    if out.empty:
        return out

    avg_row = {
        "context_key": "__LOCO_MEAN__",
        "precision@k": float(out["precision@k"].mean()),
        "recall@k": float(out["recall@k"].mean()),
        "MAP@k": float(out["MAP@k"].mean()),
        "nDCG@k": float(out["nDCG@k"].mean()),
        "queries": float(out["queries"].sum()),
    }
    return pd.concat([out, pd.DataFrame([avg_row])], ignore_index=True)


# ---- Post‑export evaluation helpers ----

def _load_config(path: str) -> Dict[str, Any]:
    if yaml is None:
        raise ImportError("PyYAML is required to load config files for post‑export evaluation")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def evaluate_after_export(
    *,
    config_path: Optional[str] = None,
    csv_path: Optional[str] = None,
    k: int = 5,
    score_col: str = "score_cbf",
    run_loco: bool = True,
    save_summary_paths: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """Evaluate **after** the pipeline has written CSVs to disk, so notebook metrics
    match the artifacts under outputs/.
    - If `csv_path` is given, we evaluate that file directly.
    - Else, if `config_path` is provided (YAML), we load the path
      `hybrid_paths.cbf_recommendations_eval` if present, otherwise `hybrid_paths.cbf_recommendations`.
    Optionally saves summaries to the given paths.
    Returns a dict with keys: full, unique, (optional) loco.
    """
    if csv_path is None:
        if not config_path:
            raise ValueError("evaluate_after_export: provide either csv_path or config_path")
        cfg = _load_config(config_path)
        hp = ((cfg.get("hybrid_paths") or {}) if isinstance(cfg, dict) else {})
        csv_path = hp.get("cbf_recommendations_eval") or hp.get("cbf_recommendations")
        if not csv_path:
            raise KeyError("evaluate_after_export: could not find CBF CSV path in config.hybrid_paths")

        # pick k from config if available
        try:
            k = int(((cfg.get("evaluation") or {}).get("k_at", k)))
        except (TypeError, ValueError, AttributeError, KeyError):
            pass
        try:
            score_col = str(((cfg.get("evaluation") or {}).get("score_col", score_col)))
        except (TypeError, ValueError, AttributeError, KeyError):
            pass

    # Load CSV written by the pipeline
    df = pd.read_csv(csv_path)
    _guard_eval_frame(df)

    # Full & Unique
    full = evaluate_cbf_full(df, k=k, score_col=score_col)
    unique = evaluate_cbf_unique(df, k=k, score_col=score_col)

    results: Dict[str, Any] = {"full": full, "unique": unique}

    # LOCO (ranking-only segmentation by context key)
    if run_loco:
        try:
            loco_df = evaluate_cbf_loco(df, k=k, score_col=score_col)
            results["loco"] = loco_df
        except (KeyError, ValueError) as ex:
            # context columns missing — skip LOCO gracefully
            results["loco_error"] = str(ex)

    # Optional saving of summaries
    if save_summary_paths:
        try:
            if "full" in save_summary_paths:
                pd.DataFrame([full]).to_csv(save_summary_paths["full"], index=False)
            if "unique" in save_summary_paths:
                pd.DataFrame([unique]).to_csv(save_summary_paths["unique"], index=False)
            if run_loco and "loco" in results and "loco" in save_summary_paths:
                assert isinstance(results["loco"], pd.DataFrame)
                results["loco"].to_csv(save_summary_paths["loco"], index=False)
        except (OSError, ValueError, KeyError, AssertionError) as ex:
            # do not raise; the caller can log this if needed
            results["save_warning"] = f"failed to save summaries: {ex}"

    return results


__all__ = [
    "REQUIRED_COLS",
    "_guard_eval_frame",
    "precision_at_k",
    "recall_at_k",
    "average_precision_at_k",
    "dcg_at_k",
    "ndcg_at_k",
    "prepare_scores_for_eval",
    "evaluate_cbf_full",
    "evaluate_cbf_unique",
    "evaluate_cbf_loco",
    "evaluate_after_export",
    "ranking_at_k",
    "summarize_loco",
]
