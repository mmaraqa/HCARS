"""
log_diagnostics.py

This utility scans all log files in the configured logs/ directory,
counts warnings and errors per log, and writes a structured diagnostic summary.
It is designed to support maintainability, reliability, and quality assurance
within the hypertension recommender system under ISO/IEC 25010 standards.

Usage:
    python -m utils.log_diagnostics

Output:
    - reports/log_summary.txt: summary of warnings and errors
    - console output indicating execution status

Compliance:
    - Logging Verification: ISO/IEC 27001 (Security Logging)
    - Code Quality Traceability: ISO/IEC 25010 (Maintainability, Reliability)
"""

import os
import glob
from datetime import datetime
from utils.config_loader import load_global_config
config = load_global_config()

LOG_DIR = "logs"
REPORT_DIR = "reports"
SUMMARY_FILE = os.path.join(REPORT_DIR, "log_summary.txt")
CATEGORY_FILTER = None  # Set to "validation", "pipeline", etc. to filter output

CATEGORIES = {
    "validation": ["Validation", "schema", "columns"],
    "pipeline": ["Pipeline", "run_pipeline", "execution"],
    "shap": ["SHAP", "explainability", "shap_values"],
    "encoding": ["encoding", "encode", "transformer"],
    "cf": ["collaborative", "cf_pipeline", "user-similarity"],
    "cbf": ["cbf_pipeline", "content-based", "cosine"],
    "hybrid": ["hybrid_pipeline", "hybrid"],
}

def analyze_log(file_path):
    errors = 0
    warnings = 0
    recent_lines = []
    category_counts = {cat: 0 for cat in CATEGORIES}
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line_lower = line.lower()
            if "ERROR" in line:
                errors += 1
                recent_lines.append(line.strip())
            elif "WARNING" in line:
                warnings += 1
                recent_lines.append(line.strip())
            for cat, keywords in CATEGORIES.items():
                if any(keyword.lower() in line_lower for keyword in keywords):
                    category_counts[cat] += 1
    return errors, warnings, recent_lines[-5:], category_counts  # Last 5 important lines

def summarize_logs():
    if not os.path.exists(LOG_DIR):
        print(f"❌ Log directory '{LOG_DIR}' not found.")
        return

    if not os.path.exists(REPORT_DIR):
        os.makedirs(REPORT_DIR)

    file_reports = []
    for log_file in glob.glob(os.path.join(LOG_DIR, "*.log")):
        if not os.path.exists(log_file):
            continue
        print(f"\n🔎 Inspecting {log_file}")
        with open(log_file, "r", encoding="utf-8") as f:
            content = f.read()
            for ctx in ["bp_category", "chol_category", "risk_level", "age_group"]:
                if ctx in content:
                    print(f"   ✅ Found context column: {ctx}")
                else:
                    print(f"   ❌ Missing context column: {ctx}")
        errors, warnings, samples, category_counts = analyze_log(log_file)
        if isinstance(CATEGORY_FILTER, str) and category_counts.get(CATEGORY_FILTER, 0) == 0:
            continue  # Skip if filter is active and category not present
        file_reports.append({
            "file": os.path.basename(log_file),
            "errors": errors,
            "warnings": warnings,
            "samples": samples,
            "category_counts": category_counts
        })
    file_reports.sort(key=lambda x: (x["errors"] + x["warnings"]), reverse=True)

    summary = []
    total_errors = total_warnings = 0
    category_totals = {cat: 0 for cat in CATEGORIES}
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    summary.append(f"📅 Log Summary Generated: {timestamp}\n")

    for report in file_reports:
        total_errors += report["errors"]
        total_warnings += report["warnings"]
        for cat, count in report["category_counts"].items():
            category_totals[cat] += count
        summary.append(f"{report['file']} — ⚠️ {report['warnings']} warnings, ❌ {report['errors']} errors")
        if report["samples"]:
            summary.append("    Recent Issues:")
            summary.extend([f"    • {line}" for line in report["samples"]])

    summary.append("\n📊 Category Breakdown:")
    for cat, count in category_totals.items():
        summary.append(f"    • {cat}: {count} mentions")

    with open(SUMMARY_FILE, "w", encoding="utf-8") as summary_file:
        summary_file.write("\n".join(summary))
        summary_file.write(f"\n\n🟢 Total Warnings: {total_warnings}, Errors: {total_errors}\n")
        summary_file.write("📊 Category Breakdown:\n")
        for cat, count in category_totals.items():
            summary_file.write(f"    • {cat}: {count} mentions\n")

    write_markdown_summary(summary, total_warnings, total_errors, category_totals)
    write_html_summary(summary, total_warnings, total_errors, category_totals)

    print("\n📋 Summary of context columns across all logs:")
    context_features = config.get("context_features", ["bp_category", "chol_category", "risk_level", "age_group"])
    context_presence = {ctx: 0 for ctx in context_features}
    for report in file_reports:
        for ctx in context_presence:
            if ctx in str(report):
                context_presence[ctx] += 1
    for ctx, count in context_presence.items():
        if count == 0:
            print(f"   ❌ Context feature '{ctx}' not detected in any logs.")
        else:
            print(f"   ✅ Context feature '{ctx}' found in {count} log(s).")

    print(f"✅ Log summary written to: {SUMMARY_FILE}")

def write_markdown_summary(summary_lines, total_warnings, total_errors, category_totals):
    md_file = os.path.join(REPORT_DIR, "log_summary.md")
    with open(md_file, "w", encoding="utf-8") as md:
        md.write("# Log Summary\n\n")
        for line in summary_lines:
            if line.startswith("📅"):
                md.write(f"**{line}**\n\n")
            elif "—" in line and ("warnings" in line and "errors" in line):
                md.write(f"## {line}\n\n")
            elif line.strip().startswith("Recent Issues:"):
                md.write(f"### Recent Issues:\n")
            elif line.strip().startswith("•"):
                md.write(f"- {line.strip()[2:]}\n")
            elif line.strip().startswith("Category Breakdown:") or line.strip().startswith("📊"):
                md.write(f"## Category Breakdown\n\n")
            else:
                md.write(f"{line}\n")
        md.write(f"\n**Total Warnings:** {total_warnings}  \n")
        md.write(f"**Total Errors:** {total_errors}\n\n")
        md.write("### Category Mentions:\n")
        for cat, count in category_totals.items():
            md.write(f"- **{cat}**: {count} mentions\n")

def write_html_summary(summary_lines, total_warnings, total_errors, category_totals):
    html_file = os.path.join(REPORT_DIR, "log_summary.html")
    with open(html_file, "w", encoding="utf-8") as html:
        html.write("<html><head><title>Log Summary</title></head><body>\n")
        html.write("<h1>Log Summary</h1>\n")
        for line in summary_lines:
            if line.startswith("📅"):
                html.write(f"<h2>{line}</h2>\n")
            elif "—" in line and ("warnings" in line and "errors" in line):
                html.write(f"<h3>{line}</h3>\n")
            elif line.strip().startswith("Recent Issues:"):
                html.write("<h4>Recent Issues:</h4>\n<ul>\n")
            elif line.strip().startswith("•"):
                html.write(f"<li>{line.strip()[2:]}</li>\n")
            elif line.strip().startswith("Category Breakdown:") or line.strip().startswith("📊"):
                if html.tell() > 0 and summary_lines[summary_lines.index(line)-1].strip().startswith("•"):
                    html.write("</ul>\n")
                html.write("<h3>Category Breakdown</h3>\n<ul>\n")
            else:
                html.write(f"<p>{line}</p>\n")
        if summary_lines and summary_lines[-1].strip().startswith("•"):
            html.write("</ul>\n")
        html.write(f"<p><strong>Total Warnings:</strong> {total_warnings}</p>\n")
        html.write(f"<p><strong>Total Errors:</strong> {total_errors}</p>\n")
        html.write("<h4>Category Mentions:</h4>\n<ul>\n")
        for cat, count in category_totals.items():
            html.write(f"<li><strong>{cat}</strong>: {count} mentions</li>\n")
        html.write("</ul>\n")
        html.write("</body></html>\n")

if __name__ == "__main__":
    summarize_logs()