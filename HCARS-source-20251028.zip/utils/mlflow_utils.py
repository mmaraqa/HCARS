

import mlflow

def log_experiment(config, metrics, artifacts=None, run_name="Experiment", tags=None):
    """
    Log parameters, metrics, and output artifacts for a single experiment run in MLflow.

    Args:
        config (dict): Dictionary of configuration parameters (hyperparameters, settings).
        metrics (dict): Dictionary of evaluation metrics (e.g. precision, recall).
        artifacts (list, optional): List of file paths (CSV, reports, SHAP, etc.) to log as artifacts.
        run_name (str, optional): Custom name for the experiment run (e.g. log_id or pipeline name).
        tags (dict, optional): Extra tags for run metadata (e.g. {"stage": "CF", "author": "Mohammed"}).

    Returns:
        str: MLflow run_id for tracking or querying later.

    Example:
        log_experiment(
            config={"top_k": 10, "model": "CF"},
            metrics={"precision@10": 0.82, "recall@10": 0.65},
            artifacts=["outputs/final/df_cf_recommendations.csv"],
            run_name="CF_Recommendation_Run_20240622",
            tags={"stage": "cf_pipeline"}
        )
    """
    with mlflow.start_run(run_name=run_name):
        # سجل كل الإعدادات كمفاتيح
        if config:
            mlflow.log_params(config)
        # سجل كل مقاييس التقييم
        if metrics:
            mlflow.log_metrics(metrics)
        # أضف العلامات الوصفية إذا توفرت
        if tags:
            mlflow.set_tags(tags)
        # سجل جميع الملفات الهامة (CSV, SHAP, تقارير ...)
        if artifacts:
            for artifact_path in artifacts:
                mlflow.log_artifact(artifact_path)
        run_id = mlflow.active_run().info.run_id
    return run_id