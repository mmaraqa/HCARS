# If this module is imported elsewhere and cleanup_orphaned_backups is needed, ensure import is present:
# from .restoration import cleanup_orphaned_backups  # Only if this module is imported elsewhere causing confusion

from utils.logging_utils import setup_logger
import uuid
from utils.config_loader import load_global_config
GLOBAL_CONFIG = load_global_config()
logger = setup_logger("restoration_logger", "logs/restoration.log")

# Patch: Import FallbackRestorer for contextual columns fallback logic
from context.fallback import FallbackRestorer


def encode_categoricals(df, categorical_cols, log_id=None):
    """
    encode categorical columns in the DataFrame, managing backup copies appropriately.

    Args:
        df (pd.DataFrame): The input DataFrame to encode.
        categorical_cols (list): List of column names to be encoded.
        log_id (str, optional): Unique identifier for logging. auto-generated if not provided.

    Returns:
        pd.DataFrame: The DataFrame with encoded categorical columns and cleaned backup copies.
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    assert isinstance(categorical_cols, list), "[Encoding Error] categorical_cols must be a list"
    logger.debug(f"[{log_id}] [Encoding Debug] DataFrame columns before encoding: {df.columns.tolist()}")
    used_backup_cols = set()
    for col in categorical_cols:
        backup_col = f"{col}_copy"
        backup_candidates = [c for c in df.columns if c.endswith(f"__{backup_col}")]
        if backup_col in df.columns:
            # Use backup_col for encoding if needed
            used_backup_cols.add(backup_col)
        elif backup_candidates:
            selected_backup = sorted(backup_candidates, key=lambda x: len(x.split("__")[0]))[0]
            # Use selected_backup for encoding if needed
            used_backup_cols.add(selected_backup)
        # Encoding logic here (omitted for brevity)
    # Collect all *_copy columns and their prefixed variants
    all_backup_cols = [col for col in df.columns if col.endswith('_copy')]
    # Determine which backup columns were not used and can be removed
    removable_backups = [
        col for col in all_backup_cols
        if col not in used_backup_cols and not col.endswith('target_copy')
    ]
    df.drop(columns=removable_backups, inplace=True)
    logger.info(f"[{log_id}] [Encoding Cleanup] Removed backup-prefixed columns: {removable_backups}")
    logger.debug(f"[{log_id}] [Encoding Debug] DataFrame columns after encoding: {df.columns.tolist()}")
    # Cleanup orphaned *_copy or derived backup columns after encoding
    df_encoded = cleanup_orphaned_backups(df)

    # Drop columns with _copy_copy or _preserved patterns
    df_encoded = df_encoded.loc[:, ~df_encoded.columns.str.contains(r'_copy_copy|_preserved')]
    logger.info(f"[{log_id}] [Encoding] Dropped columns matching *_copy_copy or *_preserved patterns.")

    # Apply filtering based on config
    expected_final_columns = GLOBAL_CONFIG.get("final_columns_after_encoding", [])
    # Ensure contextual columns are preserved during final filtering
    contextual_cols = ["bp_category", "chol_category", "risk_level", "age_group"]
    for col in contextual_cols:
        if col not in expected_final_columns:
            expected_final_columns.append(col)
            logger.warning(f"[{log_id}] [Encoding Patch] Contextual column '{col}' was missing in config 'final_columns_after_encoding' and has been added.")
    df_encoded = df_encoded[[col for col in expected_final_columns if col in df_encoded.columns]]
    print("✅ [ENCODING] Final encoded columns:", df_encoded.columns.tolist())
    logger.info(f"[{log_id}] [Encoding] Columns retained after filtering with final_columns_after_encoding: {df_encoded.columns.tolist()}")
    logger.info(f"[{log_id}] [Encoding] Final filtered columns retained: {df_encoded.columns.tolist()}")

    return df_encoded


# Restore protected columns from their backup copies (with or without prefix support)
def restore_protected_columns(df, protected_cols, fallback_data=None, log_id=None):
    """
    restore protected columns in the DataFrame from their backup copies.

    note:
        ➤ This function should only be called after encoding and after merging protected columns.
        ➤ Ensures recovery of critical clinical features such as risk_level, risk_score, etc.

    Args:
        df (pd.DataFrame): The DataFrame to restore columns in.
        protected_cols (list): List of column names to restore.
        fallback_data (pd.DataFrame, optional): Optional DataFrame to use as fallback source for restoration.
        log_id (str, optional): Unique identifier for logging. auto-generated if not provided.

    Returns:
        pd.DataFrame: The DataFrame with restored protected columns.
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    logger.info(f"[{log_id}] [Restore] Executing after encoding and protected column merge.")
    # Ensure contextual clinical columns are always available
    df = FallbackRestorer.restore_derived_clinical_columns(df)
    df_before_restore = df.copy()
    final_cols = GLOBAL_CONFIG.get("final_columns_after_encoding", [])
    # Only support hypertension-related derived columns plus new clinical categories
    backup_mapping = {
        "target": ["target_train_copy", "target_test_copy", "target_copy"],
        "risk_level": ["risk_level_copy", "remainder__risk_level"],
        "risk_score": ["risk_score_copy"],
        "chol_flag": ["chol_flag_copy"],
        "multi__risk_level_high": ["multi__risk_level_high"],
        "multi__risk_level_low": ["multi__risk_level_low"],
        "multi__risk_level_medium": ["multi__risk_level_medium"],
        "bp_category": ["bp_category_copy"],
        "chol_category": ["chol_category_copy"],
        "age_group": ["age_group_copy"]
    }
    logger.info(f"[{log_id}] [Restore] Checking restoration for columns: {protected_cols}. Valid backups: {backup_mapping}.")
    assert isinstance(protected_cols, list), "[Restoration Error] protected_cols must be a list"
    restored = []
    missing = []

    already_present = [col for col in protected_cols if col in df.columns and df[col].notnull().all()]
    logger.info(f"[{log_id}] [Restore] Checking if all protected columns are present before restoration.")
    if len(already_present) == len(protected_cols):
        logger.info(f"[{log_id}] [Restore] All protected columns are already present. Skipping restore.")
        return df

    for col in protected_cols:
        if final_cols and col not in final_cols:
            logger.info(f"[{log_id}] [Restore-Skip] Column '{col}' not in final_columns_after_encoding. Skipping.")
            continue
        if col not in df.columns or df[col].isnull().all():
            fallback_col = next((c for c in backup_mapping.get(col, [f"{col}_copy"]) if c in df.columns), None)
            if fallback_col:
                logger.info(f"[{log_id}] [Restore] Restoring '{col}' from backup column '{fallback_col}'")
                df = df.copy()
                df[col] = df[fallback_col]
                if df[col].dtype == 'object' or (len(df[col]) > 0 and isinstance(df[col].iloc[0], str)):
                    df[col] = df[col].astype(str)
                    logger.info(f"[{log_id}] [Restore-Cast] Column '{col}' casted to string after restoration.")
                restored.append(col)
                logger.info(f"[{log_id}] [Restore] Restored '{col}' from backup column '{fallback_col}'")
                assert col in df.columns and df[col].notnull().sum() > 0, f"[Restore-Failure] Column '{col}' restoration produced empty result"
            else:
                logger.warning(f"[{log_id}] [Restore] No backup found for '{col}'. Skipping.")
                missing.append(col)
        else:
            logger.info(f"[{log_id}] [Restore-Skip] Column '{col}' already exists with non-null values. Skipping restore.")
            restored.append(col)

    # Only check for unused derived backups for hypertension-related columns
    cleanup_candidates = [
        col for col in df.columns
        if col.endswith('_copy') and not any(col in backup_mapping.get(r, []) for r in restored)
    ]
    if cleanup_candidates:
        logger.warning(f"[{log_id}] [Restore-Cleanup] Unused backup columns detected: {cleanup_candidates}")

    if not restored:
        logger.warning(f"[{log_id}] [Restoration] No hypertension-derived columns were restored — all backups are missing!")

    logger.info(f"[{log_id}] [Restoration Summary] ✅ Restored columns: {restored} | ❌ Missing backups for: {missing}")
    logger.info(f"[{log_id}] [Restoration Final] Total Restored Columns: {len(restored)} | Missing Columns: {len(missing)}")
    if restored:
        logger.debug(f"[{log_id}] [Restoration Final] Successfully restored columns: {restored}")
    if missing:
        logger.warning(f"[{log_id}] [Restoration Final] Columns failed to restore: {missing}")

    for col in restored:
        if df[col].isnull().all():
            logger.warning(f"[{log_id}] [Restoration Warning] Restored column '{col}' contains only NaN values.")

    logger.info(f"[{log_id}] 🏁 Hypertension restoration operations completed successfully.")

    orphaned_backups = [
        col for col in df.columns
        if col.endswith("_copy") and not any(col.endswith(f"{r}_copy") for r in restored) and (not final_cols or col not in final_cols)
    ]
    if orphaned_backups:
        logger.warning(f"[{log_id}] [Restoration] Orphaned hypertension backup columns exist without being restored: {orphaned_backups}")

    from utils.validation import FeatureEngineeringValidator
    FeatureEngineeringValidator.check_column_consistency(
        before_df=df_before_restore,
        after_df=df,
        stage="Post-Restoration"
    )

    df = cleanup_orphaned_backups(df, log_id=log_id)
    logger.info(f"[{log_id}] [Restore] Cleaned orphaned backup columns.")

    # Remove any remaining risk_level backup columns (orphans) only if not in final_cols
    # (Removed per instruction: do not drop unless in final_columns_after_encoding)
    # df.drop(
    #     columns=[col for col in df.columns if 'risk_level_copy' in col or col.startswith('remainder__risk_level')],
    #     errors='ignore',
    #     inplace=True
    # )
    # logger.info("[Cleanup] Removed residual risk_level backup columns.")

    if final_cols:
        # ضمان وجود الأعمدة السياقية في الأعمدة النهائية
        contextual_cols = ["bp_category", "chol_category", "risk_level", "risk_score", "age_group"]
        for col in contextual_cols:
            if col not in final_cols:
                final_cols.append(col)
                logger.warning(f"[{log_id}] [Restore-Patch] Contextual column '{col}' was missing in final_columns_after_encoding and has been added.")
        df = df[[col for col in final_cols if col in df.columns]]
        logger.info(f"[{log_id}] [Restore] Final DataFrame columns after filtering with final_columns_after_encoding: {df.columns.tolist()}")
    logger.info(f"[{log_id}] [Restore] Final DataFrame columns after restoration: {df.columns.tolist()}")
    print("✅ [RESTORATION] Final columns after restoration:", df.columns.tolist())

    # Final consistency check
    if fallback_data is not None and len(df) != len(fallback_data):
        logger.warning(f"[{log_id}] [Restore-Final] Row count mismatch after restoration: df={len(df)} vs fallback={len(fallback_data)}")

    logger.debug(f"[{log_id}] [Restore-Final] DataFrame shape after restoration: {df.shape}")

    # Log value counts for specified clinical categories if present
    clinical_categories = ['bp_category', 'chol_category', 'risk_level', 'chol_flag']
    for cat_col in clinical_categories:
        if cat_col in df.columns:
            counts = df[cat_col].value_counts(dropna=False).to_dict()
            logger.info(f"[{log_id}] [Restore Stats] Distribution of '{cat_col}': {counts}")
    # Print distributions to terminal as well
    for cat_col in clinical_categories:
        if cat_col in df.columns:
            print(f"📊 Distribution of '{cat_col}':", df[cat_col].value_counts(dropna=False).to_dict())

    # Final assertion to ensure consistency with expected context features
    expected_context_features = ["risk_level", "age_group", "bp_category", "chol_category"]
    for feature in expected_context_features:
        if feature not in df.columns:
            logger.warning(f"[{log_id}] [Context Check] Missing context feature: {feature}")
        else:
            logger.debug(f"[{log_id}] [Context Check] Verified context feature: {feature} with {df[feature].nunique()} unique values.")

    print("✅ [RESTORATION] Final shape:", df.shape)

    # ✅ Re-confirm context columns restoration
    expected_contextual = ["bp_category", "chol_category", "risk_level", "age_group"]
    restored_contextual = [col for col in expected_contextual if col in df.columns]
    print("🛠️ Contextual columns confirmed after restoration:", restored_contextual)
    logger.info(f"[{log_id}] [Restore-Final] Confirmed contextual columns after restoration: {restored_contextual}")

    logger.warning(f"[{log_id}] [Columns Trace] Columns at this stage: {df.columns.tolist()}")
    print("✅ [RESTORATION] Final columns before return:", df.columns.tolist())

    # (Fallback context reinsertion logic removed; now handled by FallbackRestorer)

    return df


def cleanup_orphaned_backups(df, log_id=None):
    """
    Remove orphaned *_copy or derived backup columns not part of active DataFrame logic.
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    orphaned_cols = [col for col in df.columns if (
        col.endswith("_copy") or
        "__" in col and col.endswith("_copy")
    ) and not any(x in col for x in ['target_copy', 'target_train_copy', 'target_test_copy'])]
    if orphaned_cols:
        df.drop(columns=orphaned_cols, inplace=True)
        logger.info(f"[{log_id}] [Cleanup] Removed orphaned backup columns: {orphaned_cols}")
    return df


# Ensure the 'target' column exists and is valid, restoring from backup if necessary
def ensure_target_integrity(df, backup_df=None, log_id=None):
    """
    ensure the 'target' column exists and is valid in the DataFrame, restoring from backup if necessary.

    Args:
        df (pd.DataFrame): The DataFrame to check and restore 'target' column.
        backup_df (pd.DataFrame, optional): Backup DataFrame to restore from if needed.
        log_id (str, optional): Unique identifier for logging. auto-generated if not provided.

    Returns:
        pd.DataFrame: The DataFrame with ensured 'target' column integrity.
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    # Save a copy of df before any restoration for consistency checking
    df_before_restore = df.copy()
    if "target" not in df.columns or df["target"].isnull().all():
        if "target" not in df.columns:
            if backup_df is not None and "target_copy" in backup_df.columns:
                df = df.copy()
                df["target"] = backup_df["target_copy"]
                logger.info(f"[{log_id}] 'target' column restored from 'target_copy'")
            else:
                logger.critical(f"[{log_id}] Column 'target' is entirely missing from DataFrame. Columns available: {df.columns.tolist()}")
                raise KeyError("'target' column not found in DataFrame before attempting restoration.")
        elif df["target"].isnull().all():
            logger.warning(f"[{log_id}] 'target' column exists but contains all nulls.")
            if backup_df is not None and "target_copy" in backup_df.columns:
                df = df.copy()
                df["target"] = backup_df["target_copy"]
                logger.info(f"[{log_id}] 'target' column restored from 'target_copy'")
            else:
                logger.error(f"[{log_id}] 'target' is null and no valid backup found")
                raise ValueError("Critical column 'target' is null and cannot be recovered.")
    else:
        logger.info(f"[{log_id}] 'target' column is present and valid.")

    # Validate presence of target and its backups explicitly
    required_columns = ["target", "target_copy", "target_train_copy", "target_test_copy"]
    missing_required = [col for col in required_columns if col not in df.columns]
    if missing_required:
        logger.critical(f"[{log_id}] Missing required columns after restoration: {missing_required}")
        raise KeyError(f"Required columns missing after restoration: {missing_required}")

    logger.info(f"[{log_id}] ✅ 'target' verified.")

    non_null_count = df['target'].notnull().sum()
    if non_null_count < 5:
        logger.warning(f"[{log_id}] 'target' column has very few non-null values ({non_null_count}). Potential data integrity issue.")
    else:
        logger.info(f"[{log_id}] 'target' column verified with {non_null_count} non-null entries.")

    logger.info(f"[{log_id}] Restoration operations completed successfully.")
    # 🛡️ Ensure protected target-related backup columns are retained
    protected_backups = ["target_copy", "target_test_copy", "target_train_copy"]
    for col in protected_backups:
        if col not in df.columns:
            logger.warning(f"[{log_id}] Backup column '{col}' is unexpectedly missing before return.")

    # [Trace] Logging for final 'target' column and DataFrame status
    logger.debug(f"[{log_id}] [Trace] Final 'target' column stats — non-nulls: {df['target'].notnull().sum()}, nulls: {df['target'].isnull().sum()}")
    logger.debug(f"[{log_id}] [Trace] Final DataFrame columns after ensure_target_integrity: {df.columns.tolist()}")
    if 'target' in df.columns:
        logger.debug(f"[{log_id}] [Trace] Sample 'target' values: {df['target'].dropna().unique()[:5]}")
    # Consistency check between columns before and after restoration
    from utils.validation import check_column_consistency
    df_after_restore = df.copy()
    check_column_consistency(df_before_restore, df_after_restore, stage="Ensure Target Integrity")
    return df


# Restore contextual clinical columns if missing or null, based on FallbackRestorer logic
def restore_contextual_columns(df, log_id=None):
    """
    Restore contextual clinical columns if missing or null, based on logic from FallbackRestorer
    and available backups. This serves as a defensive patch for ensuring the presence of:
        - bp_category
        - chol_category
        - risk_level
        - age_group

    Args:
        df (pd.DataFrame): Input DataFrame
        log_id (str, optional): Unique identifier for logging. Auto-generated if not provided.

    Returns:
        pd.DataFrame: DataFrame with contextual columns restored if needed
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    logger.info(f"[{log_id}] [RestoreContextual] Checking for missing contextual columns.")
    contextual_cols = ["bp_category", "chol_category", "risk_level", "age_group"]
    missing_or_null = [col for col in contextual_cols if col not in df.columns or df[col].isnull().all()]

    logger.info(f"[{log_id}] [RestoreContextual] Checking if all contextual columns are present before restoration.")
    if not missing_or_null:
        logger.info(f"[{log_id}] [RestoreContextual] All contextual columns are present and non-null.")
        return df

    logger.warning(f"[{log_id}] [RestoreContextual] Missing or null contextual columns detected: {missing_or_null}")
    df = FallbackRestorer.restore_derived_clinical_columns(df)

    restored_now = [col for col in contextual_cols if col in df.columns and df[col].notnull().sum() > 0]
    still_missing = [col for col in contextual_cols if col not in restored_now]

    logger.info(f"[{log_id}] [RestoreContextual] Restored contextual columns: {restored_now}")
    if still_missing:
        logger.warning(f"[{log_id}] [RestoreContextual] Columns still missing or null after restoration: {still_missing}")

    return df