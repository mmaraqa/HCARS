import yaml
import pandas as pd
import logging
from utils.config_loader import load_global_config

logger = logging.getLogger(__name__)

def load_yaml_as_dataframe(path: str, mode: str = "prod") -> pd.DataFrame:
    logger.info(f"[YAML Loader] 🔄 Mode: {mode.upper()} | File: {path}")
    with open(path, "r", encoding="utf-8") as file:
        yaml_data = yaml.safe_load(file)

    if isinstance(yaml_data, list):
        # Simple list of records
        df = pd.DataFrame(yaml_data)
        logger.info(f"[YAML Loader] ✅ Loaded list-based YAML with {len(df)} rows.")
        if mode == "test":
            logger.debug(f"[YAML Loader - TEST] Preview:\n{df.head(2).to_string(index=False)}")
        return clean_context_columns(df)

    elif isinstance(yaml_data, dict):
        # Handle hybrid or structured dict formats
        if "test_data" in yaml_data:
            try:
                df = pd.DataFrame(yaml_data["test_data"])
                logger.info(f"[YAML Loader] ✅ Loaded 'test_data' section with {len(df)} rows.")
                if mode == "test":
                    logger.debug(f"[YAML Loader - TEST] Preview:\n{df.head(2).to_string(index=False)}")
                return clean_context_columns(df)
            except Exception as e:
                logger.warning(f"[YAML Loader] ⚠️ Failed to parse 'test_data': {e}")

        if "hybrid_recommendations" in yaml_data:
            records = []
            for rec in yaml_data.get("hybrid_recommendations", []):
                patient_id = rec.get("patient_id")
                context = rec.get("context", {})
                for item in rec.get("items", []):
                    feature_id = item.get("feature_id")
                    score = item.get("score")
                    if patient_id and feature_id and score is not None:
                        records.append({
                            "patient_id": patient_id,
                            "feature_id": feature_id,
                            "hybrid_score": score,
                            **context
                        })
            if records:
                df = pd.DataFrame(records)
                logger.info(f"[YAML Loader] ✅ Loaded {len(df)} hybrid recommendation rows.")
                if mode == "test":
                    logger.debug(f"[YAML Loader - TEST] Preview:\n{df.head(2).to_string(index=False)}")
                return clean_context_columns(df)

        # Fallback: assume single top-level key with records
        key = next(iter(yaml_data))
        records = yaml_data[key]
        df = pd.DataFrame(records)
        logger.info(f"[YAML Loader] ✅ Loaded records under key '{key}' with {len(df)} rows.")
        if mode == "test":
            logger.debug(f"[YAML Loader - TEST] Preview:\n{df.head(2).to_string(index=False)}")
        return clean_context_columns(df)

    else:
        raise ValueError("Unsupported YAML format: must be a list or dict.")

def clean_context_columns(df: pd.DataFrame) -> pd.DataFrame:
    config = load_global_config()
    context_keys = config.get("context_features", ['risk_level', 'age_group', 'bp_category', 'chol_category'])
    for key in context_keys:
        if key not in df.columns:
            df[key] = pd.NA
    return df