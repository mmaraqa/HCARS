"""
risk_score_transformer.py
============================
Implements a custom scikit-learn transformer to calculate a simplified clinical risk score
based on age, resting blood pressure (trestbps), and cholesterol (chol), used in the thesis:
"Hybrid Context-Aware Recommendation System for Hypertension Problem".

Features:
- Stateless transformer conforming to sklearn's API
- Rule-based logic for simplified hypertension risk stratification
- Configuration-driven toggle for activation
- Extendable for future context-aware clinical scoring models
"""

# 💡 هذا المِلف يطبق منطقًا سريريًا مبنيًا على أدلة مبسطة لكنه قابل للتوسعة نحو تصنيف سريري شامل متعدد المتغيرات

import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from utils.config_loader import load_global_config, get_config
from utils import get_logger

# Set pandas option for future downcasting behavior
pd.set_option('future.no_silent_downcasting', True)
GLOBAL_CONFIG = load_global_config()
DISEASE_CONTEXT = GLOBAL_CONFIG.get("disease_context", "hypertension")
logger = get_logger("RiskScoreTransformer")


def validate_columns_for_risk_score(x: pd.DataFrame, age_col: str, trestbps_col: str, chol_col: str):
    """
    validates the presence of required columns in the input DataFrame for risk score calculation.

    Args:
        x (pd.DataFrame): Input data.
        age_col (str): Name of the age column.
        trestbps_col (str): Name of the resting blood pressure column.
        chol_col (str): Name of the cholesterol column.

    Returns:
        bool: True if required columns are present for risk scoring, False otherwise.

    Logs:
        Warnings if critical columns are missing or if risk score cannot be computed.
    """
    # Accept any DataFrame-like object that exposes a 'columns' attribute (duck typing).
    try:
        _ = x.columns  # type: ignore[attr-defined]
    except Exception as e:
        error_msg = "Input must be a pandas DataFrame (missing 'columns' attribute)."
        logger.critical(error_msg)
        raise ValueError(error_msg) from e

    missing = []
    for col in [age_col, trestbps_col, chol_col]:
        if col not in x.columns:
            missing.append(col)

    if missing:
        error_msg = f"[Critical Medical Error] Missing essential clinical columns: {missing}. Cannot continue with risk score calculation."
        logger.critical(error_msg)
        raise ValueError(error_msg)

    for col in [age_col, trestbps_col, chol_col]:
        if not pd.api.types.is_numeric_dtype(x[col]):
            logger.warning(f"[Clinical Type Warning] ⚠️ العمود '{col}' ليس من نوع عددي، قد يؤدي إلى نتائج غير دقيقة.")

    logger.debug(f"[RiskScoreTransformer] Input validation passed. Columns present: {list(x.columns)}")
    return True


def apply_advanced_hypertension_scoring(x: pd.DataFrame, age_col: str, trestbps_col: str, chol_col: str) -> pd.DataFrame:
    """
    applies a simple hypertension risk scoring based on age, resting blood pressure, and cholesterol.

    scoring logic:
        - +1 point if age > 60
        - +1 point if trestbps > 130
        - +1 point if chol > configurable threshold (default 240 via config: preprocessing.risk_score.thresholds.chol)

    risk levels:
        0 points: low risk
        1 point: medium risk
        2 or more points: high risk

    args:
        x (pd.DataFrame): Input data.
        age_col (str): Name of the age column.
        trestbps_col (str): Name of the resting blood pressure column.
        chol_col (str): Name of the cholesterol column.

    Returns:
        pd.DataFrame: DataFrame with an added 'risk_score' column.

    Logs:
        Risk computation steps, factors used per record, and final risk distribution.
    """
    logger.info("[Risk Score Status] Starting advanced hypertension risk scoring calculation...")
    logger.info("🩺 يتم استخدام معايير سريرية مبسطة تعتمد على العمر، ضغط الدم الانقباضي، والكوليسترول.")
    age_filled = x[age_col].fillna(x[age_col].median())
    trestbps_filled = x[trestbps_col].fillna(x[trestbps_col].median())
    chol_filled = x[chol_col].fillna(x[chol_col].median())

    age_flag = (age_filled > 60).astype(int)
    trestbps_flag = (trestbps_filled > 130).astype(int)
    # Use configurable cholesterol threshold (fallback to 240 if not provided)
    cfg = get_config()
    chol_threshold = (
        cfg.get("preprocessing", {})
           .get("risk_score", {})
           .get("thresholds", {})
           .get("chol", 240)
    )
    chol_flag = (chol_filled > chol_threshold).astype(int)

    risk_points = age_flag + trestbps_flag + chol_flag
    logger.debug("[Trace] Risk point flags — age_flag, trestbps_flag, chol_flag:")
    logger.debug(f"{pd.DataFrame({'age': age_filled, 'age_flag': age_flag, 'trestbps': trestbps_filled, 'trestbps_flag': trestbps_flag, 'chol': chol_filled, 'chol_flag': chol_flag}).head(5)}")

    # 🧠 التصنيف حسب النُقاط السريرية: 0=منخفض، 1=متوسط، ≥2=مرتفع — مستند إلى استدلال مبسط لخطر فرط الضغط.
    def map_risk_level(points):
        if points == 0:
            return "low"
        elif points == 1:
            return "medium"
        else:
            return "high"

    risk_level = risk_points.apply(map_risk_level)

    x = x.copy()
    x["risk_score"] = np.floor(risk_points).astype(int)
    if not x["risk_score"].between(0, 3).all():
        logger.warning(f"[Post-Scoring Warning] ❗ Detected risk_score values outside [0–3] after flooring. Values: {x['risk_score'][~x['risk_score'].between(0, 3)].unique().tolist()}")
    # 🧪 تأكيد سريري: يجب أن تبقى قيمة risk_score ضمن [0, 3] وفقًا للمنطق الطبي المستخدم
    assert x["risk_score"].between(0, 3).all(), "[Clinical Integrity Check] ❌ Detected invalid 'risk_score' values outside expected range [0–3]."
    logger.info(f"[Risk Score] Columns after scoring: {x.columns.tolist()}")
    x["risk_level"] = risk_level
    logger.info(f"[Risk Score] Columns after scoring: {x.columns.tolist()}")
    logger.info(f"[Risk Score] Value counts for risk_level:\n{x['risk_level'].value_counts().to_dict()}")
    logger.info(f"[Risk Score] Value counts for risk_score:\n{x['risk_score'].value_counts().to_dict()}")

    # Context field verification
    expected_context_fields = ["risk_level"]
    for field in expected_context_fields:
        if field not in x.columns:
            logger.warning(f"[Context Check] ❗Missing context field after scoring: {field}")
        else:
            unique_vals = x[field].dropna().unique().tolist()
            logger.debug(f"[Context Check] {field} present with values: {unique_vals}")

    # Log factors used per record (sample of first 5 for brevity)
    sample_factors = pd.DataFrame({
        "age_flag": age_flag,
        "trestbps_flag": trestbps_flag,
        "chol_flag": chol_flag,
        "risk_score": risk_points,
        "risk_level": risk_level
    }).head(5)
    logger.debug(f"[Risk Score Status] Sample risk factors for first 5 records:\n{sample_factors}")

    # Log final distribution of risk levels
    distribution = risk_level.value_counts(dropna=False).to_dict()
    logger.info(f"[Risk Score Status] Final risk level distribution: {distribution}")

    if risk_points.isna().any():
        logger.warning(f"[Clinical Warning] ⚠️ Detected {risk_points.isna().sum()} NaN values in computed risk_score.")

    logger.info("[Risk Score Status] Applied advanced hypertension risk scoring.")
    logger.info("[Risk Score Status] Scoring applied successfully.")

    risk_level_dummies = pd.get_dummies(x["risk_level"], prefix="multi__risk_level")
    # Deduplicate columns in risk_level_dummies to prevent downstream duplication
    risk_level_dummies = risk_level_dummies.loc[:, ~risk_level_dummies.columns.duplicated()]
    x = pd.concat([x, risk_level_dummies], axis=1)
    # Remove duplicate columns in the final DataFrame before returning
    x = x.loc[:, ~x.columns.duplicated()]

    # Deduplicate and validate context fields
    context_fields = ["risk_level", "risk_score"]
    for ctx in context_fields:
        if ctx not in x.columns:
            logger.warning(f"[Post-Scoring Check] Context field '{ctx}' missing.")
        else:
            logger.debug(f"[Post-Scoring Check] Context field '{ctx}' values preview: {x[ctx].dropna().unique().tolist()}")

    logger.debug(f"[Risk Score] Final DataFrame sample (first 5 rows):\n{x.head(5)}")
    return x


class RiskScoreTransformer(BaseEstimator, TransformerMixin):
    """
    A custom rule-based feature engineering transformer to compute a simplified hypertension risk score.
    This is based on age, resting blood pressure, and cholesterol, aligned with common medical risk stratification logic.
    """

    def __init__(self, strategy="hypertension_risk_simple", age_col="age", trestbps_col="trestbps", chol_col="chol"):
        self.strategy = strategy
        self.age_col = age_col
        self.trestbps_col = trestbps_col
        self.chol_col = chol_col
        self.enabled = GLOBAL_CONFIG.get("risk_score", {}).get("enabled", True)
        logger.info("🩺 [Risk Score Init] تم تهيئة المحول بمعلومات سريرية أساسية.")

    def fit(self, _x: pd.DataFrame, _y=None):
        # Stateless transformer — input parameters are unused by design
        return self

    def transform(self, x: pd.DataFrame) -> pd.DataFrame:
        logger.info(f"[Risk Score Status] ➤ Transformation triggered.")
        # Reload config dynamically to get latest enable flag
        current_config = load_global_config()
        self.enabled = current_config.get("risk_score", {}).get("enabled", True)
        logger.info(f"[Risk Score Status] Reloaded config, enable_risk_score={self.enabled}")

        if not self.enabled:
            logger.info("[Risk Score Status] Skipping transformation: Transformer explicitly disabled by config.")
            return x

        logger.info("[Risk Score Status] ⚙️ Starting transformation...")
        try:
            validate_columns_for_risk_score(x, self.age_col, self.trestbps_col, self.chol_col)
            x = apply_advanced_hypertension_scoring(x, self.age_col, self.trestbps_col, self.chol_col)
            logger.info("[Risk Score Status] Transformation completed successfully.")
        except Exception as e:
            logger.exception(f"[Risk Score Status] ❌ Exception during transformation: {e}")
            return x

        if "risk_score" not in x.columns:
            logger.warning("[Data Integrity] ⚠️ 'risk_score' column was not created.")
        elif not x["risk_score"].between(0, 3).all():
            logger.warning("[Clinical Sanity Check] ⚠️ Detected 'risk_score' values outside expected clinical bounds [0–3].")
        logger.debug(f"[Trace] Final columns after transformation: {x.columns.tolist()}")
        logger.debug(f"[Trace] Null counts post-scoring:\n{x[['risk_score']].isnull().sum()}")
        if "risk_score" in x.columns:
            logger.debug(f"[Trace] Sample 'risk_score' values: {x['risk_score'].dropna().head(5).tolist()}")

        logger.info("🩺 [Risk Score Transformer] التحول السريري اكتمل وتم توليد الأعمدة risk_score و risk_level.")
        return x

    def _validate_input(self, x: pd.DataFrame):
        """
        Validate presence of required input columns for hypertension risk scoring.

        Parameters
        ----------
        x : pd.DataFrame
            Input DataFrame to validate.

        Returns
        -------
        None

        Logs
        ----
        [Clinical Warning] if any of the required columns are missing.
        """
        validate_columns_for_risk_score(x, self.age_col, self.trestbps_col, self.chol_col)

    def _apply_simple_scoring(self, x: pd.DataFrame) -> pd.DataFrame:
        """
        Apply hypertension scoring logic to input DataFrame.

        Parameters
        ----------
        x : pd.DataFrame
            DataFrame containing required clinical features.

        Returns
        -------
        pd.DataFrame
            DataFrame with added 'risk_score' and 'risk_level' columns.

        Logs
        ----
        [Risk Score Status] Logging scoring steps and column creation.
        """
        return apply_advanced_hypertension_scoring(x, self.age_col, self.trestbps_col, self.chol_col)

    @staticmethod
    def get_feature_names_out(input_features_=None):
        """
        Extend feature names with risk_score for pipeline compatibility.

        Parameters
        ----------
        input_features_ : list or None
            Original feature names.

        Returns
        -------
        np.ndarray
            Extended list of feature names including 'risk_score'.
        """
        return np.array(list(input_features_ or []) + ["risk_score"])

# NOTE: Columns multi__risk_level_low, medium, high added for schema validation in post-encoding step.


# ✅ الملائم سريريًا: يعتمد على منطق مفسّر ومتاح للتوسع مستقبلاً لتشمل أنماط حياة، سمنة، وتاريخ وراثي


# Wrapper function to apply RiskScoreTransformer and return dictionary output for debug_preprocessing_pipeline.py
def apply_risk_score_as_dict(df: pd.DataFrame) -> dict:
    """
    Applies the RiskScoreTransformer outside sklearn context and returns output as a dictionary
    with key 'hypertension_df' to integrate with debug_preprocessing_pipeline.py.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.

    Returns
    -------
    dict
        Dictionary with key 'hypertension_df' mapped to transformed DataFrame.
    """
    logger.info("[RiskScoreTransformer Wrapper] ➤ Applying risk score as dictionary output.")
    try:
        transformer = RiskScoreTransformer()
        transformed_df = transformer.transform(df)
        return {"hypertension_df": transformed_df}
    except Exception as e:
        logger.exception(f"[RiskScoreTransformer Wrapper] ❌ Exception during transformation: {e}")
        return {"hypertension_df": df}
