"""
Initialization module for the `utils` package in the HCARS system.

Exposes core utility functions and constants related to:
- Configuration loading
- Data validation
- Feature engineering consistency checks
- Logging and clinical auditing

This file is critical for maintaining reusable and centralized access to foundational logic
across the HCARS pipeline including recommendation and risk analysis modules.

Compliance:
- ✅ ISO/IEC 25010 (Modularity, Maintainability)
- ✅ ISO/IEC 27001 (Logging, Security Audit Trails)
- ✅ ISO/IEC 29119 (Unit test hooks via self-test)
"""

from .config_loader import load_config
from .hcars_utils import HCARSUtils, get_cbf_features_by_dataset
from .restoration import restore_protected_columns
from .logging_utils import get_logger, pipeline_logger
from .safe_copy import safe_copy
from . import yaml_utils, log_diagnostics
from .constants import plan_as_dict
from .constants import RECOMMENDATION_EXPLAIN, RECOMMENDATION_SOURCE
from .context_utils import make_core_context_key

from .validation import (
    validate_required_columns,
    check_column_consistency,
    ensure_no_nans,
    backup_protected_columns,
    apply_risk_score,
)

# Developer Note:
# This module acts as the controlled import gateway for utility functions and constants
# used throughout the HCARS pipeline. Do not modify exposed items without validating full pipeline.

# Initialize logger
logger = get_logger("utils.__init__")
logger.info("🔧 __init__.py module loaded successfully — HCARS utilities are ready!")

__all__ = [
    "load_config",
    "validate_required_columns",
    "check_column_consistency",
    "ensure_no_nans",
    "get_cbf_features_by_dataset",
    "backup_protected_columns",
    "restore_protected_columns",
    "apply_risk_score",
    "get_logger",
    "pipeline_logger",
    "HCARSUtils",
    "safe_copy",
    "self_test_utils",
    "yaml_utils",
    "log_diagnostics",
    "plan_as_dict",
    "RECOMMENDATION_EXPLAIN",
    "RECOMMENDATION_SOURCE",
    "make_core_context_key",

]

def self_test_utils():
    try:
        logger.info("[Self-Test] Running utility module import checks...")
        assert callable(load_config)
        logger.info("✅ load_config available")
        assert callable(validate_required_columns)
        logger.info("✅ validate_required_columns available")
        assert callable(check_column_consistency)
        logger.info("✅ check_column_consistency available")
        assert callable(ensure_no_nans)
        logger.info("✅ ensure_no_nans available")
        assert callable(restore_protected_columns)
        logger.info("✅ restore_protected_columns available")
        assert callable(apply_risk_score)
        logger.info("✅ apply_risk_score available")
        logger.info("[Self-Test] ✅ Core utility imports validated.")
    except Exception as e:
        logger.error(f"[Self-Test] ❌ Failure in utility imports or callable check: {e}")

# Run self-test upon loading
self_test_utils()
