from typing import Union, Optional, List, Dict, Any
import pandas as pd
import numpy as np
from pandas.api.types import CategoricalDtype

# --- Canonical feature id helpers
from utils.constants import canonicalize_feature_id, CANONICAL_FEATURE_IDS

# --- Family mapping for LOCO-Family fallback (string-based feature binning)
FAMILY_MAP = {
    # Pharmacologic families (examples; extend as needed)
    "amlodipine": "ccb",
    "amlodipine_and_thiazide": "ccb+thiazide",
    "ace_inhibitor": "acei",
    "acei": "acei",
    "arb": "arb",
    "beta_blockers": "beta_blocker",
    "beta_blocker": "beta_blocker",
    "thiazide": "thiazide",
    # Lifestyle & monitoring
    "diet_control": "lifestyle",
    "increase_exercise": "lifestyle",
    "lifestyle_monitoring": "lifestyle",
    # Default catch-all is handled via .fillna("unknown") below
}

# --- Canonicalization for feature_id (Arabic docstring)
def sanitize_feature_id(x):
    """
    يُعيد feature_id بصيغة canonical (إن أمكن)، أو القيمة الأصلية إن كانت قانونية،
    وإلا يعيد 'manual_review' ليتعامل معها النظام لاحقًا.
    """
    canon = canonicalize_feature_id(x)
    if canon in CANONICAL_FEATURE_IDS:
        return canon
    # لو فشل التعريف تمامًا، لا نرمي الصف — نوسمه للمراجعة اليدوية
    return "manual_review"

# --- Helper: safely canonicalize a feature_id Series and always return string dtype
def _safe_canonicalize_feature_id_series(ser: pd.Series) -> pd.Series:
    """
    Apply sanitize_feature_id to a Series safely and ALWAYS return a pandas Series
    with string dtype. Non-Series inputs (including None) are coerced to a
    Series to satisfy callers and static type checkers.
    """
    def _to_str_series(x, like: Optional[pd.Series] = None) -> pd.Series:
        """
        يحوّل أي إدخال إلى Series نصية. إن قُدّم like فسيُستخدم فهرسه/اسمه للمحاذاة.
        """
        if isinstance(x, pd.Series):
            try:
                return x.astype("string")
            except (TypeError, ValueError):
                return x.astype(object).astype("string")

        idx = getattr(like, "index", None) if like is not None else None
        name = getattr(like, "name", None) if like is not None else None

        if x is None:
            return pd.Series(pd.array([], dtype="string"), index=idx, name=name)

        if not hasattr(x, "__iter__") or isinstance(x, (str, bytes)):
            data = [x]
        else:
            try:
                data = list(x)
            except (TypeError, ValueError, AttributeError):
                data = [str(x)]

        s = pd.Series(data, dtype="string")
        if idx is not None and len(s) == len(idx):
            s.index = idx
            s.name = name
        return s

    try:
        # Coerce to Series if needed
        if not isinstance(ser, pd.Series):
            ser = _to_str_series(ser, like=ser if isinstance(ser, pd.Series) else None)
        # Apply canonicalization row-wise
        out = ser.apply(sanitize_feature_id)
        try:
            return out.astype("string")
        except (TypeError, ValueError):
            return out.astype(object).astype("string")
    except (TypeError, ValueError, KeyError, AttributeError):
        # On any local failure, return the best-effort string Series
        return _to_str_series(ser)

def get_all_context_columns(config_dict: dict = None, context_cols: list = None, secondary_cols: list = None) -> list:
    """
    Returns a unified list of all context columns (primary + secondary).
    Takes columns from config if available, else explicit args.

    Parameters
    ----------
    config_dict : dict, optional
        Config dict containing "context_columns" and "secondary_context_columns".
    context_cols : list, optional
        Explicit list of primary context columns.
    secondary_cols : list, optional
        Explicit list of secondary context columns.

    Returns
    -------
    list of str
        Full list of all context columns.
    """
    if config_dict is not None:
        cols = list(config_dict.get("context_columns", []))
        sec = list(config_dict.get("secondary_context_columns", []))
    else:
        cols = list(context_cols) if context_cols else []
        sec = list(secondary_cols) if secondary_cols else []
    all_cols = cols + sec
    if not all_cols:
        raise ValueError("No context columns defined in config or parameters.")
    # إزالة أي تكرار مع الحفاظ على الترتيب
    seen = set()
    all_cols = [x for x in all_cols if not (x in seen or seen.add(x))]
    return all_cols

def normalize_context_value(x):
    """Minimal normalizer: lowercase + strip; missing/empty -> 'unknown'.
    Does NOT insert underscores or map placeholder tokens; use
    `normalize_context_value_ext` for robust handling.
    """
    if x is None:
        return "unknown"
    xs = str(x).strip().lower()
    return xs if xs else "unknown"

# --- Lightweight normalizer (as requested): minimal, consistent lower/underscore
def normalize_context_value_basic(x):
    if x is None:
        return "unknown"
    try:
        # Handle pandas / numpy nulls
        if isinstance(x, float) and np.isnan(x):
            return "unknown"
    except (TypeError, ValueError):
        # Non-numeric types may raise here; treat as non-NaN and continue
        pass
    s_val = str(x).strip().lower().replace(" ", "_")
    if s_val in {"", "none", "null", "nan"}:
        return "unknown"
    return s_val

def normalize_context_value_ext(x) -> str:
    """
    Robust normalizer that ALWAYS returns a string:
    - Accepts scalars, pd.Series/Index, or np.ndarray
    - Picks the first non-null (or mean for numeric arrays) when needed
    - Maps missing/NaN/empty -> 'unknown'
    - Lowercases and replaces spaces/hyphens with underscores
    """
    # Fast-path for simple missing
    if x is None:
        return "unknown"

    # Unwrap pandas containers
    if isinstance(x, (pd.Series, pd.Index)):
        if len(x) == 0:
            return "unknown"
        # Prefer first non-null
        xv = pd.Series(x).dropna()
        if xv.empty:
            return "unknown"
        x = xv.iloc[0]

    # Unwrap numpy arrays
    if isinstance(x, np.ndarray):
        if x.size == 0:
            return "unknown"
        # If numeric, use first finite value
        try:
            x_num = x.astype(float)
            # pick first non-nan
            for _val_num in x_num:
                if not np.isnan(_val_num):
                    x = _val_num
                    break
            else:
                return "unknown"
        except (ValueError, TypeError):
            # fallback to first element as string
            x = x.flat[0]

    # Handle NaN for floats
    if isinstance(x, float):
        if np.isnan(x):
            return "unknown"

    sval = str(x).strip().lower().replace(" ", "_").replace("-", "_")
    if sval in {"", "none", "null", "nan"}:
        return "unknown"
    return str(sval)

# --- Import normalize_label and ADVICE_MAP for use in generate_plan_additions
from utils.constants import ADVICE_MAP

# --- Auto-plan gap-filling helper
def generate_plan_additions(uncovered_df: pd.DataFrame, rules: dict) -> dict:
    """
    يُنتج إضافات قاموسية تلقائية لسد فجوات التخطيط السريري.
    Parameters
    ----------
    uncovered_df : DataFrame
        يحتوي أعمدة سياق مثل: bp_category, chol_category, risk_level, وربما fbs_cat/cp_cat.
    rules : dict
        قاموس بسيط: { "rule_name": {"when": {...}, "recommend": [feature_ids...] } }
        حيث قيم when والقوائم تُطبَّع عبر normalize_label.
    Returns
    -------
    dict
        { context_key(str) : [feature_id, ...] } — مقترحات إضافة.
    """
    if not isinstance(uncovered_df, pd.DataFrame) or uncovered_df.empty:
        return {}

    props = {}
    for _, r in uncovered_df.iterrows():
        bp = normalize_label(r.get("bp_category", "unknown"))
        chol = normalize_label(r.get("chol_category", "unknown"))
        risk = normalize_label(r.get("risk_level", "unknown"))
        fbs = normalize_label(r.get("fbs_cat", "any"))
        cp  = normalize_label(r.get("cp_cat", "any"))
        ctx_key = f"{bp}|{chol}|{risk}"

        chosen = None
        for rn, rd in (rules or {}).items():
            when = (rd or {}).get("when", {})
            ok = True
            for k, allowed in (when or {}).items():
                v = {
                    "bp_category": bp, "chol_category": chol, "risk_level": risk,
                    "fbs_cat": fbs, "cp_cat": cp
                }.get(k, "unknown")
                allowed_norm = {normalize_label(x) for x in (allowed if isinstance(allowed, (list, tuple, set)) else [allowed])}
                if v not in allowed_norm:
                    ok = False
                    break
            if ok:
                recs = [normalize_label(x) for x in (rd or {}).get("recommend", [])]
                chosen = recs if recs else None
                break

        # إن لم تُطابق قاعدة، اقترح lifestyle_monitoring كخيار آمن
        if not chosen:
            chosen = ["lifestyle_monitoring"] if "lifestyle_monitoring" in ADVICE_MAP else []

        if chosen:
            props[ctx_key] = chosen
    return props


def make_core_context_key(row_or_dict) -> str:
    """Build a stable key 'bp|chol|risk' from bp_category/chol_category/risk_level."""
    try:
        getter = (row_or_dict.get if hasattr(row_or_dict, "get")
                  else (lambda k, d=None: getattr(row_or_dict, k, d)))
        bp = normalize_context_value(getter("bp_category", "unknown"))
        chol = normalize_context_value(getter("chol_category", "unknown"))
        risk = normalize_context_value(getter("risk_level", "unknown"))
        return f"{bp}|{chol}|{risk}"
    except (AttributeError, TypeError, ValueError):
        try:
            return str(row_or_dict)
        except (TypeError, ValueError):
            try:
                return repr(row_or_dict)
            except (TypeError, ValueError):
                return "unknown|unknown|unknown"

# --- Simple, extensible keyword → family mapping for feature binning
_DEF_FAMILY_MAP: Dict[str, str] = {
    "acei": "ACEI",
    "arb": "ARB",
    "ccb": "CCB",
    "beta": "Beta_Blocker",
    "diur": "Diuretic",
    "thiaz": "Diuretic",
    "statin": "Statin",
    "lifestyle": "Lifestyle",
}
# Clinical gating logic for candidate filtering (see plan)
def filter_candidates_by_clinical_gating(
    context_row: Union[pd.Series, Dict[str, Any]],
    candidates_df: pd.DataFrame,
    cfg: Dict[str, Any],
    logger=None,
) -> pd.DataFrame:
    """
    Apply clinical gating based on rules in cfg['cbf']['clinical_gating'].
    - If disabled or rules missing → passthrough
    - Else, match the first rule whose 'when' conditions fit the normalized context
    - Keep only candidates whose `feature_id` ∈ rule['allow_features']
    - If all rows are filtered, attempt a safe fallback (e.g., 'lifestyle_monitoring'); if unavailable, return the original candidates
    - Update `source` with rule['source'] (or default) when empty/unknown
    """

    # Guard: candidates_df must be a DataFrame with at least one row
    if not isinstance(candidates_df, pd.DataFrame) or candidates_df.empty:
        return candidates_df

    # Read gating config
    try:
        cg = (((cfg or {}).get("cbf", {}) or {}).get("clinical_gating", {}) or {})
    except (AttributeError, TypeError, ValueError):
        cg = {}
    if not cg or not bool(cg.get("enabled", False)):
        return candidates_df

    rules = cg.get("rules", {}) or {}
    default_source = cg.get("default_source", "Clinical policy (config)")
    safe_fallback = cg.get("safe_fallback", ["lifestyle_monitoring"])  # configurable

    # Build normalized context map
    def _get_ctx(name: str, default: str) -> str:
        try:
            if isinstance(context_row, pd.Series):
                val_ctx = context_row.get(name, default)
            elif isinstance(context_row, dict):
                val_ctx = context_row.get(name, default)
            else:
                val_ctx = getattr(context_row, name, default)
        except (AttributeError, TypeError):
            val_ctx = default
        return normalize_label(val_ctx)  # from utils.constants

    ctx_map = {
        "bp_category": _get_ctx("bp_category", "unknown"),
        "chol_category": _get_ctx("chol_category", "unknown"),
        "risk_level": _get_ctx("risk_level", "unknown"),
        "fbs_cat": _get_ctx("fbs_cat", "any"),
        "cp_cat": _get_ctx("cp_cat", "any"),
    }

    matched_rule_name = None
    allow_features = None
    rule_source = None

    # Evaluate rules in declaration order (YAML preserves insertion order)
    for rname, rdef in rules.items():
        when = (rdef or {}).get("when", {}) or {}
        ok = True
        for k, allowed_vals in when.items():
            ctx_val = ctx_map.get(k, "unknown")
            if isinstance(allowed_vals, (list, tuple, set)):
                allowed_norm = {normalize_label(x) for x in allowed_vals}
            else:
                allowed_norm = {normalize_label(allowed_vals)}
            if ctx_val not in allowed_norm:
                ok = False
                break
        if ok:
            matched_rule_name = rname
            allow_features = list((rdef or {}).get("allow_features", []) or [])
            rule_source = (rdef or {}).get("source", default_source)
            break

    # If no rules matched → passthrough
    if not matched_rule_name or not allow_features:
        if logger is not None and hasattr(logger, "info"):
            logger.info(f"[clinical_gating] no matching rule for ctx={ctx_map}; passthrough")
        return candidates_df

    # Filter by allowed features
    out = candidates_df.copy()
    if "feature_id" not in out.columns:
        return candidates_df
    before_n = len(out)
    mask = out["feature_id"].astype(str).isin([str(x) for x in allow_features])
    out = out.loc[mask].copy()

    # Update source where missing/empty
    if "source" in out.columns:
        _src = out["source"].astype(str)
        out.loc[_src.isna() | (_src.str.lower().isin(["", "none", "nan", "unknown"])) , "source"] = rule_source
    else:
        out["source"] = rule_source

    if logger is not None and hasattr(logger, "info"):
        logger.info(f"[clinical_gating] rule={matched_rule_name} kept={len(out)}/{before_n} allow={allow_features}")

    # Safe fallback if everything got filtered out
    if out.empty:
        if logger is not None and hasattr(logger, "warning"):
            logger.warning(f"[clinical_gating] rule={matched_rule_name} removed all; attempting safe fallback {safe_fallback}")
        orig = candidates_df.copy()
        if "feature_id" in orig.columns and safe_fallback:
            sf_list = [str(x) for x in safe_fallback]
            sf = orig.loc[orig["feature_id"].astype(str).isin(sf_list)].copy()
            if not sf.empty:
                if "source" in sf.columns:
                    _src2 = sf["source"].astype(str)
                    sf.loc[_src2.isna() | (_src2.str.lower().isin(["", "none", "nan", "unknown"])) , "source"] = rule_source
                else:
                    sf["source"] = rule_source
                return sf
        # Fallback to passthrough if no safe option available
        return candidates_df

    return out


def _bin_feature_simple(fid: str, fmap: Optional[Dict[str, str]] = None) -> str:
    fmap = fmap or _DEF_FAMILY_MAP
    token = (fid or "").strip().lower()
    for k, fam in fmap.items():
        if k in token:
            return fam
    return "Other"

def make_context_key(
    context_dict: Union[dict, pd.Series],
    context_columns: Optional[List[str]] = None,
    secondary_columns: Optional[List[str]] = None,
    config_dict: Optional[dict] = None,
    verbose: bool = False
) -> str:
    """
    Generate a strict, normalized context key from a dict or Series of contextual values,
    supporting both primary and secondary context columns.
    ALWAYS use this function both for training (dictionary creation) and prediction (lookup).

    - All columns (primary + secondary) are normalized via normalize_context_value (which always returns a string).
    - Missing or None values are filled as "unknown" and normalized.
    - All values are always normalized, even if missing or None.
    - The join character is always a single underscore ("_").
    - The function is robust to missing or extra columns in context_dict: only all context columns are used,
      missing ones default to "unknown".
    - WARNING: The order of all context columns is critical; always use the same ordering for both training and prediction.
    - One of context_columns or a config with "context_columns" **must** be provided. No implicit config loading is performed.

    Parameters
    ----------
    context_dict : dict or pd.Series
        Contextual values as dict or Series.
    context_columns : Optional[List[str]]
        List of primary context column names (order matters). If None, will use config["context_columns"] if provided.
    secondary_columns : Optional[List[str]]
        List of secondary context column names (order matters). If None, will use config["secondary_context_columns"] if provided.
    config_dict : Optional[dict]
        A config dictionary (e.g., loaded from config.yaml) containing "context_columns" and optionally "secondary_context_columns".
        Used to supply context columns if not provided directly.
    verbose : bool, optional
        If True, prints the context columns, raw values, and the final key.

    Returns
    -------
    str
        A unified, strictly normalized context key (e.g., "normal_high_adult").
    Raises
    ------
    ValueError
        If neither context_columns nor a config with 'context_columns' is provided.
    """
    all_cols = get_all_context_columns(config_dict, context_columns, secondary_columns)
    # Always use only the specified columns, in order
    raw_values = []
    for col in all_cols:
        # start with a default
        val = None
        if isinstance(context_dict, dict):
            val = context_dict.get(col, None)
        elif isinstance(context_dict, pd.Series):
            # Series.get is safe and returns default if not present
            val = context_dict.get(col, None)
        # normalize missing
        if val is None:
            val = "unknown"
        raw_values.append(val)
    if verbose:
        print(f"[make_context_key][columns]: {all_cols}")
        print(f"[make_context_key][before] values: {raw_values}")
    normalized_values = [normalize_context_value_ext(val) for val in raw_values]
    key = "_".join(str(v) for v in normalized_values)
    if verbose:
        print(f"[make_context_key][after] key: {key}")
        assert len(normalized_values) == len(all_cols), \
            f"Number of columns ({len(normalized_values)}) does not match context_columns ({len(all_cols)})"
    return key


def make_context_key_tuple(row: Union[pd.Series, dict], context_columns: List[str]) -> tuple:
    """Return a stable, tuple-based context key using the robust normalizer.
    This keeps compatibility with existing string-based keys while providing
    a hashable tuple form for groupby/merge operations.
    """
    get_val = (row.get if isinstance(row, dict) else (lambda c, d=None: row.get(c, d)))
    return tuple(normalize_context_value_ext(get_val(c, "unknown")) for c in context_columns)


def is_categorical_dtype(series: pd.Series) -> bool:
    return isinstance(getattr(series, "dtype", None), CategoricalDtype)

def downcast_context_categories(df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    """
    Downcast provided columns to 'category' dtype when possible.
    Safe no-op on missing/invalid columns.
    """
    for col_name in cols:
        if col_name in df.columns:
            try:
                if not is_categorical_dtype(df[col_name]):
                    df[col_name] = df[col_name].astype("category")
            except (TypeError, ValueError):
                # Keep original dtype if conversion fails
                pass
    return df

# --- Thin alias for backward-compatibility
def _downcast_context_cats(df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    """
    Backward-compatible alias to downcast context columns to 'category' dtype.
    """
    return downcast_context_categories(df, cols)

# =========================
# CF/CBF semantic alignment helpers
# Ensure family columns exist before any contextual re-ranking,
# and expose a unified medical recommendation selector.
# =========================
from typing import Dict as _Dict, Any as _Any

try:
    # Import core constants and planners from the canonical module
    from utils.constants import (
        CONTEXT_COLUMNS,
        BINNED_CONTEXT_COLUMNS,
        make_binned_key,
        normalize_label,
        get_medical_plan,
    )
except (ImportError, AttributeError) as _ex:  # pragma: no cover - keep runtime resilient if import paths are different
    # Re-raise so missing clinical mapping/symbols are surfaced early during development
    raise

def _coerce_str_no_space(x: _Any) -> str:
    """Normalize to string and strip spaces. Empty/NA -> 'unknown'."""
    if x is None:
        return "unknown"
    s = str(x).strip()
    return s if s else "unknown"



def ensure_feature_id_binned_and_context(
    df,
    feature_family_map: Optional[Dict[str, str]] = None,
    log=None,
    log_id: str = "CBF"
):
    """
    Ensure `feature_id_binned` and `context_feature_id` exist with strict normalization.
    - Fills missing core context columns with 'unknown' and normalizes them.
    - Builds `context_feature_id = f"{bp}|{chol}|{risk}"`.
    - Creates/normalizes `feature_id_binned` via simple keyword map (overridable by `feature_family_map`).
    Returns a COPY of the input DataFrame with guaranteed columns.
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"ensure_feature_id_binned_and_context expects a pandas DataFrame, got {type(df)}")

    out = df.copy()

    # 1) Guard & normalize the core triad
    for col in ("bp_category", "chol_category", "risk_level"):
        if col not in out.columns:
            out[col] = "unknown"
        out[col] = out[col].apply(normalize_context_value)

    # 2) Build context_feature_id as "bp|chol|risk"
    try:
        out["context_feature_id"] = out.apply(make_core_context_key, axis=1)
    except (TypeError, ValueError, KeyError, AttributeError):
        bp = out.get("bp_category", "unknown").astype(str)
        chol = out.get("chol_category", "unknown").astype(str)
        risk = out.get("risk_level", "unknown").astype(str)
        out["context_feature_id"] = (
            bp.map(normalize_context_value).astype(str) + "|"
            + chol.map(normalize_context_value).astype(str) + "|"
            + risk.map(normalize_context_value).astype(str)
        )

    # 2.5) Always canonicalize feature_id if present (even if binned exists)
    if "feature_id" in out.columns:
        out.loc[:, "feature_id"] = _safe_canonicalize_feature_id_series(out["feature_id"])

    # 3) Ensure/derive feature_id_binned (robust)
    fmap = feature_family_map or _DEF_FAMILY_MAP
    try:
        if "feature_id_binned" not in out.columns:
            if "feature_id" in out.columns:
                out.loc[:, "feature_id_binned"] = out["feature_id"].astype(str).apply(lambda x: _bin_feature_simple(x, fmap))
            else:
                out.loc[:, "feature_id_binned"] = "Other"
        else:
            # Normalize provided binned values; if empty/unknown -> recompute from canonical feature_id
            fb = out["feature_id_binned"].astype(str).str.strip()
            need_rebin = fb.isna() | fb.eq("") | fb.str.lower().isin({"unknown", "none", "nan", "any"})
            # Normalize existing
            out.loc[~need_rebin, "feature_id_binned"] = (
                out.loc[~need_rebin, "feature_id_binned"]
                  .astype(str)
                  .apply(normalize_context_value)
                  .replace({"any": "other"})
                  .str.title()
            )
            # Recompute where needed from canonical feature_id
            if "feature_id" in out.columns:
                out.loc[need_rebin, "feature_id_binned"] = out.loc[need_rebin, "feature_id"].astype(str).apply(lambda x: _bin_feature_simple(x, fmap))
            else:
                out.loc[need_rebin, "feature_id_binned"] = "Other"
    except (TypeError, ValueError, KeyError, AttributeError) as _exc_ctx_bin:
        # Non-fatal: fall back to a coarse default
        if "feature_id_binned" not in out.columns:
            out["feature_id_binned"] = "Other"
        else:
            try:
                out["feature_id_binned"] = out["feature_id_binned"].astype(str).fillna("Other")
            except (TypeError, ValueError, KeyError, AttributeError):
                out["feature_id_binned"] = "Other"

    # 4) Diagnostics (unique counts)
    if log is not None:
        try:
            n_ctx = int(out["context_feature_id"].nunique(dropna=True)) if "context_feature_id" in out.columns else 0
            n_fam = int(out["feature_id_binned"].nunique(dropna=True)) if "feature_id_binned" in out.columns else 0
            log.info(f"[{log_id}] [context_utils] uniques: context_feature_id={n_ctx}, feature_id_binned={n_fam}")
        except (TypeError, ValueError, KeyError, AttributeError):
            pass

    return out



# Lightweight helper to assert no many-to-many before merges
def assert_no_many_to_many(df_right, keys):
    """
    Raise ValueError if the right-hand frame has duplicate key combinations (violates many_to_one).
    Returns True when unique.
    """
    if not isinstance(df_right, pd.DataFrame):
        raise TypeError("df_right must be a pandas DataFrame")
    if isinstance(keys, (str,)):
        keys = [keys]
    keys = list(keys)
    if not all(k in df_right.columns for k in keys):
        missing = [k for k in keys if k not in df_right.columns]
        raise KeyError(f"Missing merge keys on RHS: {missing}")
    dups = df_right.duplicated(subset=keys, keep=False)
    if bool(getattr(dups, "any", lambda: False)()):
        raise ValueError(f"Right-hand keys not unique for {keys}: {int(dups.sum())} duplicate rows")
    return True


def select_medical_recommendation_from_row(row: "pd.Series", log=None) -> _Dict[str, _Any]:
    """
    Use the unified MEDICAL_RECOMMENDATION_PLAN → CONTEXT_TO_RECOMMENDATION_MAP → FEATURE_ID_BINNED_MAP → fallback pipeline
    to obtain a clinical recommendation dict (action/reason/explanation/source) from a row with context columns.
    """
    import pandas as _pd  # local import to avoid hard dependency at module import time
    if not isinstance(row, _pd.Series):
        raise TypeError("select_medical_recommendation_from_row expects a pandas Series")

    # Read context with safe defaults
    bp_cat = normalize_label(row.get("bp_category", "unknown"))
    chol_cat = normalize_label(row.get("chol_category", "unknown"))
    risk_level = normalize_label(row.get("risk_level", "unknown"))
    fbs_cat = normalize_label(row.get("fbs_cat", "any"))
    cp_cat = normalize_label(row.get("cp_cat", "any"))

    rec = get_medical_plan(bp_cat, chol_cat, risk_level, fbs_cat=fbs_cat, cp_cat=cp_cat, log=log, input_context=None)
    # `rec` is already a dict with action, reason, explanation, source per constants.plan_as_dict/get_clinical_plan_fields
    return rec

def _selftest_context_utils():  # pragma: no cover - quick smoke tests
    # 1) Stability: same row, pre/post normalization using make_context_key (underscore-joined)
    row = pd.Series({
        "bp_category": " High ",
        "chol_category": "Normal",
        "risk_level": "MEDIUM",
        "fbs_cat": None,
        "cp_cat": float('nan'),
    })
    cols_primary = ["bp_category", "chol_category", "risk_level"]
    cols_secondary = ["fbs_cat", "cp_cat"]

    key1 = make_context_key(row, context_columns=cols_primary, secondary_columns=cols_secondary)
    # Re-run after applying normalizer column-wise
    row2 = row.copy()
    for c in cols_primary + cols_secondary:
        row2[c] = normalize_context_value_ext(row2.get(c, None))
    key2 = make_context_key(row2, context_columns=cols_primary, secondary_columns=cols_secondary)
    assert key1 == key2, f"Context key unstable: {key1} vs {key2}"
    assert isinstance(key1, str) and key1.count("_") >= (len(cols_primary) - 1), "Underscore-joined key expected"

    # 2) Core key consistency (pipe join 'bp|chol|risk')
    df = pd.DataFrame([row])
    core_ser = df.apply(make_core_context_key, axis=1)
    assert isinstance(core_ser, pd.Series) and core_ser.shape[0] == 1
    assert "|" in core_ser.iloc[0], "Core key should be pipe-joined as 'bp|chol|risk'"

    # 3) Missing columns handled
    row_missing = pd.Series({"bp_category": "high"})
    key_missing = make_context_key(row_missing, context_columns=cols_primary)
    assert key_missing.count("_") == (len(cols_primary) - 1), "Missing columns not filled/normalized correctly"

    # 4) Type mixing & whitespace
    row_mix = pd.Series({"bp_category": 120, "chol_category": "  HIGH-CHO L  ", "risk_level": None})
    key_mix = make_context_key(row_mix, context_columns=cols_primary)
    assert isinstance(key_mix, str) and len(key_mix) > 0

# Optionally run when module is executed directly
if __name__ == "__main__":  # pragma: no cover
    _selftest_context_utils()

__all__ = [
    "get_all_context_columns",
    "normalize_context_value",
    "normalize_context_value_basic",
    "normalize_context_value_ext",
    "make_context_key",
    "make_context_key_tuple",
    "is_categorical_dtype",
    "make_core_context_key",
    "downcast_context_categories",
    "_downcast_context_cats",
    "_safe_canonicalize_feature_id_series",
    "ensure_feature_id_binned_and_context",
    "select_medical_recommendation_from_row",
    "assert_no_many_to_many",
    "filter_candidates_by_clinical_gating",
    "sanitize_feature_id",
    "generate_plan_additions",
]
