from pathlib import Path
import os
from .logging_utils import setup_logger
import yaml

GLOBAL_CONFIG = None  # Global configuration variable shared across modules

SCHEMA_ALIAS_MAP = {
    "hypertension_data": "hypertension.yaml",
    "raw": "raw.yaml",
    "post_cleaning": "post-cleaning.yaml",
    "post_encoding": "post-encoding.yaml"
}

# Store config-defined schema aliases
CONFIG_SCHEMAS = {}

config_logger = setup_logger("config_logger", "logs/config.log")

def get_config(path: str = None, log_id: str = None) -> dict:
    """
    load the YAML configuration file for the project safely and consistently, with structured logging and schema registration.

    Parameters:
        path (str): Optional path to config.yaml. defaults to /pipeline/config.yaml if None.
        log_id (str): Optional unique identifier for logging. if None, a random ID is generated.

    Returns:
        dict: Parsed configuration dictionary.

    Raises:
        FileNotFoundError: If the configuration file does not exist.
        KeyError: If required keys are missing in the configuration.
        yaml.YAMLError, OSError, ValueError: If there is an error reading, parsing, or the config is empty.
    """
    if log_id is None:
        import uuid
        log_id = uuid.uuid4().hex[:8]
    config_logger.info(f"[{log_id}] 🛡️ [Config] Starting configuration loading process...")
    if path is None:
        root_path = Path(__file__).resolve().parents[1]
        path = root_path / "pipeline" / "config.yaml"
    config_logger.info(f"[{log_id}] [Config Debug] Final resolved config path: {path}")

    if not os.path.exists(path):
        config_logger.error(f"[{log_id}] ❌ [Config] Configuration file not found at path: {path}")
        raise FileNotFoundError(f"Configuration file not found: {path}")

    config_logger.info(f"[{log_id}] 📄 [Config] Attempting to open config file: {path}")
    try:
        config_logger.info(f"[{log_id}] [Config Load] Parsing YAML configuration...")
        with open(path, "r") as file:
            config = yaml.safe_load(file)
            if not isinstance(config, dict) or not config:
                config_logger.error(f"[{log_id}] ❌ [Config] Loaded config is empty or invalid at path: {path}")
                raise ValueError(f"Loaded config is empty or invalid: {path}")
            # Check for model_settings.cbf.include_context
            if "model_settings" not in config or "cbf" not in config["model_settings"]:
                config_logger.warning(f"[{log_id}] ⚠️ [Config] 'model_settings.cbf' block not found in config file.")
            elif "include_context" not in config["model_settings"]["cbf"]:
                config_logger.warning(f"[{log_id}] ⚠️ [Config] 'include_context' not defined under 'model_settings.cbf' block.")
            else:
                config_logger.info(f"[{log_id}] ✅ [Config] 'include_context' is set to: {config['model_settings']['cbf']['include_context']}")
    except (yaml.YAMLError, OSError) as e:
        config_logger.error(f"[{log_id}] ❌ [Config] YAML parsing or file reading error.")
        config_logger.error(f"[{log_id}] ❌ [Config] Failed to open or parse the configuration file: {e}")
        raise

    required_keys = ["target_column"]
    missing_keys = [key for key in required_keys if key not in config]
    if missing_keys:
        config_logger.error(f"[{log_id}] ❌ [Config] Missing required keys in config file: {missing_keys}")
        raise KeyError(f"Missing keys in config: {missing_keys}")

    if "schemas" in config:
        # Adjust hypertension_data schema to use post-feature-engineering.yaml as per instructions
        config["schemas"]["hypertension_data"] = "post-feature-engineering.yaml"
        global CONFIG_SCHEMAS
        CONFIG_SCHEMAS = config.get("schemas", {})

    schema_path = Path("schemas/post-feature-engineering.yaml")
    if not schema_path.exists():
        config_logger.warning(f"[{log_id}] ⚠️ Schema file 'post-feature-engineering.yaml' not found. Default fallback may fail.")

    if "target_column" in config:
        config_logger.info(f"[{log_id}] ✅ [Config] Configuration loaded successfully. Target column: {config['target_column']}")
    if "final_columns_after_encoding" in config:
        config_logger.info(f"[{log_id}] ✅ [Config] final_columns_after_encoding loaded with {len(config['final_columns_after_encoding'])} columns.")
    global GLOBAL_CONFIG
    GLOBAL_CONFIG = config
    return config

def load_config(path: str = None, log_id: str = None) -> dict:
    """
    Wrapper for get_config providing linear control flow and caching.

    Parameters:
        path (str): Optional path to config.yaml.
        log_id (str): Optional unique identifier for logging.

    Returns:
        dict: Cached or freshly loaded configuration dictionary.
    """
    global GLOBAL_CONFIG

    # Fast-path: return if a valid dict is cached
    if isinstance(GLOBAL_CONFIG, dict):
        return GLOBAL_CONFIG

    # Cold or invalid cache path: (re)load and cache
    cfg = get_config(path, log_id=log_id)
    GLOBAL_CONFIG = cfg
    return cfg

def self_test():
    try:
        config = load_global_config(log_id="selftest")
        config_logger.info(f"✅ [Config] Self-test passed. Loaded config keys: {list(config.keys())}")
        for key, schema_path in config.get("schemas", {}).items():
            if not isinstance(schema_path, str):
                config_logger.error(f"❌ [Schema] Invalid schema path type for key '{key}': expected string, got {type(schema_path)}")
                continue
            columns = load_schema(schema_path)
            config_logger.info(f"✅ [Schema] Schema '{key}' loaded successfully with columns: {columns}")
            config_logger.info(f"✅ [Schema] {key} → columns: {columns}")
    except Exception as e:
        config_logger.error(f"❌ [Config] Self-test failed: {e}")

import logging

logger = logging.getLogger(__name__)

def load_schema(schema_key: str):
    """
    Load a YAML schema file from the schemas directory. If a full path is not provided,
    it will attempt to locate the file within the /schemas directory.

    Args:
        schema_key (str): The filename of the YAML schema (with or without path or extension).

    Returns:
        dict: The parsed YAML content.

    Raises:
        ValueError: If the schema is invalid or missing required structure.
        FileNotFoundError: If the schema file does not exist.
    """
    if isinstance(schema_key, dict):
        raise ValueError(f"Invalid schema path type: expected string, got dict")
    if isinstance(schema_key, list):
        raise ValueError(f"Invalid schema path type: expected string, got list")

    logger.info(f"[Schema Loader] Requested schema key: {schema_key}")
    if any(x in str(schema_key).lower() for x in ["sample", "test", "tests/"]):
        logger.warning(f"[Schema Loader] ⚠️ Detected schema key from test environment: {schema_key}")

    # Use config-defined schemas from GLOBAL_CONFIG if available
    config_schemas = {}
    if isinstance(GLOBAL_CONFIG, dict) and "schemas" in GLOBAL_CONFIG:
        config_schemas = GLOBAL_CONFIG["schemas"]
    schema_alias_map = {**SCHEMA_ALIAS_MAP, **config_schemas}

    if schema_key in schema_alias_map:
        schema_key = schema_alias_map[schema_key]

    schema_path = Path(schema_key)
    if not schema_path.is_absolute():
        if not schema_path.suffix:
            schema_path = Path("schemas") / f"{schema_path}.yaml"
        else:
            schema_path = Path("schemas") / schema_path.name

    logger.info(f"[Schema Loader] Resolved schema path: {schema_path}")

    if not schema_path.exists():
        raise FileNotFoundError(f"[Schema Loader] Schema file not found: {schema_path}")

    with open(schema_path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)

    if not data:
        logger.error(f"[Schema Load Error] Empty or missing schema data: {data}")
        raise ValueError(f"[Schema Load Error] Empty or missing schema: {schema_path}")

    if "columns" in data:
        if isinstance(data["columns"], list):
            if all(isinstance(col, dict) for col in data["columns"]):
                column_names = [col["name"] for col in data["columns"] if isinstance(col, dict) and "name" in col]
                data["columns"] = column_names
            elif all(isinstance(col, str) for col in data["columns"]):
                pass
            else:
                logger.error(f"[Schema Load Error] Invalid 'columns' format: {data}")
                raise ValueError(f"[Schema Load Error] 'columns' must be a list of strings or dicts in schema: {schema_path}")
    elif "expected_columns" in data:
        if isinstance(data["expected_columns"], dict):
            if not all(isinstance(k, str) for k in data["expected_columns"].keys()):
                raise ValueError("Invalid keys in expected_columns: keys must be strings.")
            column_names = list(map(str, data["expected_columns"].keys()))
            data["columns"] = column_names
            data["expected_columns_raw"] = data["expected_columns"]  # preserve full structure
            logger.warning(f"[Schema Normalization] Converted 'expected_columns' to 'columns' and preserved full schema as 'expected_columns_raw'. Source: {schema_path}")
        else:
            logger.error(f"[Schema Load Error] 'expected_columns' must be a dictionary: {data}")
            raise ValueError(f"[Schema Load Error] 'expected_columns' must be a dictionary in schema: {schema_path}")
    else:
        logger.error(f"[Schema Load Error] Missing both 'columns' and 'expected_columns': {data}")
        raise ValueError(f"[Schema Load Error] Schema must contain either 'columns' or 'expected_columns': {schema_path}")

    logger.info(f"[Schema Loader] Schema loaded successfully from: {schema_path}")
    logger.debug(f"[Schema Loader] Loaded schema keys: {list(data.keys())}")
    # Optional: Validate schema columns using non-contextual schema validator, with recursion prevention
    try:
        import inspect
        from utils.validation import validate_noncontextual_schema
        import pandas as pd
        call_stack = [frame.function for frame in inspect.stack()]
        recursion_blocks = {"load_schema", "validate_loaded_dataset", "validate_noncontextual_schema"}
        if any(func in call_stack for func in recursion_blocks):
            logger.warning("[Schema Loader] ⚠️ Skipping internal validation to prevent recursive loop.")
            return data["columns"]

        contextual_cols = {"bp_category", "chol_category", "risk_level", "age_group", "chol_flag", "target_copy"}
        noncontextual_cols = [col for col in data["columns"] if col not in contextual_cols]
        dummy_df = pd.DataFrame(columns=noncontextual_cols)

        if isinstance(schema_path, Path):
            schema_path = str(schema_path)

        validate_noncontextual_schema(dummy_df, schema_path_or_dict=schema_path, dataset_name="config_loader_schema_check")
    except Exception as e:
        logger.warning(f"[Schema Validator] ⚠️ Non-contextual schema validation failed: {e}")
    return data["columns"]
def load_global_config(log_id: str = None):
    """
    Public method to load and expose GLOBAL_CONFIG explicitly.
    This can be called in any module to ensure configuration is ready.

    Args:
        log_id (str): Optional unique identifier for logging. If None, a random ID is generated.

    Returns:
        dict: The loaded global configuration.
    """
    global GLOBAL_CONFIG
    if GLOBAL_CONFIG is None:
        GLOBAL_CONFIG = get_config(log_id=log_id)
    return GLOBAL_CONFIG