import logging
import pandas as pd
from typing import Optional, Sequence
from utils.config_loader import load_global_config
import inspect
config = load_global_config()

def is_recursion_context() -> bool:
    recursion_blocks = {"load_schema", "validate_loaded_dataset", "validate_noncontextual_schema"}
    for frame in inspect.stack()[1:]:
        if any(block in frame.function for block in recursion_blocks):
            return True
    return False

logger = logging.getLogger(__name__)

def audit_columns(df: object, stage: str = "Unnamed Stage", clinical_required: Optional[Sequence[str]] = None, log_id: Optional[str] = None) -> None:
    if clinical_required is None:
        clinical_required = config.get("clinical_required_columns", [])
    """
    Perform a structural audit of DataFrame columns with optional clinical schema validation.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to inspect.
    stage : str, optional
        Descriptive label for the pipeline stage being audited.
    clinical_required : list of str, optional
        List of required clinical columns expected in the DataFrame.
    """
    if log_id is None:
        import uuid
        log_id = uuid.uuid4().hex[:8]

    if is_recursion_context():
        logger.warning(f"[{log_id}] ⚠️ Column audit skipped to prevent recursion loop.")
        print("⚠️ Column audit skipped to avoid recursive schema validation.")
        return

    if not isinstance(df, pd.DataFrame):
        logger.error(f"[{log_id}] [Column Audit ❌] Provided object is not a DataFrame at stage: {stage}")
        print(f"❌ Column Audit Failed — Non-DataFrame object at {stage}")
        return

    if clinical_required:
        missing_clinical = [col for col in clinical_required if col not in df.columns]
        if missing_clinical:
            logger.error(f"[{log_id}] 🩺 [Clinical Audit ❌] Missing essential clinical columns at stage '{stage}': {missing_clinical}")
            print(f"❌ Missing Clinical Columns: {missing_clinical}")
        else:
            logger.info(f"[{log_id}] ✅ [Clinical Audit] All required clinical columns present at stage '{stage}'.")

    column_list = df.columns.tolist()
    logger.warning(f"[{log_id}] [🔎 Column Audit] Stage: {stage} — Columns: {column_list}")
    print(f"\n🧾 [Column Audit Report] — Stage: {stage}")
    print(f"📊 Total Columns: {len(column_list)}")
    print(f"🧬 Column Names: {column_list}")