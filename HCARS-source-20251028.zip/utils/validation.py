def parse_schema_object(schema_path_or_dict, dataset_name: str):
    if isinstance(schema_path_or_dict, (dict, list)):
        return schema_path_or_dict
    elif isinstance(schema_path_or_dict, str):
        return load_schema(schema_path_or_dict)
    else:
        pipeline_logger.error(f"[{log_id}] [{dataset_name}] ❌ Invalid schema format: expected string, dict, or list. Got {type(schema_path_or_dict)}")
        raise SystemExit(f"[{dataset_name}] CRITICAL ERROR: Invalid schema format: {type(schema_path_or_dict)}")
# validation.py - نسخة مخصصة للفحص الطبي الدقيق وتسجيل العمليات الحرجة
# هذا المِلف مجهز لفحص طبي دقيق للبيانات مع تسجيل شامل لكل التغيرات الحرجة في الأعمدة والبيانات.

import pandas as pd
from collections.abc import Iterable
from .config_loader import load_schema
from .logging_utils import setup_logger
import uuid
log_id = uuid.uuid4().hex[:8]
from .sklearn_version_utils import validate_sklearn_for_contextual_pipeline
# --- Load global config at module level ---
from utils.config_loader import load_global_config
GLOBAL_CONFIG = load_global_config()

# --- YAML uniform list length validator ---
import yaml

def validate_dataset_lengths(yaml_file_path: str):
    """
    Ensure all lists in test_data of a YAML file are of the same length.
    """
    with open(yaml_file_path, 'r', encoding='utf-8') as file:
        data = yaml.safe_load(file)

    if "test_data" not in data:
        raise ValueError(f"❌ YAML file does not contain 'test_data' key: {yaml_file_path}")

    test_data = data["test_data"]
    lengths = {key: len(values) for key, values in test_data.items() if isinstance(values, list)}

    unique_lengths = set(lengths.values())
    if len(unique_lengths) > 1:
        raise ValueError(
            f"❌ Inconsistent list lengths in test_data of {yaml_file_path}. "
            f"Detected lengths: {lengths}"
        )
    else:
        print(f"✅ All test_data lists have uniform length: {unique_lengths.pop()} in {yaml_file_path}")

pipeline_logger = setup_logger("pipeline_logger", "logs/pipeline.log")
data_quality_logger = setup_logger("data_quality_logger", "logs/data_quality.log")
validate_sklearn_for_contextual_pipeline()



def backup_protected_columns(df: pd.DataFrame, protected_columns: list) -> pd.DataFrame:
    backup_df = df[protected_columns].copy()
    return backup_df

class ClinicalValidator:
    @staticmethod
    def ensure_no_nans(df: pd.DataFrame, context: str = ""):
        if df.isnull().values.any():
            raise ValueError(f"❌ Detected NaN values in {context}. Modeling requires complete data.")

    @staticmethod
    def validate_required_columns(df: pd.DataFrame, required_columns, context: str = ""):
        # Normalize required_columns into a concrete list to avoid 'unreachable code' static warnings
        def _to_list(cols):
            """
            Normalize `required_columns` into a concrete list with linear control-flow,
            avoiding multiple early returns that can confuse static analyzers.
            Accepts: list/tuple/set/str, pandas Index / numpy arrays (via .tolist()), and generic Iterables.
            """
            # Common simple cases
            if isinstance(cols, (list, tuple, set)):
                return list(cols)
            if isinstance(cols, str):
                return [cols]

            # Try pandas/NumPy style `.tolist()`
            tolist_method = getattr(cols, "tolist", None)
            candidate = None
            if callable(tolist_method):
                try:
                    candidate = tolist_method()
                except (TypeError, ValueError) as e:
                    pipeline_logger.warning(f"[{log_id}] [{context}] ⚠️ Failed to convert via tolist(): {e}")
                    candidate = cols
            else:
                candidate = cols

            # Normalize the candidate into a list with a single return at the end
            result = None
            if isinstance(candidate, list):
                result = candidate
            elif isinstance(candidate, (str, bytes)):
                result = [candidate]
            elif isinstance(candidate, Iterable):
                try:
                    result = list(candidate)
                except (TypeError, ValueError) as iter_err:
                    pipeline_logger.warning(f"[{log_id}] [{context}] ⚠️ Failed to list() iterable candidate: {iter_err}")
                    result = [candidate]
            else:
                result = [candidate]

            return result

        required_columns = _to_list(required_columns)
        data_quality_logger.info(f"[{log_id}] [Validation Check] 🔍 Validating required columns: {required_columns}")
        data_quality_logger.info(f"[{log_id}] [Clinical Context] 🩺 التحقق من الأعمدة السريرية الإلزامية في السياق: {context}")
        # removed unused protected variable
        missing = [col for col in required_columns if col not in df.columns]
        if missing:
            # Trace logging before raising error
            data_quality_logger.debug(f"[{log_id}] [Trace] Current DataFrame columns: {df.columns.tolist()}")
            data_quality_logger.debug(f"[{log_id}] [Trace] Required columns: {required_columns}")
            data_quality_logger.debug(f"[{log_id}] [Trace] Missing columns: {missing}")
            pipeline_logger.critical(f"[{log_id}] [Validation Check] ⛔ Pipeline halted due to missing required columns: {missing}")
            raise ValueError(f"[{context}] CRITICAL ERROR: Required columns missing: {missing}")
        data_quality_logger.info(f"[{log_id}] [Validation Check] ✅ Completed validate_required_columns function successfully.")

    @staticmethod
    def validate_schema(df: pd.DataFrame, schema, dataset_name: str = "") -> None:
        from utils.column_audit import is_recursion_context
        if is_recursion_context():
            data_quality_logger.warning(f"[{log_id}] [{dataset_name}] ⚠️ Skipping validate_schema due to recursive context.")
            print(f"⚠️ Skipping schema validation for {dataset_name} to prevent recursion.")
            return
        data_quality_logger.info(f"[{log_id}] [Validation Check] 🔍 Starting schema validation...")
        # Flexible schema parsing logic
        if isinstance(schema, dict):
            if "expected_columns" in schema and isinstance(schema["expected_columns"], list):
                schema = schema["expected_columns"]
            elif "expected_columns_raw" in schema and isinstance(schema["expected_columns_raw"], dict):
                schema = list(schema["expected_columns_raw"].keys())
            elif "columns" in schema:
                cols = schema["columns"]
                if isinstance(cols, list):
                    if all(isinstance(col, dict) and "name" in col for col in cols):
                        schema = [col["name"] for col in cols]
                    elif all(isinstance(col, str) for col in cols):
                        schema = cols
                    else:
                        invalid_items = [col for col in cols if not (isinstance(col, dict) and "name" in col) and not isinstance(col, str)]
                        pipeline_logger.critical(f"[{log_id}] [{dataset_name}] ❌ Invalid column definitions found in schema: {invalid_items}")

                        raise SystemExit(f"[{dataset_name}] CRITICAL ERROR: Invalid format in 'columns'. Must be list of dicts with 'name' or list of strings.")
                else:
                    raise SystemExit(f"[{dataset_name}] CRITICAL ERROR: 'columns' must be a list.")
            else:
                raise SystemExit(f"[{dataset_name}] CRITICAL ERROR: Schema must contain either 'expected_columns', 'expected_columns_raw', or 'columns'.")
        elif isinstance(schema, list):
            pass  # schema is already a list of expected column names
        else:
            pipeline_logger.error(f"[{log_id}] [{dataset_name}] ❌ Schema format unrecognized.")
            raise SystemExit(f"[{dataset_name}] CRITICAL ERROR: Unrecognized schema format.")

        # Normalize DataFrame columns by removing known prefixes before schema comparison
        df_columns_normalized = set()
        schema = set(schema)
        for col in df.columns:
            col_clean = col
            for prefix in ["remainder__", "multi__", "binary__", "num__"]:
                if col_clean.startswith(prefix):
                    col_clean = col_clean[len(prefix):]
            df_columns_normalized.add(col_clean)
        missing_cols = schema - df_columns_normalized
        extra_cols = df_columns_normalized - schema

        if extra_cols:
            data_quality_logger.warning(f"[{log_id}] [Validation Check] ⚠️ [SCHEMA VALIDATION] Extra columns in {dataset_name}: {extra_cols}")
        if missing_cols:
            # Trace logging before raising SystemExit
            data_quality_logger.debug(f"[{log_id}] [Trace] Available columns: {df.columns.tolist()}")
            data_quality_logger.debug(f"[{log_id}] [Trace] Expected schema: {list(schema)}")
            data_quality_logger.debug(f"[{log_id}] [Trace] Missing columns detail: {missing_cols}")
            pipeline_logger.critical(f"[{log_id}] [Validation Check] ⛔ Missing expected schema columns. Terminating pipeline.")
            pipeline_logger.critical(f"[{log_id}] [{dataset_name}] CRITICAL ERROR: Missing schema columns: {missing_cols}")
            pipeline_logger.critical(f"[{log_id}] [{dataset_name}] CRITICAL ERROR: Missing schema columns: {', '.join(sorted(missing_cols))}")
            print(f"❌ Terminal Notice — Missing schema columns: {', '.join(sorted(missing_cols))}")
            raise SystemExit(f"[{dataset_name}] CRITICAL ERROR: Missing schema columns: {', '.join(sorted(missing_cols))}")

        data_quality_logger.info(f"[{log_id}] [Validation Check] ✅ Schema validation completed.")
        data_quality_logger.info(f"[{log_id}] [Validation Check] ✅ Completed validate_schema function successfully.")


    @staticmethod
    def apply_risk_score(df: pd.DataFrame) -> pd.DataFrame:
        from .hcars_utils import HCARSUtils
        return HCARSUtils.apply_risk_score(df)

    @staticmethod
    def ensure_target_integrity(df: pd.DataFrame, backup_df: pd.DataFrame = None) -> pd.DataFrame:
        from . import safe_copy
        df = safe_copy(df)
        # df_before_restore = df.copy()  # <-- Removed as per instruction
        try:
            data_quality_logger.info(f"[{log_id}] [Validation Check] 🔍 Starting target integrity check...")
            if "target" not in df.columns:
                if backup_df is not None and "target" in backup_df.columns:
                    df["target"] = backup_df["target"]
                    data_quality_logger.warning(f"[{log_id}] [Fallback] ⚠️ Restored 'target' from backup_df.")
                elif backup_df is not None and "target_backup" in backup_df.columns:
                    df["target"] = backup_df["target_backup"]
                    data_quality_logger.warning(f"[{log_id}] [Fallback] ⚠️ Restored 'target' from target_backup in backup_df.")
                elif "target_copy" in df.columns:
                    df["target"] = df["target_copy"]
                    data_quality_logger.warning(f"[{log_id}] [Fallback] ⚠️ Restored 'target' from target_copy.")
                else:
                    df["target"] = pd.NA
                    pipeline_logger.critical(f"[{log_id}] [Validation Check] ⛔ 'target' column missing and could not be restored. Pipeline will halt.")
                    raise SystemExit("CRITICAL ERROR: 'target' column irrecoverable.")
            data_quality_logger.info(f"[{log_id}] [Validation Check] ✅ Completed ensure_target_integrity function successfully.")
            return df
        except Exception as e:
            pipeline_logger.error(f"[{log_id}] [Validation Check] ❌ Error during target integrity check: {e}")
            return df


    @staticmethod
    def enforce_column_order(df: pd.DataFrame, column_order: list) -> pd.DataFrame:
        ordered = [col for col in column_order if col in df.columns]
        others = [col for col in df.columns if col not in ordered]
        return df[ordered + others]

    @staticmethod
    def validate_feature_ranges(df: pd.DataFrame, feature_ranges: dict, context: str = "") -> None:
        """
        (ClinicalValidator) التحقق من مطابقة قيم الميزات للنطاقات السريرية المتوقعة.
        """
        for feature, (min_val, max_val) in feature_ranges.items():
            if feature not in df.columns:
                data_quality_logger.warning(f"[{log_id}] [{context}] ⚠️ Feature '{feature}' not found for range validation.")
                continue
            if df[feature].dropna().between(min_val, max_val).all():
                continue
            outliers = df[~df[feature].between(min_val, max_val)]
            if not outliers.empty:
                data_quality_logger.warning(
                    f"[{log_id}] [{context}] ⚠️ Feature '{feature}' contains out-of-range values. "
                    f"Expected: [{min_val}, {max_val}], Detected: {outliers[feature].tolist()}"
                )
                raise ValueError(f"[{context}] Feature '{feature}' out of range.")

    @staticmethod
    def categorize_extra_columns(df: pd.DataFrame, schema: list) -> dict:
        """
        (ClinicalValidator) تصنيف الأعمدة الزائدة إلى فئات: مشتقة، مخاطر، غير معروفة.
        """
        extra_cols = set(df.columns) - set(schema)
        categories = {"risk_related": set(), "derived": set(), "unknown": set()}
        for col in extra_cols:
            col_lower = col.lower()
            if 'risk' in col_lower:
                categories["risk_related"].add(col)
            elif "flag" in col_lower:
                categories.setdefault("flags", set()).add(col)
            elif any(keyword in col_lower for keyword in ['diff', 'score', 'derived']):
                categories["derived"].add(col)
            else:
                categories["unknown"].add(col)
        return categories

    @staticmethod
    def check_column_consistency(before_df: pd.DataFrame, after_df: pd.DataFrame, stage: str = "", strict: bool = True):
        before_cols = set(before_df.columns)
        after_cols = set(after_df.columns)
        missing = before_cols - after_cols
        extra = after_cols - before_cols

        data_quality_logger.debug(f"[{log_id}] [{stage}] Column consistency check:")
        data_quality_logger.debug(f"[{log_id}]     Before: {sorted(before_cols)}")
        data_quality_logger.debug(f"[{log_id}]     After: {sorted(after_cols)}")
        data_quality_logger.debug(f"[{log_id}]     Missing: {sorted(missing)}")
        data_quality_logger.debug(f"[{log_id}]     Extra: {sorted(extra)}")

        if strict and missing:
            pipeline_logger.critical(f"[{log_id}] [{stage}] ❌ Strict mode: missing columns after processing: {sorted(missing)}")
            raise ValueError(f"[{stage}] Critical: missing columns after transformation: {sorted(missing)}")

        return {"missing": sorted(missing), "extra": sorted(extra)}

def validate_loaded_dataset(df: pd.DataFrame, schema_path_or_dict, dataset_name: str, allow_missing_contextual: bool = False):
    from utils.safe_copy import safe_copy
    df = safe_copy(df)
    # Log columns after safe_copy
    pipeline_logger.debug(f"[{log_id}] [{dataset_name}] Columns after safe_copy: {df.columns.tolist()}")

    if dataset_name == "hypertension_data":
        data_quality_logger.info(f"[{log_id}] [{dataset_name}] ⏩ Skipping early schema validation as per hypertension_data rule.")
        return df  # skip early schema validation

    schema = parse_schema_object(schema_path_or_dict, dataset_name)

    # Check contextual columns after safe_copy, before schema validation
    contextual_columns = ["bp_category", "chol_category", "risk_level", "age_group"]
    for col in contextual_columns:
        if col not in df.columns:
            pipeline_logger.warning(f"[{log_id}] [{dataset_name}] ⚠️ Contextual column missing after safe_copy: {col}")

    if isinstance(schema, list):
        missing_contextual = [col for col in contextual_columns if col not in df.columns]
        if missing_contextual:
            if allow_missing_contextual:
                pipeline_logger.warning(f"[{log_id}] [{dataset_name}] ⚠️ Contextual features missing (allowed temporarily): {missing_contextual}")
            else:
                pipeline_logger.critical(f"[{log_id}] [{dataset_name}] ❌ CRITICAL: Missing contextual features before schema validation: {missing_contextual}")
                print(f"❌ Terminal Notice — Missing contextual columns: {', '.join(missing_contextual)}")
                raise SystemExit(f"[{dataset_name}] CRITICAL ERROR: Required contextual features are missing: {', '.join(missing_contextual)}")

    ClinicalValidator.validate_schema(df, schema, dataset_name)
    data_quality_logger.info(f"[{log_id}] [Validation Check] ✅ Completed validate_loaded_dataset for '{dataset_name}' successfully.")
    return df


# --- General-purpose schema validation ---
def validate_noncontextual_schema(df: pd.DataFrame, schema_path_or_dict, dataset_name: str):
    """
    ✅ General-purpose schema validation without enforcing contextual feature presence.
    Used in preprocessing stages to ensure schema integrity after operations like cleaning, encoding, imputation, and integration.
    """
    from utils.safe_copy import safe_copy_for_preprocessing
    df = safe_copy_for_preprocessing(df)
    pipeline_logger.debug(f"[{log_id}] [{dataset_name}] Columns after safe_copy: {df.columns.tolist()}")

    if dataset_name == "hypertension_data":
        data_quality_logger.info(f"[{log_id}] [{dataset_name}] ⏩ Skipping early schema validation as per hypertension_data rule.")
        return df

    schema = parse_schema_object(schema_path_or_dict, dataset_name)

    # Exclude contextual columns from validation if not present
    contextual_columns = {"bp_category", "chol_category", "risk_level", "age_group", "chol_flag", "target_copy"}
    if isinstance(schema, dict) and "columns" in schema:
        schema["columns"] = [
            col for col in schema["columns"]
            if (isinstance(col, dict) and col.get("name") not in contextual_columns)
            or (isinstance(col, str) and col not in contextual_columns)
        ]

    ClinicalValidator.validate_schema(df, schema, dataset_name)
    data_quality_logger.info(f"[{log_id}] [Validation Check] ✅ Completed validate_noncontextual_schema for '{dataset_name}' successfully.")
    return df



def validate_schema(df: pd.DataFrame, schema, dataset_name: str = ""):
    if isinstance(schema, str):
        schema_loaded = load_schema(schema)
        return ClinicalValidator.validate_schema(df, schema_loaded, dataset_name)
    else:
        return ClinicalValidator.validate_schema(df, schema, dataset_name)

def validate_required_columns(df: pd.DataFrame, required_columns: list, context: str = ""):
    return ClinicalValidator.validate_required_columns(df, required_columns, context)

def ensure_no_nans(df: pd.DataFrame, context: str = ""):
    return ClinicalValidator.ensure_no_nans(df, context)

def apply_risk_score(df: pd.DataFrame) -> pd.DataFrame:
    return ClinicalValidator.apply_risk_score(df)

def ensure_target_integrity(df: pd.DataFrame, backup_df: pd.DataFrame = None) -> pd.DataFrame:
    return ClinicalValidator.ensure_target_integrity(df, backup_df)

# --- Strict type-safe validate_data function ---
def validate_data(df, schema_path):
    if isinstance(schema_path, dict) or isinstance(schema_path, list):
        # Already loaded schema object (dict or list), pass directly
        validate_schema(df, schema_path)
    elif isinstance(schema_path, str):
        schema = load_schema(schema_path)
        validate_schema(df, schema)
    else:
        raise TypeError(f"schema_path must be a string, dict, or list; got {type(schema_path)} instead.")


# --- Feature Engineering Validator for strict clinical compliance ---
class FeatureEngineeringValidator:
    @staticmethod
    def check_column_consistency(before_df: pd.DataFrame, after_df: pd.DataFrame, stage: str = "", strict: bool = True):
        return ClinicalValidator.check_column_consistency(before_df, after_df, stage, strict)

    @staticmethod
    def check_global_validation_config():
        validation_config = GLOBAL_CONFIG.get("validation", {})
        if not validation_config:
            raise ValueError("❌ GLOBAL_CONFIG is missing 'validation' section.")
        pipeline_logger.info(f"[{log_id}] ✅ Loaded validation config: {validation_config}")
        return validation_config



# Proxy function for column consistency check, re-added at end of file
def check_column_consistency(before_df: pd.DataFrame, after_df: pd.DataFrame, stage: str = "", strict: bool = True):
    return ClinicalValidator.check_column_consistency(before_df, after_df, stage, strict)


# --- Model evaluation function using validation set ---
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

def evaluate_with_validation(model, df, y_val=None):
    if df is None:
        raise ValueError("❌ Must provide a DataFrame to evaluate.")

    if "target" not in df.columns:
        raise ValueError("❌ 'target' column missing in input DataFrame.")

    x = df.drop(columns=["target"])
    y = df["target"]

    # تقسيم البيانات
    x_train, x_temp, y_train, y_temp = train_test_split(x, y, test_size=0.3, random_state=42)
    x_val, x_test, y_val_split, y_test = train_test_split(x_temp, y_temp, test_size=0.5, random_state=42)

    # If y_val is None, use y_val_split
    if y_val is None:
        y_val = y_val_split

    if y_val is None:
        pipeline_logger.warning(f"[{log_id}] ⚠️ y_val غير متوفرة — سيتم تجاوز تقييم مجموعة التحقق.")
        return {"train_accuracy": None, "val_accuracy": None, "test_accuracy": None}

    # تدريب النموذج
    model.fit(x_train, y_train)

    # التقييم
    train_preds = model.predict(x_train)
    test_preds = model.predict(x_test)

    train_acc = accuracy_score(y_train, train_preds)
    test_acc = accuracy_score(y_test, test_preds)

    results = {
        "train_accuracy": train_acc,
        "test_accuracy": test_acc
    }

    if x_val is not None and y_val is not None:
        val_preds = model.predict(x_val)
        val_acc = accuracy_score(y_val, val_preds)
        results["val_accuracy"] = val_acc
        print("[Validation] Accuracy:", val_acc)
    else:
        print("⚠️ Validation set not available, skipping validation accuracy.")

    print("[Train] Accuracy:", train_acc)
    print("[Test] Accuracy:", test_acc)

    return results

__all__ = [
    "ClinicalValidator",
    "FeatureEngineeringValidator",
    "backup_protected_columns",
    "validate_loaded_dataset",
    "validate_noncontextual_schema",
    "load_schema",
    "evaluate_with_validation",
    "check_column_consistency",
    "validate_schema",
    "validate_required_columns",
    "ensure_no_nans",
    "apply_risk_score"
]
