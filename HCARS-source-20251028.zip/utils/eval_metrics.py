"""
Module: utils.eval_metrics

نقطة الحقيقة الوحيدة (Single Source of Truth) لمقاييس التقييم في النظام.

❖ ملاحظة مهمة حول true_response:
- عمود true_response يُمثل الـ Ground Truth المُعرّف بقواعد سريرية Rule-Based (مستمدة من الجداول/الخرائط الطبية في المشروع)،
  وليس تفاعلات مستخدمين حقيقية. لذا تُقرأ المقاييس هنا كتقييم اتساق/توافق مع القواعد السريرية، وليست قياسًا لسلوك مستخدمين.
"""
import numpy as np
import pandas as pd
import os
from typing import Any, Dict
from builtins import list as _blist, set as _bset

# -- Unified list-preparation helper (dedup + cap at K) --
def _prepare_lists(true_items, pred_items, k: int):
    """
    Normalize inputs for list-based metrics:
      - true_items: iterable of relevant item ids (can be None)
      - pred_items: iterable of predicted item ids (may contain duplicates)
      - k: cut-off
    Returns: (true_set, pred_topk_list)
    """
    if true_items is None:
        true_items = []
    # keep order, remove dups
    pred_unique = _blist(dict.fromkeys(pred_items or []))
    k = int(k) if k else 0
    return _bset(true_items or []), pred_unique[:k]

# -- Helpers to normalize vectors to 1D numpy arrays --
def _as_1d(a):
    """Coerce array-like to a contiguous 1D numpy array."""
    arr = np.asarray(a)
    return arr.ravel()

def precision_at_k(y_true, y_pred, k=5):
    # List-based implementation with internal dedup and K-cap
    true_set, pred_topk = _prepare_lists(y_true, y_pred, k)
    if k == 0 or len(pred_topk) == 0:
        return np.nan
    # Precision@k: relevant hits in top-k divided by k_used (len(pred_topk))
    hits = len(true_set.intersection(pred_topk))
    denom = float(len(pred_topk))
    return float(hits / denom) if denom > 0 else np.nan

def recall_at_k(y_true, y_pred, k=5):
    # List-based implementation with internal dedup and K-cap
    true_set, pred_topk = _prepare_lists(y_true, y_pred, k)
    if k == 0 or len(pred_topk) == 0:
        return np.nan
    if len(true_set) == 0:
        return np.nan
    hits = len(true_set.intersection(pred_topk))
    denom = float(len(true_set))
    return float(hits / denom) if denom > 0 else np.nan

def map_at_k(y_true, y_pred, k=5):
    # List-based implementation of AP@k with internal dedup
    true_set, pred_topk = _prepare_lists(y_true, y_pred, k)
    if k == 0 or len(pred_topk) == 0:
        return np.nan
    if len(true_set) == 0:
        return 0.0
    precisions = []
    hits = 0
    for i, item in enumerate(pred_topk):
        if item in true_set:
            hits += 1
            precisions.append(hits / float(i + 1))
    if not precisions:
        return 0.0
    denom = float(min(len(true_set), len(pred_topk)))
    return float(np.sum(precisions) / denom) if denom > 0 else 0.0

def ndcg_at_k(y_true, y_pred, k=5):
    # List-based NDCG@k with binary gains
    true_set, pred_topk = _prepare_lists(y_true, y_pred, k)
    if k == 0 or len(pred_topk) == 0:
        return 0.0

    def dcg_binary(items):
        gains = []
        for i, it in enumerate(items):
            rel = 1.0 if it in true_set else 0.0
            gains.append(rel / np.log2(i + 2))
        return float(np.sum(gains)) if gains else 0.0

    dcg_val = dcg_binary(pred_topk)
    ideal_hits = min(len(true_set), len(pred_topk))
    if ideal_hits == 0:
        return 0.0
    # ideal list: all relevant first (binary gains of 1 at top `ideal_hits` positions)
    idcg_val = float(np.sum(_blist(1.0 / np.log2(i + 2) for i in range(ideal_hits))))
    return float(dcg_val / idcg_val) if idcg_val > 0.0 else 0.0

# ---------------- Per-patient metrics (with components for micro-averaging) ----------------

def _per_patient_metrics(df: pd.DataFrame, k: int, true_col: str = "true_response", score_col: str = "score_cf", patient_col: str = "patient_id") -> pd.DataFrame:
    """
    يُعيد DataFrame بمقاييس لكل مريض + مكونات عددية للحسابات الميكروية:
      - hits@k, k_used, total_relevant
    """
    rows = []
    feature_col = "feature_id"
    for pid, g in df.groupby(patient_col, sort=False):
        # Predicted order by score
        g_sorted = g.sort_values(by=score_col, ascending=False)
        pred_items = (
            g_sorted[feature_col]
            .dropna()
            .astype(str)
            .tolist()
        )
        # True items: where true_response == 1
        idx_pos = g[true_col].fillna(0).astype(int).eq(1)
        true_series = g.loc[idx_pos, feature_col]
        true_series = true_series.dropna().astype(str)
        true_items = _blist(true_series.values)
        # k actually used (after dedup + cap inside metrics we still report external k)
        k_used = int(min(len(pred_items), k)) if k else 0
        if k_used == 0:
            prec = rec = mapv = nd = np.nan
            hits_k = 0.0
            total_rel = float(len(set(true_items)))
        else:
            prec = precision_at_k(true_items, pred_items, k)
            rec = recall_at_k(true_items, pred_items, k)
            mapv = map_at_k(true_items, pred_items, k)
            nd = ndcg_at_k(true_items, pred_items, k)
            # hits@k for micro-averaging
            true_set, pred_topk = _prepare_lists(true_items, pred_items, k)
            hits_k = float(len(true_set.intersection(pred_topk)))
            total_rel = float(len(true_set))
        rows.append({
            patient_col: pid,
            f"precision@{k}": prec,
            f"recall@{k}": rec,
            f"map@{k}": mapv,
            f"ndcg@{k}": nd,
            "_hits_at_k": hits_k,
            "_k_used": float(k_used),
            "_total_relevant": total_rel,
        })
    return pd.DataFrame(rows)

# ---------------- Public: grouped evaluation ----------------

def evaluate_grouped(
    df: pd.DataFrame,
    k: int,
    by: str | list[str] = "patient_id",
    true_col: str = "true_response",
    score_col: str = "score_cf",
    patient_col: str = "patient_id",
    save_dir: str | None = None,
    return_micro_macro: bool = True,
) -> dict:
    """
    يُقيّم التوصيات ويُعيد:
      - per_patient: مقاييس لكل مريض.
      - grouped: قاموس لمقاييس مُجمّعة حسب الحقل/الحقول في `by` (متوسط macro).
      - micro_macro (اختياري): صفّان يُمثّلان تلخيص micro/macro عبر المرضى.

    الملاحظات:
    - الماكرو = متوسط بسيط لمقاييس المرضى (مع تجاهل NaN).
    - الميكرو لِـ precision@k: sum(hits@k) / sum(k_used)؛ لِـ recall@k: sum(hits@k) / sum(total_relevant).
      (MAP/NDCG تُلخّص عادةً كمعدّل ماكرو فقط.)
    - إذا تم تمرير `save_dir` سيتم حفظ ملفات CSV للطبقات: metrics_by_<col>.csv.
    """
    if df is None or df.empty:
        return {"per_patient": pd.DataFrame(), "grouped": {}, "micro_macro": pd.DataFrame()}

    per_patient = _per_patient_metrics(df, k, true_col=true_col, score_col=score_col, patient_col=patient_col)

    # Micro/Macro summary
    micro_macro = pd.DataFrame()
    if return_micro_macro:
        # Macro: المتوسط البسيط عبر المرضى
        metric_cols = [c for c in per_patient.columns if c.endswith(f"@{k}")]
        macro_vals = per_patient[metric_cols].mean(numeric_only=True)
        macro_row: Dict[str, Any] = {"summary": "macro"}
        macro_row.update(macro_vals.to_dict())

        # Micro للـ precision@k و recall@k
        hits = per_patient["_hits_at_k"].sum()
        k_used = per_patient["_k_used"].sum()
        total_rel = per_patient["_total_relevant"].sum()

        micro_row: Dict[str, Any] = {"summary": "micro"}
        if k_used > 0:
            micro_row[f"precision@{k}"] = float(hits / k_used)
        if total_rel > 0:
            micro_row[f"recall@{k}"] = float(hits / total_rel)
        # MAP/NDCG: نُبقِيها كقِيَم ماكرو فقط
        micro_row[f"map@{k}"] = float("nan")
        micro_row[f"ndcg@{k}"] = float("nan")

        micro_macro = pd.DataFrame([macro_row, micro_row])

    # Grouped (stratified) evaluation
    grouped: dict[str, pd.DataFrame] = {}
    if isinstance(by, (list, tuple)) and len(by) == 1:
        by = by[0]
    if isinstance(by, str) and by != patient_col and by in df.columns:
        # ادمج تسمية المجموعة لكل مريض
        group_df = df[[patient_col, by]].drop_duplicates()
        per_patient = per_patient.merge(group_df, on=patient_col, how="left")
        metric_cols = [c for c in per_patient.columns if c.endswith(f"@{k}")]
        gdf = (
            per_patient.dropna(subset=[by])
                      .groupby(by)[metric_cols]
                      .mean()
                      .reset_index()
        )
        grouped[by] = gdf
        if save_dir:
            try:
                os.makedirs(save_dir, exist_ok=True)
                gdf.to_csv(os.path.join(save_dir, f"metrics_by_{by}.csv"), index=False)
            except (OSError, ValueError) as e:
                import logging
                logging.getLogger(__name__).warning(f"[evaluate_grouped] Could not save grouped metrics for {by}: {e}")
    elif isinstance(by, (list, tuple)):
        for col in [c for c in by if c in df.columns and c != patient_col]:
            group_df = df[[patient_col, col]].drop_duplicates()
            pp = per_patient.merge(group_df, on=patient_col, how="left")
            metric_cols = [c for c in pp.columns if c.endswith(f"@{k}")]
            gdf = (
                pp.dropna(subset=[col])
                  .groupby(col)[metric_cols]
                  .mean()
                  .reset_index()
            )
            grouped[col] = gdf
            if save_dir:
                try:
                    os.makedirs(save_dir, exist_ok=True)
                    gdf.to_csv(os.path.join(save_dir, f"metrics_by_{col}.csv"), index=False)
                except (OSError, ValueError) as e:
                    import logging
                    logging.getLogger(__name__).warning(f"[evaluate_grouped] Could not save grouped metrics for {col}: {e}")

    return {"per_patient": per_patient, "grouped": grouped, "micro_macro": micro_macro}

def evaluate_recommendations(
    df_recommendations,
    df_contextualized=None,
    true_col="true_response",
    score_col="score_cf",
    groupby_col="patient_id",
    k=5,
    add_metrics_to_df=False,
    save_path=None,
    logger=None,
    return_coverage_stats=False,
    print_coverage_stats=False
):
    import logging
    import traceback
    if logger is None:
        logger = logging.getLogger("eval_metrics")
        if not logger.hasHandlers():
            logger.addHandler(logging.StreamHandler())
        logger.setLevel(logging.INFO)
    try:
        logger.info(f"بدء تقييم التوصيات مع k={k}")

        # دمج true_response تلقائياً إذا غير موجود
        if true_col not in df_recommendations.columns:
            if df_contextualized is not None:
                # تحقق من توفر patient_id و feature_id في كلا الداتا فريم
                if ('patient_id' in df_recommendations.columns and 'feature_id' in df_recommendations.columns and
                    'patient_id' in df_contextualized.columns and 'feature_id' in df_contextualized.columns):
                    merge_cols = ['patient_id', 'feature_id']
                    if logger:
                        logger.info(f"عمود '{true_col}' غير موجود، سيتم دمجه باستخدام الأعمدة ['patient_id', 'feature_id'].")
                elif groupby_col in df_recommendations.columns and groupby_col in df_contextualized.columns:
                    merge_cols = [groupby_col]
                    if logger:
                        logger.info(f"عمود '{true_col}' غير موجود، سيتم دمجه باستخدام العمود [{groupby_col}].")
                else:
                    error_msg = (f"لا يمكن دمج العمود '{true_col}' لأن الأعمدة اللازمة للدمج غير متوفرة "
                                 f"في كلا DataFrame. الأعمدة المتوفرة في df_recommendations: {df_recommendations.columns.tolist()}, "
                                 f"وفي df_contextualized: {df_contextualized.columns.tolist()}")
                    if logger:
                        logger.error(error_msg)
                    raise ValueError(error_msg)

                df_recommendations = df_recommendations.merge(
                    df_contextualized[merge_cols + [true_col]],
                    on=merge_cols,
                    how='left'
                )
                if true_col not in df_recommendations.columns:
                    error_msg = f"فشل دمج العمود '{true_col}' من df_contextualized."
                    if logger:
                        logger.error(error_msg)
                    raise ValueError(error_msg)
            else:
                error_msg = f"العمود '{true_col}' غير موجود في توصيات الإدخال ولم يتم توفير df_contextualized للدمج."
                if logger:
                    logger.error(error_msg)
                raise ValueError(error_msg)

        # التحقق من الأعمدة المطلوبة
        missing_cols = [col for col in [true_col, score_col, groupby_col] if col not in df_recommendations.columns]
        if missing_cols:
            error_msg = f"الأعمدة التالية مفقودة في DataFrame: {missing_cols}"
            if logger:
                logger.error(error_msg)
            raise ValueError(error_msg)

        # حساب إحصائيات التغطية المتقدمة
        coverage_stats = {}
        unique_patients = df_recommendations[groupby_col].nunique()
        coverage_stats['num_patients'] = unique_patients

        # عدد التوصيات لكل مريض
        rec_counts = df_recommendations.groupby(groupby_col).size()
        num_patients_with_k_or_more = (rec_counts >= k).sum()
        coverage_stats['pct_patients_with_>=k_recommendations'] = num_patients_with_k_or_more / unique_patients if unique_patients > 0 else np.nan

        # عدد المرضى الذين لديهم true_response واحد على الأقل
        true_response_per_patient = df_recommendations.groupby(groupby_col)[true_col].apply(lambda x: x.fillna(0).astype(int).sum())
        num_patients_with_true_response = (true_response_per_patient > 0).sum()
        coverage_stats['pct_patients_with_true_response'] = num_patients_with_true_response / unique_patients if unique_patients > 0 else np.nan

        # توزيع الأسباب إذا كان عمود reason موجود
        if 'reason' in df_recommendations.columns:
            reason_counts = df_recommendations['reason'].value_counts(normalize=True).to_dict()
            coverage_stats['reason_distribution'] = reason_counts

        # طباعة أو تسجيل إحصائيات التغطية
        coverage_msg_lines = [
            f"إحصائيات التغطية:",
            f"- نسبة المرضى الذين لديهم ≥{k} توصية: {coverage_stats['pct_patients_with_>=k_recommendations']:.2%}" if not np.isnan(coverage_stats['pct_patients_with_>=k_recommendations']) else f"- نسبة المرضى الذين لديهم ≥{k} توصية: غير متوفرة",
            f"- نسبة المرضى الذين لديهم true_response: {coverage_stats['pct_patients_with_true_response']:.2%}" if not np.isnan(coverage_stats['pct_patients_with_true_response']) else "- نسبة المرضى الذين لديهم true_response: غير متوفرة",
            f"- عدد المرضى: {coverage_stats['num_patients']}"
        ]
        if 'reason_distribution' in coverage_stats:
            coverage_msg_lines.append("- توزيع الأسباب:")
            for reason, pct in coverage_stats['reason_distribution'].items():
                coverage_msg_lines.append(f"  * {reason}: {pct:.2%}")
        coverage_msg = "\n".join(coverage_msg_lines)

        if print_coverage_stats:
            print(coverage_msg)
        logger.info(coverage_msg)

        metrics = []
        # استخدام groupby مع sort_values داخل كل مجموعة لتقليل استهلاك الذاكرة مع مجموعات كبيرة
        for pid, group in df_recommendations.groupby(groupby_col, sort=False):
            feature_col = "feature_id"
            group_sorted = group.sort_values(by=score_col, ascending=False)
            pred_items = group_sorted[feature_col].dropna().astype(str).tolist()
            true_items = group.loc[group[true_col].fillna(0).astype(int) == 1, feature_col].dropna().astype(str).tolist()
            if len(set(true_items)) == 0:
                logger.warning(f"لا توجد إيجابيات حقيقية لـ {groupby_col}={pid}. سيتم إرجاع NaN للمقاييس.")
                precision = recall = map_score = ndcg = np.nan
            else:
                precision = precision_at_k(true_items, pred_items, k)
                recall = recall_at_k(true_items, pred_items, k)
                map_score = map_at_k(true_items, pred_items, k)
                ndcg = ndcg_at_k(true_items, pred_items, k)
            metric = {
                groupby_col: pid,
                f'precision@{k}': precision,
                f'recall@{k}': recall,
                f'map@{k}': map_score,
                f'ndcg@{k}': ndcg
            }
            logger.debug(f"Metrics for {groupby_col}={pid}: {metric}")
            metrics.append(metric)

        metrics_df = pd.DataFrame(metrics)

        if add_metrics_to_df:
            # دمج النتائج الأصلية مع المقاييس بكفاءة
            try:
                dirpath = os.path.dirname(save_path) or "."
                os.makedirs(dirpath, exist_ok=True)
                df_merged = df_recommendations.merge(metrics_df, on=groupby_col, how='left')
                df_merged.to_csv(save_path, index=False)
                logger.info(f"✅ تم حفظ ملف التقييم النهائي: {save_path}")
                print(f"✅ تم حفظ ملف التقييم النهائي: {save_path}")
            except (OSError, ValueError) as e:
                err_msg = f"حدث خطأ أثناء تقييم التوصيات: {e}\n{traceback.format_exc()}"
                logger.error(err_msg)
                print(f"❌ {err_msg}")
                raise
            if return_coverage_stats:
                return df_merged, coverage_stats
            else:
                return df_merged
        else:
            if save_path:   # NEW: أضف هذا الجزء للحفظ حتى عند عدم دمج المقاييس
                try:
                    dirpath = os.path.dirname(save_path) or "."
                    os.makedirs(dirpath, exist_ok=True)
                    metrics_df.to_csv(save_path, index=False)
                    logger.info(f"✅ تم حفظ ملف التقييم النهائي: {save_path}")
                    print(f"✅ تم حفظ ملف التقييم النهائي: {save_path}")
                except (OSError, ValueError) as e:
                    err_msg = f"حدث خطأ أثناء تقييم التوصيات: {e}\n{traceback.format_exc()}"
                    logger.error(err_msg)
                    print(f"❌ {err_msg}")
                    raise
            if return_coverage_stats:
                return metrics_df, coverage_stats
            else:
                return metrics_df

    except Exception as e:
        import traceback
        err_msg = f"حدث خطأ أثناء تقييم التوصيات: {e}\n{traceback.format_exc()}"
        logger.error(err_msg)
        print(f"❌ {err_msg}")
        raise

def evaluate_by_split_or_reason(
    df_recommendations,
    df_contextualized=None,
    k=5,
    split_col="split",
    reason_col="reason",
    true_col="true_response",
    score_col="score_cf",
    groupby_col="patient_id",
    save_dir=None,
    logger=None
):

    results = {}
    try:
        if split_col in df_recommendations.columns:
            if logger:
                logger.info(f"التقييم حسب تقسيم البيانات باستخدام العمود '{split_col}'.")
            for split_value in df_recommendations[split_col].dropna().unique():
                if logger:
                    logger.info(f"تقييم التقسيم: {split_value}")
                split_df = df_recommendations[df_recommendations[split_col] == split_value]
                eval_df = evaluate_recommendations(
                    split_df,
                    df_contextualized=df_contextualized,
                    true_col=true_col,
                    score_col=score_col,
                    groupby_col=groupby_col,
                    k=k,
                    add_metrics_to_df=False,
                    logger=logger
                )
                results[split_value] = eval_df
                if save_dir:
                    os.makedirs(save_dir, exist_ok=True)
                    file_path = os.path.join(save_dir, f"evaluation_{split_col}_{split_value}.csv")
                    eval_df.to_csv(file_path, index=False)
                    if logger:
                        logger.info(f"تم حفظ تقييم التقسيم '{split_value}' في الملف: {file_path}")

        elif reason_col in df_recommendations.columns:
            if logger:
                logger.info(f"التقييم حسب سبب التوصية باستخدام العمود '{reason_col}'.")
            for reason in df_recommendations[reason_col].dropna().unique():
                if logger:
                    logger.info(f"تقييم السبب: {reason}")
                reason_df = df_recommendations[df_recommendations[reason_col] == reason]
                eval_df = evaluate_recommendations(
                    reason_df,
                    df_contextualized=df_contextualized,
                    true_col=true_col,
                    score_col=score_col,
                    groupby_col=groupby_col,
                    k=k,
                    add_metrics_to_df=False,
                    logger=logger
                )
                results[reason] = eval_df
                if save_dir:
                    os.makedirs(save_dir, exist_ok=True)
                    file_path = os.path.join(save_dir, f"evaluation_{reason_col}_{reason}.csv")
                    eval_df.to_csv(file_path, index=False)
                    if logger:
                        logger.info(f"تم حفظ تقييم السبب '{reason}' في الملف: {file_path}")

        else:
            warning_msg = f"لم يتم العثور على عمود '{split_col}' أو '{reason_col}' في البيانات."
            if logger:
                logger.warning(warning_msg)
    except Exception as e:
        if logger:
            logger.error(f"حدث خطأ أثناء التقييم حسب التقسيم أو السبب: {e}")
        raise

    return results

__all__ = [
    "precision_at_k",
    "recall_at_k",
    "map_at_k",
    "ndcg_at_k",
    "evaluate_grouped",
]