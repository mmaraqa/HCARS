import datetime
import os
import pandas as pd
import logging

# Define context feature keys directly here
CONTEXT_FEATURE_KEYS = ["context_risk_level", "context_age_group", "context_bp_category", "context_chol_category"]

from utils.config_loader import load_global_config
from utils.validation import (
    validate_loaded_dataset,
    validate_noncontextual_schema
)
from utils import safe_copy

logger = logging.getLogger(__name__)
if not logger.hasHandlers():
    logging.basicConfig(level=logging.INFO)

logger.info("🔧 hcars_utils.py module loaded: HCARSUtils ready with CBF, risk scoring, and dynamic feature support.")
logger.info("🩺 HCARSUtils متوافق مع بيئة البيانات السريرية، ويشمل توليد وتصنيف المخاطر وتحليل السمات السياقية.")


class HCARSUtils:
    @staticmethod
    def get_cbf_features_with_context(config: dict, log_id: str = None) -> list:
        if log_id is None:
            import uuid
            log_id = uuid.uuid4().hex[:8]
        logger.info(f"[Timestamp] ⏱️ {datetime.datetime.now()} - Entered: {__name__}.get_cbf_features_with_context")
        base_features = config.get("model_settings", {}).get("cbf", {}).get("features", [])
        context_flags = config.get("model_settings", {}).get("cbf", {}).get("include_context", True)
        context_keys = CONTEXT_FEATURE_KEYS
        full_features = base_features + [c for c in context_keys if c not in base_features and context_flags]
        logger.info(f"[{log_id}] [Validation Check] ✅ CBF features retrieved (with context): {full_features}")
        return full_features

    @staticmethod
    def filter_existing_features(df: pd.DataFrame, features: list[str]) -> list[str]:
        """
        Filters the provided features list to only those existing in the DataFrame or protected columns.
        Note: Does not currently support log_id for logging; consider adding for future enhancements.
        """
        logger.info(f"[Timestamp] ⏱️ {datetime.datetime.now()} - Entered: {__name__}.filter_existing_features")
        if df is None:
            logger.error("[Data Integrity] ❌ [filter_existing_features] Input dataframe is None.")
            raise ValueError("filter_existing_features - Input dataframe cannot be None.")
        config = load_global_config()
        if not features:
            logger.warning("[Data Integrity] ⚠️ [filter_existing_features] No features provided for filtering.")
            return []
        protected = config.get("preprocessing", {}).get("protected_columns", [])
        filtered_features = [f for f in features if f in df.columns or f in protected]
        logger.info(f"[Validation Check] [filter_existing_features] ✅ Filtered features: {filtered_features}")
        return filtered_features

    @staticmethod
    def validate_feature_list(features) -> bool:
        logger.info(f"[Timestamp] ⏱️ {datetime.datetime.now()} - Entered: {__name__}.validate_feature_list")
        if not isinstance(features, list):
            logger.error("❌ [HCARSUtils] Invalid CBF features format. Expected list.")
            return False
        return True

    @staticmethod
    def get_cbf_features(config: dict) -> list:
        """
        Retrieves CBF features from configuration.
        Note: Does not currently support log_id for logging; consider adding for future enhancements.
        """
        logger.info(f"[Timestamp] ⏱️ {datetime.datetime.now()} - Entered: {__name__}.get_cbf_features")
        # Log the config file path or origin
        logger.info(f"[Config Debug] Loaded config from get_config() with keys: {list(config.keys())}")
        features = config.get("model_settings", {}).get("cbf", {}).get("features", [])
        if not HCARSUtils.validate_feature_list(features):
            return []
        if not features:
            logger.warning("⚠️ [HCARSUtils] No CBF features defined in configuration.")
        else:
            logger.info(f"✅ [HCARSUtils] Extracted CBF features: {features}")
        return features

    @staticmethod
    def ensure_no_nans(df: pd.DataFrame, context: str = ""):
        logger.info(f"[Timestamp] ⏱️ {datetime.datetime.now()} - Entered: {__name__}.ensure_no_nans")
        logger.info(f"🔍 [HCARSUtils] Checking for NaN values in {context}...")
        if df.isnull().values.any():
            raise ValueError(f"❌ [Medical Validation] Detected NaN values in {context}. CF/CBF modeling requires complete data integrity.")

    @staticmethod
    def apply_risk_score(df: pd.DataFrame) -> pd.DataFrame:
        """
        Applies risk score transformer to the DataFrame if enabled in config.
        Note: Does not currently support log_id for logging; consider adding for future enhancements.
        """
        logger.info(f"[Timestamp] ⏱️ {datetime.datetime.now()} - Entered: {__name__}.apply_risk_score")
        from utils.risk_score_transformer import RiskScoreTransformer

        # 🛡️ Begin safe risk score transformation with data integrity checks
        try:
            config = load_global_config()
            logger.info(f"[Config Debug] Loaded config keys: {list(config.keys())}")
            risk_config = config.get("risk_score_transformer", {})
            logger.info(f"[Config Debug] Risk Score Transformer Config: {risk_config}")
            if not risk_config.get("enabled", False):
                logger.info("ℹ️ [HCARSUtils] Risk Score Transformer is disabled in config.")
                df_transformed = df
            elif df.empty:
                logger.error("❌ [HCARSUtils] Provided DataFrame is empty. Skipping RiskScoreTransformer.")
                df_transformed = df
            elif df.isnull().any().any():
                logger.error("❌ [HCARSUtils] DataFrame contains NaNs. Skipping RiskScoreTransformer for safety.")
                logger.error("🩺 [HCARSUtils] يحتوي الجدول على بيانات ناقصة - لا يمكن تطبيق نموذج الخطر السريري دون إكمال البيانات.")
                df_transformed = df
            else:
                transformer = RiskScoreTransformer()
                df_transformed = transformer.transform(safe_copy(df))
                logger.info("🩺 [RiskScore] تم تطبيق نموذج التصنيف السريري بنجاح باستخدام ضغط الدم والكوليسترول والعمر.")
                logger.info(f"🧾 [Column Audit] After transformation: {df_transformed.columns.tolist()}")
                logger.info(f"[Debug Columns] Post-risk transformation columns: {df_transformed.columns.tolist()}")

                def validate_with_schema_handling(df_to_validate, context):
                    # Enforce schema validation using YAML schema path (not in-memory dictionary)
                    validate_noncontextual_schema(
                        df=df_to_validate,
                        schema_path_or_dict="schemas/post-risk-score.yaml",
                        dataset_name=context
                    )

                validate_with_schema_handling(df_transformed, "Post-RiskScoreTransformer")

                logger.info(f"🧾 [Column Audit] Post-Risk Score: {df_transformed.columns.tolist()}")
                logger.info("✅ [HCARSUtils] Successfully applied Risk Score Transformer to dataset.")
                for col in ["bp_category", "chol_category", "risk_level"]:
                    if col not in df_transformed.columns:
                        logger.warning(f"[Context Warning] Missing contextual column after risk scoring: {col}")
            return df_transformed
        except FileNotFoundError as fnf_error:
            logger.error(f"❌ [HCARSUtils] Config file not found: {fnf_error}")
            df_transformed = df
            return df_transformed
        except Exception as e:
            import yaml
            if isinstance(e, yaml.YAMLError):
                logger.error(f"❌ [HCARSUtils] Error parsing config.yaml: {e}")
            elif isinstance(e, ImportError):
                logger.error(f"❌ [HCARSUtils] Could not import RiskScoreTransformer: {e}")
            else:
                logger.exception("❌ [HCARSUtils] Unexpected error during Risk Score application.", exc_info=e)
            df_transformed = df
            return df_transformed

    # ✅ تحديد السمات السريرية المحفزة للـ Content-Based Filtering حسب المرض
    @staticmethod
    def get_cbf_features_by_dataset(dataset_name: str) -> list:
        logger.info(f"[Timestamp] ⏱️ {datetime.datetime.now()} - Entered: {__name__}.get_cbf_features_by_dataset")
        dataset_name = dataset_name.lower()
        if "hypertension" in dataset_name:
            features = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg", "thalach", "exang", "oldpeak",
                        "slope", "ca", "thal"]
        else:
            features = []  # fallback to empty if disease not recognized

        if not features:
            logger.warning(f"⚠️ [HCARSUtils] No predefined CBF features for dataset '{dataset_name}'.")
        else:
            logger.info(f"✅ [HCARSUtils] Selected CBF features for '{dataset_name}': {features}")
        return features

    @staticmethod
    def print_schema_status():
        logger.info(f"[Timestamp] ⏱️ {datetime.datetime.now()} - Entered: {__name__}.print_schema_status")
        schema_dir = os.path.join(os.path.dirname(__file__), "../schemas")
        logger.info("🩺 [Schema Debug] عرض مخططات التحقق الطبي المتوفرة.")
        logger.info(f"[Schema Debug] Available schemas in {schema_dir}: {os.listdir(schema_dir)}")

    @staticmethod
    def validate_final_schema(df: pd.DataFrame, loaded_schema: dict, dataset_name: str = "final_output"):
        """
        Validates the final DataFrame against a preloaded YAML schema dictionary.

        Parameters
        ----------
        df : pd.DataFrame
            The DataFrame to validate.
        loaded_schema : dict
            The schema in dictionary form, already loaded from YAML.
        dataset_name : str, default="final_output"
            A label used for logging context during validation.
        """
        logger.info(f"[Schema Validation] Validating final schema for dataset: {dataset_name}")
        from utils.validation import validate_schema
        validate_schema(df=df, schema=loaded_schema, dataset_name=dataset_name)
        logger.info("✅ Final schema validation passed.")

    @staticmethod
    def get_clean_schema(schemas):
        logger.info(f"[Timestamp] ⏱️ {datetime.datetime.now()} - Entered: {__name__}.get_clean_schema")
        if not isinstance(schemas, dict):
            raise TypeError(f"Expected schemas to be a dict, but got {type(schemas)}")

        value = schemas.get("clean_hypertension_data")
        if isinstance(value, str):
            return value
        elif isinstance(value, dict):
            logger.error(f"❌ [Schema Error] متوقع مسار مخطط (string)، تم تقديم {type(value)}. تحقق من تحميل schema بشكل صحيح.")
            raise TypeError("Schema appears to be already loaded. Expected a file path as a string.")
        elif isinstance(value, list):
            logger.error(f"❌ [Schema Error] متوقع مسار مخطط (string)، تم تقديم {type(value)}. تحقق من تحميل schema بشكل صحيح.")
            raise TypeError("Schema is a list. Expected a file path as a string.")
        else:
            logger.error(f"❌ [Schema Error] متوقع مسار مخطط (string)، تم تقديم {type(value)}. تحقق من تحميل schema بشكل صحيح.")
            raise TypeError(f"Invalid schema type: expected str, got {type(value)}")

    @staticmethod
    def self_test():
        logger.info(f"[Timestamp] ⏱️ {datetime.datetime.now()} - Entered: {__name__}.self_test")
        logger.info("🧪 [HCARSUtils] Running self-test...")
        sample_df = pd.DataFrame({
            'age': [45, 52],
            'sex': [1, 0],
            'cp': [3, 2],
            'trestbps': [120, 140],
            'chol': [250, 230],
            'fbs': [0, 1],
            'restecg': [1, 0],
            'thalach': [150, 160],
            'exang': [0, 1],
            'oldpeak': [1.5, 2.3],
            'slope': [2, 1],
            'ca': [0, 1],
            'thal': [2, 3],
            'target': [1, 0],
            'target_copy': [1, 0],
            'chol_category': ['High', 'Borderline High'],
            'bp_category': ['Hypertension Stage 2', 'Hypertension Stage 1'],
            'risk_level': ['High', 'Medium'],
            'chol_flag': [1, 0],
        })
        logger.info(f"🧾 [Column Audit] Self-test start columns: {sample_df.columns.tolist()}")
        HCARSUtils.print_schema_status()
        validate_loaded_dataset(
            df=sample_df,
            schema_path_or_dict="schemas/clean_hypertension_data.yaml",
            dataset_name="HCARSUtils Self-test"
        )
        features = ["age", "sex", "cp", "trestbps", "chol", "non_existing",
                    "chol_category", "bp_category", "risk_level", "chol_flag"]
        filtered = HCARSUtils.filter_existing_features(sample_df, features)
        assert "non_existing" not in filtered, "❌ Unexpected feature passed validation"
        assert "age" in filtered, "❌ Valid feature missing from validation"
        assert "chol_category" in filtered, "❌ Valid feature missing from validation"
        assert "bp_category" in filtered, "❌ Valid feature missing from validation"
        logger.info("✅ [HCARSUtils] Self-test passed successfully.")

    @staticmethod
    def score_recommendations(df: pd.DataFrame, context_dict: dict, log_id: str = None) -> pd.DataFrame:
        if log_id is None:
            import uuid
            log_id = uuid.uuid4().hex[:8]
        logger.info(f"[Timestamp] ⏱️ {datetime.datetime.now()} - Entered: {__name__}.score_recommendations")
        for key in CONTEXT_FEATURE_KEYS:
            value = context_dict.get(key, "unknown")
            df[key] = value
            logger.info(f"[{log_id}] [Score Recommendations] Assigned {key} = {value} for all rows.")
        return df


get_cbf_features = HCARSUtils.get_cbf_features
get_cbf_features_by_dataset = HCARSUtils.get_cbf_features_by_dataset
apply_risk_score = HCARSUtils.apply_risk_score
ensure_no_nans = HCARSUtils.ensure_no_nans
filter_existing_features = HCARSUtils.filter_existing_features

get_cbf_features_with_context = HCARSUtils.get_cbf_features_with_context
score_recommendations = HCARSUtils.score_recommendations

# مكونات HCARSUtils المعتمدة للأنظمة السريرية الذكية
__all__ = [
    "HCARSUtils",
    "get_cbf_features",
    "get_cbf_features_by_dataset",
    "apply_risk_score",
    "ensure_no_nans",
    "filter_existing_features",
    "get_cbf_features_with_context",
    "score_recommendations",
]
# مكونات HCARSUtils المعتمدة للأنظمة السريرية الذكية