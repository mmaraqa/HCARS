import logging
import os


def get_logger(name: str) -> logging.Logger:
    """
    Returns a logger with the specified name, configured with a StreamHandler
    and a default formatter if no handlers exist.

    Args:
        name (str): Name of the logger.

    Returns:
        logging.Logger: Configured logger instance.
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger

RISK_LOG_MARKER = "🩺"

def create_default_formatter():
    """
    إنشاء Formatter افتراضي للسجلات العامة.

    Returns:
        logging.Formatter: Formatter جاهز بتنسيق قياسي.
    """
    return logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

# Formatter مخصص لتسجيلات تقييم المخاطر باستخدام رمز مرئي.
def create_risk_formatter():
    """
    إنشاء Formatter مخصص لرسائل تقييم المخاطر.

    Returns:
        logging.Formatter: Formatter بتنسيق مميز لتقييم المخاطر.
    """
    return logging.Formatter(f'%(asctime)s - {RISK_LOG_MARKER} RISK - %(name)s - %(levelname)s - %(message)s')

def setup_logger(name, log_file, level=logging.INFO, formatter=None, risk_logger=False, mode: str = "prod"):
    """
    إعداد Logger خاص بملف محدد مع دعم UTF-8 وإدارة إنشاء الأدلة ومنع تكرار المعالجات.

    Args:
        name (str): اسم اللوجر.
        log_file (str): مسار ملف السجل.
        level (int): مستوى تسجيل الرسائل (افتراضي INFO).
        formatter (logging.Formatter): شكل الرسائل (افتراضي قياسي).
        risk_logger (bool): إذا True يستخدم Formatter خاص بالمخاطر.
        mode (str): وضع التشغيل، يمكن أن يكون "prod" أو "test" (افتراضي "prod").
                    إذا كان "test"، يتم توجيه السجلات إلى مجلد logs/testing/.

    Returns:
        logging.Logger: كائن اللوجر المُجهز.
    """
    if mode == "test":
        base_log_name = os.path.basename(log_file)
        log_file = os.path.join("logs", "testing", base_log_name)

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    print(f"📄 Logger '{name}' will write to: {log_file}")

    if formatter is None:
        formatter = create_risk_formatter() if risk_logger else create_default_formatter()

    handler = logging.FileHandler(log_file, mode='a', encoding='utf-8')
    handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.setLevel(level)
    print(f"🔧 Logger '{name}' configured at level: {logging.getLevelName(level)}")

    if not any(isinstance(h, logging.FileHandler) and getattr(h, 'baseFilename', None) == os.path.abspath(log_file) for h in logger.handlers):
        logger.addHandler(handler)
    logger.propagate = False

    logger.debug(f"🪵 Handler added to logger '{name}' writing to {log_file}")

    print(f"✅ Logger '{name}' setup complete.")
    return logger

def check_context_fields_in_log(log_file_path: str):
    from utils.config_loader import load_global_config
    config = load_global_config()
    required_fields = config.get("context_features", ["bp_category", "chol_category", "risk_level", "age_group"])
    if not os.path.exists(log_file_path):
        print(f"⚠️ Log file not found: {log_file_path}")
        pipeline_logger.info(f"Log file not found: {log_file_path}")
        return
    with open(log_file_path, "r", encoding="utf-8") as f:
        content = f.read()
        for field in required_fields:
            if field not in content:
                print(f"❗ Context field missing in log: {field}")
                pipeline_logger.info(f"Context field missing in log: {field}")
            else:
                print(f"✅ Context field found in log: {field}")
                pipeline_logger.info(f"Context field found in log: {field}")

def verify_context_columns_in_log(log_file_path: str):
    """
    يتحقق من وجود جميع الأعمدة السياقية داخل مِلف السجل المحدد ويطبع النتيجة.

    Args:
        log_file_path (str): المسار الكامل إلى مَلف السجل.
    """
    from utils.config_loader import load_global_config
    config = load_global_config()
    context_columns = config.get("context_features", ["bp_category", "chol_category", "risk_level", "age_group"])
    print(f"🔍 فحص الأعمدة السياقية داخل السجل: {log_file_path}")
    pipeline_logger.info(f"Checking context columns in log: {log_file_path}")
    if not os.path.exists(log_file_path):
        print(f"❌ الملف غير موجود: {log_file_path}")
        pipeline_logger.info(f"Log file does not exist: {log_file_path}")
        return
    with open(log_file_path, "r", encoding="utf-8") as log_file:
        content = log_file.read()
        for col in context_columns:
            if col in content:
                print(f"✅ موجود: {col}")
                pipeline_logger.info(f"Context column found: {col}")
            else:
                print(f"❌ غير موجود: {col}")
                pipeline_logger.info(f"Context column missing: {col}")

# Global logger for pipeline usage
pipeline_logger = setup_logger(
    name="pipeline_logger",
    log_file="logs/pipeline.log",
    level=logging.INFO,
    mode="prod"
)

# feature_engineering_logger = setup_logger(
#     name="feature_engineering",
#     log_file="logs/feature_engineering.log",
#     level=logging.DEBUG,
#     mode="prod"
# )

def get_feature_engineering_logger():
    """
    يُعيد logger مهيأ خصيصًا للـ feature engineering.
    لا يُهيأ إلا إذا تم استدعاؤه فعليًا (وليس أثناء استيراد logging_utils).
    """
    return setup_logger(
        name="feature_engineering",
        log_file="logs/feature_engineering.log",
        level=logging.DEBUG,
        mode="prod"
    )

__all__ = ["create_default_formatter", "create_risk_formatter", "setup_logger", "get_logger", "pipeline_logger", "check_context_fields_in_log", "verify_context_columns_in_log", "get_feature_engineering_logger"]
