

import pandas as pd
from pandas.api.types import CategoricalDtype

# Additional typing imports for clinical plan field accessors
from typing import Dict, Any, Tuple
from typing import TypedDict

# ثابت الأعمدة السياقية الموحدة - يجب استخدامه في كل بناء مفتاح سياقي
CONTEXT_COLUMNS = ["bp_category", "chol_category", "risk_level", "fbs_cat", "cp_cat", "age_group"]

# ثابت الأعمدة السياقية الثانوية - يُستخدم لتوسعة التحليل السياقي أو بناء مفاتيح إضافية عند الحاجة
SECONDARY_CONTEXT_COLUMNS = [
    "chol_bins", "restecg_cat", "exang_cat", "oldpeak_cat", "ca_cat", "thal_cat"
]

import re
import logging
# --- [FEATURE SYNONYMS & CANONICALIZATION] ---
# القيم القانونية/النهائية (canonical) — يُفضّل توحيد المخرجات عليها لتقليل تشتت الميزات
CANONICAL_FEATURE_IDS = {
    "amlodipine",
    "ace_inhibitor",
    "arb",
    "beta_blocker",
    "thiazide_diuretic",
    "thiazide",
    "amlodipine_and_thiazide",
    "statin",
    "diet_control",
    "low_sodium_diet",
    "increase_exercise",
    "lifestyle_monitoring",
    "hospital_referral",
    "emergency_admission",
    "urgent_review",
}

# مرادفات شائعة (regex → canonical)
_FEATURE_SYNONYMS_REGEX = [
    # مضادات ACE
    (re.compile(r"\b(acei|ace|lisinopril|enalapril|perindopril|ramipril)\b", re.I), "ace_inhibitor"),
    # ARB / أمثلة جنيسة
    (re.compile(r"\b(arb|losartan|valsartan|irbesartan|candesartan|olmesartan)\b", re.I), "arb"),
    # Common brand names (to improve canonicalization from free-text)
    (re.compile(r"\b(norvasc)\b", re.I), "amlodipine"),
    (re.compile(r"\b(cozaar|diovan|avapro|benicar)\b", re.I), "arb"),
    # CCB / Amlodipine
    (re.compile(r"\b(amlod(ipine)?|ccb|calcium[_\s-]*channel[_\s-]*blocker)\b", re.I), "amlodipine"),
    # Beta blockers (تشمل atenolol)
    (re.compile(r"\b(beta[_\s-]*blocker(s)?|metoprolol|atenolol|bisoprolol|propranolol|nebivolol)\b", re.I), "beta_blocker"),
    # Thiazide
    (re.compile(r"\b(thiazide|hct|hctz|hydrochlorothiazide|chlorthalidone)\b", re.I), "thiazide_diuretic"),
    # Statins
    (re.compile(r"\b(statin|atorvastatin|rosuvastatin|simvastatin|pravastatin|pitavastatin)\b", re.I), "statin"),
    # Lifestyle / Diet
    (re.compile(r"\b(low[_\s-]*sodium|salt|sodium)\b", re.I), "low_sodium_diet"),
    (re.compile(r"\b(diet|nutrition|dash)\b", re.I), "diet_control"),
    (re.compile(r"\b(exercise|activity|physical[_\s-]*activity|sport|walk(ing)?)\b", re.I), "increase_exercise"),
    (re.compile(r"\b(lifestyle|monitor(ing)?|follow[_\s-]*up)\b", re.I), "lifestyle_monitoring"),
    # توليفة شائعة
    (re.compile(r"\b(amlodipine.*thiazide|thiazide.*amlodipine)\b", re.I), "amlodipine_and_thiazide"),
    # إحالات/تحويل
    (re.compile(r"\b(emergency|er|admit|hypertensive[_\s-]*emergency)\b", re.I), "emergency_admission"),
    (re.compile(r"\b(urgent[_\s-]*review|urgent)\b", re.I), "urgent_review"),
    (re.compile(r"\b(hospital|referral)\b", re.I), "hospital_referral"),
]

from typing import Optional

def canonicalize_feature_id(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    v = str(value).strip().lower()
    if v in CANONICAL_FEATURE_IDS:
        return v
    for pat, canon in _FEATURE_SYNONYMS_REGEX:
        if pat.search(v):
            return canon
    # محاولات تصحيح بسيطة لأسماء مختصرة
    if v in {"hct", "hctz"}:
        return "thiazide_diuretic"
    if v in {"amlod"}:
        return "amlodipine"
    if v in {"acei", "ace"}:
        return "ace_inhibitor"
    # إن لم تُعرَف، أعد None ليعالجها منادٍ الدالة أو تبقى كما هي إن كانت ضمن allowed_feature_ids في config
    return None
def normalize_label(val: str) -> str:
    if val is None:
        return "unknown"
    s = str(val).strip().lower()
    s = s.replace("–", "-").replace("—", "-")  # en/em dash -> hyphen
    s = re.sub(r"\s+", "_", s)
    return s if s else "unknown"

# ------------------------------
# Lightweight dtype helpers (memory-aware)
# ------------------------------
def is_categorical(s: pd.Series) -> bool:
    """Return True if the series dtype is categorical."""
    return isinstance(getattr(s, "dtype", None), CategoricalDtype)

def downcast_context(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    for c in cols:
        if c in df.columns:
            try:
                if not is_categorical(df[c]):
                    df[c] = df[c].astype("category")
            except (TypeError, ValueError):
                # Keep resilient: skip columns that cannot be cast safely
                pass
    return df

from utils.config_loader import get_config
# ----------------------------------------------------

# --- Local make_context_key to avoid circular imports with context_utils ---
def make_context_key(row_or_dict, *, context_columns=None):
    if row_or_dict is None:
        raise ValueError("make_context_key received None")

    # Resolve columns immutably (tuple) to avoid mutable-default warnings
    cols = tuple(context_columns) if context_columns is not None else tuple(CONTEXT_COLUMNS)

    # Dict-like vs Series/row-like accessor
    if isinstance(row_or_dict, dict):
        getter = row_or_dict.get  # type: ignore[assignment]
    else:
        # pandas Series / row-like: safe accessor without broad exceptions
        def getter(k):
            try:
                return row_or_dict[k] if hasattr(row_or_dict, "__contains__") and (k in row_or_dict) else None
            except (KeyError, TypeError, AttributeError, IndexError):
                return None

    # Build normalized tuple in the provided order
    vals = [normalize_label(getter(col)) for col in cols]
    return tuple(vals)


# ------------------------------
# Wildcard matching helpers for context keys
# ------------------------------
from itertools import combinations as _it_combinations

def _iter_wildcard_variants(key_tuple: tuple, wildcard: str = "any"):
    """توليد جميع البدائل الممكنة للمفتاح السياقي مع استبدال عناصر بـ wildcard تدريجيًا."""
    if not isinstance(key_tuple, tuple):
        raise TypeError("key_tuple must be a tuple")
    n = len(key_tuple)
    yield key_tuple
    for r in range(1, n + 1):
        for combo in _it_combinations(range(n), r):
            k = list(key_tuple)
            for i in combo:
                k[i] = wildcard
            yield tuple(k)

def find_best_context_match(mapping: dict, key_tuple: tuple, *, wildcard: str = "any"):
    """البحث عن أفضل تطابق للمفتاح السياقي في mapping باستخدام وايلدكارد."""
    if not isinstance(mapping, dict):
        return None, None
    for cand in _iter_wildcard_variants(key_tuple, wildcard=wildcard):
        if cand in mapping:
            return cand, mapping[cand]
    return None, None

config = get_config()

# ---------------- Compatibility helpers for config key renames ----------------

def _safe_rec_cfg(config_obj):
    try:
        return config_obj.get("recommendation", {}) if isinstance(config_obj, dict) else {}
    except (AttributeError, TypeError):
        return {}


def get_top_n_ui(config_obj) -> int:
    """Backward-compatible getter for clinical display Top-N.
    Prefers `recommendation.top_n_ui`, falls back to legacy `top_n_for_clinical_display`, else 3.
    """
    rec = _safe_rec_cfg(config_obj)
    return int(rec.get("top_n_ui", rec.get("top_n_for_clinical_display", 3)))


def get_top_n_eval(config_obj) -> int:
    """Backward-compatible getter for evaluation Top-N.
    Prefers `recommendation.top_n_eval`, falls back to legacy `top_n_for_evaluation`, else 5.
    """
    rec = _safe_rec_cfg(config_obj)
    return int(rec.get("top_n_eval", rec.get("top_n_for_evaluation", 5)))

# ---------------------------------------------------------------------------
# تم بناء معظم التركيبات في هذا القاموس بناءً على تحليل تكرار السياقات الحقيقية من البيانات الأصلية،
# لضمان تغطية سريرية شاملة وربط كل توصية بعلاج سريري مناسب وقابل للتوسع.
# ---------------------------------------------------------------------------
MEDICAL_RECOMMENDATION_PLAN = {
    # حالات حرجة جدا (تحليل بيانات: حالات hypertensive_crisis الأكثر تكراراً)
    ("hypertensive_crisis", "high", "high", "high_fbs", "severe_cp"): "emergency_admission",  # تحليل: ضغط حرج مع سكر وألم شديد
    ("hypertensive_crisis", "high", "high", "any", "any"): "emergency_admission",  # تحليل: ضغط حرج مع خطورة عالية بأي حالة سكر/ألم

    # ضغط دم مرتفع جداً مع خطورة عالية (تحليل بيانات: stage_2/high/high)
    ("hypertension_stage_2", "high", "high", "high_fbs", "any"): "amlodipine_and_thiazide",  # شائع: ضغط شديد وكوليسترول وسكر مرتفع
    ("hypertension_stage_2", "high", "high", "moderate_fbs", "any"): "amlodipine_and_thiazide",  # ضغط شديد مع مقدمات سكري
    ("hypertension_stage_2", "high", "high", "normal_fbs", "any"): "amlodipine",  # ضغط شديد مع سكر طبيعي
    ("hypertension_stage_2", "high", "medium", "any", "any"): "amlodipine",  # ضغط شديد مع خطورة متوسطة
    ("hypertension_stage_2", "high", "low", "any", "any"): "losartan",  # ضغط شديد وخطورة منخفضة

    # ضغط شديد مع borderline_high (تحليل بيانات: stage_2/borderline_high)
    ("hypertension_stage_2", "borderline_high", "high", "any", "any"): "amlodipine_and_thiazide",
    ("hypertension_stage_2", "borderline_high", "medium", "any", "any"): "losartan",
    ("hypertension_stage_2", "borderline_high", "low", "any", "any"): "losartan",

    # ضغط شديد مع desirable (تحليل بيانات: stage_2/desirable)
    ("hypertension_stage_2", "desirable", "high", "any", "any"): "beta_blocker",
    ("hypertension_stage_2", "desirable", "medium", "any", "any"): "amlodipine",
    ("hypertension_stage_2", "desirable", "low", "any", "any"): "lifestyle_monitoring",

    # ضغط متوسط (stage 1) مع high (تحليل بيانات: stage_1/high)
    ("hypertension_stage_1", "high", "high", "any", "any"): "amlodipine_and_thiazide",
    ("hypertension_stage_1", "high", "medium", "any", "any"): "atenolol",
    ("hypertension_stage_1", "high", "low", "any", "any"): "diet_control",

    # ضغط متوسط مع borderline_high (تحليل بيانات: stage_1/borderline_high)
    ("hypertension_stage_1", "borderline_high", "high", "any", "any"): "amlodipine_and_thiazide",
    ("hypertension_stage_1", "borderline_high", "medium", "any", "any"): "ace_inhibitor",
    ("hypertension_stage_1", "borderline_high", "low", "any", "any"): "low_sodium_diet",

    # ضغط متوسط مع desirable (تحليل بيانات: stage_1/desirable)
    ("hypertension_stage_1", "desirable", "high", "any", "any"): "beta_blocker",
    ("hypertension_stage_1", "desirable", "medium", "any", "any"): "thiazide_diuretic",
    ("hypertension_stage_1", "desirable", "low", "any", "any"): "lifestyle_monitoring",

    # ضغط طبيعي أو منخفض مع كوليسترول مرتفع أو طبيعي، جميع الخطورات (تحليل: normal/borderline_high/high)
    ("normal", "desirable", "low", "any", "any"): "lifestyle_monitoring",
    ("normal", "borderline_high", "low", "any", "any"): "diet_control",
    ("normal", "high", "low", "any", "any"): "diet_control",

    # دمج حالات السكر وألم الصدر (تحليل: medium risk مع سكر/ألم)
    ("hypertension_stage_1", "any", "medium", "high_fbs", "any"): "atenolol",
    ("hypertension_stage_1", "any", "medium", "moderate_fbs", "any"): "ace_inhibitor",
    ("hypertension_stage_1", "any", "medium", "any", "moderate_cp"): "ace_inhibitor",

    # === Added: synchronize uncovered contexts into MEDICAL_RECOMMENDATION_PLAN (age-agnostic) ===
    ("hypertensive_crisis", "high", "medium", "normal_fbs", "typical_angina"): "emergency_admission",
    ("normal", "borderline_high", "low", "normal_fbs", "typical_angina"): "lifestyle_monitoring",
    ("elevated", "borderline_high", "medium", "high_fbs", "atypical_angina"): "ace_inhibitor",
    ("hypertension_stage_1", "borderline_high", "medium", "normal_fbs", "typical_angina"): "beta_blocker",
    ("hypertension_stage_2", "high", "medium", "normal_fbs", "atypical_angina"): "amlodipine",

    # === Added: clinical generalizations for robust matching ===
    ("hypertensive_crisis", "any", "medium", "any", "any"): "emergency_admission",
    ("hypertension_stage_2", "high", "medium", "any", "any"): "amlodipine",
    ("hypertension_stage_1", "borderline_high", "medium", "any", "any"): "ace_inhibitor",

    # fallback الشامل
    ("any", "any", "any", "any", "any"): "manual_review"
}

# <<< AUTO-EXPANDED MEDICAL_RECOMMENDATION_PLAN (generated)
# generated at 2025-09-30 21:28:13
MEDICAL_RECOMMENDATION_PLAN.update({
    ('elevated', 'borderline_high', 'high', 'high_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('elevated', 'borderline_high', 'high', 'high_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('elevated', 'borderline_high', 'high', 'high_fbs', 'typical_angina'): 'ace_inhibitor',
    ('elevated', 'borderline_high', 'high', 'normal_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('elevated', 'borderline_high', 'high', 'normal_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('elevated', 'borderline_high', 'high', 'normal_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('elevated', 'borderline_high', 'high', 'normal_fbs', 'typical_angina'): 'ace_inhibitor',
    ('elevated', 'borderline_high', 'medium', 'high_fbs', 'asymptomatic'): 'increase_exercise',
    ('elevated', 'borderline_high', 'medium', 'high_fbs', 'atypical_angina'): 'increase_exercise',
    ('elevated', 'borderline_high', 'medium', 'high_fbs', 'typical_angina'): 'increase_exercise',
    ('elevated', 'borderline_high', 'medium', 'normal_fbs', 'asymptomatic'): 'increase_exercise',
    ('elevated', 'borderline_high', 'medium', 'normal_fbs', 'atypical_angina'): 'increase_exercise',
    ('elevated', 'borderline_high', 'medium', 'normal_fbs', 'non_anginal_pain'): 'increase_exercise',
    ('elevated', 'borderline_high', 'medium', 'normal_fbs', 'typical_angina'): 'increase_exercise',
    ('elevated', 'desirable', 'high', 'normal_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('elevated', 'desirable', 'high', 'normal_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('elevated', 'desirable', 'high', 'normal_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('elevated', 'desirable', 'high', 'normal_fbs', 'typical_angina'): 'ace_inhibitor',
    ('elevated', 'desirable', 'low', 'normal_fbs', 'non_anginal_pain'): 'increase_exercise',
    ('elevated', 'desirable', 'low', 'normal_fbs', 'typical_angina'): 'increase_exercise',
    ('elevated', 'desirable', 'medium', 'high_fbs', 'atypical_angina'): 'increase_exercise',
    ('elevated', 'desirable', 'medium', 'normal_fbs', 'asymptomatic'): 'increase_exercise',
    ('elevated', 'desirable', 'medium', 'normal_fbs', 'atypical_angina'): 'increase_exercise',
    ('elevated', 'desirable', 'medium', 'normal_fbs', 'non_anginal_pain'): 'increase_exercise',
    ('elevated', 'desirable', 'medium', 'normal_fbs', 'typical_angina'): 'increase_exercise',
    ('elevated', 'high', 'high', 'high_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('elevated', 'high', 'high', 'high_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('elevated', 'high', 'high', 'normal_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('elevated', 'high', 'high', 'normal_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('elevated', 'high', 'high', 'normal_fbs', 'typical_angina'): 'ace_inhibitor',
    ('elevated', 'high', 'medium', 'high_fbs', 'asymptomatic'): 'diet_control',
    ('elevated', 'high', 'medium', 'high_fbs', 'atypical_angina'): 'diet_control',
    ('elevated', 'high', 'medium', 'normal_fbs', 'asymptomatic'): 'diet_control',
    ('elevated', 'high', 'medium', 'normal_fbs', 'atypical_angina'): 'diet_control',
    ('elevated', 'high', 'medium', 'normal_fbs', 'typical_angina'): 'diet_control',
    ('hypertension_stage_1', 'borderline_high', 'high', 'normal_fbs', 'asymptomatic'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'borderline_high', 'high', 'normal_fbs', 'atypical_angina'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'borderline_high', 'high', 'normal_fbs', 'non_anginal_pain'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'borderline_high', 'high', 'normal_fbs', 'typical_angina'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'borderline_high', 'low', 'normal_fbs', 'typical_angina'): 'diet_control',
    ('hypertension_stage_1', 'borderline_high', 'medium', 'normal_fbs', 'asymptomatic'): 'diet_control',
    ('hypertension_stage_1', 'borderline_high', 'medium', 'normal_fbs', 'atypical_angina'): 'diet_control',
    ('hypertension_stage_1', 'borderline_high', 'medium', 'normal_fbs', 'non_anginal_pain'): 'diet_control',
    ('hypertension_stage_1', 'borderline_high', 'medium', 'normal_fbs', 'typical_angina'): 'diet_control',
    ('hypertension_stage_1', 'desirable', 'high', 'high_fbs', 'atypical_angina'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'desirable', 'high', 'normal_fbs', 'asymptomatic'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'desirable', 'high', 'normal_fbs', 'atypical_angina'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'desirable', 'medium', 'high_fbs', 'atypical_angina'): 'diet_control',
    ('hypertension_stage_1', 'desirable', 'medium', 'normal_fbs', 'asymptomatic'): 'diet_control',
    ('hypertension_stage_1', 'desirable', 'medium', 'normal_fbs', 'atypical_angina'): 'diet_control',
    ('hypertension_stage_1', 'high', 'high', 'high_fbs', 'asymptomatic'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'high', 'high', 'high_fbs', 'atypical_angina'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'high', 'high', 'high_fbs', 'non_anginal_pain'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'high', 'high', 'high_fbs', 'typical_angina'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'high', 'high', 'normal_fbs', 'asymptomatic'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'high', 'high', 'normal_fbs', 'atypical_angina'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'high', 'high', 'normal_fbs', 'typical_angina'): 'amlodipine_and_thiazide',
    ('hypertension_stage_1', 'high', 'medium', 'high_fbs', 'asymptomatic'): 'diet_control',
    ('hypertension_stage_1', 'high', 'medium', 'high_fbs', 'atypical_angina'): 'diet_control',
    ('hypertension_stage_1', 'high', 'medium', 'high_fbs', 'non_anginal_pain'): 'diet_control',
    ('hypertension_stage_1', 'high', 'medium', 'high_fbs', 'typical_angina'): 'diet_control',
    ('hypertension_stage_1', 'high', 'medium', 'normal_fbs', 'asymptomatic'): 'diet_control',
    ('hypertension_stage_1', 'high', 'medium', 'normal_fbs', 'atypical_angina'): 'diet_control',
    ('hypertension_stage_1', 'high', 'medium', 'normal_fbs', 'typical_angina'): 'diet_control',
    ('hypertension_stage_2', 'borderline_high', 'high', 'high_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'high', 'high_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'high', 'high_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'high', 'normal_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'high', 'normal_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'high', 'normal_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'high', 'normal_fbs', 'typical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'medium', 'high_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'medium', 'high_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'medium', 'high_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'medium', 'normal_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'medium', 'normal_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'medium', 'normal_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('hypertension_stage_2', 'borderline_high', 'medium', 'normal_fbs', 'typical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'desirable', 'high', 'high_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('hypertension_stage_2', 'desirable', 'high', 'high_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'desirable', 'high', 'normal_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('hypertension_stage_2', 'desirable', 'high', 'normal_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'desirable', 'high', 'normal_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('hypertension_stage_2', 'desirable', 'high', 'normal_fbs', 'typical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'desirable', 'medium', 'high_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('hypertension_stage_2', 'desirable', 'medium', 'high_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'desirable', 'medium', 'normal_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('hypertension_stage_2', 'desirable', 'medium', 'normal_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'desirable', 'medium', 'normal_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('hypertension_stage_2', 'desirable', 'medium', 'normal_fbs', 'typical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'high', 'high_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'high', 'high_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'high', 'high_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'high', 'normal_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'high', 'normal_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'high', 'normal_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'high', 'normal_fbs', 'typical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'medium', 'high_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'medium', 'high_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'medium', 'high_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'medium', 'normal_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'medium', 'normal_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'medium', 'normal_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('hypertension_stage_2', 'high', 'medium', 'normal_fbs', 'typical_angina'): 'ace_inhibitor',
    ('hypertensive_crisis', 'high', 'high', 'high_fbs', 'asymptomatic'): 'emergency_admission',
    ('hypertensive_crisis', 'high', 'high', 'high_fbs', 'atypical_angina'): 'emergency_admission',
    ('hypertensive_crisis', 'high', 'high', 'normal_fbs', 'asymptomatic'): 'emergency_admission',
    ('hypertensive_crisis', 'high', 'high', 'normal_fbs', 'typical_angina'): 'emergency_admission',
    ('hypertensive_crisis', 'high', 'medium', 'high_fbs', 'asymptomatic'): 'emergency_admission',
    ('hypertensive_crisis', 'high', 'medium', 'high_fbs', 'atypical_angina'): 'emergency_admission',
    ('hypertensive_crisis', 'high', 'medium', 'normal_fbs', 'asymptomatic'): 'emergency_admission',
    ('hypertensive_crisis', 'high', 'medium', 'normal_fbs', 'typical_angina'): 'emergency_admission',
    ('normal', 'borderline_high', 'high', 'high_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('normal', 'borderline_high', 'high', 'normal_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('normal', 'borderline_high', 'high', 'normal_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('normal', 'borderline_high', 'high', 'normal_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('normal', 'borderline_high', 'high', 'normal_fbs', 'typical_angina'): 'ace_inhibitor',
    ('normal', 'borderline_high', 'low', 'normal_fbs', 'atypical_angina'): 'lifestyle_monitoring',
    ('normal', 'borderline_high', 'low', 'normal_fbs', 'typical_angina'): 'lifestyle_monitoring',
    ('normal', 'borderline_high', 'medium', 'high_fbs', 'asymptomatic'): 'lifestyle_monitoring',
    ('normal', 'borderline_high', 'medium', 'normal_fbs', 'asymptomatic'): 'lifestyle_monitoring',
    ('normal', 'borderline_high', 'medium', 'normal_fbs', 'atypical_angina'): 'lifestyle_monitoring',
    ('normal', 'borderline_high', 'medium', 'normal_fbs', 'non_anginal_pain'): 'lifestyle_monitoring',
    ('normal', 'borderline_high', 'medium', 'normal_fbs', 'typical_angina'): 'lifestyle_monitoring',
    ('normal', 'desirable', 'high', 'normal_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('normal', 'desirable', 'high', 'normal_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('normal', 'desirable', 'low', 'high_fbs', 'typical_angina'): 'lifestyle_monitoring',
    ('normal', 'desirable', 'low', 'normal_fbs', 'asymptomatic'): 'lifestyle_monitoring',
    ('normal', 'desirable', 'low', 'normal_fbs', 'atypical_angina'): 'lifestyle_monitoring',
    ('normal', 'desirable', 'low', 'normal_fbs', 'non_anginal_pain'): 'lifestyle_monitoring',
    ('normal', 'desirable', 'low', 'normal_fbs', 'typical_angina'): 'lifestyle_monitoring',
    ('normal', 'desirable', 'medium', 'high_fbs', 'typical_angina'): 'lifestyle_monitoring',
    ('normal', 'desirable', 'medium', 'normal_fbs', 'asymptomatic'): 'lifestyle_monitoring',
    ('normal', 'desirable', 'medium', 'normal_fbs', 'atypical_angina'): 'lifestyle_monitoring',
    ('normal', 'desirable', 'medium', 'normal_fbs', 'non_anginal_pain'): 'lifestyle_monitoring',
    ('normal', 'desirable', 'medium', 'normal_fbs', 'typical_angina'): 'lifestyle_monitoring',
    ('normal', 'high', 'high', 'high_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('normal', 'high', 'high', 'normal_fbs', 'asymptomatic'): 'ace_inhibitor',
    ('normal', 'high', 'high', 'normal_fbs', 'atypical_angina'): 'ace_inhibitor',
    ('normal', 'high', 'high', 'normal_fbs', 'non_anginal_pain'): 'ace_inhibitor',
    ('normal', 'high', 'high', 'normal_fbs', 'typical_angina'): 'ace_inhibitor',
    ('normal', 'high', 'medium', 'high_fbs', 'atypical_angina'): 'diet_control',
    ('normal', 'high', 'medium', 'normal_fbs', 'asymptomatic'): 'diet_control',
    ('normal', 'high', 'medium', 'normal_fbs', 'atypical_angina'): 'diet_control',
    ('normal', 'high', 'medium', 'normal_fbs', 'non_anginal_pain'): 'diet_control',
    ('normal', 'high', 'medium', 'normal_fbs', 'typical_angina'): 'diet_control',
})
# >>> AUTO-EXPANDED MEDICAL_RECOMMENDATION_PLAN (generated)

def _normalize_med_plan_keys():
    """
    Ensure all MEDICAL_RECOMMENDATION_PLAN keys are normalized (lowercased/canonical)
    to avoid miss due to inconsistent labels. No-op on errors.
    """
    try:
        updated = {}
        for k, v in list(MEDICAL_RECOMMENDATION_PLAN.items()):
            if isinstance(k, tuple):
                nk = tuple(normalize_label(x) for x in k)
                updated[nk] = v
            else:
                updated[k] = v
        MEDICAL_RECOMMENDATION_PLAN.clear()
        MEDICAL_RECOMMENDATION_PLAN.update(updated)
    except (TypeError, ValueError, AttributeError):
        # best-effort only
        pass

# Normalize MEDICAL_RECOMMENDATION_PLAN keys once at import time
_normalize_med_plan_keys()

RECOMMENDATION_EXPLAIN = {
    # المراقبة وتغيير النمط الحياتي
    "lifestyle_monitoring": (
        "مراقبة منتظمة للضغط وتغيير النمط الحياتي: تقليل الملح، ممارسة الرياضة، فقدان الوزن، والامتناع عن التدخين."
        " يُنصح بها للحالات ذات الخطورة المنخفضة أو المتوسطة، أو كبار السن (>75) أو عند وجود مضاعفات للأدوية."
    ),
    "diet_control": (
        "اتباع نظام غذائي منخفض الصوديوم والدهون مع زيادة تناول الفواكه والخضراوات."
        " مناسب للحالات ذات الكوليسترول المرتفع أو borderline high مع خطورة منخفضة أو متوسطة."
    ),
    "increase_exercise": (
        "زيادة النشاط البدني (150 دقيقة/أسبوع على الأقل)، وتقليل نمط الحياة الخامل."
        " يساعد في خفض الضغط وخطر أمراض القلب، خصوصًا للبالغين في المراحل المبكرة."
    ),

    # أدوية الضغط الأساسية
    "thiazide_diuretic": (
        "مدر بول من عائلة الثيازايد، يستخدم كخط العلاج الأول للضغط المرتفع خصوصًا في المراحل الأولى أو مع خطورة متوسطة."
        " يُنصح بمراقبة الصوديوم والبوتاسيوم أثناء العلاج."
    ),
    # --- Thiazide class aliases ---
    "thiazide": (
        "مدر بول من عائلة الثيازايد، يستخدم كخط العلاج الأول للضغط المرتفع خصوصًا في المراحل الأولى أو مع خطورة متوسطة."
        " يُنصح بمراقبة الصوديوم والبوتاسيوم أثناء العلاج."
    ),
    "hctz": (
        "مدر بول من عائلة الثيازايد، يستخدم كخط العلاج الأول للضغط المرتفع خصوصًا في المراحل الأولى أو مع خطورة متوسطة."
        " يُنصح بمراقبة الصوديوم والبوتاسيوم أثناء العلاج."
    ),
    "hydrochlorothiazide": (
        "مدر بول من عائلة الثيازايد، يستخدم كخط العلاج الأول للضغط المرتفع خصوصًا في المراحل الأولى أو مع خطورة متوسطة."
        " يُنصح بمراقبة الصوديوم والبوتاسيوم أثناء العلاج."
    ),
    "chlorthalidone": (
        "مدر بول من عائلة الثيازايد، يستخدم كخط العلاج الأول للضغط المرتفع خصوصًا في المراحل الأولى أو مع خطورة متوسطة."
        " يُنصح بمراقبة الصوديوم والبوتاسيوم أثناء العلاج."
    ),
    # --- End Thiazide aliases ---
    "amlodipine": (
        "دواء أملوديبين (محصر قناة الكالسيوم)، فعال كخط أول أو مع الأدوية الأخرى لعلاج ارتفاع الضغط خاصة مع السكري أو كبار السن."
    ),
    # --- Amlodipine aliases ---
    "norvasc": (
        "دواء أملوديبين (محصر قناة الكالسيوم)، فعال كخط أول أو مع الأدوية الأخرى لعلاج ارتفاع الضغط خاصة مع السكري أو كبار السن."
    ),
    "ccb": (
        "دواء أملوديبين (محصر قناة الكالسيوم)، فعال كخط أول أو مع الأدوية الأخرى لعلاج ارتفاع الضغط خاصة مع السكري أو كبار السن."
    ),
    # --- End Amlodipine aliases ---
    "amlodipine_and_thiazide": (
        "مزيج دوائي (أملوديبين + مدر بول ثيازايد)، يُستخدم للحالات الشديدة (Hypertension Stage 2, high risk) خاصة إذا كان هناك سكري أو فشل في العلاج الأحادي."
    ),
    "losartan": (
        "دواء لوسارتان (محصر مستقبلات الأنجيوتنسين)، فعال لعلاج الضغط خصوصًا في حالات الخطورة المتوسطة أو المصاحبة لأمراض مزمنة كالسكري أو أمراض الكلى."
    ),
    "ace_inhibitor": (
        "مثبطات الإنزيم المحول للأنجيوتنسين (ACE inhibitors) تُعد خيارًا أساسيًا للضغط المرتفع خاصة في المرضى المصابين بالسكري، أمراض الكلى، أو بعد الجلطة القلبية."
    ),
    # --- ACE inhibitor aliases ---
    "ace": (
        "مثبطات الإنزيم المحول للأنجيوتنسين (ACE inhibitors) تُعد خيارًا أساسيًا للضغط المرتفع خاصة في المرضى المصابين بالسكري، أمراض الكلى، أو بعد الجلطة القلبية."
    ),
    "acei": (
        "مثبطات الإنزيم المحول للأنجيوتنسين (ACE inhibitors) تُعد خيارًا أساسيًا للضغط المرتفع خاصة في المرضى المصابين بالسكري، أمراض الكلى، أو بعد الجلطة القلبية."
    ),
    # --- End ACE inhibitor aliases ---
    "arb": (
        "محصرات مستقبلات الأنجيوتنسين (ARBs) مثل لوسارتان/فالسارتان؛ بديل فعّال لمثبطات ACE خاصة عند السعال أو عدم التحمل. "
        "مناسبة لارتفاع الضغط مع السكري أو مرض كلوي مرافق، مع متابعة وظائف الكلى والبوتاسيوم."
    ),
    # --- ARB aliases ---
    "valsartan": (
        "محصرات مستقبلات الأنجيوتنسين (ARBs) مثل لوسارتان/فالسارتان؛ بديل فعّال لمثبطات ACE خاصة عند السعال أو عدم التحمل. "
        "مناسبة لارتفاع الضغط مع السكري أو مرض كلوي مرافق، مع متابعة وظائف الكلى والبوتاسيوم."
    ),
    "irbesartan": (
        "محصرات مستقبلات الأنجيوتنسين (ARBs) مثل لوسارتان/فالسارتان؛ بديل فعّال لمثبطات ACE خاصة عند السعال أو عدم التحمل. "
        "مناسبة لارتفاع الضغط مع السكري أو مرض كلوي مرافق، مع متابعة وظائف الكلى والبوتاسيوم."
    ),
    "candesartan": (
        "محصرات مستقبلات الأنجيوتنسين (ARBs) مثل لوسارتان/فالسارتان؛ بديل فعّال لمثبطات ACE خاصة عند السعال أو عدم التحمل. "
        "مناسبة لارتفاع الضغط مع السكري أو مرض كلوي مرافق، مع متابعة وظائف الكلى والبوتاسيوم."
    ),
    "olmesartan": (
        "محصرات مستقبلات الأنجيوتنسين (ARBs) مثل لوسارتان/فالسارتان؛ بديل فعّال لمثبطات ACE خاصة عند السعال أو عدم التحمل. "
        "مناسبة لارتفاع الضغط مع السكري أو مرض كلوي مرافق، مع متابعة وظائف الكلى والبوتاسيوم."
    ),
    "cozaar": (
        "محصرات مستقبلات الأنجيوتنسين (ARBs) مثل لوسارتان/فالسارتان؛ بديل فعّال لمثبطات ACE خاصة عند السعال أو عدم التحمل. "
        "مناسبة لارتفاع الضغط مع السكري أو مرض كلوي مرافق، مع متابعة وظائف الكلى والبوتاسيوم."
    ),
    "diovan": (
        "محصرات مستقبلات الأنجيوتنسين (ARBs) مثل لوسارتان/فالسارتان؛ بديل فعّال لمثبطات ACE خاصة عند السعال أو عدم التحمل. "
        "مناسبة لارتفاع الضغط مع السكري أو مرض كلوي مرافق، مع متابعة وظائف الكلى والبوتاسيوم."
    ),
    "avapro": (
        "محصرات مستقبلات الأنجيوتنسين (ARBs) مثل لوسارتان/فالسارتان؛ بديل فعّال لمثبطات ACE خاصة عند السعال أو عدم التحمل. "
        "مناسبة لارتفاع الضغط مع السكري أو مرض كلوي مرافق، مع متابعة وظائف الكلى والبوتاسيوم."
    ),
    "benicar": (
        "محصرات مستقبلات الأنجيوتنسين (ARBs) مثل لوسارتان/فالسارتان؛ بديل فعّال لمثبطات ACE خاصة عند السعال أو عدم التحمل. "
        "مناسبة لارتفاع الضغط مع السكري أو مرض كلوي مرافق، مع متابعة وظائف الكلى والبوتاسيوم."
    ),
    # --- End ARB aliases ---
    "statin": (
        "الستاتينات (مثل أتورفاستاتين/روسوفاستاتين) للمرضى ذوي الكوليسترول المرتفع أو خطورة قلبية وعائية أعلى؛ "
        "تُستخدم لخفض LDL وتقليل المخاطر القلبية الوعائية على المدى البعيد، مع متابعة وظائف الكبد."
    ),
    # --- Statin aliases ---
    "atorvastatin": (
        "الستاتينات (مثل أتورفاستاتين/روسوفاستاتين) للمرضى ذوي الكوليسترول المرتفع أو خطورة قلبية وعائية أعلى؛ "
        "تُستخدم لخفض LDL وتقليل المخاطر القلبية الوعائية على المدى البعيد، مع متابعة وظائف الكبد."
    ),
    "rosuvastatin": (
        "الستاتينات (مثل أتورفاستاتين/روسوفاستاتين) للمرضى ذوي الكوليسترول المرتفع أو خطورة قلبية وعائية أعلى؛ "
        "تُستخدم لخفض LDL وتقليل المخاطر القلبية الوعائية على المدى البعيد، مع متابعة وظائف الكبد."
    ),
    "simvastatin": (
        "الستاتينات (مثل أتورفاستاتين/روسوفاستاتين) للمرضى ذوي الكوليسترول المرتفع أو خطورة قلبية وعائية أعلى؛ "
        "تُستخدم لخفض LDL وتقليل المخاطر القلبية الوعائية على المدى البعيد، مع متابعة وظائف الكبد."
    ),
    "pravastatin": (
        "الستاتينات (مثل أتورفاستاتين/روسوفاستاتين) للمرضى ذوي الكوليسترول المرتفع أو خطورة قلبية وعائية أعلى؛ "
        "تُستخدم لخفض LDL وتقليل المخاطر القلبية الوعائية على المدى البعيد، مع متابعة وظائف الكبد."
    ),
    "pitavastatin": (
        "الستاتينات (مثل أتورفاستاتين/روسوفاستاتين) للمرضى ذوي الكوليسترول المرتفع أو خطورة قلبية وعائية أعلى؛ "
        "تُستخدم لخفض LDL وتقليل المخاطر القلبية الوعائية على المدى البعيد، مع متابعة وظائف الكبد."
    ),
    # --- End Statin aliases ---

    # الأدوية المصاحبة لألم الصدر أو الحالات الخاصة
    "beta_blocker": (
        "حاصرات بيتا، تُضاف للعلاج في حالات ألم الصدر (angina) أو وجود تاريخ مرضي لمرض قلبي. تخفف من ضغط الدم وتقلل من خطر الذبحة الصدرية."
    ),
    # --- Beta-blocker aliases ---
    "metoprolol": (
        "حاصرات بيتا، تُضاف للعلاج في حالات ألم الصدر (angina) أو وجود تاريخ مرضي لمرض قلبي. تخفف من ضغط الدم وتقلل من خطر الذبحة الصدرية."
    ),
    "bisoprolol": (
        "حاصرات بيتا، تُضاف للعلاج في حالات ألم الصدر (angina) أو وجود تاريخ مرضي لمرض قلبي. تخفف من ضغط الدم وتقلل من خطر الذبحة الصدرية."
    ),
    "propranolol": (
        "حاصرات بيتا، تُضاف للعلاج في حالات ألم الصدر (angina) أو وجود تاريخ مرضي لمرض قلبي. تخفف من ضغط الدم وتقلل من خطر الذبحة الصدرية."
    ),
    "nebivolol": (
        "حاصرات بيتا، تُضاف للعلاج في حالات ألم الصدر (angina) أو وجود تاريخ مرضي لمرض قلبي. تخفف من ضغط الدم وتقلل من خطر الذبحة الصدرية."
    ),
    # --- End Beta-blocker aliases ---
    "atenolol": (
        "أتينولول (Beta-1 selective blocker)، يُستخدم خصوصًا في حالات ألم الصدر غير النمطي مع ارتفاع الضغط أو عند عدم تحمل العلاجات الأخرى."
    ),

    # الحميات الغذائية/الوقاية
    "low_sodium_diet": (
        "اتباع نظام غذائي منخفض الصوديوم ضروري في جميع حالات ارتفاع الضغط، ويُعد أساسياً عند borderline high cholesterol."
    ),

    # الإجراءات السريعة أو التحويل للطبيب/المستشفى
    "hospital_referral": (
        "تحويل عاجل للمستشفى بسبب ارتفاع خطورة الحالة أو فشل السيطرة على الضغط رغم العلاج."
    ),
    "emergency_admission": (
        "دخول عاجل للمستشفى ضروري في حالات الأزمة القلبية، أعراض فشل القلب الحادة، أو ارتفاع الضغط مع أعراض خطيرة (hypertensive crisis)."
    ),
    "manual_review": (
        "مطلوب مراجعة يدوية من الطبيب لأن التركيبة السريرية غير مغطاة بدليل سريري واضح أو تحتاج قراراً فردياً."
    ),
    "urgent_review": (
        "مطلوب تدخل طبي سريع – الحالة مصنفة كخطر مرتفع جدًا، يجب مراجعة الطبيب فورًا."
    ),

    # الحالات الخاصة أو الأقل شيوعًا
    "manual_review_low": (
        "تركيبة منخفضة الخطورة لكنها غير شائعة – يجب مراجعة الطبيب للتأكد من عدم وجود عوامل خطورة مخفية."
    ),
    "manual_review_medium": (
        "تركيبة متوسطة الخطورة وغير نمطية، يستلزم رأي سريري متخصص لتحديد الحاجة للعلاج الدوائي أو المراقبة."
    ),
    "manual_review_high": (
        "تركيبة مرتفعة الخطورة وغير شائعة، تحتاج مراجعة سريرية عاجلة لضمان عدم وجود خطورة كامنة."
    ),
}



# ------------------------------
# Typed accessors for clinical plan fields (reason/explanation/source)
# ------------------------------
class ClinicalPlanFields(TypedDict, total=False):
    reason: str
    explanation: str
    source: str

_DEFAULT_REASON: str = "Standard clinical plan"
_DEFAULT_EXPL: str = "Aligned with guideline-driven defaults."
_DEFAULT_SOURCE: str = "AHA/ESC consolidated"

def get_clinical_plan_fields(feature_id: str, overrides: Optional[Dict[str, str]] = None) -> ClinicalPlanFields:
    reason = _DEFAULT_REASON
    explanation = RECOMMENDATION_EXPLAIN.get(feature_id, _DEFAULT_EXPL)
    source = RECOMMENDATION_SOURCE.get(feature_id, _DEFAULT_SOURCE)

    base: ClinicalPlanFields = {
        "reason": reason,
        "explanation": explanation,
        "source": source,
    }
    if overrides:
        if overrides.get("reason"):
            base["reason"] = overrides["reason"]  # type: ignore[typeddict-item]
        if overrides.get("explanation"):
            base["explanation"] = overrides["explanation"]  # type: ignore[typeddict-item]
        if overrides.get("source"):
            base["source"] = overrides["source"]  # type: ignore[typeddict-item]
    return base
    # نمط الحياة والحميات



RECOMMENDATION_SOURCE = {

    "lifestyle_monitoring": "AHA 2023 Guideline, Section: Lifestyle Interventions",
    "diet_control": "AHA 2023 Guideline, Section: Dietary Approaches (DASH, sodium restriction)",
    "low_sodium_diet": "AHA 2023 Guideline; ESC/ESH 2023, Lifestyle modification",
    "increase_exercise": "AHA 2023 Guideline, Physical Activity Recommendations",

    # الأدوية الأساسية للضغط
    "thiazide_diuretic": "ESC/ESH 2023 Guidelines, Section: Pharmacological Treatment",
    # --- Thiazide class aliases ---
    "thiazide": "ESC/ESH 2023 Guidelines, Section: Pharmacological Treatment",
    "hctz": "ESC/ESH 2023 Guidelines, Section: Pharmacological Treatment",
    "hydrochlorothiazide": "ESC/ESH 2023 Guidelines, Section: Pharmacological Treatment",
    "chlorthalidone": "ESC/ESH 2023 Guidelines, Section: Pharmacological Treatment",
    # --- End Thiazide aliases ---
    "amlodipine": "AHA/ESC Guidelines (Amlodipine as first-line, esp. elderly/diabetics)",
    # --- Amlodipine aliases ---
    "norvasc": "AHA/ESC Guidelines (Amlodipine as first-line, esp. elderly/diabetics)",
    "ccb": "AHA/ESC Guidelines (Amlodipine as first-line, esp. elderly/diabetics)",
    # --- End Amlodipine aliases ---
    "amlodipine_and_thiazide": "AHA/ESC Guidelines, Combination Therapy for Stage 2 HTN",
    # --- ARB class and aliases ---
    "losartan": "AHA 2023 Guideline, ARBs as alternative to ACEi; ESC/ESH 2023 Pharmacologic Treatment",
    "valsartan": "AHA 2023 Guideline, ARBs as alternative to ACEi; ESC/ESH 2023 Pharmacologic Treatment",
    "irbesartan": "AHA 2023 Guideline, ARBs as alternative to ACEi; ESC/ESH 2023 Pharmacologic Treatment",
    "candesartan": "AHA 2023 Guideline, ARBs as alternative to ACEi; ESC/ESH 2023 Pharmacologic Treatment",
    "olmesartan": "AHA 2023 Guideline, ARBs as alternative to ACEi; ESC/ESH 2023 Pharmacologic Treatment",
    "cozaar": "AHA 2023 Guideline, ARBs as alternative to ACEi; ESC/ESH 2023 Pharmacologic Treatment",
    "diovan": "AHA 2023 Guideline, ARBs as alternative to ACEi; ESC/ESH 2023 Pharmacologic Treatment",
    "avapro": "AHA 2023 Guideline, ARBs as alternative to ACEi; ESC/ESH 2023 Pharmacologic Treatment",
    "benicar": "AHA 2023 Guideline, ARBs as alternative to ACEi; ESC/ESH 2023 Pharmacologic Treatment",
    "arb": "AHA 2023 Guideline, ARBs as alternative to ACEi; ESC/ESH 2023 Pharmacologic Treatment",
    # --- End ARB aliases ---
    "ace_inhibitor": "AHA 2023 & ESC/ESH 2023, ACE inhibitors as first-line for DM/CKD",
    # --- ACE inhibitor aliases ---
    "ace": "AHA 2023 & ESC/ESH 2023, ACE inhibitors as first-line for DM/CKD",
    "acei": "AHA 2023 & ESC/ESH 2023, ACE inhibitors as first-line for DM/CKD",
    # --- End ACE inhibitor aliases ---
    "statin": "AHA/ACC 2018–2022 Cholesterol Guidelines; ESC/EAS 2019 Dyslipidaemia Guidelines",
    # --- Statin molecule aliases ---
    "atorvastatin": "AHA/ACC 2018–2022 Cholesterol Guidelines; ESC/EAS 2019 Dyslipidaemia Guidelines",
    "rosuvastatin": "AHA/ACC 2018–2022 Cholesterol Guidelines; ESC/EAS 2019 Dyslipidaemia Guidelines",
    "simvastatin": "AHA/ACC 2018–2022 Cholesterol Guidelines; ESC/EAS 2019 Dyslipidaemia Guidelines",
    "pravastatin": "AHA/ACC 2018–2022 Cholesterol Guidelines; ESC/EAS 2019 Dyslipidaemia Guidelines",
    "pitavastatin": "AHA/ACC 2018–2022 Cholesterol Guidelines; ESC/EAS 2019 Dyslipidaemia Guidelines",
    # --- End Statin aliases ---

    # أدوية مصاحبة لحالات معينة
    "beta_blocker": "AHA 2023; ESC 2023, Use in angina/post-MI/arrhythmia",
    # --- Beta-blocker aliases ---
    "metoprolol": "AHA 2023; ESC 2023, Use in angina/post-MI/arrhythmia",
    "bisoprolol": "AHA 2023; ESC 2023, Use in angina/post-MI/arrhythmia",
    "propranolol": "AHA 2023; ESC 2023, Use in angina/post-MI/arrhythmia",
    "nebivolol": "AHA 2023; ESC 2023, Use in angina/post-MI/arrhythmia",
    # --- End Beta-blocker aliases ---
    "atenolol": "ESC/ESH 2023, Beta-blockers in specific scenarios",

    # إجراءات سريعة أو قرارات سريرية خاصة
    "hospital_referral": "Expert clinical decision, AHA/ESC Crisis Section",
    "emergency_admission": "Expert clinical decision, Hypertensive Emergency Protocols",
    "urgent_review": "Expert clinical decision, Red Flags in Hypertension",

    # fallback وحالات غير مغطاة
    "manual_review": "Fallback – No specific guideline covers this combination (Clinical judgment required)",
    "manual_review_low": "Fallback – No direct evidence, low risk (Clinical review needed)",
    "manual_review_medium": "Fallback – No direct evidence, moderate risk (Clinical review needed)",
    "manual_review_high": "Fallback – No direct evidence, high risk (Urgent clinical review required)",
    }


# ------------------------------
# قوائم مساعدة غير كاسرة لتصنيف نوع التوصية (نمط حياة vs أدوية)
# ------------------------------
# قوائم موسّعة تشمل المعرفات القانونية والمرادفات الشائعة لضمان عدم فقدان المطابقة
LIFESTYLE_FEATURES: list[str] = [
    "lifestyle_monitoring",
    "diet_control",
    "increase_exercise",
    "low_sodium_diet",
    # مرادفات نمط الحياة الشائعة (تُوحَّد لاحقًا عبر canonicalize_feature_id)
    "dash_diet",
    "weight_loss",
    "smoking_cessation",
]

DRUG_FEATURES: list[str] = [
    # أدوية أساسية/مركبة
    "thiazide_diuretic",
    "thiazide",
    "hctz",
    "hydrochlorothiazide",
    "chlorthalidone",

    "amlodipine",
    "norvasc",
    "ccb",

    "amlodipine_and_thiazide",

    "losartan",
    "valsartan",
    "irbesartan",
    "candesartan",
    "olmesartan",
    "arb",
    "cozaar",
    "diovan",
    "avapro",
    "benicar",

    "ace_inhibitor",
    "ace",
    "acei",

    "statin",
    "atorvastatin",
    "rosuvastatin",
    "simvastatin",
    "pravastatin",
    "pitavastatin",

    # محصرات بيتا/سيناريوهات خاصة
    "beta_blocker",
    "metoprolol",
    "bisoprolol",
    "propranolol",
    "nebivolol",
    "atenolol",
]

# تحسين الأداء: مجموعات جاهزة للتحقق السريع بدون إنشاء set في كل استدعاء
# ملاحظة: نحول العناصر عبر sanitize_feature_id للتماسك مع canonicalize_feature_id ثم نجمدها.
# --- Robust sanitize_feature_id defined early to avoid NameError during import ---
def sanitize_feature_id(value) -> str | None:
    """
    Normalize a feature-id string to canonical, or return None for nullish/empty.
    Uses `canonicalize_feature_id` and never raises.
    """
    if value is None:
        return None
    try:
        v = str(value).strip().lower()
    except (TypeError, ValueError, AttributeError):
        return None
    if not v:
        return None
    try:
        canon = canonicalize_feature_id(v)
    except (TypeError, ValueError, AttributeError):
        canon = None
    return canon if canon is not None else v

from typing import Optional, Iterable
from functools import lru_cache

def _to_canon_set(items: Iterable[str]) -> frozenset[str]:
    _acc: set[str] = set()
    for _it in items:
        _s = sanitize_feature_id(_it)
        if _s:
            _acc.add(_s)
    return frozenset(_acc)

FSET_LIFESTYLE: frozenset[str] = _to_canon_set(LIFESTYLE_FEATURES)
FSET_DRUG: frozenset[str] = _to_canon_set(DRUG_FEATURES)

def _is_nullish(x: object) -> bool:
    """
    Return True for nullish inputs:
    - None
    - Empty strings
    - String literals 'none' or 'nan'
    - Numeric NaN (after safe float conversion)
    Uses narrow exception handling to avoid 'Too broad exception clause'.
    """
    if x is None:
        return True
    # Safe string normalization
    try:
        s = str(x).strip().lower()
    except (TypeError, ValueError, AttributeError):
        return False

    if s in ("", "none", "nan"):
        return True

    # Try numeric path; treat NaN as nullish
    try:
        f = float(s)
    except (TypeError, ValueError):
        return False
    # NaN check without math.isnan (NaN != NaN)
    return f != f

def _norm_fid(x: object) -> str:
    try:
        if _is_nullish(x):
            return "unknown"
        return normalize_label(x)
    except (TypeError, ValueError, AttributeError):
        return "unknown"

@lru_cache(maxsize=4096)
def _canon_feature_id(fid: Optional[str]) -> Optional[str]:
    if fid is None:
        return None
    v = sanitize_feature_id(fid)
    if v is None:
        v = _norm_fid(fid)
    return v

def is_lifestyle_feature(feature_id: Optional[str]) -> bool:
    """إرجاع True إذا كانت التوصية من نوع نمط حياة/غير دوائي (يدعم المرادفات)."""
    cfid = _canon_feature_id(feature_id if feature_id is not None else "")
    return bool(cfid) and cfid in FSET_LIFESTYLE

def is_drug_feature(feature_id: Optional[str]) -> bool:
    """إرجاع True إذا كانت التوصية دوائية (أحادية أو مركبة) — يدعم الأسماء الجنيسة/التجارية والاختصارات."""
    cfid = _canon_feature_id(feature_id if feature_id is not None else "")
    return bool(cfid) and cfid in FSET_DRUG

# Back-compat shim: expose pharmacologic checker under the expected name
def is_pharmacologic_feature(feature_id: Optional[str]) -> bool:
    """Alias to is_drug_feature for backward compatibility."""
    return is_drug_feature(feature_id)

# دوال تصنيف ديناميكية محدثة لمؤشرات FBS وCP (متوافقة مع النظام والبيانات الفعلية)
def categorize_bp(systolic_bp) -> str:
    """
    تصنيف ضغط الدم الانقباضي بناءً على BP_CATEGORIES القياسية.
    يعيد bp_category المناسب (مثال: "Hypertension Stage 1", ...).
    يقبل قيمًا رقمية أو نصوصًا جاهزة (سيتم تطبيعها إن كانت تناظر اسم تصنيف).
    """
    # إن طُرح نص يطابق الاسم مباشرةً
    try:
        # يدعم مدخلات نصية مثل "Hypertension Stage 1"
        lbl = normalize_label(systolic_bp)  # قد ينجح إذا كانت القيمة اسم تصنيف
        if lbl in {normalize_label(k) for k in BP_CATEGORIES.keys()}:
            return lbl
    except (TypeError, ValueError, AttributeError):
        pass

    # مسار رقمي
    try:
        v = float(systolic_bp)
        # فحص NaN
        if v != v:
            return "unknown"
    except (TypeError, ValueError):
        return "unknown"

    for category, (lo, hi) in BP_CATEGORIES.items():
        try:
            if float(lo) <= v <= float(hi):
                return normalize_label(category)
        except (TypeError, ValueError):
            continue
    return "unknown"

def categorize_chol(cholesterol_level) -> str:
    """
    تصنيف الكوليسترول حسب العتبات التشغيلية: <=204 desirable, <=230 borderline_high, >230 high.
    يقبل أرقامًا أو تسميات جاهزة.
    """
    try:
        lbl = normalize_label(cholesterol_level)
        if lbl in {"desirable", "borderline_high", "high"}:
            return lbl
    except (TypeError, ValueError, AttributeError):
        pass

    try:
        v = float(cholesterol_level)
        if v != v:
            return "unknown"
    except (TypeError, ValueError):
        return "unknown"

    if v <= 204.0:
        return "desirable"
    elif v <= 230.0:
        return "borderline_high"
    elif v > 230.0:
        return "high"
    return "unknown"

def _normalize_fbs_label(x) -> str:
    if _is_nullish(x):
        return "unknown"
    s = normalize_label(x)
    if s in {"high", "high_fbs", "dm", "diabetes"}:
        return "high_fbs"
    if s in {"normal", "normal_fbs", "pre_dm", "prediabetes"}:
        return "normal_fbs"
    return s

def categorize_fbs(fbs_level) -> str:
    """
    تصنيف سكر الدم الصائم (FBS) مع دعم المدخلات النصية (>=126 → high_fbs).
    """
    try:
        v = float(fbs_level)
        if v != v:
            return _normalize_fbs_label(fbs_level)
        return "high_fbs" if v >= 126.0 else "normal_fbs"
    except (TypeError, ValueError):
        return _normalize_fbs_label(fbs_level)

def categorize_cp(cp_label) -> str:
    """
    تصنيف ألم الصدر إلى أربع فئات معتمدة في بيانات النظام مع دعم المرادفات.
    """
    if _is_nullish(cp_label):
        return "unknown"
    s = normalize_label(cp_label)
    synonyms = {
        "typical_angina": {"ta", "typical", "typical-angina", "typical_angina"},
        "atypical_angina": {"aa", "atypical", "atypical-angina", "atypical_angina"},
        "non_anginal_pain": {"nap", "non-anginal", "non_anginal", "non_anginal_pain"},
        "asymptomatic": {"no_pain", "asx", "asympt", "asymptomatic"},
    }
    for canon, alts in synonyms.items():
        if s == canon or s in alts:
            return canon
    allowed = {"asymptomatic", "atypical_angina", "non_anginal_pain", "typical_angina"}
    return s if s in allowed else "unknown"

def build_context_key(
    bp_cat, chol_cat, risk_level, fbs_cat: str = "any", cp_cat: str = "any"
) -> tuple[str, str, str, str, str]:
    """
    توليد المفتاح المركب المستخدم في MEDICAL_RECOMMENDATION_PLAN.
    يتم دمج التصنيفات الخمسة في tuple (lowercased/canonical) مع دعم 'any'.
    """
    def _nz(v, default="any"):
        return normalize_label(v) if v else default

    return (
        _nz(bp_cat),
        _nz(chol_cat),
        _nz(risk_level),
        _nz(fbs_cat),
        _nz(cp_cat),
    )

def validate_context_key_length(key, expected_len: int = 5) -> None:
    """
    تحقق أن المفتاح السياقي يحوي العدد الصحيح من الأعمدة (أو tuple).
    raise ValueError إذا كان هناك خطأ لمنع فشل المطابقة.
    """
    if isinstance(key, tuple):
        if len(key) != expected_len:
            raise ValueError(f"[validate_context_key_length] طول المفتاح السياقي ({len(key)}) لا يطابق المطلوب ({expected_len}): {key}")
    elif isinstance(key, str):
        # صيغة نصية بــ "__" ليست مستخدمة هنا عادةً، لكن نُبقي الفحص حفاظًا على التوافق.
        if key.count("__") != expected_len - 1:
            raise ValueError(f"[validate_context_key_length] المفتاح السياقي النصي لا يحوي العدد الصحيح من الفواصل: {key}")


def get_medical_plan(bp_cat, chol_cat, risk_level, fbs_cat="any", cp_cat="any", log=None, input_context=None):
    # بناء السياق النهائي
    context = {
        "bp_cat": bp_cat,
        "chol_cat": chol_cat,
        "risk_level": risk_level,
        "fbs_cat": fbs_cat,
        "cp_cat": cp_cat
    }
    if input_context is not None:
        # إذا تم تمرير input_context، استخدمه (مع تحديث القيم الأساسية)
        context.update(input_context)

    key = build_context_key(bp_cat, chol_cat, risk_level, fbs_cat, cp_cat)
    validate_context_key_length(key, expected_len=5)
    # تحقق من وجود التوصية مباشرة في القاموس الذكي
    if key in MEDICAL_RECOMMENDATION_PLAN:
        rec = MEDICAL_RECOMMENDATION_PLAN[key]
        if not isinstance(rec, dict):
            rec = canonicalize_feature_id(rec) or rec
        result = plan_as_dict(rec, context=context)
        result["context"] = context
        return result

    # مطابقة وايلدكارد في MEDICAL_RECOMMENDATION_PLAN
    _matched_key, _val = find_best_context_match(MEDICAL_RECOMMENDATION_PLAN, key, wildcard="any")
    if _matched_key is not None and _matched_key != key:
        if hasattr(log, "warning") and callable(log.warning):
            log.warning(f"[get_medical_plan] Wildcard match in MEDICAL_RECOMMENDATION_PLAN: {key} -> {_matched_key}")
        rec = _val
        if not isinstance(rec, dict):
            rec = canonicalize_feature_id(rec) or rec
        result = plan_as_dict(rec, context=context)
        result["context"] = context
        result["fallback_layer"] = "med_plan_wildcard"
        return result

    # fallback: جرب تقليل التعقيد تدريجياً للبحث في القاموس
    key_simple = (key[0], key[1], key[2], "any", "any")
    if key_simple in MEDICAL_RECOMMENDATION_PLAN:
        if hasattr(log, "warning") and callable(log.warning):
            log.warning(f"[get_medical_plan] Fallback to key_simple (bp/chol/risk only): {context}")
        rec = MEDICAL_RECOMMENDATION_PLAN[key_simple]
        if not isinstance(rec, dict):
            rec = canonicalize_feature_id(rec) or rec
        result = plan_as_dict(rec, context=context)
        result["context"] = context
        result["fallback_layer"] = "key_simple"
        return result

    # fallback: استخدم CONTEXT_TO_RECOMMENDATION_MAP بمفتاح سداسي عبر make_context_key (bp, chol, risk, fbs=any, cp=any, age_group=any)
    context_key_6 = make_context_key(
        {
            "bp_category": key[0],
            "chol_category": key[1],
            "risk_level": key[2],
            "fbs_cat": "any",
            "cp_cat": "any",
            "age_group": "any",
        },
        context_columns=CONTEXT_COLUMNS,
    )
    _match6, _val6 = find_best_context_match(CONTEXT_TO_RECOMMENDATION_MAP, context_key_6, wildcard="any")
    if _match6 is not None:
        if hasattr(log, "warning") and callable(log.warning):
            log.warning(f"[get_medical_plan] Fallback to CONTEXT_TO_RECOMMENDATION_MAP wildcard: {context_key_6} -> {_match6}")
        rec = _val6
        if not isinstance(rec, dict):
            rec = canonicalize_feature_id(rec) or rec
        result = plan_as_dict(rec, context=context)
        result["context"] = context
        result["fallback_layer"] = "context_to_recommendation_map_wildcard"
        return result

    # fallback: استخدم FEATURE_ID_BINNED_MAP إذا كان bp_cat و chol_cat و risk_level تتوافق مع binning
    feature_id_key = f"{bp_cat}__{chol_cat}__{risk_level}"
    if feature_id_key in FEATURE_ID_BINNED_MAP:
        if hasattr(log, "warning") and callable(log.warning):
            log.warning(f"[get_medical_plan] Fallback to FEATURE_ID_BINNED_MAP: {context}")
        rec = FEATURE_ID_BINNED_MAP[feature_id_key]
        if not isinstance(rec, dict):
            rec = canonicalize_feature_id(rec) or rec
        result = plan_as_dict(rec, context=context)
        result["context"] = context
        result["fallback_layer"] = "feature_id_binned_map"
        return result

    # fallback احترافي: تحليل أوتوماتيكي لمستوى الخطورة وتوليد توصية احترافية مخصصة
    def _normalize(val):
        if val is None:
            return ""
        return str(val).lower()
    _bp = _normalize(bp_cat)
    _chol = _normalize(chol_cat)
    _risk = _normalize(risk_level)
    _fbs = _normalize(fbs_cat)
    _cp = _normalize(cp_cat)
    high_risk_triggers = [
        "hypertensive_crisis", "stage_2", "hypertension_stage_2", "high_fbs", "severe_cp", "high"
    ]
    medium_risk_triggers = [
        "stage_1", "hypertension_stage_1", "borderline_high", "medium"
    ]
    low_risk_triggers = [
        "normal", "desirable", "low"
    ]
    if any(x in (_bp, _chol, _risk, _fbs, _cp) for x in high_risk_triggers):
        fallback_risk = "high"
    elif any(x in (_bp, _chol, _risk, _fbs, _cp) for x in medium_risk_triggers):
        fallback_risk = "medium"
    elif any(x in (_bp, _chol, _risk, _fbs, _cp) for x in low_risk_triggers):
        fallback_risk = "low"
    else:
        fallback_risk = "unknown"

    if hasattr(log, "warning") and callable(log.warning):
        log.warning(f"[get_medical_plan] Fallback to final fallback ({fallback_risk}): context={context}")
    fallback_dict = {
        "action": "مراجعة يدوية من قبل الطبيب",
        "advice": (
            "لم يتمكن النظام من تصنيف حالتك بدقة استناداً إلى البيانات السريرية المتاحة. "
            "يرجى مراجعة الطبيب المختص لمزيد من التقييم والمتابعة."
        ),
        "explanation": (
            "هذه التوصية تم توليدها أوتوماتيكياً عبر fallback لتحليل مستوى الخطورة الظاهر، "
            f"ولم يتم العثور على تطابق كامل في القواميس الذكية. المدخلات: {context}"
        ),

        "source": f"Fallback Recommendation (Risk Level: {fallback_risk})",
        "context": context,
        "fallback_layer": "final",
        "risk_level": fallback_risk
    }
    return fallback_dict

# دالة مساعدة لتحويل اسم التوصية لناتج dict احترافي
def plan_as_dict(rec, context=None, fallback_reason=None, risk_level=None):
    """
    Convert a recommendation entry (string feature_id or dict) into a uniform dict.
    - Canonicalizes the action/feature_id.
    - Pulls reason/explanation/source from get_clinical_plan_fields.
    - Does not force-fill advice here; leaves it empty/unchanged so that
      pipeline-level `_fill_advice_fallbacks` provides consistent, centralized advice.
    """
    # Helper to canonicalize an action id safely
    def _canon_action(x):
        try:
            c = canonicalize_feature_id(x)
            return c if c is not None else sanitize_feature_id(x)
        except (TypeError, ValueError, AttributeError):
            return sanitize_feature_id(x)

    if isinstance(rec, dict):
        result = dict(rec)
        # Canonicalize embedded action if present
        if "action" in result and result["action"] is not None:
            result["action"] = _canon_action(result["action"]) or "manual_review"
        # Attach context / meta
        if context is not None:
            result.setdefault("context", context)
        if fallback_reason is not None:
            result["fallback_reason"] = fallback_reason
        if risk_level is not None:
            result["risk_level"] = risk_level
        # Fill clinical fields from typed accessor (based on action when available)
        act_for_fields = str(result.get("action", result.get("feature_id", "manual_review")))
        fields = get_clinical_plan_fields(act_for_fields)
        result.setdefault("reason", fields.get("reason"))
        result.setdefault("explanation", fields.get("explanation"))
        result.setdefault("source", fields.get("source"))
        # Do not overwrite pre-existing advice; if missing, leave empty for pipeline fillers
        if "advice" not in result or result["advice"] is None:
            result.setdefault("advice", "")
        return result

    # `rec` is expected to be a string feature_id/action
    action = _canon_action(rec) or "manual_review"
    fields = get_clinical_plan_fields(action)

    result = {
        "action": action,
        # leave advice to pipeline-level fallback fillers for consistency
        "advice": "",
        "explanation": fields.get("explanation"),
        "source": fields.get("source"),
        "reason": fields.get("reason"),
        "context": context if context is not None else {},
    }
    if fallback_reason is not None:
        result["fallback_reason"] = fallback_reason
    if risk_level is not None:
        result["risk_level"] = risk_level
    return result

# إعدادات ديناميكية (تُقرأ بأمان من config.yaml مع قيم افتراضية)
try:
    _CFG = get_config()
except (TypeError, ValueError, AttributeError, OSError):
    # Fall back to empty config on typical parsing/attribute/os errors.
    _CFG = {}

# واجهة TOP_N الآمنة
TOP_N = get_top_n_ui(_CFG)

# قسم recommendation من الإعدادات
_REC = (_CFG.get("recommendation", {}) if isinstance(_CFG, dict) else {}) or {}

try:
    MIN_INTERACTIONS = int(_REC.get("min_interactions", 5))
except (TypeError, ValueError):
    MIN_INTERACTIONS = 5

try:
    SCORE_THRESHOLD = float(_REC.get("score_threshold", 0.50))
except (TypeError, ValueError):
    SCORE_THRESHOLD = 0.50

# قائمة توصيات fallback الآمنة (قد تكون مفقودة)
_safe_fallback = _REC.get("safe_fallback_recommendations", [])
SAFE_FALLBACK_RECOMMENDATIONS = list(_safe_fallback) if isinstance(_safe_fallback, (list, tuple)) else []

try:
    FALLBACK_SCORE_CF = float(_REC.get("fallback_score_cf", 0.50))
except (TypeError, ValueError):
    FALLBACK_SCORE_CF = 0.50

# عتبات تقييم المخاطر من قسم constants (مع افتراضات آمنة)
_CONSTS = (_CFG.get("constants", {}) if isinstance(_CFG, dict) else {}) or {}
_RST = _CONSTS.get("risk_thresholds", None)
if isinstance(_RST, dict) and _RST:
    RISK_SCORE_THRESHOLDS = _RST
else:
    RISK_SCORE_THRESHOLDS = {"low": 0.20, "medium": 0.50, "high": 0.80}

# === Hybrid Bucketing & Conflict thresholds ===
CONFIDENCE_HIGH_MIN = 0.45
CONFIDENCE_MED_MIN = 0.20

SIM_HIGH_MIN = 0.70
SIM_MED_MIN = 0.50

CONFLICT_DELTA_MIN = 0.35

# BP_CATEGORIES : dict
# ----------------------
# تصنيفات ضغط الدَم الانقباضي وفقًا لتوصيات جمعية القلب الأمريكية (AHA 2023).
# تُستخدم هذه القيم لتصنيف المرضى وتحديد مستوى الخطر في النظام التوصي.
# 🩺 تصنيفات ضغط الدًم (Systolic BP) وفقًا لجمعية القلب الأمريكية AHA 2023 لتحديد مستويات الخطورة
# 📈 تصنيفات ضغط الدًم حسب جمعية القلب الأمريكية (AHA)
BP_CATEGORIES = {
    "Low": (0, 89),
    "Normal": (90, 119),
    "Elevated": (120, 129),
    "Hypertension Stage 1": (130, 139),
    "Hypertension Stage 2": (140, 179),
    "Hypertensive Crisis": (180, float('inf'))
}

# 📝 أسماء تصنيفات ضغط الدًم مُستخرجة من القاموس أعلاه لاستخدامها في العروض أو المعالجات
BP_CATEGORY_NAMES = list(BP_CATEGORIES.keys())

# AGE_GROUPS : list of str
# -------------------------
# تمثّل الفئات العمرية المُعتمدة لتقسيم المرضى وتحليل أنماط الخطر المرتبطة بالعمر.
# 🧠 تصنيفات الفئات العمرية (تعتمد على توصيات منظمة الصحة العالمية لتقييم أنماط المخاطر حسب العمر)
AGE_GROUPS = ["<18", "18–30", "31–45", "46–60", "61–75", "75+"]

BP_BIN4_LABELS = ["Q1", "Q2", "Q3", "Q4"]
CHOL_BINS_LABELS = [
    "(125.999, 204.0]", "(204.0, 230.0]", "(230.0, 254.0]",
    "(254.0, 286.0]", "(286.0, 564.0]"
]
AGE_Q3_LABELS = ["Young", "Middle", "Old"]

ALL_CONTEXT_FEATURES = [
    "bp_category", "chol_category", "risk_level", "age_group",
    "bp_bin4", "chol_bins", "age_q3", "feature_id_binned", "context_feature_id"
]

# Context columns used to build the triad-based binned key (feature_id_binned)
BINNED_CONTEXT_COLUMNS = ["bp_bin4", "chol_bins", "age_q3"]

# Helper to build normalized binned key (matches assign_feature_id_by_binned normalization)
def make_binned_key(bp_bin: str, chol_bin: str, age_bin: str) -> str:
    return f"{str(bp_bin)}__{str(chol_bin)}__{str(age_bin)}".replace(" ", "")

# 🧬 استخدام تعداد رسمي (Enum) لتعريف رموز الأمراض المزمنة لتسهيل الاستخدام والوضوح في البرمجة
from enum import Enum

# DiseaseCodes : Enum
# ---------------------
# تعريف رسمي لأكواد الأمراض المزمنة، يدعم نظام التوسعة المستقبلية بوضوح برمجي.
class DiseaseCodes(Enum):
    hypertension = 0
    diabetes = 1   # 🚧 مخصص لدعم أنظمة السكري لاحقًا
    stroke = 2     # 🚧 مخصص لدعم أنظمة السكتة الدماغية لاحقًا
    # 🚧 القيم أعلاه معرفة مسبقًا لدعم توسعة مستقبلية بدون الحاجة لتعديل لاحق في التعداد.




# --- Hooks for rule-based gap filling used by the plan generator (3.3) ---
CBF_FILL_RULES = {
    # Primary BP-driven action preference (tiered)
    "bp_to_action": {
        "normal": "lifestyle_monitoring",
        "elevated": "increase_exercise",
        "hypertension_stage_1": "diet_control",
        "hypertension_stage_2": "ace_inhibitor",
        "hypertensive_crisis": "emergency_admission",
    },
    # Risk modifiers (raise medication priority)
    "risk_bias": {
        "high": "drug_bias",
        "very_high": "drug_bias",
    },
    # Cholesterol bias (reinforce diet/exercise narrative)
    "chol_bias": {
        "high": "diet_bias",
        "borderline_high": "diet_bias",
    },
    # Age heuristics
    "age_bias": {
        "<18": "lifestyle_only",
        "18–30": "lifestyle_prefer",
        "61–75": "drug_prefer",
        "75+": "drug_prefer",
    },
}
from functools import lru_cache

def _to_norm_label(x: object) -> str:
    try:
        return normalize_label(x)
    except (TypeError, ValueError, AttributeError):
        return "unknown"

def _canon_action_id(x: object) -> str:
    try:
        s = sanitize_feature_id(x)
        return s if s is not None else "manual_review"
    except (TypeError, ValueError, AttributeError):
        return "manual_review"

def _normalize_cbf_fill_rules() -> None:
    """Normalize keys and canonicalize action values once at import time."""
    try:
        CBF_FILL_RULES["bp_to_action"] = {
            _to_norm_label(k): _canon_action_id(v)
            for k, v in CBF_FILL_RULES.get("bp_to_action", {}).items()
        }
        CBF_FILL_RULES["risk_bias"] = {
            _to_norm_label(k): str(v)
            for k, v in CBF_FILL_RULES.get("risk_bias", {}).items()
        }
        CBF_FILL_RULES["chol_bias"] = {
            _to_norm_label(k): str(v)
            for k, v in CBF_FILL_RULES.get("chol_bias", {}).items()
        }
        CBF_FILL_RULES["age_bias"] = {
            str(k): str(v)
            for k, v in CBF_FILL_RULES.get("age_bias", {}).items()
        }
    except (TypeError, ValueError, AttributeError, KeyError):
        # best-effort; don't break import
        pass

_normalize_cbf_fill_rules()
@lru_cache(maxsize=256)
def get_fill_action_for_bp(bp_category: object) -> str:
    """Return canonical action for a BP category or 'manual_review' if unknown."""
    lbl = _to_norm_label(bp_category)
    return CBF_FILL_RULES.get("bp_to_action", {}).get(lbl, "manual_review")

@lru_cache(maxsize=256)
def get_risk_bias(risk_level: object) -> str | None:
    """Return risk bias token (e.g., 'drug_bias') if applicable; else None."""
    lbl = _to_norm_label(risk_level)
    return CBF_FILL_RULES.get("risk_bias", {}).get(lbl)

@lru_cache(maxsize=256)
def get_chol_bias(chol_category: object) -> str | None:
    """Return cholesterol-driven bias token (e.g., 'diet_bias') if applicable; else None."""
    lbl = _to_norm_label(chol_category)
    return CBF_FILL_RULES.get("chol_bias", {}).get(lbl)

@lru_cache(maxsize=256)
def get_age_bias(age_group: object) -> str | None:
    """Return age-driven bias token; '<18', '18–30', '61–75', '75+' kept as literals."""
    try:
        s = str(age_group).strip()
        return CBF_FILL_RULES.get("age_bias", {}).get(s)
    except (TypeError, ValueError, AttributeError):
        return None

# CHOLESTEROL_THRESHOLDs : floats (rule-level)
# These thresholds are used for rule nudges and are distinct from categorize_chol bin edges.
CHOLESTEROL_THRESHOLD_ALERT: float = 239.0      # historical alert threshold (>=239 mg/dL)
CHOLESTEROL_THRESHOLD_BORDERLINE: float = 204.0 # end of 'desirable' bin (per current binning)
CHOLESTEROL_THRESHOLD_HIGH: float = 230.0       # end of 'borderline_high' bin (per current binning)
# Back-compat alias (do not remove without refactor)
CHOLESTEROL_THRESHOLD: float = CHOLESTEROL_THRESHOLD_ALERT

# --- replace the whole body of is_high_chol_total with this ---
def is_high_chol_total(value: object) -> bool:
    """
    Return True when a *scalar* total cholesterol is >= alert threshold (239 mg/dL).
    - If a pandas Series/NumPy array is passed with a single item, unwrap it.
    - If a non-scalar container is passed, return False (use the vectorized helper).
    """
    try:
        # Local (optional) imports to avoid hard deps at import time
        try:
            import pandas as _pd
            import numpy as _np
        except (ImportError, ModuleNotFoundError):
            _pd = None
            _np = None

        # Unwrap singletons
        if _pd is not None and isinstance(value, _pd.Series):
            if getattr(value, "size", None) == 1:
                try:
                    value = value.iloc[0]
                except (IndexError, AttributeError, TypeError, ValueError):
                    value = value.item() if hasattr(value, "item") else value
            else:
                # Not a scalar → use is_high_chol_total_series
                return False

        if _np is not None and isinstance(value, _np.ndarray):
            if value.size == 1:
                try:
                    value = value.item()
                except (AttributeError, TypeError, ValueError):
                    value = value.ravel()[0]
            else:
                return False

        v = float(value)
        # NaN check without math.isnan
        return not (v != v) and v >= CHOLESTEROL_THRESHOLD_ALERT
    except (TypeError, ValueError):
        return False

def is_high_chol_total_series(series):
    """
    Vectorized variant of `is_high_chol_total` for pandas Series-like inputs.
    Returns a boolean Series (True if >= CHOLESTEROL_THRESHOLD_ALERT). Invalid → False.
    """
    try:
        import pandas as _pd
    except (ImportError, ModuleNotFoundError):
        # إذا لم تتوفر pandas، نُعيد القيمة كما هي لإبراز سوء الاستخدام.
        return series
    try:
        s = _pd.to_numeric(series, errors="coerce")
        mask = s >= CHOLESTEROL_THRESHOLD_ALERT
        return mask & _pd.notna(s)
    except (TypeError, ValueError, AttributeError):
        try:
            return series.apply(is_high_chol_total)
        except (TypeError, ValueError, AttributeError):
            return series

# ⚠️ هام جداً: جميع المفاتيح يجب توليدها حصراً عبر make_context_key(context_dict, context_columns=CONTEXT_COLUMNS)
# يمنع أي تعديل يدوي على المفاتيح أو الأعمدة. أي تغيير يدوي يؤدي لفشل تطابق التوصيات!
CONTEXT_TO_RECOMMENDATION_MAP = {
    # حالات منخفضة الخطورة
    make_context_key(
        {"bp_category": "normal", "chol_category": "desirable", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "lifestyle_monitoring",
    make_context_key(
        {"bp_category": "normal", "chol_category": "borderline_high", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "diet_control",
    make_context_key(
        {"bp_category": "elevated", "chol_category": "desirable", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "low_sodium_diet",
    make_context_key(
        {"bp_category": "elevated", "chol_category": "borderline_high", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "increase_exercise",
    # حالات متوسطة الخطورة
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "desirable", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "thiazide_diuretic",
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "borderline_high", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "ace_inhibitor",
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "high", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "atenolol",
    make_context_key(
        {"bp_category": "hypertension_stage_2", "chol_category": "desirable", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "amlodipine",
    make_context_key(
        {"bp_category": "hypertension_stage_2", "chol_category": "borderline_high", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "losartan",
    make_context_key(
        {"bp_category": "hypertension_stage_2", "chol_category": "high", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "amlodipine",
    # حالات مرتفعة الخطورة
    make_context_key(
        {"bp_category": "hypertension_stage_2", "chol_category": "high", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "amlodipine_and_thiazide",
    make_context_key(
        {"bp_category": "hypertensive_crisis", "chol_category": "any", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "hospital_referral",
    make_context_key(
        {"bp_category": "hypertension_stage_2", "chol_category": "borderline_high", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "beta_blocker",
    make_context_key(
        {"bp_category": "hypertensive_crisis", "chol_category": "high", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "emergency_admission",
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "any", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "beta_blocker",
    # إضافات غير مغطاة من df_contextualized.csv (تحليل بيانات)
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "borderline_high", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "amlodipine_and_thiazide",
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "borderline_high", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "low_sodium_diet",
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "desirable", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "beta_blocker",
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "high", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "amlodipine_and_thiazide",
    make_context_key(
        {"bp_category": "hypertension_stage_2", "chol_category": "borderline_high", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "losartan",
    make_context_key(
        {"bp_category": "hypertension_stage_2", "chol_category": "desirable", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "lifestyle_monitoring",
    # ==== Added to cover uncovered contexts from context_combinations_not_covered.csv ====
    make_context_key(
        {
            "bp_category": "hypertensive_crisis",
            "chol_category": "high",
            "risk_level": "medium",
            "fbs_cat": "normal_fbs",
            "cp_cat": "typical_angina",
            "age_group": "31–45",
        },
        context_columns=CONTEXT_COLUMNS,
    ): "emergency_admission",

    make_context_key(
        {
            "bp_category": "normal",
            "chol_category": "borderline_high",
            "risk_level": "low",
            "fbs_cat": "normal_fbs",
            "cp_cat": "typical_angina",
            "age_group": "<18",
        },
        context_columns=CONTEXT_COLUMNS,
    ): "lifestyle_monitoring",

    make_context_key(
        {
            "bp_category": "elevated",
            "chol_category": "borderline_high",
            "risk_level": "medium",
            "fbs_cat": "high_fbs",
            "cp_cat": "atypical_angina",
            "age_group": "18–30",
        },
        context_columns=CONTEXT_COLUMNS,
    ): "ace_inhibitor",

    make_context_key(
        {
            "bp_category": "hypertension_stage_1",
            "chol_category": "borderline_high",
            "risk_level": "medium",
            "fbs_cat": "normal_fbs",
            "cp_cat": "typical_angina",
            "age_group": "75+",
        },
        context_columns=CONTEXT_COLUMNS,
    ): "beta_blocker",

    make_context_key(
        {
            "bp_category": "hypertension_stage_2",
            "chol_category": "high",
            "risk_level": "medium",
            "fbs_cat": "normal_fbs",
            "cp_cat": "atypical_angina",
            "age_group": "61–75",
        },
        context_columns=CONTEXT_COLUMNS,
    ): "amlodipine",
    # Generalized coverage for the 5 previously uncovered contexts (age-agnostic)
    make_context_key(
        {
            "bp_category": "hypertensive_crisis",
            "chol_category": "high",
            "risk_level": "medium",
            "fbs_cat": "normal_fbs",
            "cp_cat": "typical_angina",
            "age_group": "any",
        },
        context_columns=CONTEXT_COLUMNS,
    ): "emergency_admission",
    make_context_key(
        {
            "bp_category": "normal",
            "chol_category": "borderline_high",
            "risk_level": "low",
            "fbs_cat": "normal_fbs",
            "cp_cat": "typical_angina",
            "age_group": "any",
        },
        context_columns=CONTEXT_COLUMNS,
    ): "lifestyle_monitoring",
    make_context_key(
        {
            "bp_category": "elevated",
            "chol_category": "borderline_high",
            "risk_level": "medium",
            "fbs_cat": "high_fbs",
            "cp_cat": "atypical_angina",
            "age_group": "any",
        },
        context_columns=CONTEXT_COLUMNS,
    ): "ace_inhibitor",
    make_context_key(
        {
            "bp_category": "hypertension_stage_1",
            "chol_category": "borderline_high",
            "risk_level": "medium",
            "fbs_cat": "normal_fbs",
            "cp_cat": "typical_angina",
            "age_group": "any",
        },
        context_columns=CONTEXT_COLUMNS,
    ): "beta_blocker",
    make_context_key(
        {
            "bp_category": "hypertension_stage_2",
            "chol_category": "high",
            "risk_level": "medium",
            "fbs_cat": "normal_fbs",
            "cp_cat": "atypical_angina",
            "age_group": "any",
        },
        context_columns=CONTEXT_COLUMNS,
    ): "amlodipine",
    # Clinically sound rule: hypertensive crisis, risk_level medium → emergency admission
    make_context_key(
        {"bp_category": "hypertensive_crisis", "chol_category": "any", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "emergency_admission",
    # إضافات جديدة من تحليل بيانات التركيبات الثلاثية الشائعة (غير مغطاة مسبقاً)
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "high", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "losartan",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "borderline_high", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "desirable", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "beta_blocker",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "desirable", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "amlodipine",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "high", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "diet_control",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "desirable", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "thiazide_diuretic",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "desirable", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "lifestyle_monitoring",
    make_context_key({"bp_category": "normal", "chol_category": "desirable", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "lifestyle_monitoring",
    make_context_key({"bp_category": "normal", "chol_category": "borderline_high", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "diet_control",
    make_context_key({"bp_category": "normal", "chol_category": "high", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "diet_control",
    # fallback or undefined combinations
    make_context_key({"bp_category": "unknown", "chol_category": "unknown", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "manual_review_low",
    make_context_key({"bp_category": "unknown", "chol_category": "unknown", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "manual_review_medium",
    make_context_key({"bp_category": "unknown", "chol_category": "unknown", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "manual_review_high",
    # إضافات لتغطية حالات desirable و borderline_high في تصنيفات الكوليسترول
    make_context_key({"bp_category": "elevated", "chol_category": "desirable", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "increase_exercise",
    make_context_key({"bp_category": "hypertensive_crisis", "chol_category": "desirable", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "emergency_admission",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "any", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "manual_review_medium",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "any", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "manual_review_medium",
    make_context_key({"bp_category": "hypertensive_crisis", "chol_category": "any", "risk_level": "medium", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "manual_review_medium",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "any", "risk_level": "high", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "elevated", "chol_category": "borderline_high", "risk_level": "low", "fbs_cat": "any", "cp_cat": "any", "age_group": "any"}, context_columns=CONTEXT_COLUMNS): "low_sodium_diet",

    # إضافات ثلاثية وعمريّة موحدة من التحليل (2025-07-12)
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "46–60"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "46–60"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "borderline_high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "61–75"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "61–75"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "61–75"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "desirable", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "61–75"}, context_columns=CONTEXT_COLUMNS): "beta_blocker",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "borderline_high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "46–60"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "31–45"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "desirable", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "46–60"}, context_columns=CONTEXT_COLUMNS): "beta_blocker",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "borderline_high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "75+"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "desirable", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "31–45"}, context_columns=CONTEXT_COLUMNS): "beta_blocker",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "31–45"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "borderline_high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "61–75"}, context_columns=CONTEXT_COLUMNS): "ace_inhibitor",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "75+"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "borderline_high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "31–45"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "desirable", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "75+"}, context_columns=CONTEXT_COLUMNS): "beta_blocker",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "desirable", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "75+"}, context_columns=CONTEXT_COLUMNS): "lifestyle_monitoring",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "75+"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "desirable", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "46–60"}, context_columns=CONTEXT_COLUMNS): "lifestyle_monitoring",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "borderline_high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "46–60"}, context_columns=CONTEXT_COLUMNS): "ace_inhibitor",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "desirable", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "61–75"}, context_columns=CONTEXT_COLUMNS): "lifestyle_monitoring",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "18–30"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "desirable", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "31–45"}, context_columns=CONTEXT_COLUMNS): "lifestyle_monitoring",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "desirable", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "18–30"}, context_columns=CONTEXT_COLUMNS): "beta_blocker",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "borderline_high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "31–45"}, context_columns=CONTEXT_COLUMNS): "ace_inhibitor",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "borderline_high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "75+"}, context_columns=CONTEXT_COLUMNS): "ace_inhibitor",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "borderline_high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "18–30"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "18–30"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "borderline_high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "18–30"}, context_columns=CONTEXT_COLUMNS): "ace_inhibitor",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "desirable", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "18–30"}, context_columns=CONTEXT_COLUMNS): "lifestyle_monitoring",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "borderline_high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "<18"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "desirable", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "<18"}, context_columns=CONTEXT_COLUMNS): "beta_blocker",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "<18"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_2", "chol_category": "high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "<18"}, context_columns=CONTEXT_COLUMNS): "amlodipine_and_thiazide",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "desirable", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "<18"}, context_columns=CONTEXT_COLUMNS): "lifestyle_monitoring",
    make_context_key({"bp_category": "hypertension_stage_1", "chol_category": "borderline_high", "risk_level": "any", "fbs_cat": "any", "cp_cat": "any", "age_group": "<18"}, context_columns=CONTEXT_COLUMNS): "ace_inhibitor",
    # --- Extended coverage (clinical) -------------------------------------------------
    # Elevated + desirable, medium risk → reinforce exercise
    make_context_key(
        {"bp_category": "elevated", "chol_category": "desirable", "risk_level": "medium",
         "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "increase_exercise",

    # Elevated + high, medium risk → diet-first
    make_context_key(
        {"bp_category": "elevated", "chol_category": "high", "risk_level": "medium",
         "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "diet_control",

    # Normal + high, medium risk → diet-first
    make_context_key(
        {"bp_category": "normal", "chol_category": "high", "risk_level": "medium",
         "fbs_cat": "any", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "diet_control",

    # Diabetes signal (high_fbs) escalations
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "any", "risk_level": "medium",
         "fbs_cat": "high_fbs", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "ace_inhibitor",
    make_context_key(
        {"bp_category": "hypertension_stage_2", "chol_category": "any", "risk_level": "high",
         "fbs_cat": "high_fbs", "cp_cat": "any", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "amlodipine_and_thiazide",

    # Angina bias at high risk → beta blocker
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "any", "risk_level": "high",
         "fbs_cat": "any", "cp_cat": "typical_angina", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "beta_blocker",
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "any", "risk_level": "high",
         "fbs_cat": "any", "cp_cat": "atypical_angina", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "beta_blocker",
    make_context_key(
        {"bp_category": "hypertension_stage_2", "chol_category": "any", "risk_level": "high",
         "fbs_cat": "any", "cp_cat": "typical_angina", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "beta_blocker",
    make_context_key(
        {"bp_category": "hypertension_stage_2", "chol_category": "any", "risk_level": "high",
         "fbs_cat": "any", "cp_cat": "atypical_angina", "age_group": "any"},
        context_columns=CONTEXT_COLUMNS
    ): "beta_blocker",

    # Elderly (75+) medium-risk Stage 1 → thiazide preferred
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "any", "risk_level": "medium",
         "fbs_cat": "any", "cp_cat": "any", "age_group": "75+"},
        context_columns=CONTEXT_COLUMNS
    ): "thiazide_diuretic",

    # Pediatrics (<18) hypertension → manual review default
    make_context_key(
        {"bp_category": "hypertension_stage_1", "chol_category": "any", "risk_level": "any",
         "fbs_cat": "any", "cp_cat": "any", "age_group": "<18"},
        context_columns=CONTEXT_COLUMNS
    ): "manual_review_high",
    make_context_key(
        {"bp_category": "hypertension_stage_2", "chol_category": "any", "risk_level": "any",
         "fbs_cat": "any", "cp_cat": "any", "age_group": "<18"},
        context_columns=CONTEXT_COLUMNS
    ): "manual_review_high",
}


# --- Canonicalize map values to reduce sparsity & unify labels ---
try:
    _updated_ctx_map = {}
    for _k, _v in CONTEXT_TO_RECOMMENDATION_MAP.items():
        _canon_v = canonicalize_feature_id(_v)
        _updated_ctx_map[_k] = _canon_v if _canon_v is not None else _v
    CONTEXT_TO_RECOMMENDATION_MAP = _updated_ctx_map
except (TypeError, ValueError, AttributeError) as _exc:
    # keep resilient if canonicalization is unavailable during import
    pass



# ⚠️ هام جداً: جميع المفاتيح يجب توليدها حصراً عبر make_context_key(context_dict, context_columns=CONTEXT_COLUMNS)
# يمنع أي تعديل يدوي على المفاتيح أو الأعمدة. أي تغيير يدوي يؤدي لفشل تطابق التوصيات!
FEATURE_ID_BINNED_MAP = {
    # Q1 (Lower systolic range): lifestyle-first; diet control as cholesterol rises
    make_binned_key("Q1", "(125.999, 204.0]", "Young"):  "lifestyle_monitoring",
    make_binned_key("Q1", "(125.999, 204.0]", "Middle"): "diet_control",
    make_binned_key("Q1", "(125.999, 204.0]", "Old"):    "diet_control",

    make_binned_key("Q1", "(204.0, 230.0]", "Young"):    "diet_control",
    make_binned_key("Q1", "(204.0, 230.0]", "Middle"):   "diet_control",
    make_binned_key("Q1", "(204.0, 230.0]", "Old"):      "diet_control",

    make_binned_key("Q1", "(230.0, 254.0]", "Young"):    "diet_control",
    make_binned_key("Q1", "(230.0, 254.0]", "Middle"):   "diet_control",
    make_binned_key("Q1", "(230.0, 254.0]", "Old"):      "diet_control",

    # Q2 (Moderate systolic): exercise for young/middle unless cholesterol is very high; beta-blocker bias in elderly
    make_binned_key("Q2", "(204.0, 230.0]", "Young"):    "increase_exercise",
    make_binned_key("Q2", "(204.0, 230.0]", "Middle"):   "increase_exercise",
    make_binned_key("Q2", "(204.0, 230.0]", "Old"):      "beta_blocker",

    make_binned_key("Q2", "(230.0, 254.0]", "Young"):    "increase_exercise",
    make_binned_key("Q2", "(230.0, 254.0]", "Middle"):   "ace_inhibitor",
    make_binned_key("Q2", "(230.0, 254.0]", "Old"):      "beta_blocker",

    make_binned_key("Q2", "(254.0, 286.0]", "Young"):    "increase_exercise",
    make_binned_key("Q2", "(254.0, 286.0]", "Middle"):   "increase_exercise",
    make_binned_key("Q2", "(254.0, 286.0]", "Old"):      "beta_blocker",

    # Q3 (High systolic): ACEi for middle age; increase_exercise for young; beta-blocker for elderly
    make_binned_key("Q3", "(204.0, 230.0]", "Young"):    "increase_exercise",
    make_binned_key("Q3", "(204.0, 230.0]", "Middle"):   "ace_inhibitor",
    make_binned_key("Q3", "(204.0, 230.0]", "Old"):      "beta_blocker",

    make_binned_key("Q3", "(230.0, 254.0]", "Young"):    "increase_exercise",
    make_binned_key("Q3", "(230.0, 254.0]", "Middle"):   "ace_inhibitor",
    make_binned_key("Q3", "(230.0, 254.0]", "Old"):      "beta_blocker",

    make_binned_key("Q3", "(254.0, 286.0]", "Young"):    "increase_exercise",
    make_binned_key("Q3", "(254.0, 286.0]", "Middle"):   "ace_inhibitor",
    make_binned_key("Q3", "(254.0, 286.0]", "Old"):      "beta_blocker",

    make_binned_key("Q3", "(286.0, 564.0]", "Young"):    "increase_exercise",
    make_binned_key("Q3", "(286.0, 564.0]", "Middle"):   "ace_inhibitor",
    make_binned_key("Q3", "(286.0, 564.0]", "Old"):      "beta_blocker",

    # Q4 (Very high systolic): escalate—ACEi for middle, combo for elderly; exercise-only fallback for young
    make_binned_key("Q4", "(254.0, 286.0]", "Young"):    "increase_exercise",
    make_binned_key("Q4", "(254.0, 286.0]", "Middle"):   "ace_inhibitor",
    make_binned_key("Q4", "(254.0, 286.0]", "Old"):      "amlodipine_and_thiazide",

    make_binned_key("Q4", "(286.0, 564.0]", "Young"):    "increase_exercise",
    make_binned_key("Q4", "(286.0, 564.0]", "Middle"):   "ace_inhibitor",
    make_binned_key("Q4", "(286.0, 564.0]", "Old"):      "amlodipine_and_thiazide",
}

# Logical grouping of contextual maps for clarity and future validation hooks
CONTEXT_MAPS: Dict[str, Any] = {
    "medical_plan": MEDICAL_RECOMMENDATION_PLAN,
    "context_to_recommendation": CONTEXT_TO_RECOMMENDATION_MAP,
    "feature_id_binned": FEATURE_ID_BINNED_MAP,
}

# --- Validation helpers for binned-map keys (strict format) ---
import re as _re
_BINNED_KEY_RE = _re.compile(r"^Q[1-4]__\([0-9.]+,[0-9.]+]__?(Young|Middle|Old)$")

def _is_binned_key_valid(key: str) -> bool:
    try:
        s = str(key).strip().replace(" ", "")
        return bool(_BINNED_KEY_RE.match(s))
    except (TypeError, ValueError, AttributeError):
        return False

def validate_feature_id_binned_map() -> dict:
    bad_keys, unknown_actions = [], []
    for k, v in FEATURE_ID_BINNED_MAP.items():
        if not _is_binned_key_valid(k):
            bad_keys.append(k)
        sv = sanitize_feature_id(v)
        if sv is None:
            unknown_actions.append((k, v))
    return {
        "bad_keys": bad_keys[:10],
        "n_bad_keys": len(bad_keys),
        "unknown_actions_sample": unknown_actions[:10],
        "n_unknown_actions": len(unknown_actions),
    }

def summarize_context_maps() -> Dict[str, int]:
    sizes = validate_context_maps_keys()
    report = validate_feature_id_binned_map()
    sizes["feature_id_binned_bad_keys"] = report.get("n_bad_keys", 0)
    sizes["feature_id_binned_unknown_actions"] = report.get("n_unknown_actions", 0)
    return sizes

# --- Canonicalization helpers for all clinical maps (values → canonical feature ids) ---

def sanitize_feature_id(value) -> str | None:
    """
    Normalize a feature-id string to canonical, or return None for nullish/empty.
    Uses `canonicalize_feature_id` and never raises.
    """
    if value is None:
        return None
    try:
        v = str(value).strip().lower()
    except (TypeError, ValueError, AttributeError):
        return None
    if not v:
        return None
    try:
        canon = canonicalize_feature_id(v)
    except (TypeError, ValueError, AttributeError):
        canon = None
    return canon if canon is not None else v

def _canonicalize_map_values(_map):
    try:
        updated = {}
        for k, v in _map.items():
            if isinstance(v, dict):
                act = sanitize_feature_id(v.get("action"))
                if act is not None:
                    v = dict(v)
                    v["action"] = act
                    updated[k] = v
                else:
                    updated[k] = v
            else:
                sv = sanitize_feature_id(v)
                updated[k] = sv if sv is not None else v
        _map.clear()
        _map.update(updated)
    except (TypeError, ValueError, KeyError, AttributeError) as _exc_loc_mapvals:
        # keep resilient — never break import due to map cleanup
        logging.getLogger(__name__).debug("[_canonicalize_map_values] skipped canonicalization due to: %s", _exc_loc_mapvals)

# Canonicalize values of MEDICAL_RECOMMENDATION_PLAN and FEATURE_ID_BINNED_MAP as well
try:
    _canonicalize_map_values(MEDICAL_RECOMMENDATION_PLAN)
except (TypeError, ValueError, KeyError, AttributeError) as _exc_loc_medplan:
    logging.getLogger(__name__).debug("[constants] MEDICAL_RECOMMENDATION_PLAN canonicalization skipped: %s", _exc_loc_medplan)

try:
    _canonicalize_map_values(FEATURE_ID_BINNED_MAP)
except (TypeError, ValueError, KeyError, AttributeError) as _exc_loc_binned:
    logging.getLogger(__name__).debug("[constants] FEATURE_ID_BINNED_MAP canonicalization skipped: %s", _exc_loc_binned)

def audit_constants(logger):
    """
    Lightweight audit to catch non-canonical/unknown actions in the clinical maps.
    Logs a compact sample instead of raising to avoid breaking runtime.
    """
    bad = []

    # MEDICAL_RECOMMENDATION_PLAN
    for ctx_key, plan in MEDICAL_RECOMMENDATION_PLAN.items():
        try:
            if isinstance(plan, dict):
                feat = str(plan.get("action", "")).strip().lower()
            else:
                feat = str(plan).strip().lower()
            canon = sanitize_feature_id(feat)
            if canon is None:
                bad.append(("MEDICAL_RECOMMENDATION_PLAN", ctx_key, feat))
        except (TypeError, ValueError, KeyError, AttributeError) as _exc_audit_plan:
            logging.getLogger(__name__).debug("[audit_constants] MEDICAL_RECOMMENDATION_PLAN item skipped: %s", _exc_audit_plan)

    # CONTEXT_TO_RECOMMENDATION_MAP
    for ctx_key, feat in CONTEXT_TO_RECOMMENDATION_MAP.items():
        try:
            canon = sanitize_feature_id(feat)
            if canon is None:
                bad.append(("CONTEXT_TO_RECOMMENDATION_MAP", ctx_key, feat))
        except (TypeError, ValueError, KeyError, AttributeError) as _exc_audit_ctx:
            logging.getLogger(__name__).debug("[audit_constants] CONTEXT_TO_RECOMMENDATION_MAP item skipped: %s", _exc_audit_ctx)

    # FEATURE_ID_BINNED_MAP
    for bkey, feat in FEATURE_ID_BINNED_MAP.items():
        try:
            canon = sanitize_feature_id(feat)
            if canon is None:
                bad.append(("FEATURE_ID_BINNED_MAP", bkey, feat))
        except (TypeError, ValueError, KeyError, AttributeError) as _exc_audit_bin:
            logging.getLogger(__name__).debug("[audit_constants] FEATURE_ID_BINNED_MAP item skipped: %s", _exc_audit_bin)

    # Optional content-level audit: forbid any baked-in fallback narrative texts in constants
    def _contains_fallback(txt):
        if txt is None:
            return False
        t = str(txt).strip().lower()
        return ("fallback recommendation" in t) or ("fallback" in t and "recommendation" in t)
    leak_candidates = []
    for k, v in RECOMMENDATION_SOURCE.items():
        try:
            if _contains_fallback(v):
                leak_candidates.append(("RECOMMENDATION_SOURCE", k, v))
        except (TypeError, ValueError, KeyError, AttributeError) as _exc_audit_src:
            logging.getLogger(__name__).debug("[audit_constants] RECOMMENDATION_SOURCE item skipped: %s", _exc_audit_src)
    if leak_candidates:
        bad.extend(leak_candidates)

    if bad and hasattr(logger, "warning"):
        logger.warning(
            "[CONST][audit] %d suspicious/uncanonical entries found (showing up to 10): %s",
            len(bad), bad[:10]
        )
    return {"problems": len(bad), "sample": bad[:10]}

def validate_context_maps_keys() -> Dict[str, int]:
    """Lightweight sanity check returning sizes of the core context maps."""
    return {name: len(d) for name, d in CONTEXT_MAPS.items()}

def recommend_by_binned(bp_bin: str, chol_bin: str, age_bin: str, log=None, key=None) -> str:
    # Normalize input for consistency
    chol_bin = str(chol_bin).replace(" ", "")
    bp_bin = str(bp_bin).replace(" ", "")
    age_bin = str(age_bin).replace(" ", "")

    # الحالات الخاصة جداً: الكوليسترول الأعلى جداً
    if any(th in chol_bin for th in ["286.0", "564.0"]):
        if age_bin == "Old":
            return "amlodipine_and_thiazide"
        else:
            return "amlodipine"
    # ضغط مرتفع جداً (Q4)
    if bp_bin == "Q4":
        if age_bin == "Old":
            return "amlodipine_and_thiazide"
        elif age_bin == "Middle":
            return "ace_inhibitor"
        else:
            return "increase_exercise"
    # ضغط مرتفع (Q3)
    if bp_bin == "Q3":
        if age_bin == "Old":
            return "beta_blocker"
        elif age_bin == "Middle":
            return "ace_inhibitor"
        else:
            return "increase_exercise"
    # ضغط متوسط (Q2)
    if bp_bin == "Q2":
        if age_bin == "Old":
            return "beta_blocker"
        elif age_bin == "Middle":
            if any(th in chol_bin for th in ["254.0", "230.0"]):
                return "ace_inhibitor"
            else:
                return "increase_exercise"
        else:
            return "increase_exercise"
    # ضغط منخفض (Q1)
    if bp_bin == "Q1":
        if age_bin == "Young":
            return "lifestyle_monitoring"
        elif age_bin == "Old":
            return "diet_control"
        else:
            return "diet_control"
    # حالات العمر المتقدمة دائماً مراقبة خاصة
    if age_bin == "Old" and bp_bin in ["Q1", "Q2", "Q3", "Q4"]:
        return "lifestyle_monitoring"
    # fallback لجميع الحالات غير المغطاة
    if log is not None and key is not None:
        log.warning(f"[recommend_by_binned] Unmapped case for: {key} => manual_review")
    return "manual_review"

def assign_feature_id_by_binned(df, use_map: bool = True, log=None, log_id: str | None = None):

    def normalize_binned_key(x):
        # يضمن أن كل المفتاح string بدون فراغات أو اختلاف في الصياغة
        # Prefer a narrow exception policy: separate import from null-check
        try:
            import pandas as _pd
        except (ImportError, ModuleNotFoundError):
            _pd = None

        if _pd is not None:
            try:
                if _pd.isnull(x):
                    return ""
            except (TypeError, ValueError, AttributeError):
                # Non-numeric / non-arrayish types may raise in edge cases; fall through
                pass

        if x is None:
            return ""
        if not isinstance(x, str):
            x = str(x)
        return x.strip().replace(" ", "")

    if "feature_id_binned" not in df.columns:
        if log:
            log.warning(f"[{log_id}] ❌ عمود feature_id_binned غير موجود - لن يتم تعيين التوصيات.")
        df["feature_id"] = "manual_review"
        return df

    def get_recommendation(x):
        # ⚠️ يجب استخدام make_context_key حصراً عند بناء المفتاح لأي قاموس توصية سياقي!
        key = normalize_binned_key(x)
        if key == "":
            return "manual_review"
        # هنا يجب التأكد أن المفتاح تم توليده عبر make_context_key
        if use_map and key in FEATURE_ID_BINNED_MAP:
            return FEATURE_ID_BINNED_MAP[key]
        # حاول فك المفتاح الثلاثي
        try:
            parts = key.split("__")
            if len(parts) != 3:
                raise ValueError("feature_id_binned key does not have 3 parts")
            bp_bin, chol_bin, age_bin = parts
            return recommend_by_binned(bp_bin, chol_bin, age_bin)
        except (ValueError, IndexError, AttributeError, TypeError) as ex:
            if log is not None:
                try:
                    log.warning(
                        f"[{log_id}] [assign_feature_id_by_binned] ⚠️ Failed to parse feature_id_binned='{x}' ({type(x)}) - {ex} - fallback to manual_review."
                    )
                except (KeyError, ValueError, TypeError):
                    pass
            return "manual_review"

    # توليد التوصيات
    df["feature_id"] = df["feature_id_binned"].apply(get_recommendation)
    # Normalize to canonical feature ids when possible (keeps backward compat if None)
    df["feature_id"] = df["feature_id"].apply(lambda x: canonicalize_feature_id(x) or x)

    # log الإحصائيات إذا لزم
    if log is not None:
        try:
            total = len(df)
            manual_cnt = ((df["feature_id"] == "manual_review") | (df["feature_id"].isnull())).sum()
            log.info(f"[{log_id}] [assign_feature_id_by_binned] عدد القيم غير المعيّنة أو اليدوية: {manual_cnt} / {total}")
            sample_dist = df["feature_id"].value_counts().head(10).to_dict()
            log.info(f"[{log_id}] [assign_feature_id_by_binned] توزيع العينات الأكبر: {sample_dist}")

            # إضافة log لعينة من الحالات الغير معالجة
            if manual_cnt > 0:
                sample_manual = df[df["feature_id"] == "manual_review"]["feature_id_binned"].head(5).to_list()
                log.warning(f"[{log_id}] [assign_feature_id_by_binned] عينات feature_id_binned لم يتم تعيين توصية لها: {sample_manual}")
        except (KeyError, ValueError, TypeError):
            pass

    return df


# -------------------------
# Fallback scoring policy (in case config.yaml fails to load)
# -------------------------

CBF_REASON_TO_SCORE_DEFAULT = {
    "recommended": 0.95,
    "context_key_match": 0.90,
    "knn_recommendation": 0.82,
    "similarity_fallback_high": 0.72,
    "similarity_fallback_medium": 0.60,
    "similarity_fallback_low": 0.45,
    "knn_fallback": 0.55,
    "manual_review": 0.0,
}
ACCEPT_THRESHOLD_DEFAULT = 0.50

# Default mixing configuration for CBF score blending (similarity ⊗ reason priors)
CBF_MIX_DEFAULT = {
    "w_similarity": 0.8,
    "w_reason": 0.2,
    "sim_clip_min": 0.0,
    "sim_clip_max": 1.0,
    "post_calibration": "minmax",  # options: minmax | standard | none
    "epsilon_jitter": 1e-06,
    # dynamic-prior defaults (used when not provided in config)
    "prior_mod_base": 0.5,
    "prior_mod_gain": 0.5,
    # cap for exact/contextual matches to avoid saturation/tying
    "exact_match_cap": 0.80,
    # similarity→probability mapping default (dict) to keep typing broad enough
    "sim_to_prob": {"type": "logistic", "slope": 6.0, "midpoint": 0.65},
    # default tie-break strategy name (can be overridden from config.yaml)
    "tie_break_strategy": "score_desc_sim_desc_feature_asc_patient_asc",
}

_CBF_POLICY_LOGGED_ONCE = False

# --------------------
# سياسة استخراج scoring للـ CBF مع fallback آمن (يدعم أيضاً إعدادات المزج)

def _legacy_get_cbf_scoring_policy_full(cfg: dict):
    # Helpers
    def _to_float(x, d):
        try:
            return float(x)
        except (TypeError, ValueError):
            return d

    # --- Base score map with safe defaults, then ensure modern keys exist ---
    score_map = dict(CBF_REASON_TO_SCORE_DEFAULT)
    # --- Optional: load learned priors and blend with defaults ---
    try:
        import json
        import os
        scoring_cfg = (cfg.get("scoring", {}) or {}) if isinstance(cfg, dict) else {}
        priors_path = scoring_cfg.get("reason_priors_path", "outputs/CBF/cbf_reason_priors.json")
        blend_alpha = float(scoring_cfg.get("reason_prior_blend_alpha", 0.6))  # 0..1
        if 0.0 <= blend_alpha <= 1.0 and isinstance(priors_path, str) and os.path.exists(priors_path):
            with open(priors_path, "r", encoding="utf-8") as _fh:
                learned = json.load(_fh) or {}
            # Expect shape: {"recommended": 0.93, "knn_recommendation": 0.80, ...}
            for _r, _val in learned.items():
                try:
                    lv = float(_val)
                    if 0.0 <= lv <= 1.0:
                        base = score_map.get(_r, None)
                        if base is None:
                            # allow new reasons to be introduced with a sane cap
                            base = 0.5
                        score_map[_r] = blend_alpha * lv + (1.0 - blend_alpha) * float(base)
                except (TypeError, ValueError):
                    continue
    except (OSError, IOError, ValueError, KeyError, TypeError, AttributeError):
        # Silent: keep defaults if file missing or malformed
        pass
    # Ensure new reasons exist with sensible defaults
    if "contextual_rule" not in score_map:
        score_map["contextual_rule"] = 0.90
    if "knn_fallback" not in score_map:
        score_map["knn_fallback"] = score_map.get("knn_recommendation", 0.75)

    # --- Read config from scoring.cbf_mix ---
    scoring = (cfg.get("scoring", {}) or {}) if isinstance(cfg, dict) else {}
    cbf_mix = (scoring.get("cbf_mix", {}) or {})

    # Start from defaults, then overlay user config
    mix_cfg = dict(CBF_MIX_DEFAULT)

    # Numeric overrides
    for key in ("w_similarity", "w_reason", "sim_clip_min", "sim_clip_max",
                "epsilon_jitter", "prior_mod_base", "prior_mod_gain", "exact_match_cap"):
        mix_cfg[key] = _to_float(cbf_mix.get(key, mix_cfg.get(key)), mix_cfg.get(key))

    # Non-numeric / structured overrides
    mix_cfg["post_calibration"] = str(cbf_mix.get("post_calibration", mix_cfg.get("post_calibration", "minmax"))).lower()
    mix_cfg["tie_break_strategy"] = str(cbf_mix.get("tie_break_strategy", mix_cfg.get("tie_break_strategy", "score_desc_sim_desc_feature_asc_patient_asc")))
    mix_cfg["sim_to_prob"] = cbf_mix.get(
        "sim_to_prob",
        mix_cfg.get("sim_to_prob", {"type": "logistic", "slope": 10.0, "midpoint": 0.78})
    )

    # --- Normalize weights and clamp ranges ---
    w_sim = max(0.0, _to_float(mix_cfg.get("w_similarity"), 0.70))
    w_pri = max(0.0, _to_float(mix_cfg.get("w_reason"), 0.30))
    denom = w_sim + w_pri
    if denom <= 0.0:
        w_sim, w_pri = 0.70, 0.30
    else:
        w_sim, w_pri = w_sim / denom, w_pri / denom
    mix_cfg["w_similarity"], mix_cfg["w_reason"] = w_sim, w_pri

    sim_min = max(0.0, min(1.0, _to_float(mix_cfg.get("sim_clip_min"), 0.0)))
    sim_max = max(0.0, min(1.0, _to_float(mix_cfg.get("sim_clip_max"), 1.0)))
    if sim_min > sim_max:
        sim_min, sim_max = sim_max, sim_min
    mix_cfg["sim_clip_min"], mix_cfg["sim_clip_max"] = sim_min, sim_max

    # exact_match_cap within [sim_min, sim_max]
    mix_cfg["exact_match_cap"] = max(sim_min, min(sim_max, _to_float(mix_cfg.get("exact_match_cap"), 0.95)))

    # Prior modulation bounds and simple normalization
    base = max(0.0, _to_float(mix_cfg.get("prior_mod_base"), 0.5))
    gain = max(0.0, _to_float(mix_cfg.get("prior_mod_gain"), 0.5))
    if (base + gain) > 1.0:
        scale = 1.0 / (base + gain)
        base, gain = base * scale, gain * scale
    mix_cfg["prior_mod_base"], mix_cfg["prior_mod_gain"] = base, gain

    # --- Resolve thresholds from config with safe fallbacks ---
    thresholds = {"accept_threshold": 0.0}
    try:
        ms = (cfg.get("model_settings", {}) or {})
        sc = (ms.get("scoring", {}) or {})
        thr_val = sc.get("accept_threshold", None)
        if thr_val is None:
            thr_val = ((cfg.get("recommendation", {}) or {}).get("score_threshold", None))

        # Accept only numeric/str-like values; otherwise keep default
        if isinstance(thr_val, (int, float, str)):
            thresholds["accept_threshold"] = float(thr_val)
        # else: keep default 0.0
    except (TypeError, ValueError, AttributeError):
        # keep default thresholds
        pass

    # One-time diagnostic log
    global _CBF_POLICY_LOGGED_ONCE
    if not _CBF_POLICY_LOGGED_ONCE:
        try:
            import logging
            _sample_cfg = {
                "w_similarity": mix_cfg.get("w_similarity"),
                "w_reason": mix_cfg.get("w_reason"),
                "sim_to_prob": str(mix_cfg.get("sim_to_prob")),
                "post_calibration": mix_cfg.get("post_calibration"),
                "exact_match_cap": mix_cfg.get("exact_match_cap"),
            }
            logging.getLogger(__name__).info(
                "[CBF][POLICY] mix_cfg=%s score_map_sample=%s thresholds=%s",
                _sample_cfg,
                dict(list(score_map.items())[:5]),
                thresholds,
            )
        except (ImportError, ValueError, TypeError, AttributeError):
            pass
        _CBF_POLICY_LOGGED_ONCE = True

    try:
        import logging as _logging
        _lg = _logging.getLogger(__name__)
        _lg.debug("[CBF][POLICY] final score_map sample=%s thresholds=%s mix=%s",
                  dict(list(score_map.items())[:6]),
                  thresholds,
                  {k: mix_cfg.get(k) for k in ("w_similarity","w_reason","sim_to_prob","exact_match_cap")})
    except (Exception,):
        # best-effort logging only
        pass
    return score_map, thresholds, mix_cfg


# --- Simplified scoring policy API (reason→score + floors/threshold) ---
def get_cbf_scoring_policy(cfg: Dict[str, Any]) -> Tuple[Dict[str, float], float, Dict[str, float]]:
    """
    Canonical CBF scoring policy accessor.

    Returns:
        reason_map: dict[str, float]  -> merged cbf_reason_to_score over defaults
        accept_threshold: float        -> scoring.accept_threshold (default 0.50)
        floors: dict[str, float]       -> {"unknown_reason_score", "min_floor"}
    Notes:
        - Mix/tie/clip parameters (e.g., w_similarity, exact_match_cap, sim_clip_*)
          belong to scoring.cbf_mix and are consumed by the recommender, not here.
    """
    # Safe dict access
    s: Dict[str, Any] = {}
    try:
        s = (cfg or {}).get("scoring", {}) or {}
    except AttributeError:
        s = {}

    # Start from hard defaults, then overlay user config if present
    reason_map: Dict[str, float] = dict(_CBF_REASON_DEFAULTS)
    user_map = s.get("cbf_reason_to_score", {}) or {}
    if isinstance(user_map, dict):
        for k, v in user_map.items():
            try:
                reason_map[str(k)] = float(v)
            except (TypeError, ValueError):
                continue

    # Enforce critical keys
    reason_map.setdefault("recommended", 1.0)
    reason_map.setdefault("manual_review", 0.0)

    # Threshold
    thr_raw = s.get("accept_threshold", 0.50)
    try:
        accept_threshold = float(thr_raw)
    except (TypeError, ValueError):
        accept_threshold = 0.50

    # Floors
    def _f(key: str, default: float) -> float:
        try:
            return float(s.get(key, default))
        except (TypeError, ValueError):
            return default

    floors: Dict[str, float] = {
        "unknown_reason_score": _f("unknown_reason_score", 0.55),
        "min_floor": _f("min_floor", 0.05),
    }

    return reason_map, accept_threshold, floors


# --- Minimal compatibility wrapper for legacy callers expecting 2-tuple ---
def get_cbf_scoring_policy_minimal(cfg: Dict[str, Any]) -> Tuple[Dict[str, float], float]:
    """Compatibility wrapper returning only (reason_map, accept_threshold)."""
    reason_map, thr, _floors = get_cbf_scoring_policy(cfg)
    return reason_map, thr

# مجموعة افتراضية مسموحة من feature_id لضمان التغطية عند فشل config
ALLOWED_FEATURE_IDS = {
    # Lifestyle / non-pharmacologic
    "lifestyle_monitoring", "diet_control", "increase_exercise", "low_sodium_diet",
    # Core antihypertensives
    "thiazide_diuretic", "amlodipine", "amlodipine_and_thiazide",
    "ace_inhibitor", "arb", "beta_blocker", "atenolol",
    # Escalation / disposition
    "hospital_referral", "emergency_admission", "urgent_review",
    # Fallbacks
    "manual_review", "manual_review_low", "manual_review_medium", "manual_review_high",
}

FEATURE_ID_ALLOWED = (
    set(RECOMMENDATION_EXPLAIN.keys()) |
    set(RECOMMENDATION_SOURCE.keys()) |
    set(MEDICAL_RECOMMENDATION_PLAN.values()) |
    set(CONTEXT_TO_RECOMMENDATION_MAP.values()) |
    set(FEATURE_ID_BINNED_MAP.values()) |
    {"manual_review", "manual_review_low", "manual_review_medium", "manual_review_high"}
)
# توافقاً مع الشيفرة القديمة التي تعتمد على feature_id_set
feature_id_set = FEATURE_ID_ALLOWED
_FEATURE_ID_ALLOWED = {"manual_review"}  # local fallback to satisfy linters and runtime

def get_feature_id_allowed() -> set:
    """Helper: return the full allowed feature-id set for acceptance checks/tests."""
    return set(FEATURE_ID_ALLOWED)




# === Advice Type Taxonomy (expanded) ===
# Unconditional, type-annotated definitions to avoid "may be undefined" or
# "unresolved reference" warnings from static analyzers/linters.
ADVICE_TYPES: list[str] = [
    "lifestyle",          # تغييرات نمط الحياة (ملح، وزن، حركة، توقف تدخين...)
    "pharmacologic",      # أدوية/تعديل جرعات
    "diagnostic",         # تشخيص / تأكيد / تفريق
    "monitoring",         # متابعة وقياس (منزلية/عيادية)
    "lab_order",          # تحاليل مخبرية (K+, Creatinine, A1C, Lipid panel...)
    "referral",           # إحالة (قلبي، كِلى، غدد...)
    "education",          # تثقيف/توعية/استشارة
    "adherence",          # التزام/دعم الالتزام والتداخلات السلوكية
    "safety",             # تحذير/ممنوعات/تداخلات دوائية
    "device",             # أجهزة/تقنية (H-BPM, ABPM)
    "follow_up",          # تحديد زيارة أو متابعة زمنية
    "vaccination",        # لقاحات (إن لزم سياقًا)
    "other",              # افتراضي عندما لا يطابق شيء بوضوح
]

# Lower-case containment matching keywords by advice type
_DEFAULT_ADVICE_KEYWORDS: dict[str, list[str]] = {
    "lifestyle": [
        "salt", "sodium", "exercise", "physical activity", "aerobic",
        "weight", "bmi", "calorie", "diet", "dash", "smoking", "alcohol",
        "sleep", "stress", "mediterranean", "walk", "sedentary"
    ],
    "pharmacologic": [
        "start", "initiate", "up-titrate", "titrate", "increase",
        "decrease", "switch", "add", "hold", "stop", "discontinue",
        "ace", "arb", "ccb", "thiazide", "beta-blocker", "spironolactone",
        "chlorthalidone", "amlodipine", "labetalol", "hydralazine"
    ],
    "diagnostic": [
        "rule out", "evaluate", "workup", "confirm", "secondary hypertension",
        "screen for", "assessment", "risk stratification"
    ],
    "monitoring": [
        "monitor", "check", "home blood pressure", "hbpm", "abpm",
        "recheck", "track", "log", "telemonitor"
    ],
    "lab_order": [
        "lab", "labs", "order", "creatinine", "egfr", "potassium", "k+",
        "electrolyte", "lipid", "a1c", "uacr", "urine albumin", "renal"
    ],
    "referral": [
        "refer", "referral", "consult", "cardiology", "nephrology", "endocrinology"
    ],
    "education": [
        "educate", "counsel", "counseling", "advise", "teach",
        "patient education", "shared decision"
    ],
    "adherence": [
        "adherence", "compliance", "reminder", "pill box", "blister", "behavioral"
    ],
    "safety": [
        "contraindication", "avoid", "drug interaction", "hyperkalemia",
        "pregnancy", "renal impairment", "black box", "alert"
    ],
    "device": [
        "device", "validated cuff", "home monitor", "bp monitor", "abpm device"
    ],
    "follow_up": [
        "follow-up", "follow up", "visit in", "revisit", "schedule", "return in"
    ],
    "vaccination": [
        "vaccine", "influenza", "pneumococcal", "covid"
    ],
}

# Public mapping used by hybrid/advice classifiers. Start from defaults to ensure
# the symbol always exists at import time. Callers may augment this dict later.
ADVICE_KEYWORDS: dict[str, list[str]] = {k: list(v) for k, v in _DEFAULT_ADVICE_KEYWORDS.items()}

# Optional provenance hints; values kept as None for now (reserved for future use).
ADVICE_SOURCE_HINTS: dict[str, str | None] = {
    "CBF (exact match)": None,
    "CBF (context)": None,
    "CF": None,
}

# === Advice typing: priority & regex rules ===
# Priority used to break ties when multiple categories match.
ADVICE_TYPE_PRIORITY: list[str] = [
    "safety",
    "diagnostic",
    "lab_order",
    "monitoring",
    "device",
    "pharmacologic",
    "adherence",
    "lifestyle",
    "education",
    "referral",
    "follow_up",
    "vaccination",
    "other",
]

# Regex rules for stronger classification signals (case-insensitive).
ADVICE_REGEX: dict[str, list[str]] = {
    "diagnostic": [
        r"\b(rule\s*out|evaluate|work\s*up|workup|confirm|secondary\s+hypertension|screen\s+for|assessment)\b",
    ],
    "monitoring": [
        r"\b(home\s*blood\s*pressure|hbpm|abpm|monitor(ing)?|recheck|track|telemonitor)\b",
    ],
    "lab_order": [
        r"\b(order(ed)?|labs?|creatinine|egfr|potassium|k\+|electrolyte|lipid(s)?|a1c|uacr|urine\s*albumin|renal)\b",
    ],
    "referral": [
        r"\b(refer(ral)?|consult|cardiology|nephrology|endocrinology)\b",
    ],
    "education": [
        r"\b(educat(e|ion|ional)|counsel(ing)?|advise|teach|shared\s*decision)\b",
    ],
    "adherence": [
        r"\b(adherence|compliance|reminder|pill\s*box|blister|behavioral)\b",
    ],
    "safety": [
        r"\b(contraindication|avoid|drug\s*interaction|hyperkalemia|pregnan(cy|t)|renal\s*impairment|black\s*box|alert)\b",
    ],
    "device": [
        r"\b(device|validated\s*cuff|home\s*monitor|bp\s*monitor|abpm\s*device)\b",
    ],
    "follow_up": [
        r"\b(follow-?up|revisit|return\s+in|schedule|visit\s+in)\b",
    ],
    "vaccination": [
        r"\b(vaccine|influenza|pneumococcal|covid)\b",
    ],
}

# =========================
# HYBRID ADVICE CONSTANTS
# (Appended by hybrid integration)
# =========================

# Neutral fallback advice snippet used when neither CBF/CF nor constants provide a decisive text.
# Kept concise and guideline-agnostic; downstream may append context.
ADVICE_FALLBACK: str = (
    "Neutral fallback: insufficient evidence for a specific recommendation — "
    "reinforce core lifestyle measures (DASH, sodium reduction, activity) and "
    "arrange clinician review."
)

# Short pharmacologic templates by feature_id (keys must match the recommender's feature_id values)
PHARM_TEMPLATES: dict[str, str] = {
    # ACE inhibitors / ARBs / CCBs / Beta-blockers / Thiazides examples
    "ace_inhibitor": "Consider an ACE inhibitor as first-line in DM/CKD or when indicated; monitor creatinine & potassium.",
    "arb": "ARBs are an alternative to ACEi when cough/angioedema occur; monitor renal function & potassium.",
    "amlodipine": "Amlodipine (DHP-CCB) is suitable, esp. in elderly/diabetics or with angina; watch for edema.",
    "beta_blocker": "Beta-blockers are useful in CAD/post-MI/arrhythmia; not typically first-line for uncomplicated HTN.",
    "thiazide": "Thiazide diuretics are effective initial therapy; consider chlorthalidone; monitor Na⁺/K⁺.",
    # statins (lipid co-management)
    "statin": "If ASCVD risk is elevated or LDL-C high, add a statin per guideline; monitor LFTs & myalgia.",
    # --- aliases / synonyms (English & Arabic) ---
    "thiazide_diuretic": "Thiazide diuretics are effective initial therapy; consider chlorthalidone; monitor Na⁺/K⁺.",
    "losartan": "ARBs are an alternative to ACEi when cough/angioedema occur; monitor renal function & potassium.",
    "atenolol": "Beta-blockers are useful in CAD/post-MI/arrhythmia; not typically first-line for uncomplicated HTN.",
    # Arabic canonical/alias keys mapped to same concise templates
    "مثبط_الإنزيم_المحوّل": "Consider an ACE inhibitor as first-line in DM/CKD or when indicated; monitor creatinine & potassium.",
    "حاصر_مستقبلات_الأنجيوتنسين": "ARBs are an alternative to ACEi when cough/angioedema occur; monitor renal function & potassium.",
    "أملوديبين": "Amlodipine (DHP-CCB) is suitable, esp. in elderly/diabetics or with angina; watch for edema.",
    "حاصرات_بيتا": "Beta-blockers are useful in CAD/post-MI/arrhythmia; not typically first-line for uncomplicated HTN.",
    "مدر_ثيازيدي": "Thiazide diuretics are effective initial therapy; consider chlorthalidone; monitor Na⁺/K⁺.",
    "ستاتين": "If ASCVD risk is elevated or LDL-C high, add a statin per guideline; monitor LFTs & myalgia.",
}

# Lifestyle templates keyed by a simple tag used from hybrid policy
LIFESTYLE_TEMPLATES: dict[str, str] = {
    "dash": "Apply DASH dietary pattern with reduced sodium (<1500–2300 mg/day) and adequate potassium.",
    "salt_reduction": "Reduce sodium intake (target <1500–2300 mg/day) and avoid high-salt processed foods.",
    "exercise": "Aim for ≥150 min/week moderate-intensity aerobic activity + 2 resistance sessions.",
    "weight": "Target 5–10% weight loss when appropriate; improves BP and cardiometabolic risk.",
    "smoking": "Offer cessation support; quitting substantially lowers overall cardiovascular risk.",
    "sleep": "Screen for sleep apnea and improve sleep hygiene; treat OSA when present.",
    # Arabic counterparts (optional — used when Arabic feature_ids are present)
    "حمية_dash": "اتباع حمية DASH مع تقليل الصوديوم (&lt;1500–2300 ملغ/يوم) وزيادة البوتاسيوم ضمن المسموح.",
    "تقليل_الملح": "تقليل الصوديوم (هدف &lt;1500–2300 ملغ/يوم) وتجنّب الأطعمة المصنّعة عالية الملح.",
    "التمارين": "استهداف ≥150 دقيقة/أسبوع من النشاط الهوائي المتوسط + حصتين مقاومة.",
    "إنقاص_الوزن": "استهداف خفض 5–10% من الوزن عند الملاءمة؛ يُحسّن ضغط الدم والخطر القلبي الاستقلابي.",
    "الإقلاع_عن_التدخين": "تقديم دعم الإقلاع؛ يقلّل بشكل واضح من مخاطر القلب والأوعية.",
    "النوم": "التحرّي عن انقطاع النفس النومي وتحسين النظافة النوم؛ عالج OSA إن وُجد.",
}

# --- Stronger tagging with fallbacks & confidence (overrides older get_guideline_tags) ---
import re as _re

# --- Normalization helper for provenance strings (ensure availability here) ---
# Ensure clean_source_text is available; define a local version only if not already provided.
if "clean_source_text" not in globals():
    # Canonical aliases for noisy provenance strings → normalized labels used by taggers
    SOURCE_CLEAN_ALIASES: dict[str, str] = {
        # kNN variants
        "cbf knn": "CBF (kNN)",
        "cbf (knn)": "CBF (kNN)",
        "cbf - knn": "CBF (kNN)",
        "cbf_kNN".lower(): "CBF (kNN)",
        # exact/context variants
        "cbf exact": "CBF (exact/context match)",
        "cbf (exact)": "CBF (exact/context match)",
        "cbf context": "CBF (exact/context match)",
        "cbf contextual": "CBF (exact/context match)",
        "cbf exact match": "CBF (exact/context match)",
        "cbf: exact match": "CBF (exact/context match)",
        "cbf (context match)": "CBF (exact/context match)",
        # rule variants
        "cbf rule": "CBF (rule)",
        "cbf (rule)": "CBF (rule)",
        "cbf contextual rule": "CBF (contextual_rule)",
        # fallback
        "cbf fallback": "CBF (fallback)",
        "cbf (fallback)": "CBF (fallback)",
    }

    def clean_source_text(text: object) -> str:
        """
        Normalize noisy provenance strings to a small set of canonical labels.
        - Strips whitespace, collapses spaces, removes trailing ', true/false' flags.
        - Applies alias mapping in a case-insensitive manner.
        - Leaves non-CBF strings as-is after trimming (so CF-only rows pass through unchanged).
        """
        s = "" if text is None else str(text).strip()
        if not s:
            return ""
        # Drop common boolean tails often appended by CSV exports
        if s.endswith(", true"):
            s = s[:-6].rstrip()
        elif s.endswith(", false"):
            s = s[:-7].rstrip()
        # Collapse internal whitespace
        s = _re.sub(r"\s+", " ", s)
        low = s.lower()
        # Direct alias map
        if low in SOURCE_CLEAN_ALIASES:
            return SOURCE_CLEAN_ALIASES[low]
        # Pattern harmonization for frequent shapes
        if "cbf" in low:
            if "knn" in low:
                return "CBF (kNN)"
            if "exact" in low or "context" in low or "contextual" in low:
                return "CBF (exact/context match)"
            if "rule" in low and "context" in low:
                return "CBF (contextual_rule)"
            if "rule" in low:
                return "CBF (rule)"
            if "fallback" in low:
                return "CBF (fallback)"
        return s

# Primary mapping for normalized provenance strings (after clean_source_text)
GUIDELINE_TAGS_BY_SOURCE: dict[str, list[str]] = {
    "CBF (exact/context match)": ["AHA2023", "ESC/ESH2023"],
    "CBF (kNN)": ["AHA2023", "ESC/ESH2023"],
    "CBF (fallback)": ["AHA2023"],
    # Extended aliases (future-proof)
    "CBF (contextual_rule)": ["AHA2023"],
    "CBF (rule)": ["AHA2023"],
}

# Regex patterns to recognize noisy/variant provenance strings
_GUIDELINE_SOURCE_PATTERNS: list[tuple[_re.Pattern, list[str], str]] = [
    (_re.compile(r"\bcbf\b.*\b(exact|context)\b", _re.I), ["AHA2023","ESC/ESH2023"], "high"),
    (_re.compile(r"\bcbf\b.*\bknn\b", _re.I),            ["AHA2023","ESC/ESH2023"], "medium"),
    (_re.compile(r"\bcbf\b.*\bfallback\b", _re.I),       ["AHA2023"],               "low"),
]

# Class-based defaults when provenance is absent/unclear
_DEFAULT_TAGS_BY_CLASS = {
    "pharmacologic": (["AHA2023"], "low"),
    "lifestyle":     (["AHA2023","ESC/ESH2023"], "low"),
}

def get_guideline_tags(source_norm: str | None,
                       feature_id: str | None = None,
                       *,
                       with_confidence: bool = False):
    """
    أقوى إرجاع لوسوم الإرشادات:
    1) يطابق المصدر الموحّد مباشرة.
    2) يحاول regex لأنماط شائعة.
    3) يستخدم نوع الميزة كـ backfill (دوائي/نمط حياة).
    4) يعيد [] عند الفشل.
    إذا with_confidence=True سترجع (tags, confidence).
    """
    s = clean_source_text(source_norm)

    # 1) Direct dictionary match
    tags = GUIDELINE_TAGS_BY_SOURCE.get(s)
    if tags:
        return (tags, "high") if with_confidence else tags

    # 2) Pattern-based recognition
    for pat, tg, conf in _GUIDELINE_SOURCE_PATTERNS:
        try:
            if s and pat.search(s):
                return (tg, conf) if with_confidence else tg
        except (AttributeError, TypeError, ValueError, RuntimeError):
            # Be defensive; never fail tagging on regex errors
            continue

    # 3) Feature-class fallback
    if feature_id:
        try:
            fid = str(feature_id).strip().lower()
        except (AttributeError, TypeError, ValueError):
            fid = ""

        # Prefer explicit checks; avoid broad exceptions
        if fid and is_pharmacologic_feature(fid):
            tg, conf = _DEFAULT_TAGS_BY_CLASS.get("pharmacologic", ([], "none"))
            return (tg, conf) if with_confidence else tg

        if fid and is_lifestyle_feature(fid):
            tg, conf = _DEFAULT_TAGS_BY_CLASS.get("lifestyle", ([], "none"))
            return (tg, conf) if with_confidence else tg

    # 4) Nothing matched
    return ([], "none") if with_confidence else []

def pick_constant_for_feature(feature_id: str | None) -> str:
    """Return a concise pharmacologic template for the feature if known; else empty string."""
    if not feature_id:
        return ""
    return PHARM_TEMPLATES.get(str(feature_id).lower(), "")

def pick_lifestyle_defaults() -> list[str]:
    """Default set of lifestyle snippets to consider when lifestyle-first is indicated."""
    order = ["dash", "salt_reduction", "exercise"]
    return [LIFESTYLE_TEMPLATES[k] for k in order if k in LIFESTYLE_TEMPLATES]

# إضافة __all__ إذا لم تكن موجودة، أو تحديثها
__all__ = [
    "BP_CATEGORIES",
    "BP_CATEGORY_NAMES",
    "AGE_GROUPS",
    "BP_BIN4_LABELS",
    "CHOL_BINS_LABELS",
    "AGE_Q3_LABELS",
    "ALL_CONTEXT_FEATURES",
    "DiseaseCodes",
    "RISK_SCORE_THRESHOLDS",
    "CHOLESTEROL_THRESHOLD",
    "CONTEXT_TO_RECOMMENDATION_MAP",
    "FEATURE_ID_BINNED_MAP",
    "recommend_by_binned",
    "assign_feature_id_by_binned",
    "MEDICAL_RECOMMENDATION_PLAN",
    "categorize_bp",
    "categorize_chol",
    "categorize_fbs",
    "categorize_cp",
    "build_context_key",
    "get_medical_plan",
    "plan_as_dict",
    "RECOMMENDATION_EXPLAIN",
    "RECOMMENDATION_SOURCE",
    "CONTEXT_COLUMNS",
    "FEATURE_ID_ALLOWED",
    "feature_id_set",
    "_FEATURE_ID_ALLOWED",
    "BINNED_CONTEXT_COLUMNS",
    "make_binned_key",
    "normalize_label",
    "is_categorical",
    "downcast_context",
    "get_feature_id_allowed",
    "CBF_REASON_TO_SCORE_DEFAULT",
    "ACCEPT_THRESHOLD_DEFAULT",
    "CBF_MIX_DEFAULT",
    "ALLOWED_FEATURE_IDS",
    "get_cbf_scoring_policy",
    "get_cbf_scoring_policy_minimal",
    "ClinicalPlanFields",
    "get_clinical_plan_fields",
    "CONTEXT_MAPS",
    "validate_context_maps_keys",
    "get_top_n_ui",
    "get_top_n_eval",
    "make_context_key",
    "LIFESTYLE_FEATURES",
    "DRUG_FEATURES",
    "is_lifestyle_feature",
    "is_drug_feature",
    "canonicalize_feature_id",
    "sanitize_feature_id",
    "audit_constants",
    "CANONICAL_FEATURE_IDS",
    "ADVICE_MAP",
    "SECONDARY_CONTEXT_COLUMNS",
    "CBF_FILL_RULES",
    "get_fill_action_for_bp",
    "get_risk_bias",
    "get_chol_bias",
    "get_age_bias",
    "CHOLESTEROL_THRESHOLD_ALERT",
    "CHOLESTEROL_THRESHOLD_BORDERLINE",
    "CHOLESTEROL_THRESHOLD_HIGH",
    "CHOLESTEROL_THRESHOLD",
    "is_high_chol_total",
    "validate_feature_id_binned_map",
    "summarize_context_maps",
    "_is_binned_key_valid",
    "is_high_chol_total_series",
    "PHARM_TEMPLATES",
    "LIFESTYLE_TEMPLATES",
    "GUIDELINE_TAGS_BY_SOURCE",
    "SOURCE_CLEAN_ALIASES",
    "ADVICE_FALLBACK",
    "clean_source_text",
    "get_guideline_tags",
    "pick_constant_for_feature",
    "pick_lifestyle_defaults",
    "is_pharmacologic_feature",
    "PHARM_FEATURES",
    "PHARM_FEATURES_SET",
    # --- Advice taxonomy exports (inserted for hybrid/expanded advice) ---
    "ADVICE_TYPES",
    "ADVICE_KEYWORDS",
    "ADVICE_TYPES",
    "ADVICE_KEYWORDS",
    "ADVICE_TYPES",
    "ADVICE_KEYWORDS",
    "ADVICE_SOURCE_HINTS",
    "ADVICE_TYPE_PRIORITY",  # ← جديد
    "ADVICE_REGEX",  # ← جديد

]

# دالة fallback احترافية منفصلة حسب مستوى الخطورة
def get_fallback_dict(risk):
    """
    توليد قاموس fallback احترافي حسب مستوى الخطورة.
    """
    base_dict = {
        "action": "مراجعة يدوية من قبل الطبيب",
        "advice": "يرجى مراجعة الطبيب المختص لمزيد من التقييم والمتابعة.",
        "explanation": f"هذه الحالة غير مغطاة تماماً بالقاموس السريري، تم تصنيفها تلقائيًا كـ '{risk}' خطورة.",
        "source": f"Fallback Recommendation (Risk Level: {risk})"
    }
    return base_dict

def build_contextual_dict_from_data(df, rec_col="feature_id", context_columns=None):
    """
    توليد قاموس توصية سياقية من DataFrame.
    ⚠️ يجب استخدام make_context_key فقط لبناء المفاتيح.
    """
    if context_columns is None:
        context_columns = CONTEXT_COLUMNS
    rec_map = {}
    for _, row in df.iterrows():
        key = make_context_key(row, context_columns=context_columns)
        rec = row[rec_col]
        if pd.notnull(rec):
            rec_map[key] = rec
    return rec_map

 # ============================================================================
 # CBF MINIMAL API (appended): تثبيت الثوابت + التطبيع + النصائح
 # ملاحظة: هذه الكتلة تضبط واجهة مبسّطة مطلوبة من طبقة CBF فقط،
 # وتأتي في نهاية الملف كي لا تغيّر منطق بناء القواميس أعلاه عند الاستيراد.
 # أي استيراد لاحق من utils.constants لهذه الأسماء سيأخذ القيم أدناه.
 # ============================================================================

from typing import Any as _Any

# أعمدة السياق الأساسية (ثلاثية) التي تعتمدها طبقة CBF
CONTEXT_COLUMNS = ["bp_category", "chol_category", "risk_level"]

# أعمدة سياقية مبسطة مساندة لـ CBF (ليست هي أعمدة الـ binned الثلاثية)
BINNED_CONTEXT_COLUMNS = ["fbs_cat", "cp_cat"]  # فعّل/عدّل حسب بياناتك

def normalize_label(x: _Any) -> str:
    s = str(x).strip().lower().replace(" ", "_").replace("-", "_")
    if s in {"", "none", "null", "nan"}:
        return "unknown"
    return s

# خريطة النصائح (حَصرًا) — تستخدم حصريًا في apply_cbf_narratives
ADVICE_MAP = {
    "lifestyle_monitoring": "إجراءات نمط الحياة والمتابعة الدورية لضغط الدم.",
    "diet_control": "تقليل الصوديوم واتباع حمية DASH مع توازن السعرات.",
    "ace_inhibitor": "مناقشة بدء/تعديل العلاج الدوائي (ACEI) وفق التقييم الطبي.",
    "increase_exercise": "نشاط بدني منتظم (150 دقيقة/أسبوع) ما لم توجد موانع.",
}

# قائمة معرّفات مقنّنة صغيرة للـ CBF (لا تغيّر قواميس السلوك أعلاه)
CANONICAL_FEATURE_IDS = {
    "lifestyle_monitoring", "diet_control", "increase_exercise",
    "ace_inhibitor", "arb", "amlodipine", "thiazide",
    "beta_blocker", "statin"
}

def canonicalize_feature_id(x: _Any) -> str:
    """
    تبسيط مقصود: فقط ما تحتاجه طبقة CBF.
    لا تُستخدم هذه الدالة لتنظيف القواميس السريرية المبنية أعلاه.
    """
    t = normalize_label(x)
    if t in CANONICAL_FEATURE_IDS:
        return t
    if "amlodipine" in t: return "amlodipine"
    if "beta" in t: return "beta_blocker"
    if "thiaz" in t: return "thiazide"
    if "ace" in t: return "ace_inhibitor"
    if "arb" in t: return "arb"
    if "statin" in t: return "statin"
    if "life" in t or "exercise" in t or "diet" in t: return "lifestyle_monitoring"
    return t

# --- Minimal policy accessor (single source of truth) ---
_CBF_REASON_DEFAULTS = {
    "recommended": 1.0,
    "context_key_match": 0.88,
    "similarity_fallback_high": 0.82,
    "similarity_fallback_medium": 0.65,
    "similarity_fallback_low": 0.50,
    "knn_recommendation": 0.90,
    "knn_fallback": 0.70,
    "manual_review": 0.0,
}

# ===== HYBRID: explicit feature classes (append-only) =====
# Keep a set for fast membership and expose a list for typed callers
PHARM_FEATURES_SET: set[str] = {
    "ace_inhibitor", "arb", "amlodipine", "beta_blocker",
    "thiazide", "thiazide_diuretic", "amlodipine_and_thiazide", "statin"
}
PHARM_FEATURES: list[str] = sorted(PHARM_FEATURES_SET)

# Keep a set for fast membership and expose a list for typed callers
LIFESTYLE_FEATURES_SET: set[str] = {
    "diet_control", "lifestyle_monitoring", "increase_exercise",
    "salt_reduction", "dash", "weight", "smoking", "sleep"
}
LIFESTYLE_FEATURES: list[str] = sorted(LIFESTYLE_FEATURES_SET)

# Pharmacologic classifier: wrap existing helper if available; otherwise, define locally
if "is_drug_feature" in globals() and callable(globals().get("is_drug_feature")):
    def is_pharmacologic_feature(fid: str) -> bool:  # type: ignore[override]
        try:
            return bool(globals()["is_drug_feature"](fid))  # type: ignore[misc]
        except (TypeError, ValueError, AttributeError):
            # Safe fallback to local PHARM_FEATURES_SET lookup
            if not fid:
                return False
            return str(fid).strip().lower() in PHARM_FEATURES_SET
else:
    def is_pharmacologic_feature(fid: str) -> bool:
        if not fid:
            return False
        return str(fid).strip().lower() in PHARM_FEATURES_SET

# Lifestyle classifier: only define if not already provided upstream
if "is_lifestyle_feature" not in globals() or not callable(globals().get("is_lifestyle_feature")):
    def is_lifestyle_feature(fid: str) -> bool:
        if not fid:
            return False
        return str(fid).strip().lower() in LIFESTYLE_FEATURES_SET
# If an existing is_lifestyle_feature exists and is callable, we keep it as-is.