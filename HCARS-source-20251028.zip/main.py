# -*- coding: utf-8 -*-
"""
واجهة نهائية احترافية لعرض نتائج أنظمة التوصية (Hybrid / CBF / CF)
- تحميل نتائج CSV/JSON النهائية تلقائيًا
- عرض جداول + مؤشرات أداء + رسوم بيانية
- واجهة متينة (defensive) ضد الملفات المفقودة/الأعمدة الناقصة
تشغيل محلي:
    streamlit run main.py
"""

from __future__ import annotations

import os
import json
import uuid
import logging
from pathlib import Path
from typing import Dict, Any, Tuple, Optional, List
import base64

import re
import pandas as pd
import numpy as np

import streamlit as st

# Page config MUST be set before any other Streamlit command
st.write("")
st.write("")
st.write("")
st.set_page_config(
    page_title="Hypertension Recommender — Final Viewer",
    layout="wide",
    page_icon="🩺"
)

# رسوم بيانية
import matplotlib.pyplot as plt
import seaborn as sns

from matplotlib.colors import LinearSegmentedColormap

# ============================ واجهة: سِمات و CSS مخصّص ============================
def _inject_css():
    """حقن CSS ليظهر التطبيق كمركز بيانات طبي داكن بألوان هادئة."""
    st.markdown(
        """
        <style>
        :root{
            --teal-700:#0F766E;
            --emerald-500:#10B981;
            --teal-500:#14B8A6;
            --green-500:#22C55E;
            --slate-900:#0b1220;
            --slate-800:#1f2937;
            --slate-700:#334155;
            --slate-600:#475569;
            --slate-500:#64748B;
            --slate-400:#94A3B8;
            --slate-300:#CBD5E1;
            --slate-200:#E2E8F0;
            --slate-100:#F1F5F9;
        }
        .stApp { background: radial-gradient(1200px 800px at 10% 0%, rgba(20,184,166,0.05), transparent 40%) , #0B1220; }
        section[data-testid="stSidebar"] {
           background: linear-gradient(180deg, rgba(15,118,110,0.12), rgba(15,118,110,0.06)) , #0D1524;
           border-right: 1px solid rgba(20,184,166,0.15);
           width: 240px !important;
           min-width: 240px !important;
           max-width: 240px !important;
        }
        /* Ensure inner content follows the same width */
        section[data-testid="stSidebar"] > div:first-child{
           width: 240px !important;
           display: flex !important;
           flex-direction: column !important;
           align-items: center !important;   /* center all direct content */
           padding-left: 0 !important;
           padding-right: 0 !important;
        }
        h1, h2, h3 { letter-spacing: .2px; }
        h1 { color: var(--slate-100) !important; }
        h2, h3 { color: var(--slate-200) !important; }
        .block-container { padding-top: 1.2rem; }
        .stMarkdown, .stText, .stDataFrame, .stTable, .stPlotlyChart, .stPlot { background: transparent !important; }
        .stDataFrame div[data-testid="stHorizontalBlock"] { background: transparent; }
        .stDataFrame thead tr { background: rgba(148,163,184,0.08) !important; }
        .stDataFrame tbody tr:hover { background: rgba(20,184,166,0.06) !important; }
        .stDataFrame, .stTable { color: var(--slate-200) !important; }
        .stButton>button, .stDownloadButton>button {
            border-radius: 10px; border: 1px solid rgba(20,184,166,0.25);
            background: linear-gradient(180deg, rgba(20,184,166,0.18), rgba(16,185,129,0.12));
            color: var(--slate-100); padding: .45rem .8rem;
        }
        .stButton>button:hover, .stDownloadButton>button:hover {
            border-color: var(--teal-500);
            box-shadow: 0 0 0 3px rgba(20,184,166,0.18) inset;
        }
        [data-testid="stMetricValue"] { color: var(--slate-100); }
        [data-testid="stMetricLabel"] { color: var(--slate-300); }
        [data-testid="stMetricDelta"] { color: var(--green-500); }
        button[role="tab"] {
            background: rgba(15,118,110,0.10) !important;
            color: var(--slate-200) !important;
            border-radius: 10px;
            margin-right: .25rem;
        }
        button[role="tab"][aria-selected="true"]{
            background: rgba(20,184,166,0.18) !important;
            border: 1px solid rgba(20,184,166,0.35) !important;
            color: white !important;
        }
        .stSelectbox, .stMultiSelect, .stTextInput { background: transparent !important; }
        .stPlot > div, .stAltairChart > div { background: transparent !important; }
        .med-divider {
            width: 100%; height: 1px; margin: 1.25rem 0;
            background: linear-gradient(90deg, rgba(20,184,166,0.0), rgba(20,184,166,0.5), rgba(20,184,166,0.0));
        }
        .med-subtle { color: var(--slate-400); font-size: 0.9rem; }
        /* Sidebar pills: vertical (one per line) & equal size, centered + max width */
        section[data-testid="stSidebar"] div[data-baseweb="button-group"]{
            display: grid !important;
            grid-template-columns: 1fr !important;
            gap: 8px !important;
            width: 100% !important;
            max-width: 220px !important;  /* center within sidebar */
            margin: 0 auto !important;
        }
        section[data-testid="stSidebar"] div[data-baseweb="button-group"] > div{
            width: 100% !important;
        }
        section[data-testid="stSidebar"] div[data-baseweb="button-group"]::before{
            content: "";
            display: block;
            height: 0px; /* spacing is added via markdown below as well */
        }
        section[data-testid="stSidebar"] div[data-baseweb="button-group"] button{
            width: 100% !important;
            min-height: 44px !important;
            border-radius: 12px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            text-align: center !important;
            font-weight: 600 !important;
            font-size: 18px !important;
        }
        /* Ensure inner content (spans/divs) is centered as well */
        section[data-testid="stSidebar"] div[data-baseweb="button-group"] button *{
            justify-content: center !important;
            text-align: center !important;
            margin-left: auto !important;
            margin-right: auto !important;
        }
        section[data-testid="stSidebar"] div[data-baseweb="button-group"] button[aria-pressed="true"],
        section[data-testid="stSidebar"] div[data-baseweb="button-group"] button[aria-selected="true"]{
            border: 1px solid rgba(20,184,166,0.35) !important;
            background: rgba(20,184,166,0.18) !important;
            color: #ffffff !important;
        }

        /* Wrapper that we render via st.markdown('<div class="pills-center">') */
        section[data-testid="stSidebar"] .pills-center{
            display: flex !important;
            width: 100% !important;
            justify-content: center !important;   /* center horizontally */
            align-items: center !important;       /* center vertically within wrapper */
        }

        /* The BaseWeb button-group that renders the pills */
        section[data-testid="stSidebar"] .pills-center div[data-baseweb="button-group"]{
            display: grid !important;
            grid-template-columns: 1fr !important; /* vertical, one per line */
            gap: 8px !important;
            width: 100% !important;
            max-width: 220px !important;           /* narrower than sidebar */
            margin-left: auto !important;          /* center via auto margins */
            margin-right: auto !important;
        }

        /* Each pill fills the pills container width; text centered */
        section[data-testid="stSidebar"] .pills-center div[data-baseweb="button-group"] button{
            width: 100% !important;
            min-height: 44px !important;
            border-radius: 12px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            text-align: center !important;
            font-weight: 600 !important;
            font-size: 18px !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

def _section_header(title: str, emoji: str = "🩺"):
    """عنوان قسم مع فاصل متدرّج يعطي إحساس منتجات طبية."""
    st.markdown(f"<h2>{emoji} {title}</h2>", unsafe_allow_html=True)
    st.markdown('<div class="med-divider"></div>', unsafe_allow_html=True)

# لوحة ألوان سريرية هادئة (مناسبة للخلفية السوداء)
CLINICAL_PALETTE = ["#0F766E", "#10B981", "#14B8A6", "#22C55E"]

# Seaborn: أسلوب بسيط + لوحة ألواننا
sns.set_theme(style="white")  # أقل شبكة ممكنة؛ سنترك الخلفية شفافة
sns.set_palette(CLINICAL_PALETTE)

# Matplotlib: شفافية كاملة وتهيئة ألوان النص/المحاور للوضع الداكن (رمادي فاتح)
plt.rcParams["figure.facecolor"] = "none"
plt.rcParams["axes.facecolor"]  = "none"
plt.rcParams["savefig.facecolor"] = "none"
# نص وعناصر فاتحة لقراءة أفضل
plt.rcParams["text.color"]       = "#F2F2F2"
plt.rcParams["axes.labelcolor"]  = "#EDEDED"
plt.rcParams["axes.edgecolor"]   = "#CFCFCF"
plt.rcParams["xtick.color"]      = "#E6E6E6"
plt.rcParams["ytick.color"]      = "#E6E6E6"
# شبكة خفيفة جدًا حتى لا تطغى على الخلفية الداكنة
plt.rcParams["axes.grid"]   = True
plt.rcParams["grid.color"]  = "#444444"
plt.rcParams["grid.alpha"]  = 0.18
# أحجام خط متوازنة
plt.rcParams["font.size"]        = 12
plt.rcParams["axes.titlesize"]   = 14
plt.rcParams["axes.titleweight"] = "semibold"
plt.rcParams["axes.labelsize"]   = 12
plt.rcParams["legend.frameon"]   = False

# Colormap للـ Heatmaps مشتق من نفس التدرّج السريري
CLINICAL_CMAP = LinearSegmentedColormap.from_list(
    "clinical_teal", ["#0F766E", "#14B8A6", "#22C55E", "#10B981"]
)

# ألوان نص وتيكات فاتحة موحّدة
LIGHT_TEXT = "#F2F2F2"
LIGHT_LABEL = "#EDEDED"
LIGHT_TICK = "#E6E6E6"
LIGHT_EDGE = "#CFCFCF"

# أحجام افتراضية للرسومات (أصغر قليلًا)
FIGSIZE = (6, 3.6)
FIGSIZE_HEAT = (7, 5)
FIGSIZE_SQUARE = (5, 5)  # للرسم الدائري

# ================= Arabic text rendering (matplotlib/seaborn) =================
# إصلاح عرض العربية المعكوس/المفكك باستخدام arabic_reshaper + bidi، مع خطوط تدعم العربية
try:
    import arabic_reshaper  # type: ignore
    from bidi.algorithm import get_display as _bidi_get_display  # type: ignore
except ImportError:
    arabic_reshaper = None
    _bidi_get_display = None

# WordCloud import (optional)
try:
    from wordcloud import WordCloud, STOPWORDS  # type: ignore
except ImportError:
    WordCloud = None  # type: ignore
    STOPWORDS = set()  # type: ignore

def _ar_text(val):
    """إرجاع نص عربي مُشكّل وباتجاه RTL؛ يرجع الأصلي إن لم تتوفر المكتبات."""
    try:
        s = str(val)
    except (TypeError, ValueError):
        return ""
    if not s:
        return s
    if arabic_reshaper and _bidi_get_display:
        try:
            reshaped = arabic_reshaper.reshape(s)
            return _bidi_get_display(reshaped)
        except (ValueError, TypeError, RuntimeError):
            return s
    return s


# Arabic font finder for WordCloud/matplotlib
def _find_arabic_font_path() -> Optional[str]:
    """
    Returns a path to a TTF/OTF that supports Arabic glyphs if found, else None.
    We probe a few common locations for macOS/Linux/Windows.
    """
    candidates = [
        # macOS common fonts
        "/Library/Fonts/Arial Unicode.ttf",
        "/Library/Fonts/Arial Unicode MS.ttf",
        "/Library/Fonts/Tahoma.ttf",
        "/System/Library/Fonts/Supplemental/Tahoma.ttf",
        "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
        "/System/Library/Fonts/Supplemental/Arial Unicode MS.ttf",
        # Linux (Noto/DejaVu)
        "/usr/share/fonts/truetype/noto/NotoNaskhArabic-Regular.ttf",
        "/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        # Windows
        "C:\\Windows\\Fonts\\arialuni.ttf",
        "C:\\Windows\\Fonts\\tahoma.ttf",
        "C:\\Windows\\Fonts\\Arial Unicode MS.ttf",
    ]
    for p in candidates:
        try:
            if os.path.exists(p):
                return p
        except (OSError, ValueError):
            continue
    return None

def _ensure_arabic_fonts():
    """تهيئة خطوط ملائمة للعربية + تعطيل minus Unicode حتى يظهر مع هذه الخطوط."""
    plt.rcParams["font.family"] = "sans-serif"
    plt.rcParams["font.sans-serif"] = [
        "Cairo",
        "Noto Naskh Arabic",
        "Amiri",
        "DejaVu Sans",
        "Arial Unicode MS",
        "Tahoma",
    ]
    plt.rcParams["axes.unicode_minus"] = False


# WordCloud rendering helper with Arabic support/fallback
def _render_wordcloud(text: str, title: str = "Word Cloud", max_words: int = 200):
    """
    Render a word cloud image. Supports Arabic via arabic_reshaper + bidi if available.
    Falls back with a friendly warning if `wordcloud` is not installed.
    """
    text = (text or "").strip()
    if not text:
        st.info("لا توجد كلمات كافية لتوليد سحابة الكلمات.")
        return
    if WordCloud is None:
        st.warning("حزمة wordcloud غير مثبتة. ثبّت `pip install wordcloud` لتفعيل سحابة الكلمات.")
        return

    # إيقافيات عربي/إنجليزي
    ar_stops = {
        "من", "في", "على", "إلى", "الى", "عن", "هذا", "هذه", "ذلك", "تلك", "هناك", "هنا", "هو", "هي", "هم", "هن",
        "كما", "لكن", "أو", "او", "و", "ثم", "مع", "كل", "كان", "كانت", "يكون", "يمكن", "قد", "لقد", "بل", "غير",
        "أي", "اي", "أن", "ان", "إن", "إنه", "أنها", "حتى", "بعد", "قبل", "عند", "إذا", "اذا", "ما", "لا", "لم", "لن",
        "عبر", "ضمن", "بين", "بدون", "مثل", "أيضًا", "ايضًا", "أكثر", "اكثر", "أقل", "اقل", "حسب", "ضد", "كما",
    }
    base_stop = set(STOPWORDS) | ar_stops

    # اسمح بالأرقام والواصلات حتى لا تُستبعد قيم مثل 18–30
    raw_tokens = re.split(r"\s+", text)
    tokens = [t for t in raw_tokens if len(t) > 1 and any(ch.isalnum() for ch in t)]
    if not tokens:
        st.info("لا توجد كلمات كافية لتوليد سحابة الكلمات بعد التنقية.")
        return
    shaped = " ".join(_ar_text(tok) for tok in tokens)

    font_path = _find_arabic_font_path()

    wc_tmp = WordCloud(
        width=900, height=420,
        background_color=None, mode="RGBA",
        prefer_horizontal=0.95,
        max_words=max_words,
        font_path=font_path,
        stopwords=base_stop,
        collocations=False,
        regexp=r"[\u0600-\u06FFa-zA-Z0-9_\-–']+",
    )
    freqs = wc_tmp.process_text(shaped)
    if not freqs:
        st.info("لا توجد كلمات كافية لتوليد سحابة الكلمات بعد المعالجة.")
        return

    try:
        wc = wc_tmp.generate_from_frequencies(freqs)
    except ValueError:
        st.info("لا توجد كلمات كافية لتوليد سحابة الكلمات.")
        return

    fig, ax = plt.subplots(figsize=(8.5, 4.8), constrained_layout=False)
    ax.imshow(wc, interpolation="bilinear")
    ax.set_axis_off()
    ax.set_title(_ar_text(title))
    _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
    st_safe_pyplot(fig)
    plt.close(fig)

def _arabicize_axis(ax):
    """
    Arabic-friendly axis decorator:
    - يعالج العناوين والتسميات (BiDi/reshaping).
    - يحدّث كائنات نص الـticks مباشرة بدل set_*ticklabels لتجنّب تحذير FixedLocator.
    - يطبّق ألوان النص والتيكات الفاتحة.
    """
    if ax is None:
        return

    # العنوان وتسميات المحاور
    try:
        title = ax.get_title()
        if isinstance(title, str) and title:
            ax.set_title(_ar_text(title))
    except (AttributeError, TypeError):
        pass

    try:
        xl = ax.get_xlabel()
        if isinstance(xl, str) and xl:
            ax.set_xlabel(_ar_text(xl))
    except (AttributeError, TypeError):
        pass

    try:
        yl = ax.get_ylabel()
        if isinstance(yl, str) and yl:
            ax.set_ylabel(_ar_text(yl))
    except (AttributeError, TypeError):
        pass

    # تعديل نصوص الـticks الموجودة بدلاً من set_xticklabels/set_yticklabels
    try:
        for t in ax.get_xticklabels():
            txt = t.get_text()
            if isinstance(txt, str) and txt:
                t.set_text(_ar_text(txt))
    except (AttributeError, TypeError):
        pass

    try:
        for t in ax.get_yticklabels():
            txt = t.get_text()
            if isinstance(txt, str) and txt:
                t.set_text(_ar_text(txt))
    except (AttributeError, TypeError):
        pass

    # توحيد الألوان الفاتحة على المحاور والتيكات
    try:
        ax.title.set_color(LIGHT_TEXT)
        ax.xaxis.label.set_color(LIGHT_LABEL)
        ax.yaxis.label.set_color(LIGHT_LABEL)
        ax.tick_params(colors=LIGHT_TICK)
        for spine in ax.spines.values():
            spine.set_color(LIGHT_EDGE)
    except (AttributeError, ValueError, TypeError, NotImplementedError):
        # نلتقط أخطاء السمات/الأنواع فقط؛ ونتجنب اعتراض كل الاستثناءات بلا داعٍ
        pass

# تهيئة الخطوط مرة واحدة
_ensure_arabic_fonts()

# إعدادات عامة
LOG_ID = uuid.uuid4().hex[:8]
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("ui")
logger.info(f"🔖 Session Log ID: {LOG_ID}")
# تخفيض رسائل معلومات Matplotlib حول الوحدات التصنيفية (تظهر كـ "Using categorical units…")
logging.getLogger("matplotlib").setLevel(logging.WARNING)
logging.getLogger("matplotlib.category").setLevel(logging.WARNING)

# ----------------------------- مسارات الملفات النهائية -----------------------------
HYBRID_FILES = {
    "df_hybrid_recommendations.csv": "outputs/Hybrid/df_hybrid_recommendations.csv",
    "hybrid_eval_summary.json":      "outputs/Hybrid/hybrid_eval_summary.json",
}

CBF_FILES = {
    "cbf_eval_unique.csv":              "outputs/CBF/cbf_eval_unique.csv",
    "cbf_eval_loco.csv":                "outputs/CBF/cbf_eval_loco.csv",
    "cbf_recs_loco_rows.csv":           "outputs/CBF/cbf_recs_loco_rows.csv",
    "df_cbf_recommendations_eval.csv":  "outputs/CBF/df_cbf_recommendations_eval.csv",
    "df_cbf_recommendations.csv":       "outputs/CBF/df_cbf_recommendations.csv",
}

CF_FILES = {
    "df_cf_recommendations.csv":                  "outputs/CF/df_cf_recommendations.csv",
    "df_cf_recommendations_eval.csv":             "outputs/CF/df_cf_recommendations_eval.csv",
    "df_cf_recommendations_eval_loco.csv":        "outputs/CF/df_cf_recommendations_eval_loco.csv",
    "df_cf_recommendations_eval_loco_family.csv": "outputs/CF/df_cf_recommendations_eval_loco_family.csv",
}

PREPROC_FILES = {
    "df_cleaned.csv"       : "outputs/tmp/df_cleaned.csv",
    "df_contextualized.csv": "outputs/tmp/df_contextualized.csv",
}

# ----------------------------- مسار البيانات الأصلية -----------------------------
ORIGINAL_DATA_PATH = "data/hypertension_data.csv"

ALL_GROUPS = {
    "Hybrid"    : HYBRID_FILES,
    "CBF"       : CBF_FILES,
    "CF"        : CF_FILES,
    "Preprocess": PREPROC_FILES,
    # تبويب مخصص لعرض df_contextualized فقط
    "Context"   : {"df_contextualized.csv": PREPROC_FILES["df_contextualized.csv"]},
}

# ----------------------------- قاموس الأعمدة (وصف الحقول) -----------------------------
COLUMN_DOC = {
    "age": "patient's age (in years)",
    "sex": "patient's gender (1: male; 0: female)",
    "cp": "Chest pain type: 0: asymptomatic 1: typical angina 2: atypical angina 3: non-anginal pain",
    "trestbps": "Resting blood pressure (in mm Hg)",
    "chol": "Serum cholestoral in mg/dl",
    "fbs": "if the patient's fasting blood sugar > 120 mg/dl (1: yes; 0: no)",
    "restecg": "Resting ECG results: 0: normal 1: ST-T wave abnormality (> 0.05 mV) 2: probable/definite LV hypertrophy (Estes)",
    "thalach": "Maximum heart rate achieved",
    "exang": "Exercise induced angina (1: yes; 0: no)",
    "oldpeak": "ST depression induced by exercise relative to rest",
    "slope": "Peak exercise ST segment slope: 0: upsloping 1: flat 2: downsloping",
    "ca": "Number of major vessels (0–3) colored by fluoroscopy",
    "thal": "3: Normal; 6: Fixed defect; 7: Reversible defect",
    "target": "Whether the patient has hypertension (1) or not (0)"
}

# ----------------------------- Sidebar branding (optional image) -----------------------------
SIDEBAR_LOGO_CANDIDATES = [
    "assets/image.png",
]

# Header icon fixed configuration (code-controlled; no sidebar sliders)
ICON_WIDTH_PX = 60
ICON_SHIFT_LEFT_PX  = 0    # ← عدّل هذه القيمة لتحريك أيقونة اليسار أفقيًا (سالب=يسار، موجب=يمين)
ICON_SHIFT_RIGHT_PX = 0    # ← عدّل هذه القيمة لتحريك أيقونة اليمين أفقيًا (سالب=يسار، موجب=يمين)

# ----------------------------- Global font & theme setup (Arabic + English) -----------------------------
def _setup_fonts_and_theme():
    """
    اضبط خطوط Matplotlib/Seaborn لتكون مناسبة للعربية والإنجليزية مع أحجام وألوان متناسقة.
    نستخدم حزمة بدائل (fallback) واسعة: خطوط عربية أولاً ثم لاتينية؛
    DejaVu Sans يضمن أرقام/لاتيني بشكل جيد عند غياب خط عربي.
    """
    import matplotlib as mpl
    FONT_STACK = [
        "Cairo", "Almarai", "Noto Sans Arabic", "Tajawal", "Amiri",
        "Noto Sans", "DejaVu Sans", "Arial", "Helvetica", "Segoe UI", "Liberation Sans"
    ]
    mpl.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": FONT_STACK,
        "axes.unicode_minus": False,
        "figure.titlesize": 14,
        "axes.titlesize": 12,  # keep titles slightly smaller to fit more content
        "axes.labelsize": 8,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "legend.fontsize": 8,
        "figure.autolayout": True,
        # ألوان فاتحة للثيم الداكن
        "text.color": LIGHT_TEXT,
        "axes.labelcolor": LIGHT_LABEL,
        "axes.edgecolor": LIGHT_EDGE,
        "xtick.color": LIGHT_TICK,
        "ytick.color": LIGHT_TICK,
        "grid.color": "#444444",
    })
    try:
        # مرّر rc لضمان التزام Seaborn بنفس الألوان الفاتحة
        sns.set_theme(context="notebook", style="whitegrid", rc={
            "text.color": LIGHT_TEXT,
            "axes.labelcolor": LIGHT_LABEL,
            "axes.edgecolor": LIGHT_EDGE,
            "xtick.color": LIGHT_TICK,
            "ytick.color": LIGHT_TICK,
            "grid.color": "#444444",
        })
        import matplotlib as mpl
        mpl.rcParams["figure.constrained_layout.use"] = False
    except Exception as e:
        logger.debug("sns.set_theme failed: %s", e)

# تطبيق إعدادات الخط والسمات مباشرة
_setup_fonts_and_theme()

# Helper: Convert image file to base64 for embedding
@st.cache_data(show_spinner=False)
def _image_to_base64(path: str) -> Optional[str]:
    try:
        if not os.path.exists(path):
            return None
        with open(path, "rb") as f:
            data = base64.b64encode(f.read()).decode("utf-8")
        # Guard: ensure this is a real payload (not a short random token)
        if len(data) < 64:
            return None
        return data
    except (OSError, ValueError, UnicodeDecodeError) as e:
        logger.debug("image_to_base64 failed for %s: %s", path, e)
        return None

# Helper: Render header icon with optional horizontal offset
def _icon_html(b64: Optional[str], width: int = 55, shift_px: int = 0, align: str = "center") -> str:
    """HTML builder for header icon with horizontal (X) offset."""
    if not b64:
        return ""
    just = "flex-start" if align == "left" else ("flex-end" if align == "right" else "center")
    return (
        f"<div style='display:flex; justify-content:{just};'>"
        f"<img src='data:image/png;base64,{b64}' style='width:{width}px; transform: translateX({shift_px}px);' />"
        f"</div>"
    )

def _sidebar_brand():
    """Show a logo in the sidebar using base64 to avoid transient MediaFileHandler errors; fallback to text badge."""
    for p in SIDEBAR_LOGO_CANDIDATES:
        if os.path.exists(p):
            b64 = _image_to_base64(p)
            if b64:
                st.sidebar.markdown(
                    f"<img src='data:image/png;base64,{b64}' alt='logo' style='display:block; margin:0 auto 6px auto; max-width:180px; width:100%; height:auto;' />",
                    unsafe_allow_html=True,
                )
                st.sidebar.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)
                return
            # if base64 failed, fall back to image (rare)
            try:
                b64_fallback = _image_to_base64(p)
                if b64_fallback:
                    st.sidebar.markdown(
                        f"<img src='data:image/png;base64,{b64_fallback}' alt='logo' style='display:block; margin:0 auto 6px auto; max-width:180px; width:100%; height:auto;' />",
                        unsafe_allow_html=True,
                    )
                    st.sidebar.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)
                    return
            except (RuntimeError, OSError, ValueError) as e:
                logger.debug("sidebar.image fallback (b64) failed for %s: %s", p, e)
    # Fallback text badge if no image is found
    st.sidebar.markdown(
        "<div style='font-weight:700; color:#E5E7EB; font-size:16px;'>Clinical Data Hub</div>"
        "<div class='med-subtle'>Hypertension Recommender</div>"
        "<div style='height:6px'></div>",
        unsafe_allow_html=True,
    )

# ----------------------------- أدوات مساعدة عامة -----------------------------
@st.cache_data(show_spinner=False)
def _load_csv(path: str) -> Optional[pd.DataFrame]:
    try:
        if not os.path.exists(path):
            return None
        return pd.read_csv(path)
    except (OSError, ValueError, UnicodeDecodeError, pd.errors.ParserError) as e:
        logger.exception("CSV load failed for %s", path)
        st.warning(f"⚠️ تعذّر قراءة الملف: {path} — {e}")
        return None

@st.cache_data(show_spinner=False)
def _load_json(path: str) -> Optional[Dict[str, Any]]:
    try:
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError, UnicodeDecodeError, ValueError) as e:
        logger.exception("JSON load failed for %s", path)
        st.warning(f"⚠️ تعذّر قراءة JSON: {path} — {e}")
        return None

def _metric_card(label: str, value: Any, fmt: str = None):
    if fmt and isinstance(value, (int, float)):
        try:
            formatted = fmt.format(value)
        except (ValueError, TypeError):
            # إذا كانت صيغة التنسيق غير صحيحة أو النوع غير مناسب، اعرض القيمة كما هي
            formatted = f"{value}"
        st.metric(label, formatted)
    else:
        st.metric(label, value)

def _describe_numeric(df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    cols = [c for c in cols if c in df.columns]
    if not cols:
        return pd.DataFrame()
    return df[cols].describe().T

def _value_counts(df: pd.DataFrame, col: str, topn: int = 20) -> pd.DataFrame:
    if col not in df.columns:
        return pd.DataFrame()
    vc = df[col].astype(str).fillna("NA").replace({"nan": "NA"}).value_counts().head(topn)
    return vc.rename_axis(col).reset_index(name="count")

def _download_button_df(df: pd.DataFrame, label: str, filename: str):
    st.download_button(
        label=label,
        data=df.to_csv(index=False).encode("utf-8"),
        file_name=filename,
        mime="text/csv"
    )

# ----------------------------- Safe layout helper (no engine conflicts) -----------------------------
def _safe_layout(fig, ax=None, *, pad=0.02, w_pad=0.02, h_pad=0.02):
    import warnings

    # إذا لم توجد محاور، لا شيء لتهيئته
    if not hasattr(fig, "axes") or len(getattr(fig, "axes", [])) == 0:
        return

    # تطبيع المدخلات واستخدامها فعليًا
    try:
        pad_in = float(pad)
    except (TypeError, ValueError):
        pad_in = 0.02
    try:
        w_pad_in = float(w_pad)
    except (TypeError, ValueError):
        w_pad_in = 0.02
    try:
        h_pad_in = float(h_pad)
    except (TypeError, ValueError):
        h_pad_in = 0.02

    # إطفاء أي محرّك تخطيط لمنع تضارب Streamlit أثناء الحفظ/العرض
    try:
        if hasattr(fig, "set_layout_engine"):
            fig.set_layout_engine(None)
        if hasattr(fig, "set_constrained_layout"):
            fig.set_constrained_layout(False)
    except (AttributeError, RuntimeError, TypeError, ValueError):
        pass

    # استخدم pad لرسم خريطة إلى هوامش معقولة:
    # pad (≈0..0.2) ←→ margin (≈0.06..0.18)
    margin = max(0.06, min(0.18, pad_in * 3.0))

    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            category=UserWarning,
            message=r".*incompatible with subplots_adjust.*"
        )
        try:
            if hasattr(fig, "subplots_adjust"):
                fig.subplots_adjust(
                    left=margin,
                    right=1.0 - margin,
                    top=1.0 - margin,
                    bottom=margin,
                    wspace=max(0.08, w_pad_in * 4.0),
                    hspace=max(0.08, h_pad_in * 4.0),
                )
        except (RuntimeError, ValueError, TypeError, AttributeError):
            pass

    # تأمين حجم غير صفري تحسبًا لرسومات صغيرة جدًا
    try:
        if hasattr(fig, "get_size_inches") and hasattr(fig, "set_size_inches"):
            w, h = fig.get_size_inches()
            if (w is None or w <= 0.1) or (h is None or h <= 0.1) or (w * h <= 0.5):
                fig.set_size_inches(6.0, 3.6, forward=True)
    except (TypeError, ValueError):
        pass

    # لمس 'ax' لضمان استعماله عندما يمرَّر (تفادي تحذير linters)
    _ = ax

def st_safe_pyplot(fig, *, use_container_width: bool = True):
    """
    Safe wrapper around st.pyplot to avoid MediaFileStorageError and
    'constrained_layout' zero-size warnings.
    """
    try:
        if hasattr(fig, "set_layout_engine"):
            fig.set_layout_engine(None)
        if hasattr(fig, "set_constrained_layout"):
            fig.set_constrained_layout(False)
    except (AttributeError, RuntimeError, TypeError, ValueError):
        pass

    try:
        if hasattr(fig, "get_size_inches") and hasattr(fig, "set_size_inches"):
            w, h = fig.get_size_inches()
            if (w is None or w <= 0.1) or (h is None or h <= 0.1) or (w * h <= 0.5):
                fig.set_size_inches(6.0, 3.6, forward=True)
    except (TypeError, ValueError):
        pass

    # IMPORTANT: do NOT call st_safe_pyplot recursively — call st.pyplot here.
    try:
        st.pyplot(fig, use_container_width=use_container_width)
    except (RuntimeError, ValueError, TypeError, OSError) as ex:
        # Fallback: render via PNG buffer to avoid MediaFileStorage issues (without broad Exception).
        import io, logging
        logger = logging.getLogger("ui")
        logger.debug("st.pyplot failed, falling back to PNG buffer: %s", ex)
        buf = io.BytesIO()
        try:
            fig.savefig(buf, format="png", bbox_inches="tight")
            buf.seek(0)
            st.image(buf, use_container_width=use_container_width)
        except (RuntimeError, ValueError, TypeError, OSError) as ex2:
            logger.debug("fig.savefig fallback failed: %s", ex2)
            # Last resort: try to draw canvas; avoid broad except.
            try:
                if hasattr(fig, "canvas") and hasattr(fig.canvas, "draw_idle"):
                    fig.canvas.draw_idle()
            except (RuntimeError, ValueError):
                # give up silently; we don't want to crash the app due to a plotting glitch
                pass

def _plot_hist(df: pd.DataFrame, col: str, title: str):
    if df is None or not isinstance(df, pd.DataFrame) or df.empty:
        st.info("لا توجد بيانات كافية للرسم.")
        return
    if col not in df.columns:
        st.info("العمود غير موجود.")
        return
    series = pd.to_numeric(df[col], errors="coerce").dropna()
    if series.empty:
        st.info("لا توجد بيانات كافية للرسم.")
        return
    fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
    sns.histplot(series, kde=True, ax=ax, color=CLINICAL_PALETTE[2], edgecolor=None)
    ax.set_title(title)
    _arabicize_axis(ax)
    fig.patch.set_alpha(0.0)
    ax.set_facecolor("none")
    _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
    st_safe_pyplot(fig, use_container_width=True)
    plt.close(fig)

def _plot_bar(df: pd.DataFrame, col: str, title: str, topn: int = 15):
    if df is None or not isinstance(df, pd.DataFrame) or df.empty:
        st.info("لا توجد بيانات كافية للرسم.")
        return
    if col not in df.columns:
        st.info("العمود غير موجود.")
        return
    vc = df[col].astype(str).fillna("NA").value_counts()
    if vc.empty:
        st.info("لا توجد بيانات كافية للرسم.")
        return
    vc = vc.head(topn)
    fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
    # لون واحد ثابت بدون hue لتفادي تحذيرات Seaborn
    sns.barplot(x=vc.values, y=vc.index.astype(str), ax=ax, color=CLINICAL_PALETTE[1], legend=False)
    ax.set_title(title)
    ax.set_xlabel("count")
    ax.set_ylabel(col)
    _arabicize_axis(ax)
    fig.patch.set_alpha(0.0)
    ax.set_facecolor("none")
    _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
    st_safe_pyplot(fig, use_container_width=True)
    plt.close(fig)

def _plot_missingness(df: pd.DataFrame, title: str = "نسبة القيم المفقودة لكل عمود"):
    if df is None or not isinstance(df, pd.DataFrame) or df.empty:
        st.info("لا توجد بيانات كافية للرسم.")
        return
    miss = df.isna().mean().sort_values(ascending=False)
    miss = miss[miss > 0]
    if miss.empty:
        st.info("لا توجد قيم مفقودة في هذا الجدول.")
        return
    fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
    sns.barplot(x=miss.values, y=miss.index, ax=ax, color=CLINICAL_PALETTE[0])
    ax.set_xlabel("نسبة القيم المفقودة")
    ax.set_ylabel("الأعمدة")
    ax.set_title(title)
    _arabicize_axis(ax)
    fig.patch.set_alpha(0.0)
    ax.set_facecolor("none")
    _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
    st_safe_pyplot(fig, use_container_width=True)
    plt.close(fig)

def _plot_corr(df: pd.DataFrame, cols: Optional[List[str]] = None, title: str = "مصفوفة الارتباط"):
    if df is None or not isinstance(df, pd.DataFrame) or df.empty:
        st.info("لا توجد بيانات كافية للرسم.")
        return
    num_df = df.select_dtypes(include=[np.number])
    if cols:
        num_df = num_df[[c for c in cols if c in num_df.columns]]
    if num_df.shape[1] < 2:
        st.info("يلزم عمودان رقميان على الأقل لعرض الارتباط.")
        return
    corr = num_df.corr(numeric_only=True)
    fig, ax = plt.subplots(figsize=FIGSIZE_HEAT, constrained_layout=False)
    sns.heatmap(corr, annot=False, cmap=CLINICAL_CMAP, ax=ax)
    ax.set_title(title)
    _arabicize_axis(ax)
    fig.patch.set_alpha(0.0)
    ax.set_facecolor("none")
    _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
    st_safe_pyplot(fig, use_container_width=True)
    plt.close(fig)

# ----------------------------- أدوات مقارنة قبل/بعد -----------------------------
def _safe_num_cols(df: pd.DataFrame) -> List[str]:
    return df.select_dtypes(include=[np.number]).columns.tolist() if isinstance(df, pd.DataFrame) else []

def _safe_cat_cols(df: pd.DataFrame) -> List[str]:
    if not isinstance(df, pd.DataFrame):
        return []
    return [c for c in df.columns if df[c].dtype == object or str(df[c].dtype).startswith("category")]

def _compare_schemas(df_before: pd.DataFrame, df_after: pd.DataFrame) -> Tuple[List[str], List[str], pd.DataFrame]:
    before_cols = set(df_before.columns)
    after_cols  = set(df_after.columns)
    added = sorted(list(after_cols - before_cols))
    removed = sorted(list(before_cols - after_cols))
    inter = sorted(list(before_cols & after_cols))
    rows = []
    for c in inter:
        rows.append({
            "column": c,
            "dtype_before": str(df_before[c].dtype),
            "dtype_after": str(df_after[c].dtype),
            "changed": str(df_before[c].dtype) != str(df_after[c].dtype)
        })
    changes = pd.DataFrame(rows).sort_values(["changed","column"], ascending=[False, True])
    return added, removed, changes

def _compare_missingness(df_before: pd.DataFrame, df_after: pd.DataFrame) -> pd.DataFrame:
    cols = sorted(list(set(df_before.columns) | set(df_after.columns)))
    rows = []
    for c in cols:
        m_b = float(df_before[c].isna().mean()) if c in df_before.columns else np.nan
        m_a = float(df_after[c].isna().mean())  if c in df_after.columns  else np.nan
        rows.append({"column": c, "missing_before": m_b, "missing_after": m_a, "delta": (m_a - m_b) if (not np.isnan(m_b) and not np.isnan(m_a)) else np.nan})
    out = pd.DataFrame(rows)
    return out.sort_values("delta", ascending=True)

def _compare_numeric_summary(df_before: pd.DataFrame, df_after: pd.DataFrame) -> pd.DataFrame:
    num_b = _safe_num_cols(df_before)
    num_a = _safe_num_cols(df_after)
    nums = sorted(list(set(num_b) & set(num_a)))
    rows = []
    for c in nums:
        b = pd.to_numeric(df_before[c], errors="coerce")
        a = pd.to_numeric(df_after[c], errors="coerce")
        rows.append({
            "column": c,
            "mean_before": float(b.mean()),
            "mean_after": float(a.mean()),
            "std_before": float(b.std()),
            "std_after": float(a.std()),
            "median_before": float(b.median()),
            "median_after": float(a.median()),
            "delta_mean": float(a.mean() - b.mean())
        })
    return pd.DataFrame(rows).sort_values("delta_mean")

def _compare_categorical_topk(df_before: pd.DataFrame, df_after: pd.DataFrame, k: int = 10) -> pd.DataFrame:
    cats_b = _safe_cat_cols(df_before)
    cats_a = _safe_cat_cols(df_after)
    cats = sorted(list(set(cats_b) & set(cats_a)))
    rows = []
    for c in cats:
        vb = df_before[c].astype(str).fillna("NA").value_counts(normalize=True).head(k)
        va = df_after[c].astype(str).fillna("NA").value_counts(normalize=True).head(k)
        row: Dict[str, Any] = {"column": str(c)}
        # align indices
        all_vals = list(dict.fromkeys(list(vb.index) + list(va.index)))[:k]
        for v in all_vals:
            before_val = float(vb.get(v, 0.0) if vb is not None else 0.0)
            after_val  = float(va.get(v, 0.0) if va is not None else 0.0)
            row[f"before::{str(v)}"] = before_val
            row[f"after::{str(v)}"]  = after_val
        rows.append(row)
    return pd.DataFrame(rows)

def _module_summaries() -> Dict[str, str]:
    return {
        "data_cleaning.py": "تنظيف أولي: حذف صفوف مكررة، قص المسافات، توحيد أسماء الأعمدة، تصحيح أنواع شائعة (int/float)، وإزالة قيم غير صالحة الواضحة.",
        "imputation.py": "إكمال القيم المفقودة: استبدال المفقود في المتغيرات الرقمية بواسطة المتوسط/الوسيط حسب الحاجة، والفئوية بالوضع الأكثر شيوعًا.",
        "encoding.py": "ترميز فئوي: تحويل الأصناف إلى تمثيلات عددية (مثل one-hot أو label encoding) مع الحفاظ على دلالات سريرية.",
        "integration.py": "دمج مصادر: توحيد جداول متعددة/مراحل إلى إطار موحّد متسق، وفك التعارضات بين المصادر.",
        "debug_preprocessing_pipeline.py": "تتبّع وخطّ سجلات: طبعات تشخيصية، حفظ لقطات وسيطة، والتحقق من المخططات قبل/بعد كل خطوة.",
    }

# ----------------------------- أدوات سياقية متقدمة -----------------------------
def _safe_rate(a: float, b: float) -> float:
    try:
        return (a / b) if b else 0.0
    except (ZeroDivisionError, TypeError):
        return 0.0


def _target_rate_by_category(df: pd.DataFrame, cat_col: str, target_col: str = "target") -> Optional[pd.DataFrame]:
    if df is None or df.empty or cat_col not in df.columns or target_col not in df.columns:
        return None
    g = df.groupby(cat_col, dropna=False)[target_col]
    stats = pd.DataFrame({
        "count": g.size(),
        "positive": g.sum(numeric_only=True),
    })
    stats["rate"] = stats.apply(lambda r: _safe_rate(r["positive"], r["count"]), axis=1)
    return stats.sort_values("rate", ascending=False).reset_index()


def _heatmap_target_rate(df: pd.DataFrame, row_col: str, col_col: str, target_col: str = "target", title: str = "Target rate heatmap"):
    # heatmap لمعدلات الهدف عبر مصفوفة (row × col)
    if any(c not in df.columns for c in [row_col, col_col, target_col]):
        st.warning("⚠️ أعمدة غير متوفرة للرسم الحراري.")
        return
    tmp = df.copy()
    try:
        tmp[target_col] = pd.to_numeric(tmp[target_col], errors="coerce")
    except (ValueError, TypeError):
        st.warning("⚠️ عمود الهدف غير رقمي.")
        return
    pt_count = pd.crosstab(tmp[row_col], tmp[col_col])
    pt_pos = pd.crosstab(tmp[row_col], tmp[col_col], values=tmp[target_col], aggfunc="sum").fillna(0.0)
    with np.errstate(divide="ignore", invalid="ignore"):
        rate = pt_pos / pt_count.replace(0, np.nan)
    fig, ax = plt.subplots(figsize=FIGSIZE_HEAT, constrained_layout=False)
    sns.heatmap(rate, annot=False, cmap=CLINICAL_CMAP, ax=ax)
    ax.set_title(title)
    _arabicize_axis(ax)
    fig.patch.set_alpha(0.0)
    ax.set_facecolor("none")
    _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
    st_safe_pyplot(fig, use_container_width=True)
    plt.close(fig)


def _bubble_plot(df: pd.DataFrame, x: str, y: str, size: str, title: str):
    for c in (x, y, size):
        if c not in df.columns:
            st.warning("⚠️ أعمدة غير متوفرة لرسم الفقاعات.")
            return
    fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
    try:
        sns.scatterplot(
            data=df, x=x, y=y, size=size, sizes=(20, 600), alpha=0.55, ax=ax,
            hue=None, edgecolor=CLINICAL_PALETTE[0], linewidth=0.5
        )
    except (ValueError, TypeError) as ex:
        st.warning(f"⚠️ تعذر رسم الفقاعات: {ex}")
        plt.close(fig)
        return
    ax.set_title(title)
    _arabicize_axis(ax)
    fig.patch.set_alpha(0.0)
    ax.set_facecolor("none")
    _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
    st_safe_pyplot(fig, use_container_width=True)
    plt.close(fig)

# ----------------------------- رسوم إضافية وملخصات -----------------------------
def _plot_pie(df: pd.DataFrame, col: str, title: str = "Pie Chart"):
    if df is None or not isinstance(df, pd.DataFrame) or df.empty:
        st.info("لا توجد بيانات كافية للرسم.")
        return
    if col not in df.columns:
        st.warning("عمود غير موجود للرسم الدائري.")
        return
    vc = df[col].astype(str).fillna("NA").replace({"nan": "NA"}).value_counts()
    if vc.empty:
        st.info("لا توجد بيانات كافية للرسم الدائري.")
        return
    fig, ax = plt.subplots(figsize=FIGSIZE_SQUARE, constrained_layout=False)
    ax.pie(vc.values, labels=vc.index, autopct='%1.1f%%', startangle=90, counterclock=False)
    ax.axis('equal')
    ax.set_title(title)
    _arabicize_axis(ax)
    fig.patch.set_alpha(0.0)
    ax.set_facecolor("none")
    _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
    st_safe_pyplot(fig, use_container_width=True)
    plt.close(fig)

def _auto_executive_summary(df: pd.DataFrame, title: str = "Executive Summary") -> str:
    if df is None or df.empty:
        return "لا توجد بيانات لتوليد ملخص."
    n_rows, n_cols = df.shape
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = [c for c in df.columns if c not in num_cols]
    miss_overall = float(df.isna().mean().mean())
    # أعلى ارتباطات
    top_corr, corr_text = _corr_insights(df[num_cols] if len(num_cols) >= 2 else df, topk=5)
    corr_lines = []
    for _, r in top_corr.iterrows():
        corr_lines.append(f"- {r['col_1']} ↔ {r['col_2']}: ρ={r['rho']:.2f}")
    corr_block = "\n".join(corr_lines) if corr_lines else "- لا توجد ارتباطات ملحوظة."

    # أعمدة معروفة في مجالنا (إن وجدت)
    bullets = []
    if "advice_type" in df.columns:
        top_adv = df["advice_type"].astype(str).value_counts().head(5).to_dict()
        bullets.append("**Top advice_type**: " + ", ".join([f"{k} ({v})" for k, v in top_adv.items()]))
    if "confidence_bucket" in df.columns:
        dist_conf = df["confidence_bucket"].astype(str).value_counts().to_dict()
        bullets.append("**confidence_bucket**: " + ", ".join([f"{k}: {v}" for k, v in dist_conf.items()]))
    if "sim_bucket" in df.columns:
        dist_sim = df["sim_bucket"].astype(str).value_counts().to_dict()
        bullets.append("**sim_bucket**: " + ", ".join([f"{k}: {v}" for k, v in dist_sim.items()]))
    if "hybrid_score" in df.columns:
        bullets.append(f"**hybrid_score**: متوسط={df['hybrid_score'].mean():.3f}, وسيط={df['hybrid_score'].median():.3f}")

    report = f"""
    # {title}

    **Data shape:** {n_rows} rows × {n_cols} cols  
    **Numeric columns:** {len(num_cols)} | **Categorical/other:** {len(cat_cols)}  
    **Overall missingness:** {miss_overall*100:.2f}%  

    ## Key Distributions
    {"\n".join(bullets) if bullets else "لا توجد مقاييس تخصصية متاحة."}

    ## Correlation Highlights
    {corr_text}
    {corr_block}

    ## Notes
    - استخدم الرسوم المناسبة: Bar للمقارنات، Line للتوجهات الزمنية، Histogram للتوزيعات، Box لاكتشاف القيم الشاذة.
    - تجنّب ازدحام الألوان؛ استخدم تسميات واضحة ومحاور مقروءة.
    - عند وجود ارتباطات قوية جدًا، انتبه لاحتمال التكرار المعلوماتي.
    """
    return report

# ----------------------------- تحليلات ذكية أسفل الرسوم -----------------------------

# Helper: Safely scalarize to float (handles Series/arrays/lists)
def _scalarize_to_float(val: Any) -> float:
    """يحّول قيمة قد تكون Scalar/Series/ndarray إلى float بأمان؛ ويعيد NaN عند الفشل."""
    try:
        # إذا كانت Series أو مصفوفة، خذ أول عنصر
        if isinstance(val, pd.Series):
            if not val.empty:
                val = val.iloc[0]
        elif isinstance(val, (list, tuple, np.ndarray)):
            if len(val) > 0:
                val = val[0]
        # حوّل رقميًا
        num = pd.to_numeric(val, errors="coerce")
        if isinstance(num, pd.Series):
            num = num.iloc[0] if not num.empty else np.nan
        elif isinstance(num, np.ndarray):
            num = num[0] if num.size > 0 else np.nan
        return float(num)
    except (TypeError, ValueError, IndexError):
        return float("nan")
def _insight_hist(df: pd.DataFrame, col: str) -> None:
    """تعليق ذكي بعد Histogram: إحصاءات أساسية + outliers تقريبًا."""
    if df is None or col not in df.columns:
        return
    s = pd.to_numeric(df[col], errors="coerce").dropna()
    if s.empty:
        return
    mean = float(s.mean()); median = float(s.median()); std = float(s.std())
    skew = float(s.skew()); q1 = float(s.quantile(0.25)); q3 = float(s.quantile(0.75))
    iqr = q3 - q1
    out_hi = (s > (q3 + 1.5 * iqr)).mean() * 100.0
    out_lo = (s < (q1 - 1.5 * iqr)).mean() * 100.0
    st.caption(
        f"**Insight** — {col}: mean={mean:.2f}, median={median:.2f}, std={std:.2f}, "
        f"skew={skew:.2f}. IQR=[{q1:.2f}, {q3:.2f}] مع outliers ≈ {out_lo:.1f}% منخفضة / {out_hi:.1f}% مرتفعة."
    )

def _insight_bar(df: pd.DataFrame, col: str, topn: int = 3) -> None:
    """تعليق ذكي بعد Bar: أكثر الفئات تكرارًا."""
    if df is None or col not in df.columns:
        return
    vc = df[col].astype(str).fillna("NA").value_counts()
    if vc.empty:
        return
    tops = ", ".join([f"{k} ({v})" for k, v in vc.head(topn).items()])
    st.caption(f"**Insight** — الأكثر تكرارًا في {col}: {tops}.")

def _chi2_pvalue(df: pd.DataFrame, cat_col: str, target_col: str = "target") -> Optional[float]:
    """حساب p-value لاختبار الاستقلال χ² (اختياريًا إن توفّر SciPy)."""
    if df is None or any(c not in df.columns for c in (cat_col, target_col)):
        return None
    try:
        from scipy.stats import chi2_contingency  # type: ignore
    except ImportError:
        return None
    sub = df[[cat_col, target_col]].dropna()
    if sub.empty:
        return None
    try:
        sub[target_col] = pd.to_numeric(sub[target_col], errors="coerce")
    except (TypeError, ValueError):
        return None
    sub = sub.dropna()
    if sub.empty:
        return None
    table = pd.crosstab(sub[cat_col].astype(str), (sub[target_col] > 0).astype(int))
    if table.shape[0] < 2 or table.shape[1] < 2:
        return None
    chi2, p, _, _ = chi2_contingency(table)
    return float(p)

def _insight_target_rate(df: pd.DataFrame, cat_col: str, target_col: str = "target") -> None:
    """تعليق ذكي بعد Target-rate-by-category: أعلى/أدنى معدل + Δ (+ p-value إن أمكن)."""
    stats = _target_rate_by_category(df, cat_col, target_col)
    if stats is None or stats.empty:
        return
    top = stats.head(1).iloc[0]
    bot = stats.tail(1).iloc[0]
    rate_top = _scalarize_to_float(top.get("rate")) if "rate" in top.index else float("nan")
    rate_bot = _scalarize_to_float(bot.get("rate")) if "rate" in bot.index else float("nan")

    rng = rate_top - rate_bot
    cat_top = str(top.get(cat_col))
    cat_bot = str(bot.get(cat_col))

    p = _chi2_pvalue(df, cat_col, target_col)
    p_text = f", p≈{p:.3g}" if p is not None else ""
    st.caption(
        f"**Insight** — أعلى معدل هدف في '{cat_top}' = {rate_top:.2f}، "
        f"وأدناه في '{cat_bot}' = {rate_bot:.2f} (Δ={rng:.2f}{p_text})."
    )

def _insight_heatmap_rate(df: pd.DataFrame, row_col: str, col_col: str, target_col: str = "target") -> None:
    """تعليق ذكي بعد Heatmap لمعدلات الهدف: تحديد أعلى وأدنى خلية."""
    if df is None or any(c not in df.columns for c in [row_col, col_col, target_col]):
        return
    tmp = df.copy()
    tmp[target_col] = pd.to_numeric(tmp[target_col], errors="coerce")
    tmp = tmp.dropna(subset=[target_col])
    pt_count = pd.crosstab(tmp[row_col], tmp[col_col])
    pt_pos = pd.crosstab(tmp[row_col], tmp[col_col], values=tmp[target_col], aggfunc="sum").fillna(0.0)
    with np.errstate(divide="ignore", invalid="ignore"):
        rate = pt_pos / pt_count.replace(0, np.nan)
    if rate.empty:
        return
    arr = rate.to_numpy()
    if arr.size == 0 or np.isnan(arr).all():
        return
    max_idx = np.unravel_index(np.nanargmax(arr), rate.shape)
    min_idx = np.unravel_index(np.nanargmin(arr), rate.shape)
    r_idx_max = int(max_idx[0]); c_idx_max = int(max_idx[1])
    r_idx_min = int(min_idx[0]); c_idx_min = int(min_idx[1])

    rmax = rate.index[r_idx_max]
    cmax = rate.columns[c_idx_max]
    rmin = rate.index[r_idx_min]
    cmin = rate.columns[c_idx_min]
    vmax = _scalarize_to_float(rate.iat[int(max_idx[0]), int(max_idx[1])])
    vmin = _scalarize_to_float(rate.iat[int(min_idx[0]), int(min_idx[1])])
    st.caption(
        f"**Insight** — أقصى معدل هدف عند ({row_col}={rmax}, {col_col}={cmax}) ≈ {vmax:.2f}، "
        f"وأدناه عند ({row_col}={rmin}, {col_col}={cmin}) ≈ {vmin:.2f}."
    )

def _insight_box_by_target(df: pd.DataFrame, num_col: str, target_col: str = "target") -> None:
    """تعليق ذكي بعد Box-by-target: فرق المتوسط بين target=1 و target=0.
    يُحوِّل الأعمدة إلى Series رقمية صريحة لتجنّب تمرير DataFrame إلى pd.to_numeric.
    """
    # حراس الأعمدة
    if df is None or not isinstance(df, pd.DataFrame):
        return
    if num_col not in df.columns or target_col not in df.columns:
        return

    # تحويل الهدف والعمود العددي إلى Series رقمية صريحة
    t = pd.to_numeric(df[target_col], errors="coerce")
    x = pd.to_numeric(df[num_col], errors="coerce")

    # تقسيم حسب الهدف بعد إسقاط القيم المفقودة
    a = x[t == 1].dropna()
    b = x[t == 0].dropna()

    if a.empty or b.empty:
        return

    d_mean = float(a.mean() - b.mean())
    st.caption(f"**Insight** — {num_col} أعلى لدى target=1 بمقدار ≈ {d_mean:.2f} في المتوسط.")

# ----------------------------- واجهة العرض -----------------------------
def _section_group_files(name: str, files: Dict[str, str]) -> Dict[str, Optional[pd.DataFrame]]:
    st.subheader(f"📂 {name}")
    loaded: Dict[str, Optional[pd.DataFrame]] = {}
    tabs = st.tabs(list(files.keys()))
    for i, (label, path) in enumerate(files.items()):
        with tabs[i]:
            st.caption(Path(path).as_posix())
            if path.endswith(".csv"):
                df = _load_csv(path)
                loaded[label] = df
                if df is not None:
                    st.write(f"**الشكل:** {df.shape[0]} × {df.shape[1]}")
                    st.dataframe(df.head(50))
                    _download_button_df(df, "⬇️ تنزيل CSV المعروض", f"preview_{label}")
                else:
                    st.warning("⚠️ الملف غير موجود أو تعذّر قراءته.")
            elif path.endswith(".json"):
                js = _load_json(path)
                loaded[label] = js  # type: ignore
                if js is not None:
                    st.json(js)
                    try:
                        st.download_button(
                            "⬇️ تنزيل JSON", data=json.dumps(js, ensure_ascii=False, indent=2),
                            file_name=label, mime="application/json")
                    except (TypeError, ValueError) as ex:
                        st.warning(f"⚠️ تعذر تجهيز JSON للتنزيل: {ex}")
                else:
                    st.warning("⚠️ الملف غير موجود أو تعذّر قراءته.")
    return loaded


def _context_overview(files_loaded: Dict[str, Any]):
    st.header("🌐 Context — مستكشف البيانات السياقية")
    df_ctx = files_loaded.get("df_contextualized.csv")
    if not isinstance(df_ctx, pd.DataFrame) or df_ctx.empty:
        st.warning("⚠️ df_contextualized.csv غير متوفر أو فارغ.")
        return

    # KPIs
    st.markdown("### مؤشرات أساسية")
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        _metric_card("عدد الصفوف", df_ctx.shape[0])
    with c2:
        _metric_card("عدد الأعمدة", df_ctx.shape[1])
    with c3:
        miss = float(df_ctx.isna().mean().mean()) * 100
        _metric_card("نسبة المفقود الإجمالية", round(miss, 2), fmt="{:.2f}%")
    with c4:
        tgt_name = "target" if "target" in df_ctx.columns else "(لا يوجد)"
        _metric_card("عمود الهدف", tgt_name)

    tabs = st.tabs(["Overview", "Smart Correlation", "Clinical Axes", "Interactions", "Text & Tags"])

    # 1) Overview
    with tabs[0]:
        st.subheader("Overview — توزيعات أساسية")
        for c in ["risk_score", "trestbps", "chol", "oldpeak", "thalach", "age"]:
            if c in df_ctx.columns:
                _plot_hist(df_ctx, c, f"Histogram: {c}")
                _insight_hist(df_ctx, c)
        for cat in ["risk_level", "bp_category", "chol_category", "cp_cat"]:
            if cat in df_ctx.columns:
                _plot_bar(df_ctx, cat, f"Bar: {cat}")
                _insight_bar(df_ctx, cat)
                if "target" in df_ctx.columns:
                    _insight_target_rate(df_ctx, cat, "target")
        st.markdown("### مصفوفة الارتباط الذكية (مختصر)")
        num_all = df_ctx.select_dtypes(include=[np.number]).columns.tolist()
        sel = st.multiselect("اختر أعمدة رقمية", num_all, default=num_all[:8], key="ctx_overview_corr")
        _plot_corr(df_ctx, sel)

    # 2) Smart Correlation
    with tabs[1]:
        st.subheader("Smart Correlation — تحليل الارتباط")
        num_df = df_ctx.select_dtypes(include=[np.number])
        if num_df.shape[1] >= 2:
            fig, ax = plt.subplots(figsize=FIGSIZE_HEAT, constrained_layout=False)
            sns.heatmap(num_df.corr(numeric_only=True), cmap=CLINICAL_CMAP, ax=ax)
            ax.set_title("Correlation matrix (numeric-only)")
            st_safe_pyplot(fig)
            st.caption("**Insight** — راجع الأزواج الأعلى ارتباطًا أدناه؛ |ρ| ≥ 0.6 قد يدل على تكرار معلوماتي (multicollinearity).")
            pairs, text = _corr_insights(num_df, topk=10)
            st.write(text)
            if not pairs.empty:
                st.dataframe(pairs)
                high = pairs[pairs["abs_rho"] >= 0.6]
                if not high.empty:
                    st.warning("⚠️ توجد أزواج عالية الارتباط (|ρ|≥0.6). يُفضّل اختيار متغير واحد من كل كتلة عالية الترابط.")
        else:
            st.info("لا توجد أعمدة رقمية كافية.")

    # 3) Clinical Axes
    with tabs[2]:
        st.subheader("Clinical Axes — محاور سريرية")
        if "target" in df_ctx.columns:
            # BP Panel
            st.markdown("#### BP Panel")
            if "bp_category" in df_ctx.columns:
                _plot_bar(df_ctx, "bp_category", "توزيع bp_category")
                stats = _target_rate_by_category(df_ctx, "bp_category", "target")
                if stats is not None:
                    st.dataframe(stats)
                _insight_bar(df_ctx, "bp_category")
                if "target" in df_ctx.columns:
                    _insight_target_rate(df_ctx, "bp_category", "target")
            if "trestbps" in df_ctx.columns:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                sns.boxplot(x=df_ctx["target"], y=df_ctx["trestbps"], ax=ax)
                ax.set_xlabel("target")
                ax.set_ylabel("trestbps")
                ax.set_title("trestbps by target")
                _arabicize_axis(ax)
                _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
                st_safe_pyplot(fig, use_container_width=True)
                plt.close(fig)
                _insight_box_by_target(df_ctx, "trestbps", "target")
            # Lipid Panel
            st.markdown("#### Lipid Panel")
            for c in ["chol_category", "chol_bins"]:
                if c in df_ctx.columns:
                    _plot_bar(df_ctx, c, f"توزيع {c}")
                    _insight_bar(df_ctx, c)
                    if "target" in df_ctx.columns:
                        _insight_target_rate(df_ctx, c, "target")
            if all(c in df_ctx.columns for c in ["chol_bins", "age_group"]):
                _heatmap_target_rate(df_ctx, "age_group", "chol_bins", "target", "Target rate: age_group × chol_bins")
                _insight_heatmap_rate(df_ctx, "age_group", "chol_bins", "target")
            # Ischemia Panel
            st.markdown("#### Ischemia Panel")
            for c in ["oldpeak_cat", "exang_cat", "cp_cat", "restecg_cat", "thal_cat"]:
                if c in df_ctx.columns:
                    _plot_bar(df_ctx, c, f"توزيع {c}")
                    stats = _target_rate_by_category(df_ctx, c, "target")
                    if stats is not None:
                        st.dataframe(stats)
                    _insight_bar(df_ctx, c)
                    if "target" in df_ctx.columns:
                        _insight_target_rate(df_ctx, c, "target")
            # Vessels Panel
            st.markdown("#### Vessels Panel")
            if "ca_cat" in df_ctx.columns:
                _plot_bar(df_ctx, "ca_cat", "توزيع ca_cat")
                stats = _target_rate_by_category(df_ctx, "ca_cat", "target")
                if stats is not None:
                    st.dataframe(stats)
                _insight_bar(df_ctx, "ca_cat")
                if "target" in df_ctx.columns:
                    _insight_target_rate(df_ctx, "ca_cat", "target")
        else:
            st.info("عمود target غير متوفر؛ بعض اللوحات تعتمد عليه.")

    # 4) Interactions
    with tabs[3]:
        st.subheader("Interactions — تفاعلات ثنائية")
        if all(c in df_ctx.columns for c in ["bp_bin4", "chol_category", "risk_score"]):
            _bubble_plot(df_ctx, "bp_bin4", "chol_category", "risk_score", "Bubble: bp_bin4 × chol_category (size=risk_score)")
            st.caption("**Insight** — حجم الفقاعة يُمثل متوسط risk_score؛ ابحث عن فقاعات كبيرة في زوايا المصفوفة لالتقاط تآثرات مرتفعة المخاطر.")
        else:
            st.info("لرسم الفقاعات نحتاج bp_bin4, chol_category, risk_score.")
        for r, c in [("age_group", "bp_category"), ("age_group", "chol_category"), ("cp_cat", "bp_category")]:
            if r in df_ctx.columns and c in df_ctx.columns and "target" in df_ctx.columns:
                _heatmap_target_rate(df_ctx, r, c, "target", f"Target rate: {r} × {c}")
                _insight_heatmap_rate(df_ctx, r, c, "target")

    # 5) Text & Tags
    with tabs[4]:
        st.subheader("Text & Tags — سمات وهوية")
        cand = [c for c in ["feature_id", "context_feature_id", "feature_id_binned"] if c in df_ctx.columns]
        if not cand:
            st.info("لا توجد أعمدة نصية مناسبة.")
        else:
            col = st.selectbox("اختر عمودًا", cand)
            _plot_bar(df_ctx, col, f"Top frequencies: {col}")
    st.markdown("---")
    _smart_viz_hub(df_ctx, key_suffix="context")

def _hybrid_overview(df: pd.DataFrame, summary: Optional[Dict[str, Any]]):
    st.header("🧪 Hybrid — نظرة عامة (الخلاصة)")
    if df is None or df.empty:
        st.warning("لا توجد بيانات Hybrid لعرضها.")
        return

    # ==== تحميل جداول CBF/CF للمقارنة (إن وُجدت) ====
    # استخدم _load_csv مباشرة (هي تتعامل مع الأخطاء وتعيد None عند الفشل)
    cf_path = CF_FILES.get("df_cf_recommendations.csv", "")
    cbf_path = CBF_FILES.get("df_cbf_recommendations.csv", "")
    df_cf_main = _load_csv(cf_path) if cf_path else None
    df_cbf_main = _load_csv(cbf_path) if cbf_path else None

    # ==== أعمدة أساسية ====
    hy_score_col = "hybrid_score" if "hybrid_score" in df.columns else ("score" if "score" in df.columns else None)
    hy_y = pd.to_numeric(df["true_response"], errors="coerce").fillna(0).astype(int) if "true_response" in df.columns else None

    # ==== أدوات مساعدة محلية ====
    def _hy_precision_recall_ndcg_at_k(df_h: pd.DataFrame, score_col: str, topk: int = 5) -> Dict[str, float]:
        if df_h is None or df_h.empty or "patient_id" not in df_h.columns or "true_response" not in df_h.columns:
            return {"precision_at_k": np.nan, "recall_at_k": np.nan, "ndcg_at_k": np.nan, "hit_rate_at_k": np.nan}
        g = df_h.copy()
        g[score_col] = pd.to_numeric(g[score_col], errors="coerce")
        g["true_response"] = pd.to_numeric(g["true_response"], errors="coerce").fillna(0).astype(int)
        g = g.sort_values(["patient_id", score_col], ascending=[True, False]).groupby("patient_id", dropna=False)
        precs, recs, ndcgs, hits = [], [], [], []
        for _, grp_df in g:
            topk_rows = grp_df.head(topk)
            denom_pos = int(grp_df["true_response"].sum())
            tp_k = int(topk_rows["true_response"].sum())
            precs.append(tp_k / max(topk, 1))
            if denom_pos > 0:
                recs.append(tp_k / denom_pos)
            gains = topk_rows["true_response"].to_numpy(dtype=float)
            if gains.size > 0:
                discounts = 1.0 / np.log2(np.arange(2, gains.size + 2))
                ideal_gains = np.sort(grp_df["true_response"].to_numpy(dtype=float))[::-1][:topk]
                idcg = float((ideal_gains * discounts[:ideal_gains.size]).sum())
                dcg = float((gains * discounts).sum())
                ndcgs.append(dcg / idcg if idcg > 0 else 0.0)
            hits.append(1.0 if tp_k > 0 else 0.0)
        def _avg(arr):
            arr = np.array(arr, dtype=float)
            return float(arr.mean()) if arr.size > 0 else np.nan
        return {"precision_at_k": _avg(precs), "recall_at_k": _avg(recs), "ndcg_at_k": _avg(ndcgs), "hit_rate_at_k": _avg(hits)}

    def _advice_kind(txt: str) -> str:
        t = str(txt or "").lower()
        drug_kw = ["tablet", "mg", "amlodipine", "ace", "arb", "beta", "statin", "دواء", "حبوب", "أملوديبين", "مثبط"]
        life_kw = ["diet", "exercise", "walk", "salt", "sodium", "وزن", "رياضة", "حمية", "نمط", "خضار", "فواكه"]
        if any(kw in t for kw in drug_kw):
            return "drug"
        if any(kw in t for kw in life_kw):
            return "lifestyle"
        return "other"

    def _advice_len_series(frame: pd.DataFrame, col_name: str) -> pd.Series:
        if frame is None or col_name not in frame.columns:
            return pd.Series(dtype=float)
        return frame[col_name].astype(str).map(lambda txt: len(txt.strip()))

    # ==== تبويبات ملخص Hybrid ====
    tabs = st.tabs([
        "Overview KPIs",
        "Performance",
        "Contributions (CF × CBF)",
        "Advice Analysis",
        "Cross-System Comparison",
        "Case Explorer",
    ])

    # --- Overview KPIs ---
    with tabs[0]:
        st.markdown("### مؤشرات أساسية")
        c1, c2, c3, c4 = st.columns(4)
        with c1: _metric_card("عدد الصفوف", df.shape[0])
        with c2: _metric_card("عدد المرضى الفريدين", int(df["patient_id"].nunique()) if "patient_id" in df.columns else df.shape[0])
        with c3:
            if hy_score_col:
                s = pd.to_numeric(df[hy_score_col], errors="coerce")
                _metric_card("متوسط hybrid_score", float(s.mean()), fmt="{:.3f}")
            else:
                _metric_card("متوسط hybrid_score", "—")
        with c4:
            if hy_y is not None:
                _metric_card("نسبة نجاح إجمالية (~true_response)", float(hy_y.mean())*100.0, fmt="{:.1f}%")
            else:
                _metric_card("نسبة نجاح إجمالية", "—")

        # إبراز استفادة الهجين من الأوزان إن توفرت
        if {"weight_cf","weight_cbf"}.issubset(df.columns):
            st.markdown("### مزج الأوزان: weight_cf × weight_cbf")
            fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
            sns.scatterplot(data=df, x="weight_cf", y="weight_cbf", ax=ax, alpha=0.5, edgecolor=None)
            ax.set_xlabel("weight_cf"); ax.set_ylabel("weight_cbf"); ax.set_title("Scatter — مزيج الأوزان")
            _arabicize_axis(ax); _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02); st_safe_pyplot(fig, use_container_width=True); plt.close(fig)
            if hy_score_col:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                try:
                    sns.histplot(df[["weight_cf", "weight_cbf"]], multiple="stack", element="step", ax=ax)
                except (ValueError, TypeError, KeyError) as ex:
                    logger.debug("histplot stacked weights failed: %s", ex)
                    if "weight_cf" in df.columns:
                        sns.histplot(df["weight_cf"], color=CLINICAL_PALETTE[0], ax=ax)
                    if "weight_cbf" in df.columns:
                        sns.histplot(df["weight_cbf"], color=CLINICAL_PALETTE[1], ax=ax)
                ax.set_title("توزيع الأوزان")
                _arabicize_axis(ax); _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02); st_safe_pyplot(fig, use_container_width=True); plt.close(fig)

    # --- Performance ---
    with tabs[1]:
        st.markdown("### أداء النظام الهجين")
        if hy_score_col and hy_y is not None and "patient_id" in df.columns:
            k = st.slider("K لمقاييس @K", 1, 20, 5, key="hy_k")
            met = _hy_precision_recall_ndcg_at_k(df, hy_score_col, topk=k)
            c1, c2, c3, c4 = st.columns(4)
            with c1: _metric_card(f"Precision@{k}", met["precision_at_k"], fmt="{:.3f}")
            with c2: _metric_card(f"Recall@{k}", met["recall_at_k"], fmt="{:.3f}")
            with c3: _metric_card(f"nDCG@{k}", met["ndcg_at_k"], fmt="{:.3f}")
            with c4: _metric_card(f"Hit-rate@{k}", met["hit_rate_at_k"], fmt="{:.3f}")
        else:
            st.info("يلزم وجود patient_id و true_response وعمود درجات لحساب المقاييس.")

        # عرض ملخص JSON إن وُجد
        st.markdown("### Summary (من hybrid_eval_summary.json)")
        if summary:
            c1, c2, c3, c4 = st.columns(4)
            with c1: _metric_card("Precision@5 (post)", summary.get("precision_at_5_post", "-"))
            with c2: _metric_card("Recall@5 (post)", summary.get("recall_at_5_post", "-"))
            with c3: _metric_card("nDCG@5 (post)", summary.get("ndcg_at_5_post", "-"))
            with c4: _metric_card("MAP@5 (post)", summary.get("map_at_5_post", "-"))
            st.json(summary)

    # --- Contributions (CF × CBF) ---
    with tabs[2]:
        st.markdown("### كيف استفاد الهجين من CF و CBF")
        if {"weight_cf", "weight_cbf"}.issubset(df.columns):
            fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
            sns.kdeplot(df["weight_cf"], ax=ax, label="weight_cf")
            sns.kdeplot(df["weight_cbf"], ax=ax, label="weight_cbf")
            ax.legend(); ax.set_title("كثافات الأوزان")
            _arabicize_axis(ax); _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02); st_safe_pyplot(fig, use_container_width=True); plt.close(fig)

            if hy_score_col:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                ax.scatter(df["weight_cf"], df[hy_score_col], s=12, alpha=0.45, label="vs hybrid_score")
                ax.set_xlabel("weight_cf"); ax.set_ylabel("hybrid_score"); ax.set_title("تأثير weight_cf على الدرجة")
                _arabicize_axis(ax); _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02); st_safe_pyplot(fig, use_container_width=True); plt.close(fig)
        else:
            st.info("لا توجد أعمدة وزن لإظهار مساهمة كل قناة.")

        # مقارنة أداء مختصرة مقابل CF/CBF إن توفرت البيانات
        if df_cf_main is not None and "patient_id" in df.columns and hy_y is not None and hy_score_col:
            st.markdown("#### مقارنة سريعة مقابل CF")
            sc_cf = _cf_get_score_col(df_cf_main) if isinstance(df_cf_main, pd.DataFrame) else None
            if sc_cf and "true_response" in df_cf_main.columns and "patient_id" in df_cf_main.columns:
                met_h = _hy_precision_recall_ndcg_at_k(df, hy_score_col, topk=5)
                met_cf = _cf_precision_recall_ndcg_at_k(df_cf_main, sc_cf, k=5)
                comp = pd.DataFrame([
                    {"model": "Hybrid", **met_h},
                    {"model": "CF", **met_cf},
                ])
                st.dataframe(comp)
        if df_cbf_main is not None and "patient_id" in df.columns and hy_y is not None and hy_score_col:
            st.markdown("#### مقارنة سريعة مقابل CBF")
            sc_cbf = _cbf_get_score_col(df_cbf_main) if isinstance(df_cbf_main, pd.DataFrame) else None
            if sc_cbf and "true_response" in df_cbf_main.columns and "patient_id" in df_cbf_main.columns:
                met_h = _hy_precision_recall_ndcg_at_k(df, hy_score_col, topk=5)
                met_cbf = _cbf_precision_recall_ndcg_at_k(df_cbf_main, sc_cbf, k=5)
                comp = pd.DataFrame([
                    {"model": "Hybrid", **met_h},
                    {"model": "CBF", **met_cbf},
                ])
                st.dataframe(comp)

    # --- Advice Analysis ---
    with tabs[3]:
        st.markdown("### تحليل النصوص الإرشادية")
        col_hy = "advice_text" if "advice_text" in df.columns else None
        col_cf_exp = "explanation" if (isinstance(df_cf_main, pd.DataFrame) and "explanation" in df_cf_main.columns) else None
        col_cbf_adv = "advice" if (isinstance(df_cbf_main, pd.DataFrame) and "advice" in df_cbf_main.columns) else None

        c1, c2, c3 = st.columns(3)
        with c1:
            if col_hy:
                lens = _advice_len_series(df, col_hy)
                _metric_card("متوسط طول advice_text", float(lens.mean()), fmt="{:.1f}")
        with c2:
            if col_cf_exp:
                lens = _advice_len_series(df_cf_main, col_cf_exp)
                _metric_card("متوسط طول explanation (CF)", float(lens.mean()), fmt="{:.1f}")
        with c3:
            if col_cbf_adv:
                lens = _advice_len_series(df_cbf_main, col_cbf_adv)
                _metric_card("متوسط طول advice (CBF)", float(lens.mean()), fmt="{:.1f}")

        # توزيع أطوال النص الهجين لإثبات > 8 عناصر/سطور متاحة
        if col_hy:
            _plot_hist(df.assign(_len=_advice_len_series(df, col_hy)), "_len", "توزيع أطوال advice_text")
            st.caption("الهجين يُنتج نصوصًا أطول وغنية — دعم لعرض أكثر من 8 عناصر/جمل.")

        # تصنيف دوائي/سلوكي عبر الأنظمة
        st.markdown("#### Drug vs Lifestyle — عبر الأنظمة")
        rows = []
        if col_hy:
            rows.append({"system": "Hybrid", "counts": df[col_hy].astype(str).map(_advice_kind).value_counts().to_dict()})
        if col_cf_exp:
            rows.append({"system": "CF", "counts": df_cf_main[col_cf_exp].astype(str).map(_advice_kind).value_counts().to_dict()})
        if col_cbf_adv:
            rows.append({"system": "CBF", "counts": df_cbf_main[col_cbf_adv].astype(str).map(_advice_kind).value_counts().to_dict()})
        if rows:
            flat = []
            for r in rows:
                for kind_name, count_v in r["counts"].items():
                    flat.append({"system": r["system"], "kind": kind_name, "count": int(count_v)})
            dfk = pd.DataFrame(flat)
            if not dfk.empty:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                sns.barplot(data=dfk, x="count", y="system", hue="kind", ax=ax)
                ax.set_title("تصنيف التوصيات: دوائي/سلوكي")
                _arabicize_axis(ax); _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02); st_safe_pyplot(fig, use_container_width=True); plt.close(fig)
                st.dataframe(dfk.pivot(index="system", columns="kind", values="count").fillna(0).astype(int))

        # === Word Cloud for advice_text (Hybrid) ===
        st.markdown("#### سحابة كلمات — advice_text (Hybrid)")
        if col_hy:
            series_wc = df[col_hy].dropna().astype(str)
            # Controls: allow digits & hyphens already handled in _render_wordcloud
            min_len_wc = st.slider("الحد الأدنى لطول الكلمة", 1, 10, 2, key="hy_wc_min")
            max_words_wc = st.slider("الحد الأقصى لعدد الكلمات", 50, 300, 150, step=25, key="hy_wc_max")
            text_blob = " ".join([s for s in series_wc if len(s.strip()) >= min_len_wc])
            if not text_blob.strip():
                st.info("لا توجد كلمات كافية لتوليد سحابة الكلمات بعد التنقية.")
            else:
                _render_wordcloud(text_blob, title="سحابة كلمات: advice_text (Hybrid)", max_words=max_words_wc)
        else:
            st.info("لا يوجد عمود advice_text في بيانات Hybrid.")

        # === طول النص والأداء (Heatmap/Line) ===
        st.markdown("#### العلاقة بين طول النص والأداء")
        if col_hy and "true_response" in df.columns:
            # طول النص لكل صف
            lens = df[col_hy].astype(str).map(lambda txt: len(txt.strip()))
            # تصنيف النوع (دوائي/سلوكي/آخر)
            kinds = df[col_hy].astype(str).map(_advice_kind)
            # تهيئة الهدف
            y_obs = pd.to_numeric(df["true_response"], errors="coerce")
            # إسقاط القيم الفارغة
            mask_valid = (~lens.isna()) & (~y_obs.isna())
            lens = lens[mask_valid]
            kinds = kinds[mask_valid]
            y_obs = y_obs[mask_valid]

            if len(lens) > 0:
                # تقسيم الأطوال إلى حاويات (deciles أو 6 شرائح إن كانت البيانات قليلة)
                uniq = int(lens.nunique())
                try:
                    n_bins = 10 if uniq >= 10 else max(3, min(6, uniq))
                    bins = pd.qcut(lens, q=n_bins, duplicates="drop")
                except (ValueError, TypeError) as ex:
                    logger.debug("hybrid length-bin qcut fallback due to: %s", ex)
                    n_bins = max(1, min(6, uniq if uniq > 0 else 1))
                    bins = pd.cut(lens, bins=n_bins)

                # Heatmap: طول النص × نوع النص → معدل النجاح المرصود
                df_len = pd.DataFrame({"len": lens, "kind": kinds, "y": y_obs, "bin": bins})
                grp = df_len.groupby(["bin", "kind"], dropna=False, observed=True)
                stats = grp["y"].mean().reset_index().rename(columns={"y": "observed_rate"})
                if not stats.empty:
                    # pivot للحُمّى الحرارية
                    pv = stats.pivot(index="bin", columns="kind", values="observed_rate").sort_index()
                    fig, ax = plt.subplots(figsize=FIGSIZE_HEAT, constrained_layout=False)
                    sns.heatmap(pv, annot=False, cmap=CLINICAL_CMAP, vmin=0.0, vmax=1.0, ax=ax)
                    ax.set_title("Heatmap — معدل النجاح حسب طول النص × النوع")
                    _arabicize_axis(ax)
                    _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
                    st_safe_pyplot(fig, use_container_width=True)
                    plt.close(fig)
                    st.dataframe((pv * 100).round(1).astype(float))
                else:
                    st.info("لا يمكن حساب Heatmap: لا توجد بيانات كافية بعد التنقية.")

                # Line: معدل النجاح المرصود عبر حاويات طول النص
                grp_len = (
                    df_len.groupby("bin", dropna=False, observed=True)["y"]
                          .mean()
                          .reset_index()
                          .rename(columns={"y": "observed_rate"})
                )
                if not grp_len.empty:
                    fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                    ax.plot(range(len(grp_len)), grp_len["observed_rate"], marker="o", linewidth=1.2)
                    ax.set_xlabel("حاوية طول النص")
                    ax.set_ylabel("معدل النجاح المرصود")
                    ax.set_title("منحنى الأداء عبر أطوال advice_text")
                    _arabicize_axis(ax)
                    _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
                    st_safe_pyplot(fig, use_container_width=True)
                    plt.close(fig)
                    st.dataframe((grp_len.assign(observed_rate=(grp_len["observed_rate"]*100)).rename(columns={"bin":"length_bin","observed_rate":"observed_%"})))
                else:
                    st.info("لا يمكن حساب منحنى الأداء: لا توجد بيانات كافية بعد التنقية.")
            else:
                st.info("لا توجد نصوص كافية لحساب علاقة الطول بالأداء.")
        else:
            st.info("يلزم وجود advice_text و true_response لحساب علاقة الطول بالأداء.")

    # --- Cross-System Comparison ---
    with tabs[4]:
        st.markdown("### مقارنة كمية بين CF / CBF / Hybrid")
        comp_tables = []
        # CF summary (typed alias helps static analyzer)
        if isinstance(df_cf_main, pd.DataFrame):
            df_cf_typed: pd.DataFrame = df_cf_main
            sc_cf = _cf_get_score_col(df_cf_typed)
            patients_cf: int = int(pd.Series(df_cf_typed["patient_id"]).nunique()) if "patient_id" in df_cf_typed.columns else 0
            comp_tables.append({
                "system": "CF",
                "rows": int(df_cf_typed.shape[0]),
                "patients": patients_cf,
                "score_col": sc_cf or "—",
            })
        # CBF summary (typed alias helps static analyzer)
        if isinstance(df_cbf_main, pd.DataFrame):
            df_cbf_typed: pd.DataFrame = df_cbf_main
            sc_cbf = _cbf_get_score_col(df_cbf_typed)
            patients_cbf: int = int(pd.Series(df_cbf_typed["patient_id"]).nunique()) if "patient_id" in df_cbf_typed.columns else 0
            comp_tables.append({
                "system": "CBF",
                "rows": int(df_cbf_typed.shape[0]),
                "patients": patients_cbf,
                "score_col": sc_cbf or "—",
            })
        sc_h = hy_score_col or "—"
        comp_tables.append({
            "system": "Hybrid",
            "rows": int(df.shape[0]),
            "patients": int(pd.Series(df["patient_id"]).nunique()) if "patient_id" in df.columns else 0,
            "score_col": sc_h
        })
        st.dataframe(pd.DataFrame(comp_tables))

        # مقارنة @K إن أمكن
        if hy_score_col and hy_y is not None and "patient_id" in df.columns:
            rows = []
            met_h = _hy_precision_recall_ndcg_at_k(df, hy_score_col, topk=5)
            rows.append({"system": "Hybrid", **met_h})
            if isinstance(df_cf_main, pd.DataFrame):
                sc_cf = _cf_get_score_col(df_cf_main)
                if sc_cf and "true_response" in df_cf_main.columns and "patient_id" in df_cf_main.columns:
                    rows.append({"system": "CF", **_cf_precision_recall_ndcg_at_k(df_cf_main, sc_cf, k=5)})
            if isinstance(df_cbf_main, pd.DataFrame):
                sc_cbf = _cbf_get_score_col(df_cbf_main)
                if sc_cbf and "true_response" in df_cbf_main.columns and "patient_id" in df_cbf_main.columns:
                    rows.append({"system": "CBF", **_cbf_precision_recall_ndcg_at_k(df_cbf_main, sc_cbf, k=5)})
            if rows:
                perf = pd.DataFrame(rows)
                st.dataframe(perf)

    # --- Case Explorer ---
    with tabs[5]:
        if "patient_id" not in df.columns:
            st.info("لا يوجد patient_id.")
        else:
            pids = sorted(df["patient_id"].astype(str).unique().tolist())
            pid = st.selectbox("اختر patient_id", pids, index=0, key="hy_case_pid")
            k_view = st.slider("Top-K للعرض", 1, 25, 12, key="hy_case_k")
            sub = df[df["patient_id"].astype(str) == str(pid)].copy()
            if hy_score_col:
                sub[hy_score_col] = pd.to_numeric(sub[hy_score_col], errors="coerce")
                sub = sub.sort_values(hy_score_col, ascending=False)
            cols_show = [c for c in ["patient_id","feature_id","advice_text", hy_score_col, "reason","explanation","bp_category","chol_category","age_group","risk_level"] if (c is None or c in sub.columns)]
            st.dataframe(sub.head(k_view)[cols_show])
            _download_button_df(sub.head(k_view)[cols_show], "⬇️ تنزيل الحالة (Hybrid)", "hybrid_case_export.csv")

    # ذيل القسم: لمسة توضيحية
    st.caption("**مغزى الصورة** — النظام الهجين يجمع بين إشارات CF (تشابه المستخدمين/العناصر) و CBF (تشابه المحتوى) عبر مزج أوزان ذكي، ما يطيل ويُغني النص الإرشادي، ويحسّن مقاييس @K والمعايرة مقارنةً بكل قناة منفردة، وفق الأرقام المعروضة أعلاه.")

def _cbf_overview(files_loaded: Dict[str, Any]):
    st.header("📘 CBF — نظرة عامة")
    df_main = files_loaded.get("df_cbf_recommendations.csv")
    if df_main is None:
        st.warning("لا توجد بيانات CBF رئيسية.")
        return
    st.markdown("### مؤشرات أساسية")
    _metric_card("عدد الصفوف", df_main.shape[0])
    if "patient_id" in df_main.columns:
        _metric_card("عدد المرضى الفريدين", df_main["patient_id"].nunique())

    st.markdown("### رسوم بيانية")
    for col in ["cbf_score", "sim", "true_response"]:
        if col in df_main.columns:
            _plot_hist(df_main, col, f"توزيع {col}")
    _plot_bar(df_main, "reason", "توزيع الأسباب (reason)")

    st.markdown("### نظرة على ملفات التقييم")
    for key in ["df_cbf_recommendations_eval.csv", "cbf_eval_unique.csv", "cbf_eval_loco.csv", "cbf_eval_full.csv", "df_cbf_recommendations_full.csv", "cbf_recs_loco.csv", "cbf_recs_loco_rows.csv"]:
        df = files_loaded.get(key)
        if isinstance(df, pd.DataFrame) and not df.empty:
            st.write(f"**{key}** — شكل: {df.shape}")
            st.dataframe(df.head(30))

    # ================= CBF Strength Dashboard (new, non-breaking) =================
    st.markdown("### 🛡️ CBF Strength Dashboard")
    score_col = _cbf_get_score_col(df_main)
    if score_col is None:
        st.info("لا يوجد عمود درجات واضح (cbf_score أو score_cbf). سيتم عرض أجزاء لا تعتمد على الدرجات.")

    tabs_cbf = st.tabs([
        "Overview KPIs",
        "Performance",
        "KNN/Source",
        "Recommendation Mix",
        "Segment Performance",
        "Explainability",
        "Case Explorer",
        "Data Quality",
    ])

    # --- Tab 0: Overview KPIs ---
    with tabs_cbf[0]:
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            _metric_card("الصفوف", df_main.shape[0])
        with c2:
            _metric_card("المرضى الفريدون", int(df_main["patient_id"].nunique()) if "patient_id" in df_main.columns else 0)
        with c3:
            if "sim" in df_main.columns:
                s = pd.to_numeric(df_main["sim"], errors="coerce")
                _metric_card("متوسط التشابه (sim)", float(s.mean()), fmt="{:.3f}")
            else:
                _metric_card("متوسط التشابه (sim)", "—")
        with c4:
            if score_col:
                s = pd.to_numeric(df_main[score_col], errors="coerce")
                _metric_card("متوسط الدرجة", float(s.mean()), fmt="{:.3f}")
        if score_col:
            c1, c2, c3 = st.columns(3)
            with c1:
                _metric_card("الوسيط", float(pd.to_numeric(df_main[score_col], errors="coerce").median()), fmt="{:.3f}")
            with c2:
                _metric_card("أعلى درجة", float(pd.to_numeric(df_main[score_col], errors="coerce").max()), fmt="{:.3f}")
            with c3:
                tr = _cbf_safe_true(df_main)
                if tr is not None:
                    _metric_card("دقة إجمالية (~success rate)", float(tr.mean())*100.0, fmt="{:.1f}%")
            _plot_hist(df_main, score_col, f"Histogram — {score_col}")
            _insight_hist(df_main, score_col)

    # --- Tab 1: Performance ---
    with tabs_cbf[1]:
        if score_col and "patient_id" in df_main.columns and _cbf_safe_true(df_main) is not None:
            k = st.slider("K لمقاييس @K", 1, 20, 5, key="cbf_perf_k")
            met = _cbf_precision_recall_ndcg_at_k(df_main, score_col, k=k)
            c1, c2, c3, c4 = st.columns(4)
            with c1: _metric_card(f"Precision@{k}", met["precision_at_k"], fmt="{:.3f}")
            with c2: _metric_card(f"Recall@{k}", met["recall_at_k"], fmt="{:.3f}")
            with c3: _metric_card(f"nDCG@{k}", met["ndcg_at_k"], fmt="{:.3f}")
            with c4: _metric_card(f"Hit-rate@{k}", met["hit_rate_at_k"], fmt="{:.3f}")

            st.markdown("#### منحنى Precision–Recall (عتبة على الدرجة)")
            pr = _cbf_threshold_pr(df_main, score_col, steps=30)
            if not pr.empty:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                ax.plot(pr["recall"], pr["precision"], marker="o", linewidth=1.2)
                ax.set_xlabel("Recall"); ax.set_ylabel("Precision"); ax.set_title("Precision–Recall vs threshold")
                _arabicize_axis(ax); _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02); st_safe_pyplot(fig);  plt.close(fig)
                st.dataframe(pr.head(20))
                _download_button_df(pr, "⬇️ تنزيل منحنى PR", "cbf_pr_curve.csv")
            else:
                st.info("لا يمكن رسم PR (غياب true_response أو درجات).")

            st.markdown("#### معايرة الدرجات (Reliability)")
            calib = _cbf_calibration_bins(df_main, score_col, bins=10)
            if not calib.empty:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                ax.plot(calib["score_mean"], calib["observed_rate"], marker="o")
                ax.plot([calib["score_mean"].min(), calib["score_mean"].max()],
                        [calib["score_mean"].min(), calib["score_mean"].max()], linestyle="--", linewidth=1)
                ax.set_xlabel("متوسط الدرجة في الحاوية"); ax.set_ylabel("معدل النجاح المرصود"); ax.set_title("Calibration")
                _arabicize_axis(ax); _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02); st_safe_pyplot(fig); plt.close(fig)
                st.dataframe(calib)
                _download_button_df(calib, "⬇️ تنزيل معايرة", "cbf_calibration.csv")
            else:
                st.info("لا يمكن حساب المعايرة (غياب true_response أو درجات).")
        else:
            st.info("يلزم وجود patient_id و true_response وعمود درجات لحساب المقاييس.")

    # --- Tab 2: KNN/Source ---
    with tabs_cbf[2]:
        # CBF عادة لا يحوي cold_start مثل CF؛ لكن قد توجد قناة/مصدر
        src_col = None
        for c in ["source", "channel", "origin"]:
            if c in df_main.columns:
                src_col = c; break
        if src_col:
            st.markdown("#### تفكيك حسب المصدر/القناة")
            src = df_main[src_col].astype(str).fillna("unknown").value_counts().rename_axis(src_col).reset_index(name="count")
            if not src.empty:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                sns.barplot(data=src, x="count", y=src_col, ax=ax, color=CLINICAL_PALETTE[0])
                ax.set_title("توزيع المصدر/القناة"); _arabicize_axis(ax); _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02); st_safe_pyplot(fig); plt.close(fig)
                st.dataframe(src)
        else:
            st.info("لا يوجد عمود مصدر/قناة واضح في بيانات CBF.")

    # --- Tab 3: Recommendation Mix ---
    with tabs_cbf[3]:
        cnt, bys = _cbf_top_features(df_main, topn=20)
        if not cnt.empty:
            name_col = [c for c in ["feature_id","feature","term","concept"] if c in cnt.columns][0]
            _plot_bar(cnt.rename(columns={name_col:"_name"}), "_name", "Top-N features (by count)")
        if not bys.empty:
            name_col = [c for c in ["feature_id","feature","term","concept"] if c in bys.columns][0]
            fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
            sns.barplot(data=bys, x="score_sum", y=name_col, ax=ax, color=CLINICAL_PALETTE[1])
            ax.set_title("Top-N features (by score sum)"); _arabicize_axis(ax); _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02); st_safe_pyplot(fig); plt.close(fig)

    # --- Tab 4: Segment Performance ---
    with tabs_cbf[4]:
        seg_cols = [c for c in ["bp_category","chol_category","age_group","risk_level","fbs_cat","cp_cat"] if c in df_main.columns]
        if not seg_cols:
            st.info("لا توجد أعمدة شرائح سريرية متاحة.")
        else:
            k_seg = st.slider("K للحسبة", 1, 20, 5, key="cbf_seg_k")
            col = st.selectbox("اختر عمود شريحة", seg_cols, index=0)
            df_seg = _cbf_segment_metric(df_main, col, k=k_seg)
            if not df_seg.empty:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                sns.barplot(data=df_seg, x="hit_rate_at_k", y="segment", ax=ax, color=CLINICAL_PALETTE[3])
                ax.set_title(f"Hit-rate@{k_seg} حسب {col}"); _arabicize_axis(ax); _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02); st_safe_pyplot(fig); plt.close(fig)
                st.dataframe(df_seg)
                _download_button_df(df_seg, "⬇️ تنزيل أداء الشرائح", "cbf_segment_performance.csv")
            else:
                st.info("تعذر حساب أداء الشرائح (تحقق من وجود true_response ودرجات).")

    # --- Tab 5: Explainability ---
    with tabs_cbf[5]:
        cover_reason = float(df_main["reason"].notna().mean())*100.0 if "reason" in df_main.columns else 0.0
        cover_expl   = float(df_main["explanation"].notna().mean())*100.0 if "explanation" in df_main.columns else 0.0
        c1, c2 = st.columns(2)
        with c1: _metric_card("تغطية reason", cover_reason, fmt="{:.1f}%")
        with c2: _metric_card("تغطية explanation", cover_expl, fmt="{:.1f}%")
        if "reason" in df_main.columns:
            series = df_main["reason"].dropna().astype(str)
            blob = " ".join(series.tolist())[:400000]
            _render_wordcloud(blob, title="سحابة كلمات — reasons (CBF)", max_words=250)
        else:
            st.info("لا يوجد عمود reason لتوليد سحابة كلمات.")

    # --- Tab 6: Case Explorer ---
    with tabs_cbf[6]:
        if "patient_id" not in df_main.columns:
            st.info("لا يوجد patient_id.")
        else:
            pids = sorted(df_main["patient_id"].astype(str).unique().tolist())
            pid = st.selectbox("اختر patient_id", pids, index=0, key="cbf_case_pid")
            k_view = st.slider("Top-K للعرض", 1, 15, 5, key="cbf_case_k")
            sub = df_main[df_main["patient_id"].astype(str) == str(pid)].copy()
            if score_col:
                sub[score_col] = pd.to_numeric(sub[score_col], errors="coerce")
                sub = sub.sort_values(score_col, ascending=False)
            cols_show = [c for c in ["patient_id","feature_id","term","concept", score_col, "reason","explanation","sim","bp_category","chol_category","age_group","risk_level"] if (c is None or c in sub.columns)]
            st.dataframe(sub.head(k_view)[cols_show])
            _download_button_df(sub.head(k_view)[cols_show], "⬇️ تنزيل الحالة", "cbf_case_export.csv")

    # --- Tab 7: Data Quality ---
    with tabs_cbf[7]:
        _plot_missingness(df_main, "نسبة القيم المفقودة (CBF)")
        req = {"patient_id"}
        if score_col: req.add(score_col)
        missing_reqs = [c for c in req if c not in df_main.columns]
        if missing_reqs:
            st.warning("الأعمدة الأساسية المفقودة: " + ", ".join(missing_reqs))
        try:
            mask = df_main.astype(str).eq("unknown")
            unknown_ratio = float(np.mean(mask.to_numpy()) * 100.0)
        except (AttributeError, TypeError, ValueError):
            unknown_ratio = 0.0
        _metric_card("نسبة 'unknown' عبر الجدول", unknown_ratio, fmt="{:.1f}%")

    # مركز التصوير الذكي
    _smart_viz_hub(df_main, key_suffix="cbf")

# ----------------------------- CF Strength Helpers -----------------------------
def _cf_get_score_col(df: pd.DataFrame) -> Optional[str]:
    if not isinstance(df, pd.DataFrame) or df.empty:
        return None
    for c in ["score_cf", "cf_score"]:
        if c in df.columns:
            return c
    return "score" if "score" in df.columns else None

def _cf_safe_true(df: pd.DataFrame) -> Optional[pd.Series]:
    if not isinstance(df, pd.DataFrame) or df.empty:
        return None
    if "true_response" in df.columns:
        return pd.to_numeric(df["true_response"], errors="coerce").fillna(0).astype(int)
    return None

def _cf_groupby_patient(df: pd.DataFrame, score_col: str) -> Any:
    g = df.copy()
    g[score_col] = pd.to_numeric(g[score_col], errors="coerce")
    return g.sort_values(["patient_id", score_col], ascending=[True, False]).groupby("patient_id", dropna=False)

def _cf_precision_recall_ndcg_at_k(df: pd.DataFrame, score_col: str, k: int = 5) -> Dict[str, float]:
    """
    Precision@K و Recall@K و nDCG@K ومتوسط Hit-rate@K عبر المرضى.
    يتطلب true_response (0/1) و patient_id.
    """
    y = _cf_safe_true(df)
    if y is None or "patient_id" not in df.columns:
        return {"precision_at_k": np.nan, "recall_at_k": np.nan, "ndcg_at_k": np.nan, "hit_rate_at_k": np.nan}
    g = _cf_groupby_patient(df.assign(true_response=y), score_col)
    precs, recs, ndcgs, hits = [], [], [], []
    for _, grp_df in g:
        grp_df = grp_df.copy()
        grp_df["true_response"] = pd.to_numeric(grp_df["true_response"], errors="coerce").fillna(0).astype(int)
        topk = grp_df.head(k)
        denom_pos = int(grp_df["true_response"].sum())
        tp_k = int(topk["true_response"].sum())
        precs.append(tp_k / max(k, 1))
        if denom_pos > 0:
            recs.append(tp_k / denom_pos)
        gains = topk["true_response"].to_numpy(dtype=float)
        if gains.size > 0:
            discounts = 1.0 / np.log2(np.arange(2, gains.size + 2))
            dcg = float((gains * discounts).sum())
            ideal_gains = np.sort(grp_df["true_response"].to_numpy(dtype=float))[::-1][:k]
            idcg = float((ideal_gains * discounts[:ideal_gains.size]).sum())
            ndcgs.append(dcg / idcg if idcg > 0 else 0.0)
        hits.append(1.0 if tp_k > 0 else 0.0)
    def _avg(x):
        arr = np.array(x, dtype=float)
        return float(arr.mean()) if arr.size > 0 else np.nan
    return {
        "precision_at_k": _avg(precs),
        "recall_at_k": _avg(recs),
        "ndcg_at_k": _avg(ndcgs),
        "hit_rate_at_k": _avg(hits),
    }

def _cf_threshold_pr(df: pd.DataFrame, score_col: str, steps: int = 30) -> pd.DataFrame:
    """Precision–Recall عبر عتبات على مستوى الصفوف (global)."""
    y = _cf_safe_true(df)
    if y is None:
        return pd.DataFrame()
    s = pd.to_numeric(df[score_col], errors="coerce")
    mask = ~(s.isna() | y.isna())
    s, y = s[mask], y[mask]
    if s.empty:
        return pd.DataFrame()
    ts = np.linspace(float(s.min()), float(s.max()), num=max(3, steps))
    rows = []
    for t in ts:
        pred = (s >= t).astype(int)
        TP = int(((pred == 1) & (y == 1)).sum())
        FP = int(((pred == 1) & (y == 0)).sum())
        FN = int(((pred == 0) & (y == 1)).sum())
        precision = TP / (TP + FP) if (TP + FP) > 0 else np.nan
        recall    = TP / (TP + FN) if (TP + FN) > 0 else np.nan
        rows.append({"threshold": t, "precision": precision, "recall": recall})
    return pd.DataFrame(rows)

def _cf_calibration_bins(df: pd.DataFrame, score_col: str, bins: int = 10) -> pd.DataFrame:
    """تقسيم الدرجات إلى حاويات وحساب المعدل المرصود للنجاح داخل كل حاوية."""
    y = _cf_safe_true(df)
    if y is None:
        return pd.DataFrame()
    s = pd.to_numeric(df[score_col], errors="coerce")
    mask = ~(s.isna() | y.isna())
    s, y = s[mask], y[mask]
    if s.empty:
        return pd.DataFrame()
    try:
        q = pd.qcut(s, q=bins, duplicates="drop")
    except ValueError:
        return pd.DataFrame()
    grp = pd.DataFrame({"score": s, "y": y, "bin": q}).groupby("bin", observed=True)
    out = grp.agg(score_mean=("score","mean"), observed_rate=("y","mean"), count=("y","size")).reset_index(drop=True)
    return out.sort_values("score_mean")

def _cf_source_breakdown(df: pd.DataFrame) -> pd.DataFrame:
    if "source" not in df.columns:
        return pd.DataFrame()
    vc = df["source"].astype(str).fillna("unknown").value_counts().rename_axis("source").reset_index(name="count")
    return vc

def _cf_top_features(df: pd.DataFrame, topn: int = 15) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """يرجع (by_count, by_score) لأكثر feature_id انتشارًا، وكذلك مجموع score_cf (أو cf_score) لكل ميزة."""
    if "feature_id" not in df.columns:
        return pd.DataFrame(), pd.DataFrame()
    sc = _cf_get_score_col(df)
    cnt = df["feature_id"].astype(str).value_counts().head(topn).rename_axis("feature_id").reset_index(name="count")
    if sc:
        by_score = (df.groupby("feature_id")[sc].sum().sort_values(ascending=False).head(topn)
                    .rename_axis("feature_id").reset_index(name="score_sum"))
    else:
        by_score = pd.DataFrame()
    return cnt, by_score

def _cf_segment_metric(df: pd.DataFrame, seg_col: str, k: int = 5) -> pd.DataFrame:
    """
    Hit-rate@K لكل قيمة في عمود تقطيعي واحد.
    hit-rate = نسبة المرضى الذين لديهم نجاح واحد على الأقل ضمن K الأوائل داخل كل شريحة.
    """
    y = _cf_safe_true(df)
    sc = _cf_get_score_col(df)
    if y is None or sc is None or "patient_id" not in df.columns or seg_col not in df.columns:
        return pd.DataFrame()
    tmp = df.assign(true_response=y).copy()
    tmp[sc] = pd.to_numeric(tmp[sc], errors="coerce")
    rows = []
    for val, sub in tmp.groupby(seg_col, dropna=False):
        g = sub.sort_values(["patient_id", sc], ascending=[True, False]).groupby("patient_id", dropna=False)
        hits = []
        for _, s in g:
            topk = s.head(k)
            hits.append(1.0 if int(pd.to_numeric(topk["true_response"], errors="coerce").fillna(0).sum()) > 0 else 0.0)
        if len(hits) > 0:
            rows.append({"segment": str(val), "hit_rate_at_k": float(np.mean(hits)), "patients": len(hits)})
    return pd.DataFrame(rows).sort_values("hit_rate_at_k", ascending=False)


# ----------------------------- CBF Strength Helpers -----------------------------
def _cbf_get_score_col(df: pd.DataFrame) -> Optional[str]:
    if not isinstance(df, pd.DataFrame) or df.empty:
        return None
    for c in ["cbf_score", "score_cbf", "score"]:
        if c in df.columns:
            return c
    return None

def _cbf_safe_true(df: pd.DataFrame) -> Optional[pd.Series]:
    if not isinstance(df, pd.DataFrame) or df.empty:
        return None
    if "true_response" in df.columns:
        return pd.to_numeric(df["true_response"], errors="coerce").fillna(0).astype(int)
    return None

def _cbf_groupby_patient(df: pd.DataFrame, score_col: str) -> Any:
    g = df.copy()
    g[score_col] = pd.to_numeric(g[score_col], errors="coerce")
    return g.sort_values(["patient_id", score_col], ascending=[True, False]).groupby("patient_id", dropna=False)

def _cbf_precision_recall_ndcg_at_k(df: pd.DataFrame, score_col: str, k: int = 5) -> Dict[str, float]:
    """
    Precision@K و Recall@K و nDCG@K ومتوسط Hit-rate@K عبر المرضى لبيانات CBF.
    يتطلب true_response (0/1) و patient_id.
    """
    y = _cbf_safe_true(df)
    if y is None or "patient_id" not in df.columns:
        return {"precision_at_k": np.nan, "recall_at_k": np.nan, "ndcg_at_k": np.nan, "hit_rate_at_k": np.nan}
    g = _cbf_groupby_patient(df.assign(true_response=y), score_col)
    precs, recs, ndcgs, hits = [], [], [], []
    for _, grp_df in g:
        grp_df = grp_df.copy()
        grp_df["true_response"] = pd.to_numeric(grp_df["true_response"], errors="coerce").fillna(0).astype(int)
        topk = grp_df.head(k)
        denom_pos = int(grp_df["true_response"].sum())
        tp_k = int(topk["true_response"].sum())
        precs.append(tp_k / max(k, 1))
        if denom_pos > 0:
            recs.append(tp_k / denom_pos)
        gains = topk["true_response"].to_numpy(dtype=float)
        if gains.size > 0:
            discounts = 1.0 / np.log2(np.arange(2, gains.size + 2))
            dcg = float((gains * discounts).sum())
            ideal_gains = np.sort(grp_df["true_response"].to_numpy(dtype=float))[::-1][:k]
            idcg = float((ideal_gains * discounts[:ideal_gains.size]).sum())
            ndcgs.append(dcg / idcg if idcg > 0 else 0.0)
        hits.append(1.0 if tp_k > 0 else 0.0)
    def _avg(x):
        arr = np.array(x, dtype=float)
        return float(arr.mean()) if arr.size > 0 else np.nan
    return {
        "precision_at_k": _avg(precs),
        "recall_at_k": _avg(recs),
        "ndcg_at_k": _avg(ndcgs),
        "hit_rate_at_k": _avg(hits),
    }

def _cbf_threshold_pr(df: pd.DataFrame, score_col: str, steps: int = 30) -> pd.DataFrame:
    """Precision–Recall عبر عتبات على مستوى الصفوف (global) لبيانات CBF."""
    y = _cbf_safe_true(df)
    if y is None:
        return pd.DataFrame()
    s = pd.to_numeric(df[score_col], errors="coerce")
    mask = ~(s.isna() | y.isna())
    s, y = s[mask], y[mask]
    if s.empty:
        return pd.DataFrame()
    ts = np.linspace(float(s.min()), float(s.max()), num=max(3, steps))
    rows = []
    for t in ts:
        pred = (s >= t).astype(int)
        TP = int(((pred == 1) & (y == 1)).sum())
        FP = int(((pred == 1) & (y == 0)).sum())
        FN = int(((pred == 0) & (y == 1)).sum())
        precision = TP / (TP + FP) if (TP + FP) > 0 else np.nan
        recall    = TP / (TP + FN) if (TP + FN) > 0 else np.nan
        rows.append({"threshold": t, "precision": precision, "recall": recall})
    return pd.DataFrame(rows)

def _cbf_calibration_bins(df: pd.DataFrame, score_col: str, bins: int = 10) -> pd.DataFrame:
    """تقسيم درجات CBF إلى حاويات وحساب المعدل المرصود داخل كل حاوية."""
    y = _cbf_safe_true(df)
    if y is None:
        return pd.DataFrame()
    s = pd.to_numeric(df[score_col], errors="coerce")
    mask = ~(s.isna() | y.isna())
    s, y = s[mask], y[mask]
    if s.empty:
        return pd.DataFrame()
    try:
        q = pd.qcut(s, q=bins, duplicates="drop")
    except ValueError:
        return pd.DataFrame()
    grp = pd.DataFrame({"score": s, "y": y, "bin": q}).groupby("bin", observed=True)
    out = grp.agg(score_mean=("score","mean"), observed_rate=("y","mean"), count=("y","size")).reset_index(drop=True)
    return out.sort_values("score_mean")


def _cbf_top_features(df: pd.DataFrame, topn: int = 15) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Top-N features (حسب الظهور) وأيضًا حسب مجموع درجات CBF.
    نستخدم feature_id إن وُجد وإلا نحاول 'feature' أو 'term' أو 'concept'.
    """
    name_col = None
    for c in ["feature_id", "feature", "term", "concept"]:
        if c in df.columns:
            name_col = c
            break
    if name_col is None:
        return pd.DataFrame(), pd.DataFrame()
    sc = _cbf_get_score_col(df)
    cnt = df[name_col].astype(str).value_counts().head(topn).rename_axis(name_col).reset_index(name="count")
    if sc:
        by_score = (df.groupby(name_col)[sc].sum().sort_values(ascending=False).head(topn)
                    .rename_axis(name_col).reset_index(name="score_sum"))
    else:
        by_score = pd.DataFrame()
    return cnt, by_score

# NEW: CBF segment metric helper
def _cbf_segment_metric(df: pd.DataFrame, seg_col: str, k: int = 5) -> pd.DataFrame:
    """
    Hit-rate@K لكل قيمة في عمود تقطيعي واحد لبيانات CBF.
    hit-rate = نسبة المرضى الذين لديهم نجاح واحد على الأقل ضمن K الأوائل داخل كل شريحة.
    يعتمد على أعمدة: patient_id, true_response، وعمود درجات CBF (cbf_score/score_cbf/score).
    """
    # تحقّق من الأعمدة الأساسية
    y = _cbf_safe_true(df)
    sc = _cbf_get_score_col(df)
    if y is None or sc is None or "patient_id" not in df.columns or seg_col not in df.columns:
        return pd.DataFrame()

    # تجهيز البيانات
    tmp = df.assign(true_response=y).copy()
    tmp[sc] = pd.to_numeric(tmp[sc], errors="coerce")

    rows: list[dict[str, float | int | str]] = []
    for val, sub in tmp.groupby(seg_col, dropna=False):
        # ترتيب توصيات كل مريض تنازليًا حسب الدرجة وأخذ أعلى K
        g = sub.sort_values(["patient_id", sc], ascending=[True, False]).groupby("patient_id", dropna=False)
        hits: list[float] = []
        for _, s in g:
            topk = s.head(k)
            # نجاح إذا وُجد على الأقل true_response==1 ضمن K الأوائل
            has_hit = int(pd.to_numeric(topk["true_response"], errors="coerce").fillna(0).sum()) > 0
            hits.append(1.0 if has_hit else 0.0)
        if hits:
            rows.append({
                "segment": str(val),
                "hit_rate_at_k": float(np.mean(hits)),
                "patients": len(hits),
            })

    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows).sort_values("hit_rate_at_k", ascending=False)

def _cf_overview(files_loaded: Dict[str, Any]):
    st.header("📗 CF — نظرة عامة")
    df_main = files_loaded.get("df_cf_recommendations.csv")
    if df_main is None:
        st.warning("لا توجد بيانات CF رئيسية.")
        return

    st.markdown("### مؤشرات أساسية")
    _metric_card("عدد الصفوف", df_main.shape[0])
    if "patient_id" in df_main.columns:
        _metric_card("عدد المرضى الفريدين", df_main["patient_id"].nunique())

    # If there is a similar cold_ratio KPI as in CBF, update it as well
    # (Check and replace if such a line exists)

    st.markdown("### رسوم بيانية")
    for col in ["cf_score", "true_response"]:
        if col in df_main.columns:
            _plot_hist(df_main, col, f"توزيع {col}")
    _plot_bar(df_main, "reason", "توزيع الأسباب (reason)")

    st.markdown("### نظرة على ملفات التقييم")
    for key in ["df_cf_recommendations_eval.csv", "df_cf_recommendations_eval_loco.csv", "df_cf_recommendations_eval_loco_family.csv"]:
        df = files_loaded.get(key)
        if isinstance(df, pd.DataFrame) and not df.empty:
            st.write(f"**{key}** — شكل: {df.shape}")
            st.dataframe(df.head(30))

    # ================= CF Strength Dashboard (new, non-breaking) =================
    st.markdown("### 🛡️ CF Strength Dashboard")
    score_col = _cf_get_score_col(df_main)
    if score_col is None:
        st.info("لا يوجد عمود درجات واضح (score_cf أو cf_score). سيتم عرض أجزاء لا تعتمد على الدرجات.")
    tabs_cf = st.tabs([
        "Overview KPIs",
        "Performance",
        "Cold-Start Analysis",
        "Recommendation Mix",
        "Segment Performance",
        "Explainability",
        "Case Explorer",
        "Data Quality",
    ])

    # --- Tab 0: Overview KPIs ---
    with tabs_cf[0]:
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            _metric_card("الصفوف", df_main.shape[0])
        with c2:
            _metric_card("المرضى الفريدون", int(df_main["patient_id"].nunique()) if "patient_id" in df_main.columns else 0)
        with c3:
            if "source" in df_main.columns:
                src_series = df_main["source"].astype(str)
                mask = src_series.eq("cold_start_safe_default")
                cold_ratio = float(mask.mean())
            else:
                cold_ratio = 0.0
            _metric_card("نسبة Cold-start", cold_ratio*100.0, fmt="{:.1f}%")
        with c4:
            if score_col:
                s = pd.to_numeric(df_main[score_col], errors="coerce")
                _metric_card("المتوسط", float(s.mean()), fmt="{:.3f}")
        if score_col:
            c1, c2, c3 = st.columns(3)
            with c1:
                _metric_card("الوسيط", float(pd.to_numeric(df_main[score_col], errors="coerce").median()), fmt="{:.3f}")
            with c2:
                _metric_card("أعلى درجة", float(pd.to_numeric(df_main[score_col], errors="coerce").max()), fmt="{:.3f}")
            with c3:
                tr = _cf_safe_true(df_main)
                if tr is not None:
                    _metric_card("دقة إجمالية (~success rate)", float(tr.mean())*100.0, fmt="{:.1f}%")
            _plot_hist(df_main, score_col, f"Histogram — {score_col}")
            _insight_hist(df_main, score_col)

    # --- Tab 1: Performance ---
    with tabs_cf[1]:
        if score_col and "patient_id" in df_main.columns and _cf_safe_true(df_main) is not None:
            k = st.slider("K لمقاييس @K", 1, 20, 5, key="cf_perf_k")
            met = _cf_precision_recall_ndcg_at_k(df_main, score_col, k=k)
            c1, c2, c3, c4 = st.columns(4)
            with c1: _metric_card(f"Precision@{k}", met["precision_at_k"], fmt="{:.3f}")
            with c2: _metric_card(f"Recall@{k}", met["recall_at_k"], fmt="{:.3f}")
            with c3: _metric_card(f"nDCG@{k}", met["ndcg_at_k"], fmt="{:.3f}")
            with c4: _metric_card(f"Hit-rate@{k}", met["hit_rate_at_k"], fmt="{:.3f}")

            st.markdown("#### منحنى Precision–Recall (عتبة على الدرجة)")
            pr = _cf_threshold_pr(df_main, score_col, steps=30)
            if not pr.empty:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                ax.plot(pr["recall"], pr["precision"], marker="o", linewidth=1.2)
                ax.set_xlabel("Recall"); ax.set_ylabel("Precision"); ax.set_title("Precision–Recall vs threshold")
                _arabicize_axis(ax); st_safe_pyplot(fig);  plt.close(fig)
                st.dataframe(pr.head(20))
                _download_button_df(pr, "⬇️ تنزيل منحنى PR", "cf_pr_curve.csv")
            else:
                st.info("لا يمكن رسم PR (غياب true_response أو درجات).")

            st.markdown("#### معايرة الدرجات (Reliability)")
            calib = _cf_calibration_bins(df_main, score_col, bins=10)
            if not calib.empty:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                ax.plot(calib["score_mean"], calib["observed_rate"], marker="o")
                ax.plot([calib["score_mean"].min(), calib["score_mean"].max()],
                        [calib["score_mean"].min(), calib["score_mean"].max()], linestyle="--", linewidth=1)
                ax.set_xlabel("متوسط الدرجة في الحاوية"); ax.set_ylabel("معدل النجاح المرصود"); ax.set_title("Calibration")
                _arabicize_axis(ax); st_safe_pyplot(fig);plt.close(fig)
                st.dataframe(calib)
                _download_button_df(calib, "⬇️ تنزيل معايرة", "cf_calibration.csv")
            else:
                st.info("لا يمكن حساب المعايرة (غياب true_response أو درجات).")
        else:
            st.info("يلزم وجود patient_id و true_response وعمود درجات لحساب المقاييس.")

    # --- Tab 2: Cold-Start Analysis ---
    with tabs_cf[2]:
        if "source" in df_main.columns:
            st.markdown("#### تفكيك حسب المصدر")
            src = _cf_source_breakdown(df_main)
            if not src.empty:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                sns.barplot(data=src, x="count", y="source", ax=ax, color=CLINICAL_PALETTE[0])
                ax.set_title("توزيع المصادر"); _arabicize_axis(ax); st_safe_pyplot(fig); plt.close(fig)
                st.dataframe(src)
            if score_col and _cf_safe_true(df_main) is not None and "patient_id" in df_main.columns:
                k_cs = st.slider("K لمقاييس المصدر", 1, 20, 5, key="cf_src_k")
                for src_name, sub in df_main.groupby(df_main["source"].astype(str).fillna("unknown")):
                    st.markdown(f"**{src_name}**")
                    met = _cf_precision_recall_ndcg_at_k(sub, score_col, k=k_cs)
                    c1, c2, c3, c4 = st.columns(4)
                    with c1: _metric_card(f"P@{k_cs}", met["precision_at_k"], fmt="{:.3f}")
                    with c2: _metric_card(f"R@{k_cs}", met["recall_at_k"], fmt="{:.3f}")
                    with c3: _metric_card(f"nDCG@{k_cs}", met["ndcg_at_k"], fmt="{:.3f}")
                    with c4: _metric_card(f"Hit@{k_cs}", met["hit_rate_at_k"], fmt="{:.3f}")
            sub_cs = df_main[df_main["source"].astype(str) == "cold_start_safe_default"] if "source" in df_main.columns else pd.DataFrame()
            if not sub_cs.empty:
                st.markdown("#### أكثر الميزات شيوعًا في وضع Cold-Start")
                cnt, bys = _cf_top_features(sub_cs, topn=15)
                if not cnt.empty:
                    _plot_bar(cnt.rename(columns={"feature_id":"feature"}), "feature", "Top features (count) — cold-start")
                if not bys.empty:
                    fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                    sns.barplot(data=bys.head(15), x="score_sum", y="feature_id", ax=ax, color=CLINICAL_PALETTE[2])
                    ax.set_title("Top features by score_sum — cold-start"); _arabicize_axis(ax); st_safe_pyplot(fig); plt.close(fig)
        else:
            st.info("لا يوجد عمود source في البيانات.")

    # --- Tab 3: Recommendation Mix ---
    with tabs_cf[3]:
        cnt, bys = _cf_top_features(df_main, topn=20)
        if not cnt.empty:
            _plot_bar(cnt.rename(columns={"feature_id":"feature"}), "feature", "Top-N features (by count)")
        if not bys.empty:
            fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
            sns.barplot(data=bys, x="score_sum", y="feature_id", ax=ax, color=CLINICAL_PALETTE[1])
            ax.set_title("Top-N features (by score sum)"); _arabicize_axis(ax); st_safe_pyplot(fig); plt.close(fig)
        if "feature_id_binned" in df_main.columns and "source" in df_main.columns:
            st.markdown("#### تأثير المصدر على مزيج الفئات")
            mix = (df_main.assign(source=df_main["source"].astype(str).fillna("unknown"))
                           .groupby(["feature_id_binned","source"]).size().reset_index(name="count"))
            if not mix.empty:
                pivot = mix.pivot(index="feature_id_binned", columns="source", values="count").fillna(0)
                fig, ax = plt.subplots(figsize=FIGSIZE_HEAT, constrained_layout=False)
                sns.heatmap(pivot, annot=False, cmap=CLINICAL_CMAP, ax=ax)
                ax.set_title("feature_id_binned × source"); _arabicize_axis(ax); st_safe_pyplot(fig); plt.close(fig)
                st.dataframe(mix.sort_values("count", ascending=False).head(50))

    # --- Tab 4: Segment Performance ---
    with tabs_cf[4]:
        seg_cols = [c for c in ["bp_category","chol_category","age_group","risk_level","fbs_cat","cp_cat"] if c in df_main.columns]
        if not seg_cols:
            st.info("لا توجد أعمدة شرائح سريرية متاحة.")
        else:
            k_seg = st.slider("K للحسبة", 1, 20, 5, key="cf_seg_k")
            col = st.selectbox("اختر عمود شريحة", seg_cols, index=0)
            df_seg = _cf_segment_metric(df_main, col, k=k_seg)
            if not df_seg.empty:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                sns.barplot(data=df_seg, x="hit_rate_at_k", y="segment", ax=ax, color=CLINICAL_PALETTE[3])
                ax.set_title(f"Hit-rate@{k_seg} حسب {col}"); _arabicize_axis(ax); st_safe_pyplot(fig); plt.close(fig)
                st.dataframe(df_seg)
                _download_button_df(df_seg, "⬇️ تنزيل أداء الشرائح", "cf_segment_performance.csv")
            else:
                st.info("تعذر حساب أداء الشرائح (تحقق من وجود true_response ودرجات).")

    # --- Tab 5: Explainability ---
    with tabs_cf[5]:
        cover_reason = float(df_main["reason"].notna().mean())*100.0 if "reason" in df_main.columns else 0.0
        cover_expl   = float(df_main["explanation"].notna().mean())*100.0 if "explanation" in df_main.columns else 0.0
        c1, c2 = st.columns(2)
        with c1: _metric_card("تغطية reason", cover_reason, fmt="{:.1f}%")
        with c2: _metric_card("تغطية explanation", cover_expl, fmt="{:.1f}%")
        if "reason" in df_main.columns:
            series = df_main["reason"].dropna().astype(str)
            blob = " ".join(series.tolist())[:400000]
            _render_wordcloud(blob, title="سحابة كلمات — reasons", max_words=250)
        else:
            st.info("لا يوجد عمود reason لتوليد سحابة كلمات.")

    # --- Tab 6: Case Explorer ---
    with tabs_cf[6]:
        if "patient_id" not in df_main.columns:
            st.info("لا يوجد patient_id.")
        else:
            pids = sorted(df_main["patient_id"].astype(str).unique().tolist())
            pid = st.selectbox("اختر patient_id", pids, index=0, key="cf_case_pid")
            k_view = st.slider("Top-K للعرض", 1, 15, 5, key="cf_case_k")
            src_filter = st.multiselect(
                "المصدر",
                sorted(df_main.get("source", pd.Series([], dtype=object)).astype(str).unique().tolist()) if "source" in df_main.columns else [],
                default=None
            )
            sub = df_main[df_main["patient_id"].astype(str) == str(pid)].copy()
            if src_filter:
                sub = sub[sub["source"].astype(str).isin(src_filter)]
            if score_col:
                sub[score_col] = pd.to_numeric(sub[score_col], errors="coerce")
                sub = sub.sort_values(score_col, ascending=False)
            cols_show = [c for c in ["patient_id","feature_id", score_col, "reason","explanation","source","bp_category","chol_category","age_group","risk_level"] if (c is None or c in sub.columns)]
            st.dataframe(sub.head(k_view)[cols_show])
            _download_button_df(sub.head(k_view)[cols_show], "⬇️ تنزيل الحالة", "cf_case_export.csv")

    # --- Tab 7: Data Quality ---
    with tabs_cf[7]:
        _plot_missingness(df_main, "نسبة القيم المفقودة (CF)")
        req = {"patient_id","feature_id"}
        if score_col: req.add(score_col)
        missing_reqs = [c for c in req if c not in df_main.columns]
        if missing_reqs:
            st.warning("الأعمدة الأساسية المفقودة: " + ", ".join(missing_reqs))
        # نسبة 'unknown' عبر الجدول (محسوبة بأمان)
        try:
            mask = df_main.astype(str).eq("unknown")
            unknown_ratio = float(np.mean(mask.to_numpy()) * 100.0)
        except (AttributeError, TypeError, ValueError):
            unknown_ratio = 0.0
        _metric_card("نسبة 'unknown' عبر الجدول", unknown_ratio, fmt="{:.1f}%")


    # مركز التصوير الذكي
    _smart_viz_hub(df_main, key_suffix="cf")

def _preprocess_overview(files_loaded: Dict[str, Any]):
    st.header("🧱 Preprocess — نظرة عامة (قبل الدمج)")
    df_clean = files_loaded.get("df_cleaned.csv")

    # تبويبات للمقارنة والملفين
    tabs = st.tabs(["Before vs After", "df_cleaned.csv"])

    # --- Tab 0: Before vs After ---
    with tabs[0]:
        st.subheader("🔁 Before vs After — مقارنة أصلية مقابل منظّفة")
        df_before = _load_csv(ORIGINAL_DATA_PATH)
        df_after  = files_loaded.get("df_cleaned.csv")
        if not isinstance(df_before, pd.DataFrame) or not isinstance(df_after, pd.DataFrame):
            st.warning("⚠️ لم يتم العثور على البيانات الأصلية أو df_cleaned.csv.")
        else:
            c1, c2, c3, c4 = st.columns(4)
            with c1:
                _metric_card("Rows (before)", df_before.shape[0])
            with c2:
                _metric_card("Rows (after)", df_after.shape[0])
            with c3:
                _metric_card("Cols (before)", df_before.shape[1])
            with c4:
                _metric_card("Cols (after)", df_after.shape[1])
            c1, c2 = st.columns(2)
            with c1:
                _metric_card("Missing% (before)", round(float(df_before.isna().mean().mean())*100, 2), fmt="{:.2f}%")
            with c2:
                _metric_card("Missing% (after)", round(float(df_after.isna().mean().mean())*100, 2), fmt="{:.2f}%")

            st.markdown("### 🧩 تغييرات المخطط (Schema)")
            added, removed, changes = _compare_schemas(df_before, df_after)
            c1, c2 = st.columns(2)
            with c1:
                st.write("**أعمدة مضافة**", len(added))
                st.code("\n".join(added) or "- لا يوجد -")
            with c2:
                st.write("**أعمدة محذوفة**", len(removed))
                st.code("\n".join(removed) or "- لا يوجد -")
            if not changes.empty:
                st.dataframe(changes)
                _download_button_df(changes, "⬇️ تنزيل تغييرات الأنواع", "schema_type_changes.csv")

            st.markdown("### 🕳️ المقارنة في القيم المفقودة")
            miss_cmp = _compare_missingness(df_before, df_after)
            st.dataframe(miss_cmp.head(50))
            _download_button_df(miss_cmp, "⬇️ تنزيل مقارنة المفقود", "missingness_compare.csv")
            # رسم لأكبر 20 فرق مُطلق
            top_miss = miss_cmp.assign(abs_delta=miss_cmp["delta"].abs()).sort_values("abs_delta", ascending=False).head(20)
            if not top_miss.empty:
                fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
                sns.barplot(x=top_miss["delta"], y=top_miss["column"], ax=ax, color=CLINICAL_PALETTE[2])
                ax.set_ylabel("")
                ax.set_xlabel("")
                ax.set_title("Top-20 تغيّر في نسب المفقود (after-before)", fontsize=12)
                _arabicize_axis(ax)
                # تقليص حجم خط تدرّجات المحاور لهذا الرسم فقط
                ax.tick_params(axis='both', labelsize=8)
                fig.patch.set_alpha(0.0)
                ax.set_facecolor("none")
                _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
                st_safe_pyplot(fig, use_container_width=True)
                plt.close(fig)

            st.markdown("### 🔢 فروق التوزيعات الرقمية")
            num_cmp = _compare_numeric_summary(df_before, df_after)
            if not num_cmp.empty:
                st.dataframe(num_cmp.head(50))
                _download_button_df(num_cmp, "⬇️ تنزيل مقارنة رقمية", "numeric_summary_compare.csv")

            st.markdown("### 🔤 انجراف الفئات (Top-k)")
            cat_cmp = _compare_categorical_topk(df_before, df_after, k=8)
            if not cat_cmp.empty:
                st.dataframe(cat_cmp.head(30))
                _download_button_df(cat_cmp, "⬇️ تنزيل مقارنة فئوية", "categorical_topk_compare.csv")

            st.markdown("### 🧭 ملخص نصي للخطوات")
            for mod, txt in _module_summaries().items():
                st.write(f"**{mod}** — {txt}")

    # --- Tab 1: cleaned ---
    with tabs[1]:
        st.subheader("📄 df_cleaned.csv")
        if isinstance(df_clean, pd.DataFrame):
            # حمّل الأعمدة الأصلية من البيانات الخام لضمان أن تبويب cleaned لا يعرض أعمدة سياقية
            df_before_for_cols = _load_csv(ORIGINAL_DATA_PATH)
            if isinstance(df_before_for_cols, pd.DataFrame) and not df_before_for_cols.empty:
                original_cols = df_before_for_cols.columns.tolist()
                # حافظ على ترتيب الأعمدة كما في الأصل
                cols_in_clean = [c for c in original_cols if c in df_clean.columns]
                df_clean_view = df_clean[cols_in_clean].copy() if cols_in_clean else df_clean.copy()
                st.caption("عرض أعمدة **البيانات الأصلية فقط** (دون الأعمدة السياقية المضافة).")
            else:
                # تعذر تحميل الأصل — اعرض كما هو لكن مع تنبيه
                df_clean_view = df_clean.copy()
                st.warning("⚠️ تعذّر تحميل البيانات الأصلية للتحقق من الأعمدة؛ سيتم عرض df_cleaned كما هو.")

            st.write(f"**الشكل:** {df_clean_view.shape[0]} × {df_clean_view.shape[1]}")
            st.dataframe(df_clean_view.head(50))
            _download_button_df(df_clean_view, "⬇️ تنزيل df_cleaned (أعمدة الأصل)", "df_cleaned_original_cols.csv")

            # قاموس الأعمدة — اختيار عمود لعرض وصفه (مرتبط بالبيانات المنظفة df_clean_view)
            st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)
            st.markdown("<div style='text-align:center; font-weight:700; color:#E5E7EB; font-size:16px;'>📖 قاموس الأعمدة</div>", unsafe_allow_html=True)
            cdl, cdm, cdr = st.columns([1, 3, 1])
            with cdm:
                known_cols_clean = [c for c in df_clean_view.columns if c in COLUMN_DOC]
                if known_cols_clean:
                    sel_clean = st.selectbox(
                        "اختر عمودًا لعرض الوصف",
                        known_cols_clean,
                        index=0,
                        key="dict_clean"
                    )
                    st.info(f"**{sel_clean}** — {COLUMN_DOC.get(sel_clean, '—')}")
                else:
                    st.info("لا توجد أعمدة معروفة في هذا الجدول.")

            st.markdown("### فحص مبدئي")
            c1, c2, c3 = st.columns(3)
            with c1:
                _metric_card("عدد الصفوف", df_clean_view.shape[0])
            with c2:
                _metric_card("عدد الأعمدة", df_clean_view.shape[1])
            with c3:
                # تقدير بسيط لنسبة المفقود كليًا
                _metric_card("نسبة المفقود الإجمالية", round(float(df_clean_view.isna().mean().mean())*100, 2), fmt="{:.2f}%")

            st.markdown("### القيم المفقودة")
            _plot_missingness(df_clean_view)

            st.markdown("### توصيف عددي مختصر")
            num_cols_clean = df_clean_view.select_dtypes(include=[np.number]).columns.tolist()
            st.dataframe(_describe_numeric(df_clean_view, num_cols_clean))

            st.markdown("### مصفوفة الارتباط (أعمدة رقمية)")
            sel_cols = st.multiselect("اختر أعمدة رقمية (اختياري)", num_cols_clean, default=num_cols_clean[:8])
            _plot_corr(df_clean_view, sel_cols)
            # مركز التصوير الذكي
            _smart_viz_hub(df_clean_view, key_suffix="preproc_cleaned")
        else:
            st.warning("⚠️ df_cleaned.csv غير متوفر.")





# ----------------------------- مركز التصوير الذكي -----------------------------
def _corr_insights(df: pd.DataFrame, topk: int = 5):
    if df is None or df.empty or df.shape[1] < 2:
        return pd.DataFrame(), "لا توجد بيانات كافية للارتباط."
    corr = df.corr(numeric_only=True)
    corr_pairs = []
    for i, c1 in enumerate(corr.columns):
        for j, c2 in enumerate(corr.columns):
            if i < j:
                corr_pairs.append({"col_1": c1, "col_2": c2, "rho": corr.loc[c1, c2]})
    pairs_df = pd.DataFrame(corr_pairs)
    pairs_df["abs_rho"] = pairs_df["rho"].abs()
    pairs_df = pairs_df.sort_values("abs_rho", ascending=False)
    text = f"أعلى {min(topk, len(pairs_df))} ارتباطات:"
    return pairs_df.head(topk), text

def _smart_viz_hub(df: pd.DataFrame, key_suffix: str):
    if df is None or df.empty:
        return
    st.markdown("### 🧠 مركز التصوير الذكي")
    chart = st.selectbox(
        "اختر نوع الرسم",
        ["Bar", "Line", "Histogram", "Box", "Scatter", "Bubble", "Pie", "Treemap", "Heatmap (Correlation)", "Word Cloud", "Executive Summary"],
        key=f"smart_viz_{key_suffix}",
    )
    if chart == "Bar":
        cat_candidates = [c for c in df.columns if df[c].dtype == object or df[c].dtype == "category"]
        col = st.selectbox("اختر عمودًا تصنيفيًا", cat_candidates or [None], key=f"bar_{key_suffix}")
        if col:
            _plot_bar(df, col, f"Bar: {col}")
    elif chart == "Line":
        num_candidates = df.select_dtypes(include=[np.number]).columns.tolist()
        col = st.selectbox("اختر عمودًا رقميًا", num_candidates or [None], key=f"line_{key_suffix}")
        if col:
            fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
            ax.set_prop_cycle(color=CLINICAL_PALETTE)
            ax.plot(df[col].dropna().values)
            ax.set_title(f"Line: {col}")
            fig.patch.set_alpha(0.0)
            ax.set_facecolor("none")
            st_safe_pyplot(fig)
            plt.close(fig)
    elif chart == "Histogram":
        num_candidates = df.select_dtypes(include=[np.number]).columns.tolist()
        col = st.selectbox("اختر عمودًا رقميًا", num_candidates or [None], key=f"hist_{key_suffix}")
        if col:
            _plot_hist(df, col, f"Histogram: {col}")
    elif chart == "Box":
        num_candidates = df.select_dtypes(include=[np.number]).columns.tolist()
        col = st.selectbox("اختر عمودًا رقميًا", num_candidates or [None], key=f"box_{key_suffix}")
        if col:
            fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
            sns.boxplot(x=df[col].dropna(), ax=ax)
            ax.set_title(f"Box: {col}")
            fig.patch.set_alpha(0.0)
            ax.set_facecolor("none")
            st_safe_pyplot(fig)
            plt.close(fig)
    elif chart == "Scatter":
        num_candidates = df.select_dtypes(include=[np.number]).columns.tolist()
        if len(num_candidates) >= 2:
            x = st.selectbox("المحور X", num_candidates, index=0, key=f"scatter_x_{key_suffix}")
            y = st.selectbox("المحور Y", num_candidates, index=1, key=f"scatter_y_{key_suffix}")
            fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
            sns.scatterplot(data=df, x=x, y=y, alpha=0.6, ax=ax, color=CLINICAL_PALETTE[1])
            ax.set_title(f"Scatter: {x} vs {y}")
            fig.patch.set_alpha(0.0)
            ax.set_facecolor("none")
            st_safe_pyplot(fig)
            plt.close(fig)
        else:
            st.info("يلزم عمودان رقميان على الأقل.")
    elif chart == "Bubble":
        num_candidates = df.select_dtypes(include=[np.number]).columns.tolist()
        if len(num_candidates) >= 3:
            x = st.selectbox("المحور X", num_candidates, index=0, key=f"bubble_x_{key_suffix}")
            y = st.selectbox("المحور Y", num_candidates, index=1, key=f"bubble_y_{key_suffix}")
            size = st.selectbox("حجم الفقاعة", num_candidates, index=2, key=f"bubble_size_{key_suffix}")
            fig, ax = plt.subplots(figsize=FIGSIZE, constrained_layout=False)
            sns.scatterplot(
                data=df, x=x, y=y, size=size, sizes=(20, 400), alpha=0.55, ax=ax,
                hue=None, edgecolor=CLINICAL_PALETTE[0], linewidth=0.5
            )
            ax.set_title(f"Bubble: {x} vs {y}, size={size}")
            fig.patch.set_alpha(0.0)
            ax.set_facecolor("none")
            st_safe_pyplot(fig)
            plt.close(fig)
        else:
            st.info("يلزم 3 أعمدة رقمية على الأقل.")
    elif chart == "Pie":
        cat_candidates = [c for c in df.columns if df[c].dtype == object]
        col = st.selectbox("اختر عمودًا تصنيفيًا", cat_candidates or [None])
        if col:
            _plot_pie(df, col, f"Pie: {col}")
    elif chart == "Treemap":
        st.info("Treemap غير مدعوم حاليًا في هذه النسخة.")
    elif chart == "Heatmap (Correlation)":
        _plot_corr(df)
    elif chart == "Word Cloud":
        # Choose a text column or build from multiple categorical columns
        text_cols = [c for c in df.columns if df[c].dtype == object or str(df[c].dtype).startswith("category")]
        if not text_cols:
            st.info("لا توجد أعمدة نصية/تصنيفيّة مناسبة لتوليد سحابة الكلمات.")
        else:
            col = st.selectbox("اختر عمودًا نصيًا/تصنيفيًا", text_cols, key=f"wc_col_{key_suffix}")
            # Optional filters
            min_len = st.slider("الحد الأدنى لطول الكلمة", 1, 5, 2, key=f"wc_minlen_{key_suffix}")
            max_words = st.slider("الحد الأقصى لعدد الكلمات", 50, 500, 200, step=50, key=f"wc_maxw_{key_suffix}")

            series = df[col].dropna().astype(str)
            # Basic cleaning: strip and filter very short tokens
            text_blob = " ".join([s for s in series if len(s.strip()) >= min_len])
            if not text_blob.strip():
                st.info("لا توجد كلمات كافية لتوليد سحابة الكلمات بعد التنقية.")
            else:
                _render_wordcloud(text_blob, title=f"سحابة كلمات: {col}", max_words=max_words)
    elif chart == "Executive Summary":
        md = _auto_executive_summary(df)
        st.markdown(md)
        st.download_button("⬇️ تنزيل الملخص (Markdown)", data=md.encode("utf-8"), file_name="executive_summary.md", mime="text/markdown")

# ================= New: Lightweight loaders & helpers for standalone Overview =================
@st.cache_data(show_spinner=False)
def _load_for_module_xnew(module: str) -> pd.DataFrame:
    """Return a primary DataFrame per module without touching existing flow."""
    module = str(module).strip()
    if module == "Hybrid":
        p = HYBRID_FILES.get("df_hybrid_recommendations.csv")
        df = _load_csv(p) if p else None
        return df if isinstance(df, pd.DataFrame) else pd.DataFrame()
    if module == "CBF":
        p = CBF_FILES.get("df_cbf_recommendations.csv")
        df = _load_csv(p) if p else None
        return df if isinstance(df, pd.DataFrame) else pd.DataFrame()
    if module == "CF":
        p = CF_FILES.get("df_cf_recommendations.csv")
        df = _load_csv(p) if p else None
        return df if isinstance(df, pd.DataFrame) else pd.DataFrame()
    if module == "Context":
        p = PREPROC_FILES.get("df_contextualized.csv")
        df = _load_csv(p) if p else None
        return df if isinstance(df, pd.DataFrame) else pd.DataFrame()
    if module == "Preprocess":
        p = PREPROC_FILES.get("df_cleaned.csv")
        df = _load_csv(p) if p else None
        return df if isinstance(df, pd.DataFrame) else pd.DataFrame()
    return pd.DataFrame()

def _score_col_guess_xnew(module: str) -> Optional[str]:
    """Heuristic score column name per module."""
    mapping = {
        "Hybrid": "hybrid_score",
        "CBF": "cbf_score",
        "CF": "cf_score",
    }
    return mapping.get(module, None)

def _module_kpis_xnew(name: str, df: pd.DataFrame):
    """Render small KPI cards for a module."""
    st.markdown(f"##### {name}")
    c1, c2, c3 = st.columns(3)
    with c1:
        _metric_card("Rows", int(df.shape[0]) if isinstance(df, pd.DataFrame) else 0)
    with c2:
        if isinstance(df, pd.DataFrame) and "patient_id" in df.columns:
            _metric_card("Unique patients", int(df["patient_id"].nunique()))
        else:
            _metric_card("Unique patients", 0)
    with c3:
        sc = _score_col_guess_xnew(name)
        if sc and isinstance(df, pd.DataFrame) and sc in df.columns:
            s = pd.to_numeric(df[sc], errors="coerce")
            if not s.dropna().empty:
                _metric_card("Score∼mean", float(s.mean()), fmt="{:.3f}")
            else:
                _metric_card("Score∼mean", "-")
        else:
            _metric_card("Score∼mean", "-")

def _mini_hist_xnew(df: pd.DataFrame, col: str, title: str):
    if not isinstance(df, pd.DataFrame) or col not in df.columns:
        return
    fig, ax = plt.subplots(figsize=(5, 3), constrained_layout=False)
    sns.histplot(pd.to_numeric(df[col], errors="coerce").dropna(), kde=True, ax=ax, color=CLINICAL_PALETTE[2])
    ax.set_title(title)
    _arabicize_axis(ax)
    fig.patch.set_alpha(0.0)
    ax.set_facecolor("none")
    _safe_layout(fig, ax, pad=0.02, w_pad=0.02, h_pad=0.02)
    st_safe_pyplot(fig, use_container_width=True)
    plt.close(fig)

def _overview_block_xnew(module: str):
    """A compact, non-table visual summary for a module."""
    df = _load_for_module_xnew(module)
    # KPIs
    _module_kpis_xnew(module, df)
    # Visuals (no tables): one histogram for score if exists, one categorical distribution if 'reason' or similar exists
    sc = _score_col_guess_xnew(module)
    if sc and sc in df.columns:
        _mini_hist_xnew(df, sc, f"{module} — {sc}")
        _insight_hist(df, sc)
    # reason / advice / category pie or bar if available
    cand_bar = None
    for c in ["reason", "hybrid_sources", "advice_type", "bp_category", "risk_level"]:
        if c in df.columns:
            cand_bar = c
            break
    if cand_bar:
        _plot_bar(df, cand_bar, f"{module} — {cand_bar} distribution")
        _insight_bar(df, cand_bar)

def _page_overview_xnew():
    """Standalone Overview page: purely visual cards for selected modules. No tables."""
    st.subheader("نظرة عامة — Overview (جديد)")
    st.caption("هذا القسم مستقل عن بقية الصفحات ولا يغيّر أي سلوك سابق.")
    modules = st.multiselect(
        "اختر مكوّنات للعرض",
        ["Preprocess", "Context", "CF", "CBF", "Hybrid"],
        default=["CF", "CBF"],
        help="يعرض بطاقات ومرئيات موجزة دون جداول."
    )
    if not modules:
        st.info("اختر عنصرًا واحدًا على الأقل.")
        return
    # Arrange in rows of 2 blocks per row; if last row has one item, render it at half-width (centered)
    for i in range(0, len(modules), 2):
        row_mods = modules[i:i+2]
        if len(row_mods) == 1:
            # Create three columns and use the middle with double weight to achieve ~half-width, centered
            left_pad, center_col, right_pad = st.columns([1, 2, 1])
            with center_col:
                st.markdown("---")
                _overview_block_xnew(row_mods[0])
        else:
            cols = st.columns(2)
            for j, mod in enumerate(row_mods):
                with cols[j]:
                    st.markdown("---")
                    _overview_block_xnew(mod)

# ----------------------------- التطبيق -----------------------------
def main():
    # Page config is set at module import time (do not set here again)
    # مظهر عام
    _inject_css()
    # Fonts & theme: توحيد الخطوط (عربي/إنجليزي) لكل الرسوم
    _setup_fonts_and_theme()
    # تحميل الأيقونة كـ Base64 (نستخدم ثوابت للتحكم بالإزاحة من داخل الكود)
    b64_icon = _image_to_base64("assets/s.png")
    # Header: symmetric three columns (icon — titles — icon)

    left, center, right = st.columns([1, 3, 1], vertical_alignment="center")
    with left:
        st.markdown(_icon_html(b64_icon, width=ICON_WIDTH_PX, shift_px=ICON_SHIFT_LEFT_PX, align="left"), unsafe_allow_html=True)
    with center:
        st.markdown(
            """
            <div style="line-height:1.25; text-align:center;">
                <div style="font-size:28px; font-weight:700; color:#E5E7EB;">
                    Hybrid Context-Aware Recommendation System for Hypertension Problem
                </div>
                <div class="med-subtle" style="text-align:center;">
                    نظام توصية هجين قائم على السياق لعلاج ارتفاع ضغط الدم
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with right:
        st.markdown(_icon_html(b64_icon, width=ICON_WIDTH_PX, shift_px=ICON_SHIFT_RIGHT_PX, align="right"), unsafe_allow_html=True)

    st.markdown('<div class="med-divider"></div>', unsafe_allow_html=True)
    st.markdown("  ")  # عنوان
    st.caption("  ")

    # اختيار المجموعة + شعار جانبي (استخدام st.pills) — توسيط في الشريط الجانبي + سطرين فراغ
    _sidebar_brand()
    _options = ["Preprocess", "Context", "CF", "CBF", "Hybrid"]

    # مسافة علوية إضافية (سطرين)
    st.sidebar.markdown("<div style='height:20px'></div>", unsafe_allow_html=True)

    # Pills عمودية بملء العرض (سطر لكل خيار) — مجموعتان: تنظيف/سياق + توصية
    with st.sidebar:
        # ————— القسم الأول: تنظيف البيانات وإضافة الأعمدة السياقية —————
        st.markdown("  ")
        st.markdown("  ")
        st.markdown(
            "<div style='text-align:center; font-weight:700; color:#E5E7EB; font-size:16px;'>تنظيف البيانات وإضافة الأعمدة السياقية</div>",
            unsafe_allow_html=True,
        )
        st.markdown("<div style='height:10px'></div>", unsafe_allow_html=True)
        c1, c2, c3 = st.columns([2, 4, 1])
        with c2:
            group_pre = st.pills(
                "اختيار البيانات",
                ["Preprocess", "Context"],
                selection_mode="single",
                default="Preprocess",
                label_visibility="collapsed",
            )

        st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)

        # ————— القسم الثاني: أنظمة التوصية —————
        st.markdown("  ")
        st.markdown("  ")
        st.markdown(
            "<div style='text-align:center; font-weight:700; color:#E5E7EB; font-size:16px;'>أنظمة التوصية</div>",
            unsafe_allow_html=True,
        )
        st.markdown("<div style='height:10px'></div>", unsafe_allow_html=True)
        r1, r2, r3 = st.columns([2.5, 4, 1])
        with r2:
            group_rec = st.pills(
                "اختيار نظام التوصية",
                ["CF", "CBF", "Hybrid"],
                selection_mode="single",
                default=None,
                label_visibility="collapsed",
            )

    # اختيار نهائي: إن اختير نظام توصية نأخذه، وإلا نأخذ مجموعة التنظيف/السياق
    group_raw = group_rec if group_rec else group_pre
    group = str(group_raw).replace("\u00A0", " ").strip()

    # ================= New (independent): Display Pages selector =================
    with st.sidebar:
        st.markdown("<div style='height:12px'>  </div>", unsafe_allow_html=True)
        st.markdown("<div style='height:12px'>  </div>", unsafe_allow_html=True)
        st.markdown("<div style='height:12px'>  </div>", unsafe_allow_html=True)

        st.markdown(
            "<div style='text-align:center; font-weight:700; color:#E5E7EB; font-size:16px;'> شاشة العرض </div>",
            unsafe_allow_html=True,
        )
        st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)
        # مركز في منتصف الشريط الجانبي باستخدام أعمدة وهمية
        s1, s2, s3 = st.columns([1,5,1])
        with s2:
            page_sel_xnew = st.radio(
                "  ",
                ("Orginal View","Comparison View"),
                index=0,
                key="display_pages_selector_xnew",
                horizontal=False,
                label_visibility="collapsed",
            )

    # حارس: لو خرج نص غير مطابق للمفاتيح تمامًا، طابق بحساسية أقل
    if group not in ALL_GROUPS:
        _keys_map = {k.lower().strip(): k for k in ALL_GROUPS.keys()}
        group = _keys_map.get(group.lower().strip(), _options[0])

    # عرض ملفات المجموعة المختارة — مع تخصيص Preprocess ليعرض فقط df_cleaned في قائمة الملفات
    files = ALL_GROUPS[group]
    if group == "Preprocess":
        files_for_listing = {"df_cleaned.csv": PREPROC_FILES["df_cleaned.csv"]}
        loaded = _section_group_files(group, files_for_listing)
        # حمّل df_contextualized بصمت للاستخدام داخل التبويبات دون إظهاره في قائمة الملفات
        loaded["df_contextualized.csv"] = _load_csv(PREPROC_FILES["df_contextualized.csv"])
    else:
        loaded = _section_group_files(group, files)

    # أقسام تحليلية حسب كل نظام
    st.markdown("---")
    if group == "Hybrid":
        df = loaded.get("df_hybrid_recommendations.csv")
        js = loaded.get("hybrid_eval_summary.json")
        _hybrid_overview(df, js if isinstance(js, dict) else None)
    elif group == "CBF":
        _cbf_overview(loaded)
    elif group == "CF":
        _cf_overview(loaded)
    elif group == "Preprocess":
        _preprocess_overview(loaded)
    elif group == "Context":
        _context_overview(loaded)

    # ================= Render new standalone page(s) without affecting existing logic =================
    if page_sel_xnew == "Comparison View":
        st.markdown("---")
        _section_header("صفحات العرض — Display Pages", "📄")
        _page_overview_xnew()

    # قسم موحّد: بحث وتصفيات سريعة (لأي مجموعة)
    st.markdown("---")
    _section_header("بحث وتصفيات سريعة", "🔎")
    df_any = None
    # خذ أول DataFrame محمّل لعرض أدوات التصفية
    for v in loaded.values():
        if isinstance(v, pd.DataFrame):
            df_any = v
            break
    if df_any is not None and not df_any.empty:
        cols = st.multiselect("اختر أعمدة لعرضها", df_any.columns.tolist(), default=df_any.columns[:10].tolist())
        query = st.text_input("🧭 فلترة (pandas query) — مثال: hybrid_score > 0.6 and confidence_bucket == 'high'")
        try:
            df_view = df_any.copy()
            if query.strip():
                df_view = df_view.query(query)
            st.dataframe(df_view[cols].head(500))
            _download_button_df(df_view[cols], "⬇️ تنزيل النتائج المفلترة", f"filtered_{group}.csv")
        except (ValueError, SyntaxError, NameError, pd.errors.UndefinedVariableError) as e:
            st.warning(f"⚠️ صيغة الفلترة غير صحيحة: {e}")

    st.markdown("---")
    st.markdown('<div class="med-divider"></div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="med-subtle">© Clinical Data Hub — BY:Mohammed L. Maraqa. هذا العرض للاستخدام التحليلي ولا يغني عن الحكم السريري.</div>',
        unsafe_allow_html=True,
    )
    st.success("🎯 تم تحميل الواجهة بنجاح. حدّث الملفات في مجلد outputs وسيتم تحديث العرض تلقائيًا.")

if __name__ == "__main__":
    main()