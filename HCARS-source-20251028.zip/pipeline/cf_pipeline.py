"""
# ملاحظة هامة:
# جميع عمليات جلب التوصية الطبية (feature_id/action) أو شرح الخطة السريرية يجب أن تعتمد حصراً الأعمدة الستة الأساسية:
# bp_category, chol_category, risk_level, fbs_cat, cp_cat, age_group
# القواميس المستخدمة بالترتيب: MEDICAL_RECOMMENDATION_PLAN > CONTEXT_TO_RECOMMENDATION_MAP > FEATURE_ID_BINNED_MAP > manual_review fallback
# الأعمدة الثانوية مثل: chol_bins, restecg_cat, exang_cat, oldpeak_cat, ca_cat, thal_cat تُستخدم فقط في التحليل الإحصائي أو التوسعة المستقبلية،
# وليس ضمن مفاتيح القاموس الأساسي المستخدم في الأنظمة السريرية.
"""
# [MOD] إضافة عمود status لتعقب مصدر التوصية: collaborative_filtering أو cold_start_safe_default أو manual_review
import uuid
import pandas as pd
import re
from utils.config_loader import load_config
from utils.logging_utils import setup_logger
from pipeline.core import check_schema
from recommender.cf import run_collaborative_filtering
from pipeline.helpers import (
    evaluate_recommendations,
    finalize_recommendation_output,  # wrapper عام
    coverage_ge_k,
    cap_topk_per_patient,            # wrapper عام (بدلاً من الاسم المحمي)
)
from utils.mlflow_utils import log_experiment

from utils.constants import assign_feature_id_by_binned, get_medical_plan, plan_as_dict, get_top_n_ui, get_top_n_eval
import os
# =========================
# Helper functions for reporting (inserted by patch)
# =========================
def _report_eval_metrics(csv_path: str, k: int, logger, log_id: str) -> None:
    """
    Read an eval CSV and print/log aggregate metrics:
    precision@k, recall@k, map@k, ndcg@k (means).
    """
    try:
        if not os.path.exists(csv_path):
            logger.warning(f"[{log_id}] Eval metrics file not found: {csv_path}")
            print(f"⚠️ ملف التقييم غير موجود: {csv_path}")
            return
        df_eval = pd.read_csv(csv_path)
    except (OSError, pd.errors.EmptyDataError, pd.errors.ParserError) as ex:
        logger.warning(f"[{log_id}] Could not read eval metrics from {csv_path}: {ex}")
        print(f"⚠️ تعذّر قراءة ملف التقييم: {csv_path} — {ex}")
        return

    metric_cols = [c for c in df_eval.columns if c.endswith(f"@{k}")]
    if not metric_cols:
        logger.warning(f"[{log_id}] No metric columns *@{k} found in {csv_path}. Available columns: {df_eval.columns.tolist()}")
        print(f"⚠️ لا توجد أعمدة مقاييس *@{k} في {csv_path}")
        return

    # Aggregate safely
    agg = {}
    for c in metric_cols:
        series = pd.to_numeric(df_eval[c], errors="coerce")
        agg[c] = {
            "mean": float(series.mean()) if series.notna().any() else float("nan"),
            "std": float(series.std(ddof=1)) if series.notna().sum() > 1 else float("nan"),
            "count": int(series.notna().sum())
        }

    # Pretty print
    print("📈 ملخص المقاييس المجمعة")
    for c in sorted(metric_cols):
        vals = agg[c]
        print(f"• {c}: mean={vals['mean']:.4f}  | std={vals['std']:.4f} | n={vals['count']}")

    # Log a concise line
    means_line = ", ".join(f"{c}={agg[c]['mean']:.4f}" for c in sorted(metric_cols))
    logger.info(f"[{log_id}] Aggregated metrics from {csv_path}: {means_line}")


def _report_recs_summary(csv_path: str, patient_col: str, feature_col: str, logger, log_id: str) -> None:
    """
    Read recommendations CSV and print/log coverage-style summary:
    unique patients, min/max/avg recommendations per patient (after dedup on (patient, feature)).
    """
    try:
        if not os.path.exists(csv_path):
            logger.warning(f"[{log_id}] Recommendations CSV not found: {csv_path}")
            print(f"⚠️ ملف التوصيات غير موجود: {csv_path}")
            return
        df = pd.read_csv(csv_path)
    except (OSError, pd.errors.EmptyDataError, pd.errors.ParserError) as ex:
        logger.warning(f"[{log_id}] Could not read recommendations CSV {csv_path}: {ex}")
        print(f"⚠️ تعذّر قراءة ملف التوصيات: {csv_path} — {ex}")
        return

    if not {patient_col, feature_col} <= set(df.columns):
        logger.warning(f"[{log_id}] Recommendations CSV lacks required columns ({patient_col}, {feature_col}).")
        print(f"⚠️ ملف التوصيات يفتقد أعمدة رئيسية ({patient_col}, {feature_col}).")
        return

    dfu = df.drop_duplicates([patient_col, feature_col])
    counts = dfu.groupby(patient_col)[feature_col].count()
    if counts.empty:
        print("⚠️ لا توجد توصيات بعد إزالة التكرارات.")
        logger.info(f"[{log_id}] No recommendations after deduplication.")
        return

    n_patients = int(counts.shape[0])
    min_recs = int(counts.min())
    max_recs = int(counts.max())
    avg_recs = float(counts.mean())

    print("🧾 ملخص ملف التوصيات:")
    print(f"• عدد المرضى: {n_patients} | أقل/أكثر/متوسط توصيات لكل مريض: {min_recs} / {max_recs} / {avg_recs:.2f}")
    logger.info(f"[{log_id}] Recommendations summary from {csv_path}: patients={n_patients}, min={min_recs}, max={max_recs}, avg={avg_recs:.2f}")

def main():
    """
    جميع التحقق والترتيب يتم بعد بناء النتائج لضمان مطابقة الأعمدة النهائية.
    • يضمن تحديث وتوليد الأعمدة السياقية تلقائيًا عبر القاموس المركزي assign_feature_id_by_binned، ولا يستخدم أي منطق قديم.
    • يسجّل القيم الفريدة للأعمدة السياقية الرئيسية لمراجعة سلامة التوصية السياقية.
    """
    config = load_config()

    # Canonical column names from config (with safe fallbacks)
    cols_cfg = config.get("global", {}).get("columns", {})
    patient_col = cols_cfg.get("patient", "patient_id")
    feature_col = cols_cfg.get("feature", "feature_id")

    logger = setup_logger("cf_pipeline", config["logging"]["cf_pipeline_log_path"])
    log_id = str(uuid.uuid4())

    # --- Normalize Top-N settings to integers for safety (handles legacy keys & string/templated values) ---
    try:
        config["recommendation"]["top_n_ui"] = int(get_top_n_ui(config))
        config["recommendation"]["top_n_eval"] = int(get_top_n_eval(config))
        if "cold_start" in config:
            # Avoid relying on interpolation; set explicit integer
            config["cold_start"]["top_n"] = int(get_top_n_eval(config))
        logger.info(f"[{log_id}] Normalized Top-N: top_n_ui={config['recommendation']['top_n_ui']}, top_n_eval={config['recommendation']['top_n_eval']}")
    except (KeyError, ValueError, TypeError) as _ex:
        logger.warning(f"[{log_id}] [cf_pipeline] Could not normalize top-N values, using defaults where needed: {_ex}")

    # Ensure output directory for CF exists
    os.makedirs("outputs/CF", exist_ok=True)

    logger.info(f"[{log_id}] Starting CF pipeline")

    # Run collaborative filtering to generate recommendations
    df_cf, used_cold_start, recommendation_stats = run_collaborative_filtering()
    # [MOD] تأكد من وجود عمود status في النتائج النهائية، حسب مصدر التوصية
    if "status" not in df_cf.columns:
        # إذا كان هناك عمود reason يدل على cold_start، استخدمه
        if "reason" in df_cf.columns:
            mask_cold = df_cf["reason"] == "cold_start_safe_default"
            mask_cf = ~mask_cold
            df_cf["status"] = None
            df_cf.loc[mask_cold, "status"] = "cold_start_safe_default"
            df_cf.loc[mask_cf, "status"] = "collaborative_filtering"
        else:
            # إذا لم يوجد reason، اعتبر جميعها collaborative_filtering
            df_cf["status"] = "collaborative_filtering"


    # --- سجل القيم الفريدة للأعمدة السياقية القديمة (للمراجعة) ---
    for col in ["feature_id_binned", "context_feature_id"]:
        if col in df_cf.columns:
            unique_vals = df_cf[col].unique()[:5]
            logger.info(f"[{log_id}] Unique values of '{col}' before drop (old CF): {unique_vals}")

    if df_cf.empty:
        logger.warning(f"[{log_id}] لا توجد أي توصيات CF أو cold_start (DataFrame فارغ). تحقق من البيانات أو إعدادات min_ratings في config.")
        # Continue execution even if empty, as per instructions

    # --- تشخيص التوصيات المبدئية (cold_start) بعد التجميع النهائي ---
    if "status" in df_cf.columns:
        cold_start_mask = df_cf["status"].astype(str).eq("cold_start_safe_default")
        cold_start_ids = df_cf.loc[cold_start_mask, patient_col].unique().tolist()
    elif "reason" in df_cf.columns:
        cold_start_mask = df_cf["reason"].astype(str).eq("cold_start_safe_default")
        cold_start_ids = df_cf.loc[cold_start_mask, patient_col].unique().tolist()
        logger.warning(f"[{log_id}] Using 'reason' to infer cold-start because 'status' column is missing.")
    else:
        logger.error(f"[{log_id}] Neither 'status' nor 'reason' columns are present. Cannot identify cold-start patients.")
        cold_start_ids = []
    num_cold_start = len(cold_start_ids)
    total_patients = df_cf[patient_col].nunique() if not df_cf.empty else 0
    num_cf = total_patients - num_cold_start
    print(f"🔹 عدد المرضى بتوصيات CF حقيقية: {num_cf}")
    print(f"🔸 عدد المرضى بتوصيات cold_start فقط: {num_cold_start}")
    print(f"📊 نسبة توصيات cold_start: {(num_cold_start/total_patients):.2%} من المرضى" if total_patients > 0 else "لا يوجد مرضى.")
    logger.info(f"[{log_id}] 🔹 عدد المرضى بتوصيات CF حقيقية: {num_cf}")
    logger.info(f"[{log_id}] 🔸 عدد المرضى بتوصيات cold_start فقط: {num_cold_start}")
    logger.info(f"[{log_id}] 📊 نسبة توصيات cold_start: {(num_cold_start/total_patients):.2%} من المرضى" if total_patients > 0 else f"[{log_id}] لا يوجد مرضى.")

    logger.info(f"[{log_id}] عدد المرضى في النتائج النهائية: {total_patients}، عدد المرضى الذين حصلوا فقط على cold_start: {num_cold_start}")
    logger.info(f"[{log_id}] قائمة أول 20 مريضًا في النتائج النهائية: {df_cf[patient_col].unique()[:20].tolist() if not df_cf.empty else 'لا يوجد مرضى'}")

    if num_cold_start > 0:
        logger.warning(f"[{log_id}] WARNING: تم إصدار توصيات مبدئية غير شخصية (cold_start_safe_default) للمرضى IDs التالية: {cold_start_ids}. راجع التوصيات سريريًا قبل الاعتماد.")
        logger.info(f"[{log_id}] عدد المرضى الذين حصلوا فقط على توصيات cold_start: {num_cold_start} من أصل {total_patients} ({num_cold_start/total_patients:.2%})")
        if num_cold_start == total_patients and total_patients > 0:
            logger.warning(f"[{log_id}] تحذير: جميع التوصيات مبنية على cold_start فقط، لا توجد توصيات CF فعلية.")
    else:
        logger.info(f"[{log_id}] جميع المرضى حصلوا على توصيات شخصية مبنية على CF.")

    # Rename 'score' column to 'score_cf' if 'score_cf' does not exist
    if "score" in df_cf.columns and "score_cf" not in df_cf.columns:
        df_cf = df_cf.rename(columns={"score": "score_cf"})
        logger.info(f"[{log_id}] Renamed 'score' column to 'score_cf'")

    # Log about cold_start usage
    if used_cold_start:
        logger.warning(f"[{log_id}] Fallback to cold_start: All or some recommendations generated from cold_start_handler.py (not actual CF). Check patient history/data coverage.")
    else:
        logger.info(f"[{log_id}] Recommendations generated from actual collaborative filtering (CF) model.")

    # Check for missing columns according to config["output_columns"]["cf"]
    required_columns = config["output_columns"]["cf"]
    # [MOD] تأكد أن عمود status ضمن الأعمدة المطلوبة
    if "status" not in required_columns:
        required_columns = [patient_col, "status"] + [c for c in required_columns if c != patient_col]
    missing_columns = [col for col in required_columns if col not in df_cf.columns]
    if missing_columns:
        logger.error(f"[{log_id}] Missing required columns: {missing_columns}. Stopping execution.")
        return

    # --- منطق دمج الأعمدة السياقية الجديد ---
    try:
        # الأعمدة السياقية الأساسية التي نرغب بضمّها
        contextual_cols = [
            "bp_category", "chol_category", "age_group", "risk_level",
            "fbs_cat", "cp_cat", "feature_id_binned", "context_feature_id", "true_response"
        ]

        # استخدم مسار السياق من الإعدادات إن وُجد، وإلا المسار الافتراضي
        ctx_path = (
            config.get("data_paths", {}).get("hypertension")
            or "outputs/tmp/df_contextualized.csv"
        )
        contextual_df = pd.read_csv(ctx_path)

        # تحضير قائمة الأعمدة المتاحة فعليًا في ملف السياق
        available_contextual_cols = [c for c in contextual_cols if c in contextual_df.columns]
        if patient_col not in contextual_df.columns:
            raise KeyError(f"'{patient_col}' غير موجود في ملف السياق: {ctx_path}")

        # توحيد نوع المعرّف قبل الدمج (لتفادي فشل الدمج الصامت)
        if patient_col in df_cf.columns and contextual_df[patient_col].dtype != df_cf[patient_col].dtype:
            contextual_df[patient_col] = contextual_df[patient_col].astype(str)
            df_cf[patient_col] = df_cf[patient_col].astype(str)

        # اختزال السياق إلى مستوى المريض فقط (patient-level)
        # نأخذ mode لكل عمود، وإن لم يتوفر نأخذ أول قيمة غير فارغة
        def _first_non_null(s: pd.Series):
            s = s.dropna()
            return s.iloc[0] if not s.empty else None

        ctx_patient_level = (
            contextual_df[[patient_col] + available_contextual_cols]
            .groupby(patient_col, dropna=False)
            .agg(lambda s: s.mode().iloc[0] if not s.mode().empty else _first_non_null(s))
            .reset_index()
        )

        # احذف أي أعمدة سياقية موجودة مسبقًا في df_cf حتى لا يحصل clash
        for col in available_contextual_cols:
            if col in df_cf.columns:
                df_cf.drop(columns=[col], inplace=True)

        # دمج على مستوى patient فقط
        df_cf = df_cf.merge(
            ctx_patient_level[[patient_col] + available_contextual_cols],
            on=patient_col,
            how="left"
        )

        # تأكد من وجود وترتيب الأعمدة النهائية المطلوبة للهجين
        required_columns_hybrid = [
            "patient_id", "bp_category", "chol_category", "age_group",
            "risk_level", "fbs_cat", "cp_cat", "feature_id", "score_cf",
            "reason", "explanation", "source", "true_response"
        ]
        for col in required_columns_hybrid:
            if col not in df_cf.columns:
                if col == "score_cf":
                    df_cf[col] = 0.0
                else:
                    df_cf[col] = None
        df_cf = df_cf[required_columns_hybrid + [c for c in df_cf.columns if c not in required_columns_hybrid]]

        # إبلاغ نسب القيم المفقودة في الأعمدة السياقية بعد الدمج (تشخيص)
        na_rates = df_cf[[c for c in available_contextual_cols if c in df_cf.columns]].isna().mean().sort_values(ascending=False)
        logger.info(f"[{log_id}] Context merge (patient-level) NA rates: " + ", ".join(f"{c}={na_rates[c]:.1%}" for c in na_rates.index))

        logger.info(f"[{log_id}] ✅ Contextual columns merged at patient-level and ordered.")
    except (FileNotFoundError, KeyError, ValueError, pd.errors.ParserError) as e:
        logger.error(f"[{log_id}] Failed to merge patient-level contextual columns: {e}")
        # fallback: أنشئ الأعمدة المطلوبة إن لم تتوفر
        required_columns_hybrid = [
            "patient_id", "bp_category", "chol_category", "age_group",
            "risk_level", "fbs_cat", "cp_cat", "feature_id", "score_cf",
            "reason", "explanation", "source", "true_response"
        ]
        for col in required_columns_hybrid:
            if col not in df_cf.columns:
                if col == "score_cf":
                    df_cf[col] = 0.0
                else:
                    df_cf[col] = None
        df_cf = df_cf[required_columns_hybrid + [c for c in df_cf.columns if c not in required_columns_hybrid]]

    # Reorder columns according to config["output_columns"]["cf"], keep extra columns at the end
    extra_columns = [col for col in df_cf.columns if col not in required_columns]
    df_cf = df_cf[required_columns + extra_columns]
    logger.info(f"[{log_id}] Reordered columns according to config['output_columns']['cf']")

    # =========================
    # (5.1) دمج CF + Cold-Start ثم نظافة نهائية
    # =========================

    # محاولة التقاط df_cs إن كان متاحاً من مسار خارجي:
    df_cs = None
    try:
        # إن كانت لديك نقطة توليد منفصلة لملف/إطار cold-start يمكنك قراءته هنا
        # مثال (اختياري): df_cs = pd.read_csv("outputs/CF/df_cold_start_raw.csv")
        pass
    except (FileNotFoundError, pd.errors.ParserError) as _ex:
        logger.warning(f"[{log_id}] Could not load external cold-start frame: {_ex}")

    # إن لم يوجد df_cs منفصل، حاول استنتاج صفوف cold-start من df_cf نفسه:
    if df_cs is None:
        if "status" in df_cf.columns:
            _mask_cs = df_cf["status"].astype(str).eq("cold_start_safe_default")
            logger.info(f"[{log_id}] Cold-start rows detected inside df_cf (via status): {_mask_cs.sum()}")
        elif "reason" in df_cf.columns:
            _mask_cs = df_cf["reason"].astype(str).eq("cold_start_safe_default")
            logger.info(f"[{log_id}] Cold-start rows detected inside df_cf (via reason Fallback): {_mask_cs.sum()}")
        else:
            _mask_cs = pd.Series([False] * len(df_cf))
            logger.warning(f"[{log_id}] Neither 'status' nor 'reason' exists; cannot detect cold-start rows.")

    # k المستخدم للقصّ لكل مريض (Top-K cap). نقرأه من config:
    k_cap = int(
        config.get("recommendation", {}).get("per_patient_topn_cap", 0) or
        config.get("recommendation", {}).get("top_n_eval", 5) or
        5
    )

    # دمج CF + Cold-start
    if isinstance(df_cs, pd.DataFrame) and not df_cs.empty:
        df_all = pd.concat([df_cf, df_cs], ignore_index=True)
        logger.info(f"[{log_id}] Concatenated CF + Cold-start frames: df_all.shape={df_all.shape}")
    else:
        # لا يوجد إطار cs منفصل — نعتمد df_cf (قد يتضمن كلا المصدرين)
        df_all = df_cf.copy()
        logger.info(f"[{log_id}] Using df_cf as df_all (no separate cold-start frame). df_all.shape={df_all.shape}")

    # إزالة أي صفوف ناقصة الأعمدة الأساسية قبل إنهاء الإطار
    _core_missing = [c for c in (patient_col, feature_col) if c not in df_all.columns]
    if _core_missing:
        logger.error(f"[{log_id}] Missing core columns in df_all before finalize: {_core_missing}. Aborting.")
        return

    # 1) إزالة التكرارات (patient, feature) + 2) قصّ Top-K فريد لكل مريض (إن فُعّل)
    df_all = finalize_recommendation_output(df_all)
    df_all = cap_topk_per_patient(
        df_all, k=k_cap, patient_col=patient_col, feature_col=feature_col, score_col="score_cf"
    )
    logger.info(f"[{log_id}] ✅ df_all finalized & Top-{k_cap} capped per patient. shape={df_all.shape}")

    # --- Build evaluation candidate set (eval-only cap) ---
    # Prefer evaluation.eval_cap, fallback to evaluation.loco_family.cap, else 10
    eval_cap = int(
        (config.get("evaluation", {}) or {}).get("eval_cap")
        or (config.get("evaluation", {}).get("loco_family", {}) or {}).get("cap", 10)
        or 10
    )
    try:
        df_eval_candidates = cap_topk_per_patient(
            df_all.copy(),
            k=eval_cap,
            patient_col=patient_col,
            feature_col=feature_col,
            score_col="score_cf",
        )
        logger.info(f"[{log_id}] Built df_eval_candidates with cap={eval_cap}: shape={df_eval_candidates.shape}")
    except Exception as _ex:
        logger.warning(f"[{log_id}] Failed to build df_eval_candidates (cap={eval_cap}); falling back to df_all. Reason: {_ex}")
        df_eval_candidates = df_all

    # =========================
    # (5.2) حسابات التغطية والسجل من df_all نفسه
    # =========================
    n_patients_cov, pct_ge_k, min_recs, max_recs, avg_recs = coverage_ge_k(
        df_all, k=k_cap, patient_col=patient_col, feature_col=feature_col
    )
    logger.info(
        f"[{log_id}] Coverage on df_all (unique pairs): patients={n_patients_cov}, "
        f"min={min_recs}, max={max_recs}, avg={avg_recs:.2f}, pct_with_≥{k_cap}={pct_ge_k:.2%}"
    )

    # تحليل مصدر التوصيات لكل مريض (CF-only / CS-only / Mixed)
    if "status" in df_all.columns:
        try:
            src_by_patient = (
                df_all.groupby(patient_col)["status"]
                      .apply(lambda s: set(s.dropna().astype(str)))
                      .to_dict()
            )
            only_cs = sum(1 for v in src_by_patient.values() if v == {"cold_start_safe_default"})
            only_cf = sum(1 for v in src_by_patient.values() if v == {"collaborative_filtering"})
            mixed  = sum(1 for v in src_by_patient.values() if len(v) > 1)
            logger.info(f"[{log_id}] 🔹 CF-only patients: {only_cf}")
            logger.info(f"[{log_id}] 🔸 Cold-start-only patients: {only_cs}")
            logger.info(f"[{log_id}] 🔻 Mixed-source patients: {mixed}")
        except (KeyError, TypeError, ValueError) as _ex:
            logger.warning(f"[{log_id}] Could not compute source mix per patient: {_ex}")
    else:
        logger.warning(f"[{log_id}] 'status' column is missing in df_all — cannot compute CF-only / CS-only / Mixed stats.")

    # إضافة المنطق الجديد بعد الترتيب النهائي للأعمدة

    # --- Score Threshold Filtering (Config-driven) ---
    top_n_eval = int(config.get("recommendation", {}).get("top_n_eval", 5))
    score_threshold_enabled = config.get("recommendation", {}).get("score_threshold_enabled", False)
    score_threshold = config.get("recommendation", {}).get("score_threshold", 0.0)

    n_before_threshold = len(df_cf)
    if score_threshold_enabled and "score_cf" in df_cf.columns:
        df_cf = df_cf[df_cf["score_cf"] >= score_threshold]
    n_after_threshold = len(df_cf)
    logger.info(f"[{log_id}] Number of recommendations before threshold: {n_before_threshold}, after: {n_after_threshold}, dropped: {n_before_threshold - n_after_threshold}")

    # --- Finalize output: deduplicate (patient, feature) and optional Top-K cap per config ---
    # Ensure df_cf is a DataFrame (some branches of filtering/indexing may return a Series accidentally)
    if isinstance(df_cf, pd.Series):
        logger.warning(f"[{log_id}] df_cf is a pandas Series unexpectedly (name={getattr(df_cf, 'name', None)}). Attempting to convert to DataFrame safely.")
        df_cf = df_cf.to_frame()
        # If unnamed single column, try to preserve the intended column name
        if df_cf.shape[1] == 1 and df_cf.columns.tolist() == [0]:
            df_cf.columns = [patient_col]

    if not isinstance(df_cf, pd.DataFrame):
        raise TypeError("df_cf must be a pandas DataFrame before finalize_recommendation_output().")

    # Hard check for core columns before finalize
    missing_core_before_finalize = [c for c in (patient_col, feature_col) if c not in df_cf.columns]
    if missing_core_before_finalize:
        logger.error(f"[{log_id}] Missing core columns before finalize: {missing_core_before_finalize}. Aborting to avoid corrupt output.")
        return

    per_patient_cap = int(config.get("recommendation", {}).get("per_patient_topn_cap", 0) or 0)
    df_cf = finalize_recommendation_output(df_cf)
    logger.info(f"[{log_id}] ✅ Finalized recommendations with per_patient_topn_cap={'disabled' if per_patient_cap <= 0 else per_patient_cap}; shape={df_cf.shape}")

    # Coverage after finalize on unique pairs
    n_patients_cov, pct_ge_k, min_recs, max_recs, avg_recs = coverage_ge_k(
        df_cf, k=top_n_eval, patient_col=patient_col, feature_col=feature_col
    )
    logger.info(
        f"[{log_id}] Coverage after finalize (unique pairs): patients={n_patients_cov}, min={min_recs}, max={max_recs}, avg={avg_recs:.2f}, pct_with_≥{top_n_eval}={pct_ge_k:.2%}"
    )

    # Check patients without any recommendation versus context
    try:
        _ctx_df = pd.read_csv("outputs/tmp/df_contextualized.csv")
        _ctx_patient_col = patient_col if patient_col in _ctx_df.columns else "patient_id"
        all_patients = set(_ctx_df[_ctx_patient_col].unique())
        patients_with_recommendations = set(df_cf[patient_col])
        missing_patients = all_patients - patients_with_recommendations
        if missing_patients:
            logger.warning(f"[{log_id}] Patients with NO recommendation after finalize: {len(missing_patients)}, sample: {list(missing_patients)[:10]}")
    except Exception as _ex:
        logger.warning(f"[{log_id}] Could not compute patients-without-recommendation due to: {_ex}")

    total_patients_final = df_cf[patient_col].nunique()
    logger.info(f"[{log_id}] عدد المرضى النهائي الذين حصلوا على توصيات بعد finalize: {total_patients_final}")

    # Log reasons distribution after finalize
    if "reason" in df_cf.columns:
        reason_dist = df_cf["reason"].value_counts().to_dict()
        logger.info(f"[{log_id}] Recommendation reasons distribution (post-finalize): {reason_dist}")

    if df_cf.empty:
        logger.warning(f"[{log_id}] WARNING: df_cf_recommendations.csv was exported empty. لا يوجد أي توصية CF أو cold_start.")
        print("⚠️ ملف التوصيات النهائي فارغ: لم يتم بناء أي توصية CF أو cold_start لأي مريض.")
    else:
        if (
            "reason" in df_cf.columns
            and isinstance(df_cf["reason"], pd.Series)
            and df_cf["reason"].eq("cold_start_safe_default").all()
        ):
            logger.warning(f"[{log_id}] جميع التوصيات في الملف النهائي مبنية على cold_start فقط، مما يعني أنها توصيات مبدئية غير مخصصة سريريًا. يُنصح بمراجعة هذه التوصيات سريريًا قبل الاعتماد عليها في اتخاذ القرارات الطبية.")
            print(f"🔸 جميع التوصيات ({len(df_cf)}) في الملف النهائي مبنية على cold_start فقط. عدد المرضى: {total_patients}")

    # --- Ensure output columns match config exactly before saving ---
    required_columns = config["output_columns"]["cf"]
    # [MOD] تأكد من إضافة status في الأعمدة المطلوبة
    if "status" not in required_columns:
        required_columns = [patient_col, "status"] + [c for c in required_columns if c != patient_col]
    contextual_cols_default = [
        "bp_category", "chol_category", "age_group", "risk_level",
        "fbs_cat", "cp_cat", "feature_id_binned", "context_feature_id"
    ]
    for col in required_columns:
        if col not in df_cf.columns:
            if col in contextual_cols_default:
                df_cf[col] = "cold_start"
            elif col == "status":
                df_cf[col] = "manual_review"
            else:
                df_cf[col] = "manual_review"
    # [MOD] إذا هناك صفوف manual_review (مثلاً تم توليدها يدوياً)، status لها يجب أن يكون manual_review
    if "status" in df_cf.columns:
        if "reason" in df_cf.columns:
            mask_manual = df_cf["reason"].astype(str).str.lower() == "manual_review"
            df_cf.loc[mask_manual, "status"] = "manual_review"
        # أو إذا feature_id/manual_review
        if "feature_id" in df_cf.columns:
            mask_manual2 = df_cf["feature_id"].astype(str).str.lower() == "manual_review"
            df_cf.loc[mask_manual2, "status"] = "manual_review"
    # Reorder columns: status مباشرة بعد patient_id
    col_order = [c for c in required_columns if c != "status" and c != patient_col]
    df_cf = df_cf[[patient_col, "status"] + col_order + [c for c in df_cf.columns if c not in ([patient_col, "status"] + col_order)]]
    logger.info(f"[{log_id}] Output columns reordered and missing columns (if any) filled with 'manual_review' as per config['output_columns']['cf']")

    # --- Ensure final required columns and order for hybrid/CBF ---
    # This ensures compatibility with hybrid/CBF and guarantees required columns and order.
    required_columns_hybrid = [
        "patient_id", "status", "bp_category", "chol_category", "age_group",
        "risk_level", "fbs_cat", "cp_cat", "feature_id", "score_cf",
        "reason", "explanation", "source", "true_response"
    ]
    # Add missing columns as None/"unknown" or 0.0 for score_cf
    for col in required_columns_hybrid:
        if col not in df_cf.columns:
            if col == "score_cf":
                df_cf[col] = 0.0
            elif col == "status":
                df_cf[col] = "manual_review"
            else:
                df_cf[col] = None

    # Attempt to fill true_response if missing or all null
    if "true_response" not in df_cf.columns or df_cf["true_response"].isnull().all():
        try:
            df_contextualized = pd.read_csv("outputs/tmp/df_contextualized.csv")
            true_response_col = "true_response" if "true_response" in df_contextualized.columns else (
                "target" if "target" in df_contextualized.columns else None
            )
            if true_response_col:
                df_cf = df_cf.merge(
                    df_contextualized[[patient_col, true_response_col]].rename(columns={true_response_col: "true_response"}),
                    on=patient_col, how="left"
                )
            else:
                logger.warning(f"No true_response or target column found in df_contextualized.")
        except Exception as e:
            logger.warning(f"Could not merge true_response from context: {e}")

    # Check for missing columns before reordering
    missing_hybrid_cols = [col for col in required_columns_hybrid if col not in df_cf.columns]
    if missing_hybrid_cols:
        logger.error(f"Columns missing before final reordering: {missing_hybrid_cols}")
        for col in missing_hybrid_cols:
            if col == "score_cf":
                df_cf[col] = 0.0
            elif col == "status":
                df_cf[col] = "manual_review"
            else:
                df_cf[col] = None

    # Ensure correct column order (no extras)
    df_cf = df_cf[required_columns_hybrid]

    # --- Config-driven score clipping and explicit NA fills (do NOT drop rows) ---
    rec_cfg = config.get("recommendation", {})
    if "score_cf" in df_cf.columns and rec_cfg.get("clip_scores", True):
        pre_over1 = int((df_cf["score_cf"] > 1).sum())
        pre_under0 = int((df_cf["score_cf"] < 0).sum())
        logger.info(f"[{log_id}] Export clipping score_cf to [0,1]: >1 before={pre_over1}, <0 before={pre_under0}")
        # Clip in place; do NOT delete any rows
        df_cf["score_cf"] = df_cf["score_cf"].clip(0.0, 1.0)
    # Fill defaults from config to avoid bare fillna calls
    fill_defaults = rec_cfg.get("fill_defaults", {"true_response": 0, "reason": "", "explanation": "", "source": ""})
    for c, v in fill_defaults.items():
        if c in df_cf.columns:
            df_cf[c] = df_cf[c].fillna(v)

    # --- Robust cleaning/filling before final save (drop only rows missing core keys) ---
    core_before = len(df_all)
    core_na_mask = df_all[patient_col].isna() | df_all[feature_col].isna()
    core_drop = df_all.loc[core_na_mask]
    if not core_drop.empty:
        logger.warning(f"[{log_id}] Dropping {len(core_drop)} rows missing core keys ({patient_col}/{feature_col}).")
        df_all = df_all.loc[~core_na_mask]
    logger.info(f"[{log_id}] Core rows before={core_before}, after={len(df_all)}")

    # Fill status / score_cf
    if "status" in df_all.columns:
        df_all["status"] = df_all["status"].fillna("manual_review")
    if "score_cf" in df_all.columns:
        df_all["score_cf"] = pd.to_numeric(df_all["score_cf"], errors="coerce").fillna(0.0).clip(0.0, 1.0)

    # لا نملأ الأعمدة السياقية بـ "unknown" لأن هذه قيم حقيقية يجب أن تأتي من الدمج.
    # بدلاً من ذلك نُسجّل نسب الفراغ للتحقق، ونتركها NaN كي تظهر في التحليلات.
    _ctx_cols_diag = ["bp_category","chol_category","age_group","risk_level","fbs_cat","cp_cat","feature_id_binned","context_feature_id"]
    _ctx_cols_diag = [c for c in _ctx_cols_diag if c in df_all.columns]
    if _ctx_cols_diag:
        _na_rates_all = df_all[_ctx_cols_diag].isna().mean()
        _high_na = _na_rates_all[_na_rates_all > 0.05]
        if not _high_na.empty:
            logger.warning(f"[{log_id}] High NA rates in context columns (df_all): " +
                           ", ".join(f"{c}={_na_rates_all[c]:.1%}" for c in _high_na.index))

    # true_response fill (CSV only; ground-truth comes from external df_contextualized during evaluation)
    if "true_response" in df_all.columns:
        df_all["true_response"] = pd.to_numeric(df_all["true_response"], errors="coerce").fillna(0).astype(int)

    # --- Save final recommendations (df_all) ---
    cf_recommendations_path = "outputs/CF/df_cf_recommendations.csv"
    df_all.to_csv(cf_recommendations_path, index=False)
    logger.info(f"[{log_id}] ✅ Saved final recommendations to {cf_recommendations_path} (rows={len(df_all)})")

    # --- مراقبة نسبة manual_review بعد التصدير ---
    manual_cols = ["feature_id_binned", "context_feature_id"]
    if not df_cf.empty:
        manual_counts = {}
        for col in manual_cols:
            if col in df_cf.columns:
                mask_manual = df_cf[col].astype(str).str.lower() == "manual_review"
                if isinstance(mask_manual, pd.Series):
                    count_manual = int(mask_manual.sum())
                else:
                    # scalar bool fallback
                    count_manual = int(bool(mask_manual))
                manual_counts[col] = count_manual
                percent_manual = (count_manual / len(df_cf)) * 100
                logger.info(f"[{log_id}] نسبة manual_review في '{col}': {percent_manual:.2f}% ({count_manual} من {len(df_cf)})")
                print(f"🔎 نسبة manual_review في '{col}': {percent_manual:.2f}% ({count_manual} من {len(df_cf)})")
        if any(count > 0 for count in manual_counts.values()):
            logger.warning(f"[{log_id}] ⚠️ توجد صفوف manual_review في الأعمدة السياقية! تحقق من بيانات cf أو ملف df_contextualized.csv.")
    else:
        logger.info(f"[{log_id}] لا توجد بيانات CF لتدقيق manual_review.")

    # --- دمج التوصيات مع البيانات السياقية الكاملة وتصدير مَلف متكامل ---
    # تحديث الأعمدة السياقية المركزية في توصيات CF قبل أي دمج نهائي (حماية مزدوجة)
    if not df_cf.empty:
        df_cf = assign_feature_id_by_binned(df_cf, log=logger, log_id=log_id)
        logger.info(f"[{log_id}] ✅ Re-assigned feature_id in df_cf via assign_feature_id_by_binned.")
        # --- إعادة تخصيص التوصيات النهائية باستخدام الطبقة الذكية ---
        def extract_plan_details(row):
            """
            # [INFO] تسلسل جلب التوصية الطبية:
            # 1. البحث أولاً في MEDICAL_RECOMMENDATION_PLAN باستخدام 6 أعمدة سياقية رئيسية (CONTEXT_COLUMNS).
            # 2. في حال عدم وجود توصية، الانتقال إلى CONTEXT_TO_RECOMMENDATION_MAP عبر الثلاثي (bp_category, chol_category, risk_level).
            # 3. ثم إلى FEATURE_ID_BINNED_MAP.
            # 4. وأخيراً fallback إلى توصية تلقائية أو manual_review.
            # الأعمدة الثانوية لا تدخل أبداً في بناء المفتاح في هذا السياق.
            """
            def _safe_str(val):
                # حول إلى نص صغير أو "any" إذا كانت القيمة مفقودة أو رقمية أو float
                if pd.isnull(val):
                    return "any"
                return str(val).lower()
            bp_cat = _safe_str(row.get("bp_category", "any"))
            chol_cat = _safe_str(row.get("chol_category", "any"))
            risk_level = _safe_str(row.get("risk_level", "any"))
            fbs_cat = _safe_str(row.get("fbs_cat", "any"))
            cp_cat = _safe_str(row.get("cp_cat", "any"))
            rec = get_medical_plan(bp_cat, chol_cat, risk_level, fbs_cat, cp_cat)
            plan = plan_as_dict(rec)
            # اجعل 'reason' تفسيراً طبياً/نصيحة، و'source' يعبّر عن مصدر التوصية (status أو مصدر الخطة)
            src_label = str(row.get("status", "")).lower()
            if src_label in {"cold_start_safe_default", "collaborative_filtering", "manual_review"}:
                final_source = src_label
            else:
                final_source = plan.get("source")

            if plan.get("advice"):
                final_reason = plan.get("advice")
            elif plan.get("explanation"):
                final_reason = plan.get("explanation")
            else:
                final_reason = "unknown"

            return pd.Series({
                "feature_id": plan.get("action", "manual_review"),
                "reason": final_reason,
                "explanation": plan.get("explanation"),
                "source": final_source
            })

        df_cf[["feature_id", "reason", "explanation", "source"]] = df_cf.apply(extract_plan_details, axis=1)
        # تلخيص سريع لأهم الأعمدة السياقية
        for col in ["feature_id", "feature_id_binned", "context_feature_id"]:
            if col in df_cf.columns:
                logger.info(f"[{log_id}] {col} | Unique: {df_cf[col].nunique()} | Sample: {df_cf[col].unique()[:5].tolist()}")


    # Validate schema of the recommendations dataframe using output_columns cf
    if not check_schema(df_cf, required_columns):
        logger.error(f"[{log_id}] Schema validation failed for CF recommendations.")
        return

    logger.info(f"[{log_id}] CF recommendations dataframe shape: {df_cf.shape}")
    logger.info(f"[{log_id}] CF recommendations dataframe columns: {df_cf.columns.tolist()}")

    # Evaluate recommendations on the FINAL dataframe (post-finalize) and persist eval CSV
    # Prefer using external df_contextualized to build ground-truth (prevents leakage)
    try:
        df_ctx = pd.read_csv("outputs/tmp/df_contextualized.csv")
        logger.info(f"[{log_id}] Loaded external df_contextualized for evaluation: rows={len(df_ctx)}")
    except Exception as _ex:
        logger.warning(f"[{log_id}] Could not load df_contextualized for evaluation (fallback to df_all truth if needed): {_ex}")
        df_ctx = None

    if ("true_response" in df_all.columns) or (df_ctx is not None and {"true_response", patient_col, feature_col} <= set(df_ctx.columns)):
        try:
            k_eval = int(get_top_n_eval(config))
        except (KeyError, TypeError, ValueError):
            k_eval = 5
        eval_save_path = "outputs/CF/df_cf_recommendations_eval.csv"

        # Use the unified evaluator (helpers) and request coverage stats
        eval_result = evaluate_recommendations(
            df_all,
            df_contextualized=df_ctx,  # <<< مهم: مصدر حقيقة خارجي إن وُجد
            true_col="true_response",
            patient_col=patient_col,
            feature_col=feature_col,
            k=k_eval,
            return_coverage_stats=True,
            add_metrics_to_df=True,
            save_path=eval_save_path,
            eval_logger=logger,
            log_id=log_id,
        )

        # eval_result قد يكون (df_eval, coverage_report)
        if isinstance(eval_result, tuple):
            df_eval, coverage_report = eval_result
        else:
            df_eval, coverage_report = eval_result, None

        # Helper to sanitize metric names for MLflow
        def _sanitize_metric_name(name: str) -> str:
            # Replace '@' with '_at_' and remove unsupported characters
            name = name.replace("@", "_at_")
            # Allow only alphanumerics, underscore, dash, dot, space, colon, and slash
            return re.sub(r"[^A-Za-z0-9_. :/\\-]", "_", name)

        # بناء قاموس مقاييس مجمعة (المتوسط عبر المرضى) لرفعها إلى MLflow
        metrics_dict = {}
        if isinstance(df_eval, pd.DataFrame):
            metric_cols = [c for c in df_eval.columns if c.endswith(f"@{k_eval}")]
            for c in metric_cols:
                series_numeric = pd.to_numeric(df_eval[c], errors="coerce")
                mean_val = float(series_numeric.mean()) if not series_numeric.empty else float("nan")
                safe_key = _sanitize_metric_name(f"mean_{c}")  # sanitize metric name for MLflow
                metrics_dict[safe_key] = mean_val
            logger.info(f"[{log_id}] Evaluation metrics (means): {metrics_dict}")
        if coverage_report is not None:
            logger.info(f"[{log_id}] Evaluation coverage report: {coverage_report}")

        # --------------------------
        # Build evaluation candidate set with a higher cap (eval-only)
        # --------------------------
        # Reuse df_eval_candidates if already built; otherwise build now from config.evaluation.eval_cap
        if "df_eval_candidates" not in locals():
            eval_cap = int(
                (config.get("evaluation", {}) or {}).get("eval_cap")
                or (config.get("evaluation", {}).get("loco_family", {}) or {}).get("cap", 10)
                or 10
            )
            try:
                df_eval_candidates = cap_topk_per_patient(
                    df_all.copy(),
                    k=eval_cap,
                    patient_col=patient_col,
                    feature_col=feature_col,
                    score_col="score_cf",
                )
                logger.info(f"[{log_id}] Built df_eval_candidates with cap={eval_cap}; shape={df_eval_candidates.shape}")
            except Exception as _ex:
                logger.warning(f"[{log_id}] Failed to build df_eval_candidates (cap={eval_cap}); falling back to df_all. Reason: {_ex}")
                df_eval_candidates = df_all
        else:
            try:
                # Ensure candidate frame is well-formed and deduplicated
                df_eval_candidates = df_eval_candidates.drop_duplicates([patient_col, feature_col])
                logger.info(f"[{log_id}] Using pre-built df_eval_candidates: shape={df_eval_candidates.shape}")
            except Exception as _ex:
                logger.warning(f"[{log_id}] Pre-built df_eval_candidates invalid; falling back to df_all: {_ex}")
                df_eval_candidates = df_all
        # Optional: LOCO evaluation (Leave-One-Context-Out) if available
        # Ensure evaluate_recommendations_loco is defined even if import fails (provide a no-op stub).
        try:
            from pipeline.helpers import evaluate_recommendations_loco  # real implementation
        except ImportError:
            logger.info(f"[{log_id}] LOCO evaluator not available; using no-op stub.")
            def evaluate_recommendations_loco(*_args, **_kwargs):
                """
                No-op LOCO evaluator stub used when `pipeline.helpers.evaluate_recommendations_loco` is unavailable.
                """
                logger.info(f"[{log_id}] LOCO stub invoked (no-op); returning empty DataFrame.")
                return pd.DataFrame()

        # Run LOCO (real or stub), isolated from import errors
        try:
            if df_ctx is not None:
                df_loco = evaluate_recommendations_loco(
                    df_eval_candidates, df_ctx,
                    patient_col=patient_col, feature_col=feature_col, true_col="true_response",
                    k=k_eval, eval_logger=logger, log_id=log_id
                )
                loco_path = "outputs/CF/df_cf_recommendations_eval_loco.csv"
                if isinstance(df_loco, pd.DataFrame) and not df_loco.empty:
                    df_loco.to_csv(loco_path, index=False)
                    means_str = ", ".join(
                        f"{c}={pd.to_numeric(df_loco[c], errors='coerce').mean():.4f}"
                        for c in df_loco.columns if c.endswith(f"@{k_eval}")
                    )
                    logger.info(f"[{log_id}] LOCO metrics saved to {loco_path}; means: {means_str}")
        except Exception as _ex:
            logger.warning(f"[{log_id}] LOCO evaluation failed: {_ex}")

        # --------------------------
        # LOCO-Family evaluation (Leave-One-Family-Out) with robust diagnostics
        # --------------------------
        lf_cfg = (config.get("evaluation", {}) or {}).get("loco_family", {}) or {}
        lf_enabled = bool(lf_cfg.get("enabled", True))
        family_col = lf_cfg.get("family_col", "feature_id_binned")
        exclude_seen_families = bool(lf_cfg.get("exclude_seen_families", True))
        exclude_synonym_families = bool(lf_cfg.get("exclude_synonym_families", False))
        syn_map = lf_cfg.get("synonym_families", {}) or {}
        loco_family_path = "outputs/CF/df_cf_recommendations_eval_loco_family.csv"

        logger.info(
            f"[{log_id}] LOCO-Family config: enabled={lf_enabled}, family_col={family_col}, "
            f"exclude_seen_families={exclude_seen_families}, exclude_synonym_families={exclude_synonym_families}, "
            f"syn_map_keys={list(syn_map.keys()) if isinstance(syn_map, dict) else 'N/A'}"
        )

        if lf_enabled and (df_ctx is not None):
            # 0) Ensure family_col exists in df_ctx; if missing, try attaching from df_eval_candidates
            if family_col not in df_ctx.columns:
                logger.warning(
                    f"[{log_id}] df_ctx is missing '{family_col}'. Attempting to attach it from df_eval_candidates...")
                try:
                    _fam_map = (
                        df_eval_candidates[[feature_col, family_col]]
                        .dropna(subset=[feature_col, family_col])
                        .drop_duplicates()
                        .astype({feature_col: str})
                    )
                    before_cols = set(df_ctx.columns)
                    df_ctx = (
                        df_ctx.astype({feature_col: str})
                        .merge(_fam_map, on=feature_col, how="left")
                    )
                    added = set(df_ctx.columns) - before_cols
                    if family_col in df_ctx.columns:
                        logger.info(f"[{log_id}] Attached '{family_col}' to df_ctx via merge; added columns: {added}")
                    else:
                        logger.warning(
                            f"[{log_id}] Could not attach '{family_col}' — merge did not produce the column.")
                except Exception as _ex:
                    logger.warning(f"[{log_id}] Could not attach '{family_col}' to df_ctx: {_ex}")

            # --- Early guard: distribution of positive families per patient (from df_ctx) ---
            try:
                if isinstance(df_ctx, pd.DataFrame) and all(c in df_ctx.columns for c in [patient_col, feature_col, "true_response"]):
                    fam_col = family_col  # from config above
                    # If family_col still missing after the attach attempt, warn and continue
                    if fam_col in df_ctx.columns:
                        _needed_cols = [patient_col, feature_col, fam_col, "true_response"]
                        # Guard against None and ensure a real DataFrame slice
                        if isinstance(df_ctx, pd.DataFrame):
                            _ctx = df_ctx.loc[:, _needed_cols].copy()
                        else:
                            _ctx = pd.DataFrame(columns=_needed_cols)
                        _ctx["true_response"] = pd.to_numeric(_ctx["true_response"], errors="coerce").fillna(0).astype(int)
                        _pos = _ctx[_ctx["true_response"] == 1].dropna(subset=[patient_col, fam_col])
                        _fam_counts = (
                            _pos.drop_duplicates([patient_col, fam_col])
                                .groupby(patient_col, dropna=False)[fam_col]
                                .count()
                        )
                        _n_patients_posfam = int((_fam_counts > 0).sum())
                        _min_f = int(_fam_counts.min()) if len(_fam_counts) else 0
                        _max_f = int(_fam_counts.max()) if len(_fam_counts) else 0
                        _avg_f = float(_fam_counts.mean()) if len(_fam_counts) else 0.0
                        logger.info(
                            f"[{log_id}] LOCO-Family guard — positive families per patient: "
                            f"patients_with_pos_families={_n_patients_posfam}, "
                            f"min={_min_f}, max={_max_f}, avg={_avg_f:.2f}"
                        )
                        if _n_patients_posfam == 0:
                            logger.warning(f"[{log_id}] LOCO-Family: no patients with positive families in df_ctx; result may be empty.")
                    else:
                        logger.warning(f"[{log_id}] LOCO-Family guard: df_ctx still missing '{fam_col}' — evaluation may be empty.")
            except Exception as _ex:
                logger.warning(f"[{log_id}] LOCO-Family guard failed: {_ex}")

            # 1) Import real implementation with a safe stub fallback
            try:
                from pipeline.helpers import evaluate_recommendations_loco_family  # real impl
                logger.info(f"[{log_id}] Imported evaluate_recommendations_loco_family successfully.")
            except ImportError:
                logger.warning(f"[{log_id}] Could not import evaluate_recommendations_loco_family; using no-op stub.")

                def evaluate_recommendations_loco_family(*_a, **_kw):
                    logger.info(f"[{log_id}] LOCO-Family stub invoked (no-op); returning empty DataFrame.")
                    return pd.DataFrame()

            # 2) Call with extended kwargs; if helper doesn't support them, retry with minimal signature
            try:
                loco_family_kwargs = dict(
                    patient_col=patient_col,
                    feature_col=feature_col,
                    true_col="true_response",
                    family_col=family_col,
                    k=k_eval,
                    eval_logger=logger,
                    log_id=log_id,
                    exclude_seen_families=exclude_seen_families,
                    exclude_synonym_families=exclude_synonym_families,
                    synonym_families=syn_map,
                    use_eval_score_calibration=True,
                )
                df_loco_family = evaluate_recommendations_loco_family(df_eval_candidates, df_ctx, **loco_family_kwargs)
            except TypeError:
                logger.info(
                    f"[{log_id}] LOCO-Family helper does not accept extended kwargs; retrying with minimal signature.")
                df_loco_family = evaluate_recommendations_loco_family(
                    df_eval_candidates, df_ctx,
                    patient_col=patient_col, feature_col=feature_col, true_col="true_response",
                    family_col=family_col, k=k_eval, eval_logger=logger, log_id=log_id
                )
            except Exception as _ex:
                logger.warning(f"[{log_id}] LOCO-Family evaluation raised an exception: {_ex}")
                df_loco_family = pd.DataFrame()

            # 3) Always emit diagnostics and save CSV if not empty
            if isinstance(df_loco_family, pd.DataFrame):
                logger.info(
                    f"[{log_id}] LOCO-Family result shape: {df_loco_family.shape}; columns={df_loco_family.columns.tolist()}")
                if not df_loco_family.empty:
                    try:
                        df_loco_family.to_csv(loco_family_path, index=False)
                        means_str_family = ", ".join(
                            f"{c}={pd.to_numeric(df_loco_family[c], errors='coerce').mean():.4f}"
                            for c in df_loco_family.columns if c.endswith(f"@{k_eval}")
                        )
                        logger.info(
                            f"[{log_id}] LOCO-Family metrics saved to {loco_family_path}; means: {means_str_family}")
                        # NOTE: Do not print metrics here to avoid duplicate console output.
                        # Final reporting section will print ALL eval files in one place.
                    except Exception as _ex:
                        logger.warning(f"[{log_id}] Failed to save LOCO-Family CSV: {_ex}")
                else:
                    logger.warning(
                        f"[{log_id}] LOCO-Family produced empty DataFrame — CSV not written. "
                        f"Check that df_ctx contains '{family_col}' and that patients have positive families."
                    )
            else:
                logger.warning(f"[{log_id}] LOCO-Family returned non-DataFrame object; skipping save/print.")
        else:
            if not lf_enabled:
                logger.info(f"[{log_id}] LOCO-Family disabled by config (evaluation.loco_family.enabled=false).")
            if df_ctx is None:
                logger.info(f"[{log_id}] LOCO-Family skipped: df_ctx is None (no external ground-truth).")

        # Log to MLflow if we have any aggregate metrics
        # --- Optional MLflow logging (config-gated) ---
        mlflow_cfg = (config.get("mlflow", {}) or {})
        mlflow_enabled = bool(mlflow_cfg.get("enabled", False))
        if mlflow_enabled and metrics_dict:
            try:
                log_experiment(
                    config=mlflow_cfg,  # مرر إعدادات mlflow نفسها
                    metrics=metrics_dict,
                    artifacts=[config["hybrid_paths"]["cf_recommendations"], eval_save_path],
                    run_name=mlflow_cfg.get("run_name", f"cf_pipeline_{log_id}"),
                    tags={"pipeline": "cf", "log_id": log_id}
                )
                logger.info(f"[{log_id}] MLflow logging enabled; metrics and artifacts logged.")
            except (ValueError, TypeError, OSError, RuntimeError) as _ex:
                logger.warning(f"[{log_id}] Could not log to MLflow (disabled or misconfigured): {_ex}")
        else:
            logger.info(f"[{log_id}] MLflow logging is disabled by config or no metrics to log.")

        # =========================
        # (FINAL) Human-friendly reporting to STDOUT and logs
        # =========================
        try:
            recs_path = "outputs/CF/df_cf_recommendations.csv"
            _report_recs_summary(recs_path, patient_col=patient_col, feature_col=feature_col, logger=logger, log_id=log_id)

            # Unified reporting: print all available eval files in order: standard, LOCO, LOCO-Family
            loco_family_path = "outputs/CF/df_cf_recommendations_eval_loco_family.csv"
            loco_path = "outputs/CF/df_cf_recommendations_eval_loco.csv"
            std_eval_path = "outputs/CF/df_cf_recommendations_eval.csv"

            files_to_report = [
                ("📊 تقارير التقييم القياسي", std_eval_path),
                ("📊 تقارير LOCO (Leave-One-Context-Out)", loco_path),
                ("📊 تقارير LOCO-Family (Leave-One-Family-Out)", loco_family_path),
            ]

            any_found = False
            for title, path in files_to_report:
                if os.path.exists(path):
                    any_found = True
                    try:
                        _tmp_df = pd.read_csv(path)
                        print(f"\n{title} من {path}:")
                        if _tmp_df.empty:
                            print("⚠️ الملف موجود لكنه فارغ — لا توجد صفوف لتجميعها.")
                            logger.warning(f"[{log_id}] Eval CSV exists but is empty: {path}")
                        else:
                            _report_eval_metrics(path, k_eval, logger, log_id)
                    except Exception as _ex:
                        print(f"⚠️ تعذّر قراءة ملف التقييم: {path} — {_ex}")
                        logger.warning(f"[{log_id}] Could not read eval CSV at final reporting ({path}): {_ex}")
            if not any_found:
                print("\n⚠️ لم يتم العثور على ملفات تقييم لحساب المقاييس المجمعة.")
                logger.warning(f"[{log_id}] No eval CSVs found to report aggregate metrics.")
        except (OSError, ValueError, TypeError, pd.errors.ParserError) as ex:
            logger.warning(f"[{log_id}] Final reporting failed: {ex}")
    else:
        logger.warning(f"[{log_id}] Skipping evaluation: 'true_response' column not present in df_all and no external df_contextualized available.")


    # Diagnostics: distributions & coverage summaries (after finalize+cap)
    try:
        # Try loading external context to compute truth distributions
        _diag_ctx = None
        try:
            _diag_ctx = pd.read_csv("outputs/tmp/df_contextualized.csv")
        except Exception as _ex:
            logger.info(f"[{log_id}] Diagnostics: could not load df_contextualized (optional): {_ex}")

        # Truth positives per patient from context
        if (_diag_ctx is not None) and {"true_response", patient_col, feature_col}.issubset(set(_diag_ctx.columns)):
            # Explicitly grab a Series and coerce to numeric to avoid static type checker complaints
            col = "true_response"
            _true_series_src = _diag_ctx.filter([col]).iloc[:, 0]  # guaranteed Series even if duplicate col names
            _true_series = pd.to_numeric(_true_series_src, errors="coerce")
            _mask_pos = _true_series.fillna(0).astype(int) == 1
            ctx_pos = _diag_ctx.loc[_mask_pos, [patient_col, feature_col]].drop_duplicates()
            truth_counts = ctx_pos.groupby(patient_col)[feature_col].count()
            _min_t = int(truth_counts.min()) if len(truth_counts) else 0
            _max_t = int(truth_counts.max()) if len(truth_counts) else 0
            _avg_t = float(truth_counts.mean()) if len(truth_counts) else 0.0
            logger.info(f"[{log_id}] Truth positives per patient — min={_min_t}, max={_max_t}, avg={_avg_t:.2f}")

        # Predicted unique items per patient after finalize+cap
        pred_counts = df_all.drop_duplicates([patient_col, feature_col]).groupby(patient_col)[feature_col].count()
        _min_p = int(pred_counts.min() if len(pred_counts) else 0)
        _max_p = int(pred_counts.max() if len(pred_counts) else 0)
        _avg_p = float(pred_counts.mean() if len(pred_counts) else 0.0)
        logger.info(f"[{log_id}] Predicted unique per patient — min={_min_p}, max={_max_p}, avg={_avg_p:.2f}")

        # Coverage at K (use k_cap here; will also report at k_eval later)
        _n_cov, _pct_cov, _min_r, _max_r, _avg_r = coverage_ge_k(df_all, k=k_cap, patient_col=patient_col, feature_col=feature_col)
        logger.info(f"[{log_id}] Coverage ≥{k_cap}: patients={_n_cov}, pct={_pct_cov:.2%}, min={_min_r}, max={_max_r}, avg={_avg_r:.2f}")
    except Exception as _ex:
        logger.warning(f"[{log_id}] Diagnostics summary failed: {_ex}")


if __name__ == "__main__":
    main()
