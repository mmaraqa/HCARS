
from __future__ import annotations

from pandas.api.types import CategoricalDtype
from typing import Any, Dict, List, Optional, Tuple, Set, Mapping, Union, cast
from sklearn.preprocessing import OneHotEncoder, StandardScaler, LabelEncoder
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import jaccard_score
from scipy.spatial.distance import hamming
import sklearn
from packaging.version import Version


from sklearn.neighbors import NearestNeighbors

# --- Similarity→Probability (logistic) and Isotonic calibrator utilities ---
import math

def prob_from_similarity(sim: float, cfg: Optional[Dict[str, Any]] = None) -> float:
    """
    Map a [0,1] similarity to a pseudo-probability using a configurable transform.
    Supports both `sim_to_prob.kind` and `sim_to_prob.type` ("logistic" or "linear").
    Defaults: logistic(slope=10.0, midpoint=0.78).
    """
    # Read config block safely
    stp: Dict[str, Any] = {}
    if isinstance(cfg, dict):
        stp = (cfg.get("sim_to_prob") or {})

    # Accept both keys: kind/type
    kind = str(stp.get("kind", stp.get("type", "logistic"))).lower()

    # Coerce and clamp input similarity
    try:
        x = 0.0 if sim is None else float(sim)
    except (TypeError, ValueError):
        x = 0.0
    if x < 0.0:
        x = 0.0
    if x > 1.0:
        x = 1.0

    # Linear passthrough
    if kind == "linear":
        return x

    # Logistic parameters with safe fallbacks
    try:
        slope = float(stp.get("slope", 10.0))
    except (TypeError, ValueError):
        slope = 10.0
    try:
        mid = float(stp.get("midpoint", 0.78))
    except (TypeError, ValueError):
        mid = 0.78

    try:
        return 1.0 / (1.0 + math.exp(-slope * (x - mid)))
    except (OverflowError, ValueError):
        # Numerical fallback: return the clipped similarity
        return x

import os
import pickle
import numpy as _np

class _IsotonicCalibrator:
    def __init__(self) -> None:
        self.model = None

    def fit(self, scores: np.ndarray, y_true: np.ndarray) -> "_IsotonicCalibrator":
        from sklearn.isotonic import IsotonicRegression
        s = np.asarray(scores, dtype=float)
        y = np.asarray(y_true, dtype=float)
        s = np.clip(s, 0.0, 1.0)
        y = np.clip(y, 0.0, 1.0)
        # Guard against degenerate/collapsed distributions
        if not np.isfinite(s).all() or not np.isfinite(y).all():
            raise ValueError("Non-finite values encountered in scores/labels.")
        if (float(np.max(s)) - float(np.min(s))) <= 1e-12:
            raise ValueError("Collapsed score distribution.")
        self.model = IsotonicRegression(y_min=0.0, y_max=1.0, increasing=True, out_of_bounds="clip")
        self.model.fit(s, y)
        return self

    def transform(self, scores: np.ndarray) -> np.ndarray:
        if self.model is None:
            return np.asarray(scores, dtype=float)
        arr = np.asarray(scores, dtype=float)
        arr = np.clip(arr, 0.0, 1.0)
        return self.model.transform(arr)

    def save(self, path: str) -> None:
        d = os.path.dirname(path) or "."
        os.makedirs(d, exist_ok=True)
        with open(path, "wb") as f:
            # Cast to Any to satisfy static type checkers expecting SupportsWrite[bytes]
            pickle.dump(self, cast(Any, f), protocol=pickle.HIGHEST_PROTOCOL)

    @staticmethod
    def load(path: str):
        if not isinstance(path, str) or not path or not os.path.exists(path):
            return None
        with open(path, "rb") as r:
            # Cast to Any to satisfy static type checkers expecting SupportsRead[bytes]
            obj = pickle.load(cast(Any, r))
        return obj if isinstance(obj, _IsotonicCalibrator) else None

import pandas as pd

def fit_and_save_isotonic(df: pd.DataFrame, score_col: str, true_col: str, out_path: str, logger=None) -> bool:
    if not isinstance(df, pd.DataFrame) or score_col not in df.columns or true_col not in df.columns:
        if logger is not None and hasattr(logger, "warning"):
            logger.warning("[ISO] invalid frame/cols for isotonic fit")
        return False

    s = pd.to_numeric(df[score_col], errors="coerce").astype(float).fillna(0.0).clip(0.0, 1.0).values
    y = pd.to_numeric(df[true_col], errors="coerce").astype(float).fillna(0.0).clip(0.0, 1.0).values

    # Skip if collapsed
    try:
        if (float(np.max(s)) - float(np.min(s))) <= 1e-12:
            if logger is not None and hasattr(logger, "warning"):
                logger.warning("[ISO] skipped: collapsed score distribution")
            return False
    except (TypeError, ValueError):
        return False

    try:
        cal = _IsotonicCalibrator().fit(s, y)
        cal.save(out_path)
        if logger is not None and hasattr(logger, "info"):
            logger.info("[ISO] saved calibrator → %s", out_path)
        return True
    except (OSError, TypeError, ValueError) as e:
        if logger is not None and hasattr(logger, "warning"):
            logger.warning("[ISO] fit/save failed: %s", e)
        return False

def apply_isotonic_if_available(df: pd.DataFrame, score_col: str, model_path: str, logger_obj=None) -> pd.DataFrame:
    if not isinstance(df, pd.DataFrame) or score_col not in df.columns:
        return df
    try:
        cal = _IsotonicCalibrator.load(model_path)
    except (OSError, TypeError, ValueError) as e:
        if logger_obj is not None and hasattr(logger_obj, "debug"):
            logger_obj.debug("[ISO] load failed: %s", e)
        return df

    if cal is None or getattr(cal, "model", None) is None:
        if logger_obj is not None and hasattr(logger_obj, "debug"):
            logger_obj.debug("[ISO] model not found/empty at %s", model_path)
        return df

    s = pd.to_numeric(df[score_col], errors="coerce").astype(float).fillna(0.0).clip(0.0, 1.0).values
    try:
        if (float(np.max(s)) - float(np.min(s))) <= 1e-12:
            return df
    except (TypeError, ValueError):
        return df

    try:
        out = df.copy()
        out[score_col] = cal.transform(s)
        return out
    except (TypeError, ValueError) as e:
        if logger_obj is not None and hasattr(logger_obj, "warning"):
            logger_obj.warning("[ISO] transform failed: %s", e)
        return df

# Utility: Robust float conversion for safe aggregation of numeric-like objects
def _safe_float(val, default: float = 0.0) -> float:
    """
    Robust float conversion:
    - Handles None/NaN
    - Handles pandas Series/Index/ndarray by taking a numeric mean when possible
    - Falls back to `default` when conversion is impossible
    """
    try:
        if isinstance(val, (int, float)):
            if val is None:
                return default
            try:
                # handle NaN explicitly
                import math
                if isinstance(val, float) and math.isnan(val):
                    return default
            except (ValueError, TypeError):  # localized guard, not expected to fail
                pass
            return float(val)

        if isinstance(val, (_pd.Series, _pd.Index)):
            if val.empty:
                return default
            v = _pd.to_numeric(val, errors="coerce")
            if v.notna().any():
                return float(v.mean())
            return default

        if isinstance(val, _np.ndarray):
            if val.size == 0:
                return default
            try:
                v = val.astype(float)
                m = _np.nanmean(v)
                return float(m) if not _np.isnan(m) else default
            except (ValueError, TypeError):
                return default

        if val is None:
            return default
        return float(val)
    except (ValueError, TypeError, OverflowError):
        return default

# Helper: Fill NaN with 'unknown' safely, handling Categorical columns robustly
def _fill_unknown_safe(df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    """
    يملأ NaN بـ 'unknown' بشكل آمن حتى لو العمود Categorical.
    - Categorical: أضف الفئة 'unknown' ثم املأ، وبعدها حوّل لنص لتوحيد المقارنة.
    - غير ذلك: املأ ثم حوّل لنص.
    """
    out = df.copy()
    for c in cols:
        if c not in out.columns:
            continue
        s = out[c]
        try:
            if isinstance(s.dtype, CategoricalDtype):
                if "unknown" not in list(s.cat.categories):
                    s = s.cat.add_categories(["unknown"])
                s = s.fillna("unknown")
                out[c] = s.astype(str)
            else:
                out[c] = s.fillna("unknown").astype(str)
        except (TypeError, ValueError, AttributeError):
            out[c] = s.astype(str).replace({"nan": "unknown"}).fillna("unknown")
    return out

# --- Module-level allowed feature set (avoid per-call try/except) ---
_FEATURE_ID_ALLOWED = {"manual_review"}  # safe default
try:
    from utils.constants import FEATURE_ID_ALLOWED as _FEATURE_ID_ALLOWED  # noqa: F401
except (ImportError, ModuleNotFoundError, AttributeError):
    # keep the safe default; do not fail import
    pass

# --- Helper to extract similarity params from config (shared by recommend_by_similarity and fallback_knn_recommendation) ---
def _extract_sim_params(cfg, k_fallback: int, sim_fallback: float) -> Tuple[int, float]:
    """
    Extract k and min_similarity values from config if present.
    Supports nested under model_settings.cbf.similarity or top-level overrides.
    """
    try:
        d = (cfg or {}).get("model_settings", {}).get("cbf", {}).get("similarity", {})
        k_val = int(d.get("k", k_fallback))
        ms_val = float(d.get("min_similarity", sim_fallback))
    except (AttributeError, KeyError, TypeError, ValueError):
        k_val, ms_val = k_fallback, sim_fallback
    # Allow top-level overrides if present
    k_val = int((cfg or {}).get("cbf_k", k_val))
    ms_val = float((cfg or {}).get("cbf_min_similarity", ms_val))
    return k_val, ms_val


def _sanitize_recommendation(val: object, allowed_list: Optional[Set[str]] = None) -> str:
    """
    Ensure recommendation (medical code) is a valid string from the allowed set; otherwise return 'manual_review'.
    Always returns a string and safely unwraps numpy arrays / lists / tuples.
    Rules:
      - np.ndarray/list/tuple: if single non-null element -> use it, else 'manual_review'
      - None/NaN/numeric-only -> 'manual_review'
      - if allowed_list provided (or module-level), value must be within it
    """
    # Use module-level whitelist unless explicitly overridden
    if allowed_list is None:
        allowed_list = _FEATURE_ID_ALLOWED

    # Unwrap numpy arrays first to avoid element-wise truthiness surprises
    if isinstance(val, np.ndarray):
        try:
            val = val.tolist()
        except (ValueError, TypeError):
            return "manual_review"

    # Unwrap sequences (list/tuple) safely, dropping None/NaN
    if isinstance(val, (list, tuple)):
        seq = []
        for v in val:
            if v is None:
                continue
            if isinstance(v, float) and pd.isna(v):
                continue
            seq.append(v)
        if len(seq) == 1:
            val = seq[0]
        else:
            return "manual_review"

    # Reject None/NaN and raw numeric values
    if val is None:
        return "manual_review"
    if isinstance(val, float) and pd.isna(val):
        return "manual_review"
    if isinstance(val, (int, float)):
        return "manual_review"

    # Convert to string; reject empty or numeric-only tokens
    s = str(val).strip()
    if not s or s.isdigit():
        return "manual_review"

    # Allow only known medical codes when a whitelist is present
    try:
        is_allowed = (allowed_list is None) or (s in allowed_list)
    except TypeError:
        # If allowed_list is an unexpected type, fall back to safe behavior
        is_allowed = False
    return s if is_allowed else "manual_review"


# Lightweight clinical guardrail (inserted after _sanitize_recommendation)
def _clinical_flag(core_context: dict, feature_id: str, secondary_context: Optional[dict] = None) -> Optional[str]:
    """
    Lightweight clinical guardrail.
    Returns a short reason string if the (context, feature) should be flagged for manual review; otherwise None.

    Example temporary policy (can be moved to config/constants later):
    - If risk_level == "high" AND exang_cat == "exercise_angina", flag beta_blocker.
    """
    try:
        sec = secondary_context or {}
        risk = normalize_context_value(core_context.get("risk_level", None))
        exang = normalize_context_value(sec.get("exang_cat", None))
        feat = normalize_context_value(feature_id)
        # Policy example: flag beta_blocker in exercise-induced angina at high risk
        if risk == "high" and exang == "exercise_angina" and feat == "beta_blocker":
            return "Clinically flagged: beta_blocker with exercise_angina at high risk"
    except (KeyError, TypeError, ValueError, AttributeError):
        # Guardrail must never break the pipeline; silently allow if anything unexpected happens.
        return None
    return None

def resolve_context_key(context_key: str, dictionary: dict) -> Optional[str]:
    """
    البحث عن مفتاح سياقي في القاموس:
      - أولاً: يبحث عن التطابق الحرفي (Exact Match).
      - إذا لم يوجد: يبحث عن أقرب تطابق ممكن (Fuzzy Match) يختلف في عنصر واحد فقط (أي يختلف حرفياً في جزء واحد فقط).
      - إذا لم يوجد أي تطابق: يعيد None.

    Parameters
    ----------
    context_key : str
        المفتاح السياقي المطلوب البحث عنه (مثال: "normal_high_adult").
    dictionary : dict
        القاموس الذي يحتوي على المفاتيح السياقية.

    Returns
    -------
    Optional[str]
        المفتاح المطابق من القاموس (حرفي أو غامض)، أو None إذا لم يوجد أي تطابق.
    """
    # Exact match
    if context_key in dictionary:
        return context_key
    # Fuzzy: اختلاف عنصر واحد فقط
    key_parts = context_key.split("_")
    for dict_key in dictionary.keys():
        dict_parts = dict_key.split("_")
        if len(dict_parts) != len(key_parts):
            continue
        diff_count = sum(1 for a, b in zip(key_parts, dict_parts) if a != b)
        if diff_count == 1:
            return dict_key
    return None

# يجب تمرير جميع القيم السياقية عبر هذه الدالة قبل استخدامها كمفتاح توصية أو للمقارنة.
def normalize_context_value(val):
    """
    Normalize a contextual value for consistent comparison and key construction.
    Always returns a string; missing or None values are mapped to "unknown".
    All context columns should be passed through this function before being used
    as recommendation keys or for comparison.
    """
    if val is None or (isinstance(val, float) and pd.isna(val)) or (hasattr(pd, "isna") and pd.isna(val)):
        return "unknown"
    sval = str(val).strip().lower().replace(" ", "_")
    if sval == "" or sval == "nan":
        return "unknown"
    return sval

# CONTEXTUAL_COLUMNS = ["bp_category", "chol_category", "age_group"]  # Deprecated, use CONTEXT_COLUMNS
# لم يعد هذا المتغير مستخدمًا. جميع الأعمدة السياقية تُؤخذ ديناميكيًا من config فقط.


## جميع الأعمدة السياقية (context columns) تُؤخذ فقط من config أو من وسيط صريح، ولا يُسمح بأي قائمة ثابتة
def encode_context_features_cbf(
    df: pd.DataFrame,
    context_columns: Optional[List[str]] = None,
    encoding_type: str = 'onehot',
    return_encoders: bool = False,
    logger: Optional[object] = None,
    config: Optional[dict] = None
) -> Union[pd.DataFrame, Tuple[pd.DataFrame, Dict[str, Union[OneHotEncoder, StandardScaler, LabelEncoder]]]]:
    """
    Encode contextual feature columns into numerical vectors suitable for CBF algorithms like KNN or ML models,
    while preserving the original columns.

    Supports logging of key steps via a logger (if provided), otherwise falls back to print for important events.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame containing the contextual features.
    context_columns : List[str]
        List of column names representing contextual features to encode.
    encoding_type : str, optional
        Encoding method to use:
        - 'onehot' for categorical features using OneHotEncoder,
        - 'standard' for numerical features using StandardScaler,
        - 'label' for categorical features using LabelEncoder.
        Default is 'onehot'.
    return_encoders : bool, optional
        Whether to return the fitted encoders/scalers along with the encoded DataFrame. Default is False.
    logger : Optional[object], optional
        Logger for info/warning messages. Default is None (falls back to print).
    config : Optional[dict], optional
        إعدادات النظام المحمّلة من ملف config.yaml (إذا لم تُمرر، يتم تحميلها تلقائيًا).

    Returns
    -------
    pd.DataFrame or Tuple[pd.DataFrame, Dict[str, Union[OneHotEncoder, StandardScaler, LabelEncoder]]]
        If return_encoders is False, returns a DataFrame with original columns plus new encoded columns added.
        If return_encoders is True, returns a tuple of (DataFrame, encoders_dict) where encoders_dict maps column names to fitted encoder/scaler objects.
    """
    if logger is not None and hasattr(logger, "info"):
        logger.info("[encode_context_features_cbf] Starting encoding of context features.")
    else:
        print("[encode_context_features_cbf] Starting encoding of context features.")
    assert isinstance(df, pd.DataFrame), "df must be a pandas DataFrame"
    if config is None:
        config = load_config()
    if context_columns is None:
        context_columns = config.get("context_columns", [])
    assert isinstance(context_columns, list) and all(isinstance(c, str) for c in context_columns), "context_columns must be a list of strings"
    assert all(c in df.columns for c in context_columns), \
        f"Some contextual columns are missing: {set(context_columns) - set(df.columns)}"
    # Normalize context columns and log unique values
    # لا يتم حذف أو إسقاط أي صف مكرر أو تضارب، جميع الحالات محفوظة للسلامة السريرية.
    # Normalize all context columns before any comparison or key generation
    for col in context_columns:
        df[col] = df[col].apply(normalize_context_value)
        msg = f"[helperscbf] Normalized unique values for '{col}': {df[col].unique()}"
        if logger is not None and hasattr(logger, "info"):
            logger.info(msg)
        else:
            print(msg)
    if df[context_columns].isnull().any(axis=1).any():
        warn_msg = "[helperscbf] ⚠️ WARNING: Missing values detected in contextual columns!"
        if logger is not None and hasattr(logger, "warning"):
            logger.warning(warn_msg)
        else:
            print(warn_msg)
    encoders_dict: Dict[str, Union[OneHotEncoder, StandardScaler, LabelEncoder]] = {}
    df_encoded = df.copy()
    for col in context_columns:
        # All normalization already applied above. No duplicate row dropping or conflict dropping here.
        # لا يتم حذف أو إسقاط أي صف مكرر أو تضارب، جميع الحالات محفوظة للسلامة السريرية.
        if df[col].dtype == 'object' or df[col].dtype.name == 'category':
            if encoding_type == 'onehot':
                if Version(sklearn.__version__) >= Version("1.2"):
                    encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
                else:
                    encoder = OneHotEncoder(handle_unknown='ignore')
                encoded = encoder.fit_transform(df[[col]])
                # Ensure dense array even on older scikit-learn where OneHotEncoder returns sparse by default
                if hasattr(encoded, "toarray"):
                    encoded = encoded.toarray()
                cols = [f"{col}_{cat}" for cat in encoder.categories_[0]]
                encoded_df = pd.DataFrame(encoded, columns=cols, index=df.index)
                df_encoded = pd.concat([df_encoded, encoded_df], axis=1)
                encoders_dict[col] = encoder
                msg = f"[encode_context_features_cbf] Encoded '{col}' with OneHotEncoder. Categories: {list(encoder.categories_[0])}"
                if logger is not None and hasattr(logger, "info"):
                    logger.info(msg)
                else:
                    print(msg)
            elif encoding_type == 'label':
                encoder = LabelEncoder()
                encoded = encoder.fit_transform(df[col].astype(str))
                encoded_df = pd.DataFrame(encoded, columns=[f"{col}_enc"], index=df.index)
                df_encoded = pd.concat([df_encoded, encoded_df], axis=1)
                encoders_dict[col] = encoder
                msg = f"[encode_context_features_cbf] Encoded '{col}' with LabelEncoder. Classes: {list(encoder.classes_)}"
                if logger is not None and hasattr(logger, "info"):
                    logger.info(msg)
                else:
                    print(msg)
            else:
                raise ValueError(f"Unsupported encoding_type '{encoding_type}' for categorical column '{col}'.")
        else:
            if encoding_type == 'standard':
                scaler = StandardScaler()
                scaled = scaler.fit_transform(df[[col]])
                encoded_df = pd.DataFrame(scaled, columns=[f"{col}_scaled"], index=df.index)
                df_encoded = pd.concat([df_encoded, encoded_df], axis=1)
                encoders_dict[col] = scaler
                msg = f"[encode_context_features_cbf] Scaled '{col}' with StandardScaler."
                if logger is not None and hasattr(logger, "info"):
                    logger.info(msg)
                else:
                    print(msg)
            else:
                continue
    if logger is not None and hasattr(logger, "info"):
        logger.info("[encode_context_features_cbf] Encoding complete.")
    else:
        print("[encode_context_features_cbf] Encoding complete.")
    # Note: No duplicate or conflict rows are dropped; all clinical cases are preserved for medical and analytical integrity.
    # ملاحظة: لا يتم إسقاط أي صف مكرر أو متضارب، جميع الحالات محفوظة للأمانة الطبية والتحليلية.
    if return_encoders:
        return df_encoded, encoders_dict
    else:
        return df_encoded


## جميع الأعمدة السياقية (context columns) تُؤخذ فقط من config أو من وسيط صريح، ولا يُسمح بأي قائمة ثابتة
def aggregate_contextual_groupings(
    df: pd.DataFrame,
    context_columns: Optional[List[str]] = None,
    min_freq: int = 1,
    aggregate_label: str = 'Other',
    logger: Optional[object] = None,
    config: Optional[dict] = None
) -> pd.DataFrame:
    """
    Aggregate rare or infrequent contextual combinations into a single group to reduce sparsity.
    ⚠️ NOTE: Default (min_freq=1) now preserves all context combinations (no rare group aggregation) to suit medical analysis needs.

    Supports logging of key steps via a logger (if provided), otherwise falls back to print for important events.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame containing the contextual features.
    context_columns : List[str]
        List of columns representing contextual features to group.
    min_freq : int, optional
        Minimal count threshold below which context combinations are aggregated. Default is 1 (no aggregation).
    aggregate_label : str, optional
        Label to assign to aggregated rare groups. Default is 'Other'.
    logger : Optional[object], optional
        Logger for info/warning messages. Default is None (falls back to print).
    config : Optional[dict], optional
        إعدادات النظام المحمّلة من ملف config.yaml (إذا لم تُمرر، يتم تحميلها تلقائيًا).

    Returns
    -------
    pd.DataFrame
        DataFrame with an additional column 'context_group' representing aggregated context groups.
    """
    if logger is not None and hasattr(logger, "info"):
        logger.info("[aggregate_contextual_groupings] Starting aggregation of contextual groupings.")
    else:
        print("[aggregate_contextual_groupings] Starting aggregation of contextual groupings.")
    assert isinstance(df, pd.DataFrame), "df must be a pandas DataFrame"
    if config is None:
        config = load_config()
    if context_columns is None:
        context_columns = config.get("context_columns", [])
    assert isinstance(context_columns, list) and all(isinstance(c, str) for c in context_columns), "context_columns must be a list of strings"
    assert all(c in df.columns for c in context_columns), \
        f"Some contextual columns are missing: {set(context_columns) - set(df.columns)}"
    # لا يتم حذف أو إسقاط أي صف مكرر أو تضارب، جميع الحالات محفوظة للسلامة السريرية.
    for col in context_columns:
        df[col] = df[col].apply(normalize_context_value)
        msg = f"[helperscbf] Normalized unique values for '{col}': {df[col].unique()}"
        if logger is not None and hasattr(logger, "info"):
            logger.info(msg)
        else:
            print(msg)
    assert isinstance(min_freq, int) and min_freq > 0, "min_freq must be a positive integer"
    if df[context_columns].isnull().any(axis=1).any():
        warn_msg = "[helperscbf] ⚠️ WARNING: Missing values detected in contextual columns during aggregation!"
        if logger is not None and hasattr(logger, "warning"):
            logger.warning(warn_msg)
        else:
            print(warn_msg)
    context_combinations = df[context_columns].agg('_'.join, axis=1)
    counts = context_combinations.value_counts()
    n_original = len(counts)
    # لا يتم حذف أو إسقاط أي صف مكرر أو تضارب، جميع الحالات محفوظة للسلامة السريرية.
    # Only aggregate if min_freq > 1, and do NOT drop any rows, only annotate.
    if min_freq == 1:
        aggregated = context_combinations
        n_aggregated = n_original
        msg = "[aggregate_contextual_groupings] No aggregation performed (min_freq=1): all unique context combinations are preserved."
        if logger is not None and hasattr(logger, "info"):
            logger.info(msg)
        else:
            print(msg)
    else:
        rare_combinations = counts[counts < min_freq].index
        aggregated = context_combinations.apply(lambda x: aggregate_label if x in rare_combinations else x)
        n_aggregated = len(pd.Series(aggregated).unique())
        n_rare = len(rare_combinations)
        if n_rare / max(1, n_original) > 0.2:
            warn_msg = (f"[aggregate_contextual_groupings] ⚠️ WARNING: Aggregation affected {n_rare}/{n_original} "
                        f"({100.0 * n_rare/n_original:.1f}%) of all context combinations! "
                        "Significant information loss may occur.")
            if logger is not None and hasattr(logger, "warning"):
                logger.warning(warn_msg)
            else:
                print(warn_msg)
        msg = f"Aggregated {n_rare} rare context combinations into '{aggregate_label}'."
        if logger is not None and hasattr(logger, "info"):
            logger.info(msg)
        else:
            print(msg)
    df = df.copy()
    df['context_group'] = aggregated
    msg = f"[aggregate_contextual_groupings] Context combinations before aggregation: {n_original}, after: {n_aggregated}"
    if logger is not None and hasattr(logger, "info"):
        logger.info(msg)
    else:
        print(msg)
    # Note: No duplicate or conflict rows are dropped; all clinical cases are preserved for medical and analytical integrity.
    # ملاحظة: لا يتم إسقاط أي صف مكرر أو متضارب، جميع الحالات محفوظة للأمانة الطبية والتحليلية.
    return df


def compute_context_similarity(
    context1: Union[pd.Series, dict],
    context2: Union[pd.Series, dict],
    context_types: Dict[str, str],
    metric: str = 'cosine'
) -> float:
    """
    Compute similarity between two contextual records using specified metric, supporting categorical and numerical features.

    Parameters
    ----------
    context1 : Union[pd.Series, dict]
        First context record with features.
    context2 : Union[pd.Series, dict]
        Second context record with features.
    context_types : Dict[str, str]
        Dictionary mapping feature names to type: 'categorical' or 'numerical'.
    metric : str, optional
        Similarity metric to use: 'cosine', 'jaccard', or 'hamming'. Default is 'cosine'.

    Returns
    -------
    float
        Similarity score between 0 and 1 (1 means identical).
    """
    # Prepare feature lists
    cat_features = [k for k, v in context_types.items() if v == 'categorical']
    num_features = [k for k, v in context_types.items() if v == 'numerical']

    def get_value(context, f):
        # Handle both Series and dict gracefully
        if isinstance(context, pd.Series):
            val = context.get(f, None)
            if isinstance(val, pd.Series):
                return val.iloc[0]
            else:
                return val
        elif isinstance(context, dict):
            return context.get(f, None)
        else:
            return None

    # Categorical vectors: binary 1 if identical, else 0
    cat_vec1 = np.array([
        1 if get_value(context1, f) == get_value(context2, f) else 0
        for f in cat_features
    ])
    cat_vec2 = np.array([
        1 if get_value(context2, f) == get_value(context1, f) else 0
        for f in cat_features
    ])
    # Numerical vectors
    num_vec1 = np.array([
        float(get_value(context1, f)) if get_value(context1, f) is not None else 0.0
        for f in num_features
    ])
    num_vec2 = np.array([
        float(get_value(context2, f)) if get_value(context2, f) is not None else 0.0
        for f in num_features
    ])

    if metric == 'cosine':
        # Combine categorical and numerical vectors
        combined1 = np.concatenate([cat_vec1, num_vec1])
        combined2 = np.concatenate([cat_vec2, num_vec2])
        sim = cosine_similarity([combined1], [combined2])[0, 0]
    elif metric == 'jaccard':
        # Jaccard for categorical only (explicit binary average, safe zero_division)
        sim = jaccard_score(cat_vec1, cat_vec2, average='binary', zero_division=0) if cat_vec1.size > 0 else 0.0
    elif metric == 'hamming':
        # Hamming for categorical only
        if cat_vec1.size > 0:
            dist = hamming(cat_vec1.astype(int), cat_vec2.astype(int))
            sim = 1 - float(dist)
        else:
            sim = 0.0
    else:
        raise ValueError(f"Unsupported similarity metric '{metric}'. Supported: cosine, jaccard, hamming")
    return sim


def get_top_k_similar_contexts(
    target_context: pd.Series,
    contexts_df: pd.DataFrame,
    context_types: Dict[str, str],
    k: int = 5,
    sim_metric: str = 'cosine'
) -> pd.DataFrame:
    """
    Retrieve top-k most similar contexts to a target context from k DataFrame of contexts.

    Parameters
    ----------
    target_context : pd.Series
        Context record to compare against.
    contexts_df : pd.DataFrame
        DataFrame containing multiple context records.
    context_types : Dict[str, str]
        Dictionary mapping feature names to type: 'categorical' or 'numerical'.
    k : int, optional
        Number of top similar contexts to return. Default is 5.
    sim_metric : str, optional
        Similarity metric to use: 'cosine', 'jaccard', or 'hamming'. Default is 'cosine'.

    Returns
    -------
    pd.DataFrame
        DataFrame containing top-k similar context records with similarity scores, sorted descending.
    """
    similarities = []
    for idx, row in contexts_df.iterrows():
        sim = compute_context_similarity(target_context, row, context_types, metric=sim_metric)
        similarities.append((idx, sim))
    similarities.sort(key=lambda x: x[1], reverse=True)
    top_k = similarities[:k]
    indices = [i for i,_ in top_k]
    sims = [s for _,s in top_k]
    result = contexts_df.loc[indices].copy()
    result['similarity'] = sims
    return result.sort_values('similarity', ascending=False)


## جميع الأعمدة السياقية (context columns) تُؤخذ فقط من config أو من وسيط صريح، ولا يُسمح بأي قائمة ثابتة
def check_context_coverage(
    df: pd.DataFrame,
    context_columns: Optional[List[str]] = None,
    logger: Optional[object] = None,
    config: Optional[dict] = None
) -> pd.DataFrame:
    """
    Check coverage of all unique context combinations in the dataset.

    Supports logging of key steps via a logger (if provided), otherwise falls back to print for important events.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame containing the contextual features.
    context_columns : List[str]
        List of columns representing contextual features.
    logger : Optional[object], optional
        Logger for info/warning messages. Default is None (falls back to print).
    config : Optional[dict], optional
        إعدادات النظام المحمّلة من ملف config.yaml (إذا لم تُمرر، يتم تحميلها تلقائيًا).

    Returns
    -------
    pd.DataFrame
        DataFrame with each unique context combination and its occurrence count.
    """
    if logger is not None and hasattr(logger, "info"):
        logger.info("[check_context_coverage] Checking context coverage.")
    else:
        print("[check_context_coverage] Checking context coverage.")
    assert isinstance(df, pd.DataFrame), "df must be a pandas DataFrame"
    if config is None:
        config = load_config()
    if context_columns is None:
        context_columns = config.get("context_columns", [])
    assert isinstance(context_columns, list) and all(isinstance(c, str) for c in context_columns), "context_columns must be a list of strings"
    assert all(c in df.columns for c in context_columns), \
        f"Some contextual columns are missing: {set(context_columns) - set(df.columns)}"
    for col in context_columns:
        df[col] = df[col].apply(normalize_context_value)
        msg = f"[helperscbf] Normalized unique values for '{col}': {df[col].unique()}"
        if logger is not None and hasattr(logger, "info"):
            logger.info(msg)
        else:
            print(msg)
    if df[context_columns].isnull().any(axis=1).any():
        warn_msg = "[helperscbf] ⚠️ WARNING: Missing values detected in contextual columns when checking coverage!"
        if logger is not None and hasattr(logger, "warning"):
            logger.warning(warn_msg)
        else:
            print(warn_msg)
    context_combinations = df[context_columns].agg('_'.join, axis=1)
    coverage = context_combinations.value_counts().reset_index()
    coverage.columns = ['context_combination', 'count']
    msg = f"Found {len(coverage)} unique context combinations."
    if logger is not None and hasattr(logger, "info"):
        logger.info(msg)
    else:
        print(msg)
    return coverage


## جميع الأعمدة السياقية (context columns) تُؤخذ فقط من config أو من وسيط صريح، ولا يُسمح بأي قائمة ثابتة
def log_contextual_stats(
    df: pd.DataFrame,
    context_columns: Optional[List[str]] = None,
    logger: Optional[object] = None,
    config: Optional[dict] = None
) -> Dict[str, dict]:
    """
    Generate a professional statistical summary for contextual columns to monitor distribution and diversity.

    Supports logging of key steps via a logger (if provided), otherwise falls back to print for important events.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame containing the contextual features.
    context_columns : List[str]
        List of columns representing contextual features.
    logger : Optional[object], optional
        Logger for info/warning messages. Default is None (falls back to print).
    config : Optional[dict], optional
        إعدادات النظام المحمّلة من ملف config.yaml (إذا لم تُمرر، يتم تحميلها تلقائيًا).

    Returns
    -------
    Dict[str, dict]
        Dictionary with column names as keys and their statistical summaries as values.
        For categorical columns: unique count, top categories and frequencies.
        For numerical columns: count, mean, std, min, 25%, 50%, 75%, max.
    """
    if logger is not None and hasattr(logger, "info"):
        logger.info("[log_contextual_stats] Generating contextual stats summary.")
    else:
        print("[log_contextual_stats] Generating contextual stats summary.")
    if config is None:
        config = load_config()
    if context_columns is None:
        context_columns = config.get("context_columns", [])
    assert all(c in df.columns for c in context_columns), \
        f"Some contextual columns are missing: {set(context_columns) - set(df.columns)}"
    for col in context_columns:
        df[col] = df[col].apply(normalize_context_value)
        msg = f"[helperscbf] Normalized unique values for '{col}': {df[col].unique()}"
        if logger is not None and hasattr(logger, "info"):
            logger.info(msg)
        else:
            print(msg)
    stats = {}
    for col in context_columns:
        if df[col].dtype == 'object' or df[col].dtype.name == 'category':
            value_counts = df[col].value_counts(dropna=False)
            top_categories = value_counts.head(5).to_dict()
            stats[col] = {
                'type': 'categorical',
                'unique_count': df[col].nunique(dropna=False),
                'top_categories': top_categories,
                'total_count': len(df[col])
            }
            msg = f"[log_contextual_stats] '{col}': {stats[col]['unique_count']} unique, top: {top_categories}"
            if logger is not None and hasattr(logger, "info"):
                logger.info(msg)
            else:
                print(msg)
        else:
            desc = df[col].describe()
            stats[col] = {
                'type': 'numerical',
                'count': float(desc.get('count', np.nan)),
                'mean': float(desc.get('mean', np.nan)),
                'std': float(desc.get('std', np.nan)),
                'min': float(desc.get('min', np.nan)),
                '25%': float(desc.get('25%', np.nan)),
                '50%': float(desc.get('50%', np.nan)),
                '75%': float(desc.get('75%', np.nan)),
                'max': float(desc.get('max', np.nan)),
            }
            msg = f"[log_contextual_stats] '{col}': numerical summary: {stats[col]}"
            if logger is not None and hasattr(logger, "info"):
                logger.info(msg)
            else:
                print(msg)
    if logger is not None and hasattr(logger, "info"):
        logger.info(f"Contextual stats summary: { {col: stats[col]['type'] for col in stats} }")
    else:
        print(f"Contextual stats summary: { {col: stats[col]['type'] for col in stats} }")
    return stats

def export_uncovered_context_keys(df: pd.DataFrame, output_dir: str = "outputs/CBF") -> dict:
    """
    تصدير التركيبات السياقية غير المغطاة (manual_review أو feature_id مفقود) كملفات CSV لمراجعة القاموس وتوسيع التغطية.
    - يحفظ التركيبات غير المغطاة في كل من feature_id_binned وcontext_feature_id إذا توفرت.
    - ينشئ الملفات في المسار المحدد ويعيد dict بمسارات الملفات الناتجة.
    """
    import os
    os.makedirs(output_dir, exist_ok=True)
    report_paths = {}
    # تصدير التركيبات غير المغطاة بناءً على context_feature_id
    if "context_feature_id" in df.columns:
        mask = (df["feature_id"].isnull()) | (df["feature_id"] == "manual_review")
        uncovered = df.loc[mask & df["context_feature_id"].notnull(), "context_feature_id"].value_counts().reset_index()
        uncovered.columns = ["context_feature_id", "count"]
        if not uncovered.empty:
            path = os.path.join(output_dir, "not_covered_context_feature_id.csv")
            uncovered.to_csv(path, index=False, encoding="utf-8-sig")
            report_paths["context_feature_id"] = path
    # تصدير التركيبات غير المغطاة بناءً على feature_id_binned
    if "feature_id_binned" in df.columns:
        mask = (df["feature_id"].isnull()) | (df["feature_id"] == "manual_review")
        uncovered = df.loc[mask & df["feature_id_binned"].notnull(), "feature_id_binned"].value_counts().reset_index()
        uncovered.columns = ["feature_id_binned", "count"]
        if not uncovered.empty:
            path = os.path.join(output_dir, "not_covered_feature_id_binned.csv")
            uncovered.to_csv(path, index=False, encoding="utf-8-sig")
            report_paths["feature_id_binned"] = path
    # طباعة أو لوج للمراجعة السريعة
    print(f"[export_uncovered_context_keys] Exported uncovered context keys: {report_paths}")
    return report_paths


def ensure_feature_id_binned_and_context(df: pd.DataFrame, log=None, log_id: str = "CBF") -> pd.DataFrame:
    """
    Sanitize/canonicalize feature_id before running any binning/context composition logic.
    Safe no-op if column not present. Returns a copy.
    """
    if not isinstance(df, pd.DataFrame) or "feature_id" not in df.columns:
        return df
    out = df.copy()
    try:
        # 1) تعقيم عبر قاموس المرادفات
        out.loc[:, "feature_id"] = out["feature_id"].apply(sanitize_feature_id)
        # 2) تحويل إلى الشكل القانوني (إن أمكن)
        out.loc[:, "feature_id"] = out["feature_id"].map(canonicalize_feature_id).fillna(out["feature_id"])
        if log is not None and hasattr(log, "info"):
            log.info(f"[{log_id}] ensure_feature_id_binned_and_context: feature_id sanitized & canonicalized.")
    except (TypeError, ValueError, AttributeError, KeyError) as e:
        if log is not None and hasattr(log, "warning"):
            log.warning(f"[{log_id}] ensure_feature_id_binned_and_context skipped due to {e}")
    return out

 # ----------------------------- تقسيم بيانات توصية CBF بشكل احترافي -----------------------------
import yaml
from sklearn.model_selection import train_test_split

# === Diagnostics: count contexts that failed exact-match support and were diverted to KNN ===
_CBF_EXACT_SUPPORT_FAILED = 0

def _inc_exact_support_failed() -> None:
    global _CBF_EXACT_SUPPORT_FAILED
    _CBF_EXACT_SUPPORT_FAILED += 1

def get_exact_support_failed_count() -> int:
    return int(_CBF_EXACT_SUPPORT_FAILED)

# -------------------------------------------------------------------------
# دالة تحميل إعدادات النظام من ملف config.yaml
# -------------------------------------------------------------------------
# شرح بالعربية:
# هذه الدالة تقوم بتحميل إعدادات النظام من ملف YAML خارجي (عادة config.yaml)،
# بحيث يمكن تغيير الإعدادات (مثل أعمدة السياق، target، true_response، إعدادات التقسيم)
# بدون الحاجة لتعديل الكود البرمجي. تعيد الدالة قاموس الإعدادات الجاهز للاستخدام.
#
# English explanation:
# This function loads system configuration from an external YAML file (typically config.yaml),
# allowing you to change settings (such as context columns, target, true_response, split settings)
# without modifying the source code. Returns the config as a ready-to-use dictionary.

def load_config(path="pipeline/config.yaml"):
    """
    تحميل إعدادات النظام من ملف YAML خارجي (config.yaml).
    Loads system configuration from external YAML file.
    """
    with open(path, 'r', encoding="utf-8") as f:
        return yaml.safe_load(f)

# -------------------------------------------------------------------------
# دالة تقسيم بيانات توصية CBF إلى train/val/test بدون تسرب مرضى، مع دعم config ديناميكي
# -------------------------------------------------------------------------
# شرح بالعربية:
# هذه الدالة تقوم بتقسيم بيانات توصية CBF إلى مجموعات train/val/test
# اعتمادًا على إعدادات config.yaml، مع ضمان عدم تسرب أي سجل مريض (patient_id) بين المجموعات.
# تأخذ الأعمدة (السياقية، target، true_response) وقيم التقسيم ديناميكيًا من config.
# تدعم إضافة stratify مستقبلًا (البرمجية جاهزة).
#
# English explanation:
# This function splits the CBF recommendation dataset into train/val/test groups
# according to config.yaml, ensuring no patient data leakage (no patient_id appears in more than one group).
# All columns (context, target, true_response) and split values are taken dynamically from config.
# Ready for stratify support in the future.

def cbf_split_data(
    df: pd.DataFrame,
    config: dict,
    logger=None,
    random_state: int = 42
):
    """
    تقسيم بيانات توصية CBF إلى train/val/test اعتمادًا على config.yaml، مع ضمان عدم تسرب (Data Leakage) لأي سجل مريض بين المجموعات.

    Splits the CBF recommendation dataset into train/val/test sets according to config.yaml, ensuring no patient data leakage.

    - الأعمدة السياقية، target، true_response كلها تُستمد من config.
    - التقسيم يتم حسب patient_id إذا كان موجودًا (وهو إلزامي).
    - يمكن دعم stratify لاحقًا (جاهز للإضافة).
    """
    split_settings = config.get('split_settings', {})
    test_size = split_settings.get("test_size", 0.2)
    val_size = split_settings.get("val_size", 0.15)
    # stratify_col = split_settings.get("stratify_col")
    # stratify = df[stratify_col] if stratify_col and stratify_col in df.columns else None

    if "patient_id" not in df.columns:
        raise ValueError("يجب وجود عمود 'patient_id' في البيانات!")

    # تأكيد صلاحية قيم التقسيم
    if not (0 < test_size < 1):
        raise ValueError(f"test_size غير منطقي: {test_size}")
    if not (0 <= val_size < 1):
        raise ValueError(f"val_size غير منطقي: {val_size}")

    unique_ids = df["patient_id"].unique()
    train_ids, test_ids = train_test_split(
        unique_ids, test_size=test_size, random_state=random_state, stratify=None
    )
    if val_size > 0:
        train_ids, val_ids = train_test_split(
            train_ids, test_size=val_size, random_state=random_state, stratify=None
        )
    else:
        val_ids = []

    df_train = df[df["patient_id"].isin(train_ids)].reset_index(drop=True)
    df_val = (
        df[df["patient_id"].isin(val_ids)].reset_index(drop=True)
        if isinstance(val_ids, (list, np.ndarray)) and len(val_ids) > 0
        else pd.DataFrame()
    )
    df_test = df[df["patient_id"].isin(test_ids)].reset_index(drop=True)

    # تأكيد عدم وجود أي تقاطع بين المجموعات
    train_set = set(df_train["patient_id"])
    test_set = set(df_test["patient_id"])
    val_set = set(df_val["patient_id"]) if not df_val.empty else set()
    assert train_set.isdisjoint(test_set), "يوجد تسرب مرضى بين train و test"
    assert train_set.isdisjoint(val_set), "يوجد تسرب مرضى بين train و val"
    assert test_set.isdisjoint(val_set), "يوجد تسرب مرضى بين test و val"

    if logger:
        logger.info(
            f"Train: {df_train.shape} ({len(train_set)} مرضى), "
            f"Val: {df_val.shape} ({len(val_set)} مرضى), "
            f"Test: {df_test.shape} ({len(test_set)} مرضى)"
        )

    return df_train, df_val, df_test

from utils.context_utils import make_context_key
from utils.context_utils import sanitize_feature_id
# -------------------------------------------------------------------------
# دالة إخفاء الأعمدة الحساسة (target, true_response) من بيانات التدريب/التوليد
# -------------------------------------------------------------------------
# شرح بالعربية:
# هذه الدالة تستخدم لإزالة الأعمدة الحساسة (مثل target و true_response)
# من بيانات التدريب أو التوصية قبل التقييم، وذلك لمنع تسرب الإجابات أو كشفها للنموذج.
# الأعمدة يتم تحديدها ديناميكيًا من config.
#
# English explanation:
# This function is used to remove sensitive columns (such as target and true_response)
# from the training or recommendation data before evaluation, to prevent answer leakage to the model.
# The columns are taken dynamically from config.
def hide_sensitive_columns(df, config):
    """
    إخفاء الأعمدة الحساسة (target, true_response) من بيانات التدريب أو التوليد قبل التقييم.
    Hides sensitive columns (target, true_response) from the dataset (e.g., before training or recommendation generation).

    ⚠️ تنبيه: هذه الدالة لا تعدل DataFrame الأصلي وإنما تعيد نسخة بدون الأعمدة الحساسة فقط.
    يجب الحفاظ على الـ DataFrame الأصلي إذا كنت بحاجة للأعمدة لاحقًا.
    WARNING: This function does NOT modify the original DataFrame, but returns a copy without the sensitive columns only.
    Keep the original DataFrame if you need the sensitive columns later.
    """
    # تحذير يُطبع لمرة واحدة في كل تنفيذ إذا تم تمرير نفس df كوسيط وإرجاعه
    # (أي أن المستخدم قد يظن أن الدالة تعدل الأصل، لكنها تعيد نسخة)
    import threading
    if not hasattr(hide_sensitive_columns, "warned"):
        hide_sensitive_columns.warned = False
        hide_sensitive_columns.warned_lock = threading.Lock()
    with hide_sensitive_columns.warned_lock:
        if not hide_sensitive_columns.warned:
            print("[hide_sensitive_columns] ⚠️ تنبيه: الدالة تعيد نسخة بدون الأعمدة الحساسة فقط ولا تعدل الأصل. يجب الحفاظ على DataFrame الأصلي إذا كنت بحاجة للأعمدة لاحقًا.")
            hide_sensitive_columns.warned = True
    target_col = config.get('target_column', 'target')
    true_response_col = config.get('true_response_column', 'true_response')
    return df.drop([target_col, true_response_col], axis=1, errors="ignore")

# -------------------- وحدة اختبار make_context_key --------------------
if __name__ == "__main__":
    print("== اختبار make_context_key ==")
    # Define test context columns (matches samples)
    test_context_columns = [
        "bp_category",
        "chol_category",
        "risk_level",
        "fbs_cat",
        "cp_cat",
        "age_group"
    ]
    # عينة dict كاملة
    sample1 = {
        "bp_category": "High",
        "chol_category": "Normal",
        "risk_level": "Medium",
        "fbs_cat": "Yes",
        "cp_cat": "TypeA",
        "age_group": "Adult"
    }
    # عينة dict ناقصة (بعض القيم مفقودة)
    sample2 = {
        "bp_category": "Low",
        "chol_category": "High",
        "risk_level": None,
        "fbs_cat": None,
        "cp_cat": "TypeB",
        "age_group": "Senior"
    }
    # عينة Series
    import pandas as pd
    sample3 = pd.Series({
        "bp_category": "normal",
        "chol_category": "borderline",
        "risk_level": "low",
        "fbs_cat": "no",
        "cp_cat": "typec",
        "age_group": "teen"
    })
    # عينة dict مع عمود ناقص تمامًا (يجب أن يظهر unknown)
    sample4 = {
        "bp_category": "Normal",
        "chol_category": "High"
        # باقي الأعمدة غير موجودة
    }
    print("Sample1:", make_context_key(sample1, context_columns=test_context_columns, verbose=True))
    print("Sample2:", make_context_key(sample2, context_columns=test_context_columns, verbose=True))
    print("Sample3:", make_context_key(sample3, context_columns=test_context_columns, verbose=True))
    print("Sample4 (missing columns):", make_context_key(sample4, context_columns=test_context_columns, verbose=True))
    # تحقق من النتائج المتوقعة
    assert make_context_key(sample1, context_columns=test_context_columns) == "high_normal_medium_yes_typea_adult"
    assert make_context_key(sample2, context_columns=test_context_columns) == "low_high_unknown_unknown_typeb_senior"
    assert make_context_key(sample3, context_columns=test_context_columns) == "normal_borderline_low_no_typec_teen"
    # sample4 should fill missing columns with "unknown"
    assert make_context_key(sample4, context_columns=test_context_columns) == "normal_high_unknown_unknown_unknown_unknown"
    print("✅ جميع اختبارات make_context_key نجحت.")

## جميع الأعمدة السياقية (context columns و secondary_context_columns) تُؤخذ فقط من config أو من وسيط صريح، ولا يُسمح بأي قائمة ثابتة
def find_best_contextual_recommendation(
    context: dict,
    dictionary: pd.DataFrame,
    secondary_cols: Optional[list] = None,
    target_col: str = "feature_id",
    review_label: str = "manual_review",
    verbose: bool = False,
    config: Optional[dict] = None,
    **kwargs
) -> dict:
    """
    خوارزمية توصية سياقية متقدمة وآمنة تمنع تسرب الإجابة (true_response) وتتحقق من الأعمدة المطلوبة.
    Advanced, secure contextual recommendation algorithm that prevents true_response leakage and validates required columns.

    شرح بالعربية:
    - تمنع تمرير true_response ضمن السياق نهائيًا (حماية من التسرب).
    - تتحقق أن جميع الأعمدة الأساسية والثانوية متوفرة في القاموس.
    - تبدأ بتطابق صارم للأعمدة الأساسية فقط، ثم تضيق تدريجيًا باستخدام الأعمدة الثانوية (كل عمود على حدة ثم جميعها معًا).
    - إذا بقي التكرار أو لم يوجد تطابق: تعيد manual_review مع تقرير مفصل لكل خطوة.
    - تدعم توثيقًا ثنائي اللغة وشفافية كاملة في خطوات التنفيذ.
    - افتراضيًا، يتم التوصية باستخدام عمود feature_id (target_col="feature_id")، أما true_response فيستخدم فقط في التقييم.

    English summary:
    - Strictly prevents passing true_response as part of context (security).
    - Validates all required columns exist in the dictionary.
    - Starts with exact match on core context columns, then narrows using secondary columns (individually, then all together).
    - If ambiguity remains or no match: returns manual_review with detailed step trace.
    - Provides bilingual documentation and professional traceability.
    - By default, recommends using the "feature_id" column (target_col="feature_id"); "true_response" is used only for evaluation.

    Parameters
    ----------
    context : dict
        Contextual values for the current case (MUST NOT contain true_response).
    dictionary : pd.DataFrame
        Recommendation dictionary (must contain all required context and secondary columns, plus feature_id).
    secondary_cols : list
        List of secondary columns for progressive narrowing if multiple candidates remain.
    target_col : str
        Column holding the recommendation label (default: "feature_id").
    review_label : str
        Label to return if ambiguity is unresolved (default: "manual_review").
    verbose : bool
        If True, prints trace of each step.

    config : Optional[dict], optional
        إعدادات النظام المحمّلة من ملف config.yaml (إذا لم تُمرر، يتم تحميلها تلقائيًا).

    Returns
    -------
    dict
        {
            "recommendation": ...,
            "matched_rows": ...,
            "match_level": ...,
            "details": ...
        }
    """
    if config is None:
        config = load_config()
    context_columns = config.get("context_columns", [])
    if secondary_cols is None:
        secondary_cols = config.get("secondary_context_columns", [])
    # Minimum support for accepting exact/contextual unique matches
    # Read min_context_size safely with narrow exception handling and validation
    try:
        _cbf_cfg = (config.get("cbf") or {})
        _raw_min_ctx = _cbf_cfg.get("min_context_size", 5)
        min_context_size = int(_raw_min_ctx)
        if min_context_size <= 0:
            raise ValueError("min_context_size must be > 0")
    except (AttributeError, TypeError, ValueError) as _min_ctx_err:
        if verbose:
            print(f"[find_best_contextual_recommendation] Falling back to default min_context_size=5 due to: {_min_ctx_err}")
        min_context_size = 5

    # Helper to read the exact match cap for similarity with validation and clamping
    def _get_exact_cap(cfg):
        try:
            mix_cfg = (((cfg or {}).get("model_settings") or {}).get("scoring") or {}).get("cbf_mix", {})
            cap_val = mix_cfg.get("exact_match_cap", 0.98)
            cap = float(cap_val)
            # Clamp to sensible range (0, 1]
            if not (0.0 < cap <= 1.0):
                raise ValueError("exact_match_cap out of range")
            return cap
        except (AttributeError, TypeError, ValueError) as _cap_err:
            if verbose:
                print(f"[find_best_contextual_recommendation] Using default exact_match_cap=0.98 due to: {_cap_err}")
            return 0.98

    exact_cap = _get_exact_cap(config)

    # consume unused kwargs to silence linter
    _ = kwargs

    print("[helperscbf] Unique context/secondary columns in dictionary:")
    for col in context_columns + secondary_cols:
        if col in dictionary.columns:
            print(f"  - {col}: {sorted(dictionary[col].unique())}")

    # --- 1. منع تسرب true_response ضمن السياق (Prevent leakage of true_response in context)
    if "true_response" in context:
        raise ValueError(
            "❌ SECURITY: 'true_response' MUST NOT be passed in context for recommendation. "
            "تم رفض العملية لحماية النظام من تسرب الإجابة."
        )

    # --- 2. تحقق وجود جميع الأعمدة المطلوبة (core + secondary) في القاموس
    required_cols = list(context_columns) + list(secondary_cols) + [target_col]
    missing_cols = [c for c in required_cols if c not in dictionary.columns]
    if missing_cols:
        raise ValueError(
            f"❌ Missing required columns in dictionary: {missing_cols} | "
            f"الأعمدة الناقصة في القاموس: {missing_cols}"
        )

    # تطبيع جميع الأعمدة الأساسية والثانوية في القاموس مرة واحدة فقط (يوفر الأداء ويمنع إعادة التطبيع)
    dictionary = dictionary.copy()
    # Normalize all dictionary columns for context_columns and secondary_cols using normalize_context_value
    for col in context_columns + secondary_cols:
        if col in dictionary.columns:
            dictionary[col] = dictionary[col].map(normalize_context_value)

    details = []

    # --- [NEW 0] Full context (core + secondary) exact match
    full_cols = [c for c in (context_columns + secondary_cols) if c in dictionary.columns]
    context_full_vals = [normalize_context_value(context.get(c, None)) for c in full_cols]
    full_mask = np.all(dictionary[full_cols].values == np.array(context_full_vals), axis=1)
    matches_full = dictionary[full_mask].copy()
    details.append(f"Full context (core+secondary) exact match: {len(matches_full)} rows")
    if matches_full.shape[0] > 0:
        uniq_full = matches_full[target_col].dropna().unique()
        if len(uniq_full) == 1:
            support_n = int(matches_full.shape[0])
            n_unique_patients = int(matches_full["patient_id"].nunique()) if "patient_id" in matches_full.columns else support_n
            fam_div = int(matches_full["feature_id_binned"].nunique()) if "feature_id_binned" in matches_full.columns else 1
            if support_n >= min_context_size and n_unique_patients >= 3 and fam_div >= 2:
                if verbose:
                    print(f"[find_best_contextual_recommendation] Unique {target_col} at full context (support={support_n}, unique_patients={n_unique_patients}, fam_div={fam_div}) >= thresholds: {uniq_full[0]}")
                allowed_list = _FEATURE_ID_ALLOWED
                recommendation = uniq_full[0]
                recommendation = _sanitize_recommendation(recommendation, allowed_list=allowed_list)
                return {
                    "recommendation": recommendation,
                    "matched_rows": matches_full,
                    "match_level": "context_key_match",
                    "details": details + [f"full_context_unique_support={support_n}", f"unique_patients={n_unique_patients}", f"family_diversity={fam_div}"],
                    "similarity": float(exact_cap),
                    "candidate_feature_ids": [str(uniq_full[0])],
                    "candidate_counts": {str(uniq_full[0]): int(support_n)},
                }
            else:
                if verbose:
                    print(f"[find_best_contextual_recommendation] Full-context unique but under thresholds (support={support_n}, unique_patients={n_unique_patients}, fam_div={fam_div}); deferring to similarity/KNN")
                _inc_exact_support_failed()
                allowed_list = _FEATURE_ID_ALLOWED
                recommendation = _sanitize_recommendation("manual_review", allowed_list=allowed_list)
                return {
                    "recommendation": recommendation,
                    "matched_rows": matches_full,
                    "match_level": "context_too_rare",
                    "details": details + [f"full_context_unique_under_thresholds support={support_n} unique_patients={n_unique_patients} fam_diversity={fam_div} < required"],
                    "similarity": 0.0,
                    "candidate_feature_ids": [],
                    "candidate_counts": {},
                }
        elif len(uniq_full) > 1:
            matches = matches_full
        else:
            matches = matches_full  # empty
    else:
        # Fall back to core-stage logic
        matches = None

    # --- 3. تطابق صارم للأعمدة الأساسية (Strict match on core context columns)
    if matches is None:
        context_core_vals = [normalize_context_value(context.get(col, None)) for col in context_columns]
        dict_core = dictionary[context_columns]
        base_mask = np.all(dict_core.values == np.array(context_core_vals), axis=1)
        matches = dictionary[base_mask].copy()
        details.append(f"Core match: {len(matches)} rows")
        if verbose:
            print(f"[find_best_contextual_recommendation] Core match ({len(matches)} rows)")
        if matches.empty:
            if verbose:
                print("[find_best_contextual_recommendation] No matches found at core level. Returning review_label.")
            allowed_list = _FEATURE_ID_ALLOWED
            recommendation = review_label
            recommendation = _sanitize_recommendation(recommendation, allowed_list=allowed_list)
            return {
                "recommendation": recommendation,
                "matched_rows": matches,
                "match_level": "unresolved",
                "details": details + ["core_no_match"],
                "similarity": 0.0,
                "candidate_feature_ids": [],
                "candidate_counts": {},
            }

        uniq_responses = matches[target_col].dropna().unique()
        if len(uniq_responses) == 1:
            support_n = int(matches.shape[0])
            n_unique_patients = int(matches["patient_id"].nunique()) if "patient_id" in matches.columns else support_n
            fam_div = int(matches["feature_id_binned"].nunique()) if "feature_id_binned" in matches.columns else 1
            if support_n >= min_context_size and n_unique_patients >= 3 and fam_div >= 2:
                if verbose:
                    print(f"[find_best_contextual_recommendation] Unique {target_col} at core (support={support_n}, unique_patients={n_unique_patients}, fam_div={fam_div}) >= thresholds: {uniq_responses[0]}")
                allowed_list = _FEATURE_ID_ALLOWED
                recommendation = uniq_responses[0]
                recommendation = _sanitize_recommendation(recommendation, allowed_list=allowed_list)
                return {
                    "recommendation": recommendation,
                    "matched_rows": matches,
                    "match_level": "contextual_rule",
                    "details": details + [f"core_unique_support={support_n}", f"unique_patients={n_unique_patients}", f"family_diversity={fam_div}"],
                    "similarity": float(exact_cap),
                    "candidate_feature_ids": [str(uniq_responses[0])],
                    "candidate_counts": {str(uniq_responses[0]): int(support_n)},
                }
            else:
                if verbose:
                    print(f"[find_best_contextual_recommendation] Core unique but under thresholds (support={support_n}, unique_patients={n_unique_patients}, fam_div={fam_div}); deferring to similarity/KNN")
                _inc_exact_support_failed()
                allowed_list = _FEATURE_ID_ALLOWED
                recommendation = _sanitize_recommendation("manual_review", allowed_list=allowed_list)
                return {
                    "recommendation": recommendation,
                    "matched_rows": matches,
                    "match_level": "context_too_rare",
                    "details": details + [f"core_unique_under_thresholds support={support_n} unique_patients={n_unique_patients} fam_diversity={fam_div} < required"],
                    "similarity": 0.0,
                    "candidate_feature_ids": [],
                    "candidate_counts": {},
                }
    else:
        uniq_responses = matches[target_col].dropna().unique()

    # --- 4. تجربة الأعمدة الثانوية تدريجيًا (Try secondary columns one by one)
    for col in secondary_cols:
        col_val = normalize_context_value(context.get(col, None))
        filtered = matches[matches[col] == col_val]
        details.append(f"Secondary col {col}: {col_val} --> {len(filtered)} rows")
        if verbose:
            print(f"[find_best_contextual_recommendation] Filtering on {col}={col_val}: {len(filtered)} rows")
        if filtered.empty:
            continue
        uniq_responses_sec = filtered[target_col].dropna().unique()
        if len(uniq_responses_sec) == 1:
            support_n = int(filtered.shape[0])
            allowed_list = _FEATURE_ID_ALLOWED
            recommendation = uniq_responses_sec[0]
            recommendation = _sanitize_recommendation(recommendation, allowed_list=allowed_list)
            return {
                "recommendation": recommendation,
                "matched_rows": filtered,
                "match_level": "contextual_rule",
                "details": details + [f"secondary_unique:{col}"],
                "similarity": float(exact_cap),
                "candidate_feature_ids": [str(uniq_responses_sec[0])],
                "candidate_counts": {str(uniq_responses_sec[0]): int(support_n)},
            }
        matches = filtered  # Continue narrowing

    # --- 5. تجربة جميع الأعمدة الثانوية دفعة واحدة (Try all secondary columns together)
    if secondary_cols:
        context_sec_vals = np.array([normalize_context_value(context.get(col, None)) for col in secondary_cols])
        matches_sec = matches.copy()
        if not matches_sec.empty:
            sec_mask = np.all(matches_sec[secondary_cols].values == context_sec_vals, axis=1)
            filtered_all = matches_sec[sec_mask]
        else:
            filtered_all = matches_sec  # empty
        details.append(f"All secondary cols: {len(filtered_all)} rows")
        if verbose:
            print(f"[find_best_contextual_recommendation] Filtering on all secondary cols: {len(filtered_all)} rows")
        if not filtered_all.empty:
            uniq_responses_all = filtered_all[target_col].dropna().unique()
            if len(uniq_responses_all) == 1:
                support_n = int(filtered_all.shape[0])
                allowed_list = _FEATURE_ID_ALLOWED
                recommendation = uniq_responses_all[0]
                recommendation = _sanitize_recommendation(recommendation, allowed_list=allowed_list)
                return {
                    "recommendation": recommendation,
                    "matched_rows": filtered_all,
                    "match_level": "contextual_rule",
                    "details": details + ["all_secondary_unique"],
                    "similarity": float(exact_cap),
                    "candidate_feature_ids": [str(uniq_responses_all[0])],
                    "candidate_counts": {str(uniq_responses_all[0]): int(support_n)},
                }

    # --- 6. إذا بقي التكرار أو لم يوجد تطابق نهائي (Still ambiguous/unresolved)
    if verbose:
        print(f"[find_best_contextual_recommendation] Still duplicate responses after all filtering.")
    print("[helperscbf] ⚠️ No unique recommendation could be resolved for context:")
    print("  context:", context)
    print("  Context columns:", context_columns)
    print("  Secondary columns:", secondary_cols)
    print("  Unique candidate responses:", uniq_responses)
    print("  Candidate rows:")
    print(matches[context_columns + secondary_cols + [target_col]].head(10))
    allowed_list = _FEATURE_ID_ALLOWED
    recommendation = review_label
    recommendation = _sanitize_recommendation(recommendation, allowed_list=allowed_list)
    details.append("unresolved_after_all_filters")
    return {
        "recommendation": recommendation,
        "matched_rows": matches,
        "match_level": "unresolved",
        "details": details,
        "similarity": 0.0,
        "candidate_feature_ids": [],
        "candidate_counts": {},
    }




# --- module-level logger for helperscbf (shared across functions) ---
import logging as _logging  # standard lib; safe to import here
_CBF_LOGGER = _logging.getLogger("cbf")
# Attach a NullHandler once to avoid "No handler found" warnings if the app hasn't configured logging yet.
if not _CBF_LOGGER.handlers:
    _CBF_LOGGER.addHandler(_logging.NullHandler())

# === Lightweight, safe narrative builders (algorithmic/clinical/advice) ===
from typing import Dict, Any, Optional, Union
import pandas as pd
import numpy as np
from utils.constants import ADVICE_MAP, normalize_label, canonicalize_feature_id

# === Narrative builders (algorithmic/clinical/advice) ===
def build_algorithmic_explanation(row: pd.Series) -> str:
    """
    يعتمد على reason + أفضل متاح من (similarity -> score_cbf_raw -> score_cbf_base).
    يُطبع: reason=<..>; sim=<..>; policy=<..>
    """
    reason = str(row.get("reason", "unknown"))
    sim = None
    for k in ["similarity", "score_cbf_raw", "score_cbf_base"]:
        v = row.get(k, None)
        if v is not None:
            try:
                sim = float(v); break
            except (TypeError, ValueError, OverflowError):
                continue
    sim_txt = f"{sim:.4f}" if isinstance(sim, float) else "n/a"
    policy = str(row.get("source", "CBF")).strip() or "CBF"
    return f"reason={reason}; sim={sim_txt}; policy={policy}"

def build_clinical_explanation(row: pd.Series) -> str:
    """جُمَل قصيرة حسب (BP/Chol/Risk ± Age) فقط."""
    bp = normalize_label(row.get("bp_category", "unknown"))
    chol = normalize_label(row.get("chol_category", "unknown"))
    risk = normalize_label(row.get("risk_level", "unknown"))
    parts = []
    if bp in {"high", "stage_1", "stage_2"}:
        parts.append("ضغط مرتفع يستلزم متابعة لصيقة.")
    if chol in {"high", "very_high"}:
        parts.append("دهون مرتفعة قد تتطلب ضبطًا غذائيًا/دوائيًا.")
    if risk in {"high"}:
        parts.append("خطر قلبي وعائي مرتفع، يُفضّل تقييم سريري عاجل.")
    return " ".join(parts) if parts else "حالة مستقرة نسبيًا مع متابعة دورية."

def apply_cbf_narratives(df: pd.DataFrame, logger_obj=None) -> pd.DataFrame:
    """
    يملأ explanation دائمًا.
    يملأ explanation_clinical فقط لو كانت فارغة/غير موجودة، ولا يساوي explanation.
    يملأ advice حصريًا من الأربع رسائل (خارجها → "").
    """
    out = df.copy()

    # Preserve raw similarity for diagnostics if present
    if "similarity" in out.columns and "sim_cbf_raw" not in out.columns:
        out["sim_cbf_raw"] = pd.to_numeric(out["similarity"], errors="coerce")

    # --- Ensure similarity column exists for narrative builder (similarity -> score_cbf_raw -> sim_cbf_raw) ---
    if "similarity" not in out.columns:
        if "score_cbf_raw" in out.columns:
            out["similarity"] = out["score_cbf_raw"]
        elif "sim_cbf_raw" in out.columns:
            out["similarity"] = out["sim_cbf_raw"]

    # --- Canonicalize recommendation/feature_id to align with ADVICE_MAP keys ---
    try:
        if "recommendation" in out.columns:
            out["recommendation"] = out["recommendation"].astype(str).apply(lambda v: canonicalize_feature_id(v) or v)
    except (TypeError, ValueError, AttributeError):
        out["recommendation"] = out.get("recommendation", "").astype(str) if "recommendation" in out.columns else out.get("recommendation", "")
    try:
        if "feature_id" in out.columns:
            out["feature_id"] = out["feature_id"].astype(str).apply(lambda v: canonicalize_feature_id(v) or v)
    except (TypeError, ValueError, AttributeError):
        if "feature_id" in out.columns:
            out["feature_id"] = out["feature_id"].astype(str).str.strip().str.lower()

    out["explanation"] = out.apply(build_algorithmic_explanation, axis=1)

    if "explanation_clinical" not in out.columns:
        out["explanation_clinical"] = ""
    mask_empty = out["explanation_clinical"].astype(str).str.strip().isin(["", "none", "nan", "unknown"])
    out.loc[mask_empty, "explanation_clinical"] = out.loc[mask_empty].apply(build_clinical_explanation, axis=1)

    if "advice" not in out.columns:
        out["advice"] = ""
    def _advice_for_row(r):
        # Prefer canonical feature_id; fall back to recommendation
        fid_raw = r.get("feature_id", r.get("recommendation", ""))
        fid_norm = normalize_label(fid_raw)
        return ADVICE_MAP.get(fid_norm, "")
    out["advice"] = out.apply(_advice_for_row, axis=1)

    if logger_obj is not None and hasattr(logger_obj, "info"):
        try:
            logger_obj.info("[helperscbf] narratives applied")
        except (AttributeError, TypeError, ValueError):
            pass
    return out


# ---------------------- توصية بديلة باستخدام التشابه (Similarity-based Fallback) ----------------------
## جميع الأعمدة السياقية (context columns و secondary_context_columns) تُؤخذ فقط من config أو من وسيط صريح، ولا يُسمح بأي قائمة ثابتة
def recommend_by_similarity(
    context: dict,
    dictionary: pd.DataFrame,
    target_col: str = "feature_id",
    context_cols: Optional[list] = None,
    k: int = 3,
    min_similarity: float = 0.7,
    verbose: bool = False,
    config: Optional[dict] = None,
    details: Optional[List[str]] = None
) -> dict:
    """
    توصية سياقية باستخدام التشابه (Similarity-based Fallback).
    • Recommends a feature_id using similarity-based fallback.
    • في حال فشل التطابق الحرفي/الثانوي، يستخدم KNN لاسترجاع أقرب السياقات الممثلة عدديًا.
    • إذا كانت أعلى تشابه أقل من min_similarity تُصنّف الحالة للمراجعة اليدوية.
    • إذا كان الجار الأقرب توصيته فريدة: يتم استخدامها. إذا هناك عدة جيران: voting أو ترجيح.
    • يتوافق مع الأعمدة السياقية من config فقط.
    """
    def _dbg(_m: str):
        if verbose:
            if _CBF_LOGGER is not None:
                try:
                    _CBF_LOGGER.debug(_m)
                except (TypeError, ValueError):
                    # في حال خطأ تهيئة الرسالة فقط
                    print(_m)
            else:
                print(_m)

    # Normalize details list and register initial attempt metadata
    details = [] if details is None else details
    attempt_id = 1
    attempt_reason = "initial"
    details.append(f"attempt_id={attempt_id}")
    details.append(f"attempt_reason={attempt_reason}")
    if config is None:
        config = load_config()
    # احترام الأعمدة المُمررة + fallback آمن
    if context_cols is None:
        try:
            from utils.constants import CONTEXT_COLUMNS as _DEFAULT_CTX
            context_cols = list(_DEFAULT_CTX)
        except (ImportError, ModuleNotFoundError, AttributeError, NameError):
            context_cols = [
                "bp_category", "chol_category", "risk_level", "fbs_cat", "cp_cat", "age_group"
            ]
    context_cols = list(context_cols)
    effective_cols = [c for c in context_cols if c in dictionary.columns]
    # Fallback لمحاولة الأعمدة الافتراضية على مستوى المشروع (core+secondary) إن فشل التقاطع مع context_cols
    if not effective_cols:
        try:
            from utils.constants import CONTEXT_COLUMNS as _DEF_CTX
            effective_cols = [c for c in _DEF_CTX if c in dictionary.columns]
        except (ImportError, ModuleNotFoundError, AttributeError, NameError):
            effective_cols = []
    if not effective_cols:
        # لا ترفع استثناء هنا؛ ارجع unresolved لكي يكمل الـ pipeline إلى KNN
        return {
            "recommendation": "manual_review",
            "matched_rows": None,
            "match_level": "unresolved",
            "details": [
                f"[recommend_by_similarity] لا يوجد تقاطع بين المطلوبة={context_cols} والمتوفرة={list(dictionary.columns)}"
            ],
            "similarity": 0.0,
        }
    all_cols = effective_cols

    # Extract k and min_similarity from config if present
    k, min_similarity = _extract_sim_params(config, k, min_similarity)

    if verbose:
        _dbg(f"[recommend_by_similarity] ✔️ الأعمدة المستعملة للحساب/Columns used: {all_cols}")

    # اجبر الناتج DataFrame دائمًا (حتى لو عمود واحد)
    if len(all_cols) == 1:
        enc_cols_df = dictionary[[all_cols[0]]]
    else:
        enc_cols_df = dictionary[all_cols]
    # Always ensure enc_df is a DataFrame with normalized values using normalize_context_value
    if isinstance(enc_cols_df, pd.Series):
        enc_df = pd.DataFrame(enc_cols_df.apply(normalize_context_value))
    else:
        # DataFrame: apply normalization column-wise on a light copy of just-needed columns
        enc_df = enc_cols_df.astype(str).apply(lambda col: col.map(normalize_context_value))
    context_vec = np.array([normalize_context_value(context.get(col, None)) for col in all_cols]).reshape(1, -1)
    if verbose:
        _dbg(f"[recommend_by_similarity] ✔️ متجه السياق المطلوب/Context vector: {context_vec}")
    # يجب أن تعمل جميع العمليات التالية على enc_df وليس enc_cols_df
    encoded_matrix = []
    encoders = {}
    for col in all_cols:
        unique_vals = pd.Series(list(enc_df[col].unique()) + [context_vec[0][all_cols.index(col)]])
        encoder = {v: i for i, v in enumerate(sorted(unique_vals.unique()))}
        encoders[col] = encoder
        encoded_matrix.append(enc_df[col].map(encoder).values)
    x = np.stack(encoded_matrix, axis=1)
    context_enc = np.array([encoders[c][context_vec[0][i]] for i, c in enumerate(all_cols)]).reshape(1, -1)
    if verbose:
        _dbg(f"[recommend_by_similarity] ✔️ مصفوفة السياقات/Encoded matrix shape: {x.shape}")
        _dbg(f"[recommend_by_similarity] ✔️ السياق المشفر المطلوب/Encoded context: {context_enc}")
    # تدريب نموذج KNN على القاموس العددي
    nbrs = NearestNeighbors(n_neighbors=min(k, x.shape[0]), metric="hamming")
    nbrs.fit(x)
    dists, idxs = nbrs.kneighbors(context_enc)
    # تحويل المسافة إلى تشابه: similarity = 1 - distance
    similarities = 1 - dists[0]
    neighbor_idxs = idxs[0]
    neighbor_rows = dictionary.iloc[neighbor_idxs].copy()
    neighbor_rows["similarity"] = similarities
    # --- Ensure valid_neighbors is defined before its first usage
    try:
        valid_neighbors = neighbor_rows[neighbor_rows["similarity"] >= min_similarity]
    except (KeyError, TypeError, ValueError, AttributeError, IndexError):
        valid_neighbors = _pd.DataFrame()
    # Determine similarity band for scoring
    max_sim = float(neighbor_rows["similarity"].max()) if not neighbor_rows.empty else 0.0
    if max_sim >= 0.90:
        sim_level = "similarity_fallback_high"
    elif max_sim >= 0.70:
        sim_level = "similarity_fallback_medium"
    elif max_sim >= 0.50:
        sim_level = "similarity_fallback_low"
    else:
        sim_level = "manual_review"
    if verbose:
        _dbg("[recommend_by_similarity] ✔️ أقرب الجيران/Nearest neighbors (Top k):")
        _dbg(str(neighbor_rows[[*all_cols, "similarity", target_col]]))
    # Per-column diagnostics using the closest neighbor (index 0)
    try:
        best_idx = int(neighbor_idxs[0])
        best_row = dictionary.iloc[best_idx]
        per_col_matches = []
        for i, c in enumerate(all_cols):
            ctx_v = normalize_context_value(context.get(c, None))
            nbr_v = normalize_context_value(best_row.get(c, None))
            per_col_matches.append((c, ctx_v, nbr_v, "match" if ctx_v == nbr_v else "diff"))
    except (KeyError, IndexError, TypeError, ValueError, AttributeError):
        per_col_matches = []
    # --- Retry once with relaxed params if no valid neighbors ---
    retried = False
    attempt_id = 1
    attempt_reason = "initial"
    if valid_neighbors.empty:
        min_similarity2 = max(0.0, float(min_similarity) - 0.05)
        k2 = int(min(k + 2, x.shape[0]))
        try:
            d2, i2 = nbrs.kneighbors(context_enc, n_neighbors=k2)
            sims2 = 1 - d2[0]
            neighbor_rows2 = dictionary.iloc[i2[0]].copy()
            neighbor_rows2["similarity"] = sims2
            # update working sets
            neighbor_rows = neighbor_rows2
            max_sim = float(neighbor_rows["similarity"].max()) if not neighbor_rows.empty else 0.0
            if   max_sim >= 0.90: sim_level = "similarity_fallback_high"
            elif max_sim >= 0.70: sim_level = "similarity_fallback_medium"
            elif max_sim >= 0.50: sim_level = "similarity_fallback_low"
            else:                 sim_level = "manual_review"
            valid_neighbors = neighbor_rows[neighbor_rows["similarity"] >= min_similarity2]
            retried = True
            details.append(f"retry_relaxed: k={k2}, min_similarity={min_similarity2:.2f}")
            attempt_id = 2
            attempt_reason = "retry_relaxed"
            details.append(f"attempt_id={attempt_id}")
            details.append(f"attempt_reason={attempt_reason}")
        except (KeyError, TypeError, ValueError, AttributeError, IndexError):
            # keep original neighbor_rows and valid_neighbors
            pass
    # candidate lists for diagnostics
    cids = []
    ccnt = {}
    try:
        base_df = valid_neighbors if 'valid_neighbors' in locals() and not valid_neighbors.empty else neighbor_rows
        if base_df is not None and not base_df.empty:
            cids = base_df[target_col].dropna().astype(str).to_list()
            ccnt = base_df[target_col].value_counts(dropna=True).to_dict()
    except (KeyError, TypeError, ValueError, AttributeError, IndexError):
        pass
    allowed_list = _FEATURE_ID_ALLOWED
    uniq_recs = valid_neighbors[target_col].dropna().unique()
    if valid_neighbors.empty or sim_level == "manual_review":
        recommendation = _sanitize_recommendation("manual_review", allowed_list=allowed_list)
        try:
            recommendation = canonicalize_feature_id(recommendation) or recommendation
        except (TypeError, ValueError, AttributeError):
            pass
        return {
            "recommendation": recommendation,
            "matched_rows": neighbor_rows,
            "match_level": "similarity_fallback_low" if sim_level != "manual_review" else "manual_review",
            "details": details + [f"max_similarity={max_sim:.3f}", f"band={sim_level}"],
            "similarity": float(max_sim),
            "candidate_feature_ids": cids,
            "candidate_counts": ccnt,
            "attempt_id": attempt_id,
            "attempt_reason": attempt_reason,
        }
    if len(uniq_recs) == 1:
        recommendation = _sanitize_recommendation(uniq_recs[0], allowed_list=allowed_list)
        try:
            recommendation = canonicalize_feature_id(recommendation) or recommendation
        except (TypeError, ValueError, AttributeError):
            pass
        # Clinical guardrail
        sec_cols = config.get("secondary_context_columns", [])
        sec_ctx = {c: context.get(c) for c in sec_cols}
        flag_msg = _clinical_flag(context, recommendation, sec_ctx)
        if flag_msg:
            recommendation = _sanitize_recommendation("manual_review", allowed_list=allowed_list)
            try:
                recommendation = canonicalize_feature_id(recommendation) or recommendation
            except (TypeError, ValueError, AttributeError):
                pass
            return {
                "recommendation": recommendation,
                "matched_rows": valid_neighbors,
                "match_level": "manual_review",
                "details": details + [f"clinically_flagged: {flag_msg}", f"max_similarity={max_sim:.3f}", f"band={sim_level}"],
                "similarity": float(max_sim),
                "candidate_feature_ids": cids,
                "candidate_counts": ccnt,
                "attempt_id": attempt_id,
                "attempt_reason": attempt_reason,
            }
        return {
            "recommendation": recommendation,
            "matched_rows": valid_neighbors,
            "match_level": "knn_recommendation",
            "details": details + [f"unique_rec", f"max_similarity={max_sim:.3f}", f"band={sim_level}"],
            "similarity": float(max_sim),
            "candidate_feature_ids": cids,
            "candidate_counts": ccnt,
            "attempt_id": attempt_id,
            "attempt_reason": attempt_reason,
        }
    # Multiple recommendations: majority voting, set match_level to knn_recommendation
    top_rec = valid_neighbors[target_col].value_counts().idxmax()
    recommendation = _sanitize_recommendation(top_rec, allowed_list=allowed_list)
    try:
        recommendation = canonicalize_feature_id(recommendation) or recommendation
    except (TypeError, ValueError, AttributeError):
        pass
    # Clinical guardrail
    sec_cols = config.get("secondary_context_columns", [])
    sec_ctx = {c: context.get(c) for c in sec_cols}
    flag_msg = _clinical_flag(context, recommendation, sec_ctx)
    if flag_msg:
        recommendation = _sanitize_recommendation("manual_review", allowed_list=allowed_list)
        try:
            recommendation = canonicalize_feature_id(recommendation) or recommendation
        except (TypeError, ValueError, AttributeError):
            pass
        return {
            "recommendation": recommendation,
            "matched_rows": valid_neighbors,
            "match_level": "manual_review",
            "details": details + [f"clinically_flagged: {flag_msg}"],
            "similarity": float(max_sim),
            "candidate_feature_ids": cids,
            "candidate_counts": ccnt,
            "attempt_id": attempt_id,
            "attempt_reason": attempt_reason,
        }
    return {
        "recommendation": recommendation,
        "matched_rows": valid_neighbors,
        "match_level": "knn_recommendation",
        "details": details + [f"majority_vote", f"max_similarity={max_sim:.3f}", f"band={sim_level}"],
        "similarity": float(max_sim),
        "candidate_feature_ids": cids,
        "candidate_counts": ccnt,
        "attempt_id": attempt_id,
        "attempt_reason": attempt_reason,
    }

# ---------------------- Hierarchical Similarity Backoff Helper ----------------------
def recommend_by_similarity_with_backoff(
    context: dict,
    dictionary: pd.DataFrame,
    config: Optional[dict] = None,
    target_col: str = "feature_id",
    base_context_cols: Optional[list] = None,
    verbose: bool = False,
) -> dict:
    """
    Runs similarity-based recommendation with hierarchical backoff defined in config['cbf']['backoff']['secondary_contextual_columns_backoff'].
    Does not touch the core triad (bp_category, chol_category, risk_level). Each stage drops a set of secondary columns, then runs recommend_by_similarity.
    Returns the first non-manual result; otherwise, aggregates candidates for majority voting across stages.
    """
    if config is None:
        config = load_config()
    cbf_cfg = (config.get("cbf") or {})
    backoff_plan = (((cbf_cfg.get("backoff") or {}).get("secondary_contextual_columns_backoff")) or [])
    context_cols = base_context_cols
    if context_cols is None:
        try:
            from utils.constants import CONTEXT_COLUMNS as _DEF_CTX
            context_cols = list(_DEF_CTX)
        except (ImportError, ModuleNotFoundError, AttributeError):
            context_cols = ["bp_category", "chol_category", "risk_level", "fbs_cat", "cp_cat", "age_group"]
    # Identify the core triad explicitly to protect it
    core_triad = ["bp_category", "chol_category", "risk_level"]
    stages = []
    for i, drop_set in enumerate(backoff_plan, start=1):
        drop_list = [c for c in (drop_set or []) if c not in core_triad]
        stage_cols = [c for c in context_cols if c not in set(drop_list)]
        stages.append((i, drop_list, stage_cols))
    # Always include a final stage that uses only the core triad (if not already present)
    if not any(set(s[2]) == set(core_triad) for s in stages):
        stages.append((len(stages) + 1, [c for c in context_cols if c not in core_triad], core_triad))
    aggregate_cands = []
    aggregate_counts = {}
    for i, dropped, stage_cols in stages:
        res = recommend_by_similarity(
            context=context,
            dictionary=dictionary,
            target_col=target_col,
            context_cols=stage_cols,
            verbose=verbose,
            config=config,
            details=[f"backoff_stage={i}", f"dropped={dropped}"]
        )
        # Tag match_level if it's a similarity path
        if isinstance(res, dict):
            res.setdefault("candidate_feature_ids", [])
            res.setdefault("candidate_counts", {})
            res.setdefault("similarity", 0.0)
            if res.get("match_level", "").startswith("similarity") or res.get("match_level") in {"knn_recommendation"}:
                res["match_level"] = f"similarity_backoff_{i}"
            # Aggregate for majority vote if still manual/unresolved
            if res.get("recommendation") and res["recommendation"] != "manual_review":
                return res
            # else accumulate candidates
            for cid in res.get("candidate_feature_ids", []) or []:
                aggregate_cands.append(str(cid))
            for k, v in (res.get("candidate_counts") or {}).items():
                aggregate_counts[k] = aggregate_counts.get(k, 0) + int(v)
    # If all stages failed, majority vote over aggregates
    if aggregate_cands:
        from collections import Counter
        cnt = Counter(aggregate_cands)
        best = cnt.most_common(1)[0][0]
        return {
            "recommendation": _sanitize_recommendation(best, allowed_list=_FEATURE_ID_ALLOWED),
            "matched_rows": None,
            "match_level": "similarity_backoff_vote",
            "details": ["majority_vote_after_backoff"],
            "similarity": 0.0,
            "candidate_feature_ids": list(cnt.keys()),
            "candidate_counts": {k: int(v) for k, v in cnt.items()}
        }
    # Final manual review
    return {
        "recommendation": _sanitize_recommendation("manual_review", allowed_list=_FEATURE_ID_ALLOWED),
        "matched_rows": None,
        "match_level": "manual_review",
        "details": ["no_result_after_backoff"],
        "similarity": 0.0,
        "candidate_feature_ids": [],
        "candidate_counts": {}
    }

def fallback_knn_recommendation(
    context_row: dict,
    df_train: pd.DataFrame,
    context_cols: list[str],
    secondary_cols: list[str] | None = None,
    n_neighbors: int = 5,
    min_similarity: float = 0.7,
    return_k_neighbors: bool = False,
) -> dict:
    """
    KNN fallback recommendation: Returns best feature_id recommendation if exact match failed.
    • Inputs:
      - context_row: dict of the test context (normalized!)
      - df_train: training DataFrame (must contain context_cols, secondary_cols, target_col)
      - context_cols: main context columns
      - secondary_cols: additional columns (can be [])
      - n_neighbors: number of neighbors for fallback search
      - target_col: label/response column (default: feature_id)
      - min_similarity: threshold (0-1), otherwise returns 'manual_review'
      - return_k_neighbors: if True, always include the top-k nearest neighbor rows (with similarity) in the output dict under "neighbor_rows", regardless of filtering by min_similarity.
    • Output: dict with recommendation and trace.

    Advanced usage: If return_k_neighbors=True, the output will always include a "neighbor_rows" key containing the DataFrame of top-k nearest neighbors (with similarity), even if they do not meet min_similarity. This is useful for advanced debugging or review scenarios, to inspect all neighbor similarities regardless of filtering.

    Returns:
        dict: {
            "recommendation": ...,
            "matched_rows": ...,
            "match_level": ...,
            "details": ...,
            "neighbor_rows": ... (if return_k_neighbors=True)
        }
    """
    """
    KNN fallback recommendation: Returns best feature_id recommendation if exact match failed.
    """

    def _dbg(_m: str):
        if _CBF_LOGGER is not None:
            try:
                _CBF_LOGGER.debug(_m)
            except (TypeError, ValueError):
                print(_m)
        else:
            print(_m)

    # Ensure details list exists and register initial attempt metadata
    details = []
    attempt_id = 1
    attempt_reason = "initial"
    details.append(f"attempt_id={attempt_id}")
    details.append(f"attempt_reason={attempt_reason}")

    target_col: str = "feature_id"
    # Start message (concise)
    _dbg(
        f"[fallback_knn_recommendation] n_neighbors={n_neighbors}, min_similarity={min_similarity}, return_k_neighbors={return_k_neighbors}")

    if secondary_cols is None:
        secondary_cols = []
    cols = [*context_cols, *secondary_cols]
    cols = [c for c in cols if c in df_train.columns]

    # 1. Normalize all values before any comparison or key generation
    train_df = _fill_unknown_safe(df_train[cols], cols)
    for c in train_df.columns:
        train_df[c] = train_df[c].map(normalize_context_value)
    test_df = _fill_unknown_safe(pd.DataFrame([context_row], columns=cols), cols)
    for c in test_df.columns:
        test_df[c] = test_df[c].map(normalize_context_value)

    # Ensure matching columns
    train_df = pd.get_dummies(train_df)
    test_df = pd.get_dummies(test_df)
    test_df = test_df.reindex(columns=train_df.columns, fill_value=0)

    allowed_list = _FEATURE_ID_ALLOWED
    if train_df.shape[0] == 0:
        msg = "No training data for KNN fallback."
        _dbg(msg)
        recommendation = "manual_review"
        recommendation = _sanitize_recommendation(recommendation, allowed_list=allowed_list)
        # ensure details carries the message rather than replacing it
        details.append(msg)
        result: Dict[str, Any] = {
            "recommendation": recommendation,
            "details": details,
            "match_level": "empty",
            "matched_rows": None,
            "similarity": 0.0,
        }
        if return_k_neighbors:
            k_neighbors: List[Dict[str, Any]] = []
            result["k_neighbors"] = k_neighbors
        return result
    n_neighbors = min(n_neighbors, len(train_df))
    nbrs = NearestNeighbors(n_neighbors=n_neighbors, metric='hamming')
    nbrs.fit(train_df.values)
    dists, indices = nbrs.kneighbors(test_df.values)
    similarities = 1 - dists[0]
    neighbor_rows = df_train.iloc[indices[0]].copy()
    neighbor_rows["similarity"] = similarities
    # Ensure similarity is numeric for safe aggregations
    neighbor_rows["similarity"] = pd.to_numeric(neighbor_rows["similarity"], errors="coerce")
    # Aggregate similarity summary for return payloads (internal use)
    try:
        _max_sim_knn = float(neighbor_rows["similarity"].max()) if not neighbor_rows.empty else 0.0
    except (TypeError, ValueError, KeyError):
        _max_sim_knn = 0.0
    # 4. Filter by min_similarity, but NEVER drop any duplicate/conflict rows, only annotate
    valid_neighbors = neighbor_rows[neighbor_rows["similarity"] >= min_similarity]
    # --- Retry once with relaxed params if no valid neighbors ---
    attempt_id = 1
    attempt_reason = "initial"
    retried = False
    if valid_neighbors.empty:
        min_similarity2 = max(0.0, float(min_similarity) - 0.05)
        n_neighbors2 = int(min(n_neighbors + 2, len(train_df)))
        try:
            nbrs2 = NearestNeighbors(n_neighbors=n_neighbors2, metric='hamming')
            nbrs2.fit(train_df.values)
            d2, i2 = nbrs2.kneighbors(test_df.values)
            sims2 = 1 - d2[0]
            neighbor_rows2 = df_train.iloc[i2[0]].copy()
            neighbor_rows2["similarity"] = sims2
            neighbor_rows = neighbor_rows2
            # recompute max and valid set
            try:
                _max_sim_knn = float(neighbor_rows["similarity"].max()) if not neighbor_rows.empty else 0.0
            except (TypeError, ValueError, KeyError):
                _max_sim_knn = 0.0
            valid_neighbors = neighbor_rows[neighbor_rows["similarity"] >= min_similarity2]
            details = [
                f"KNN neighbors: {neighbor_rows[[*cols, 'similarity', target_col]].to_dict('records')}",
                f"retry_relaxed: n_neighbors={n_neighbors2}, min_similarity={min_similarity2:.2f}"
            ]
            retried = True
            attempt_id = 2
            attempt_reason = "retry_relaxed"
            details.append(f"attempt_id={attempt_id}")
            details.append(f"attempt_reason={attempt_reason}")
        except (KeyError, TypeError, ValueError, AttributeError, IndexError):
            pass
    else:
        details = [f"KNN neighbors: {neighbor_rows[[*cols, 'similarity', target_col]].to_dict('records')}"]
    _dbg(
        f"[fallback_knn_recommendation] All neighbors (top-{n_neighbors}): {neighbor_rows[[*cols, 'similarity', target_col]].to_dict('records')}")
    # Candidate diagnostics for all return branches
    cids = []
    ccnt = {}
    try:
        base_df = valid_neighbors if 'valid_neighbors' in locals() and not valid_neighbors.empty else neighbor_rows
        if base_df is not None and not base_df.empty:
            cids = base_df[target_col].dropna().astype(str).to_list()
            ccnt = base_df[target_col].value_counts(dropna=True).to_dict()
    except (KeyError, TypeError, ValueError, AttributeError, IndexError):
        pass
    # If no valid neighbor, recommend manual_review and log
    if valid_neighbors.empty:
        details.append("No neighbor has similarity >= min_similarity; returning fallback based on max similarity band.")
        recommendation = _sanitize_recommendation("manual_review", allowed_list=allowed_list)
        _match_level = "similarity_fallback_low" if float(_max_sim_knn) >= 0.5 else "manual_review"
        result: Dict[str, Any] = {
            "recommendation": recommendation,
            "matched_rows": neighbor_rows,
            "match_level": _match_level,
            "details": details,
            "similarity": float(_max_sim_knn),
            "candidate_feature_ids": cids,
            "candidate_counts": ccnt,
            "attempt_id": attempt_id,
            "attempt_reason": attempt_reason,
        }
        if return_k_neighbors:
            try:
                _records = neighbor_rows.to_dict(orient="records")
                k_neighbors: List[Dict[str, Any]] = []
                if isinstance(_records, list):
                    for row in _records:
                        if isinstance(row, dict):
                            # نُجبر المفاتيح لتكون str حتى يرضى الفاحص
                            k_neighbors.append({str(k): v for k, v in row.items()})
                result["k_neighbors"] = k_neighbors
            except (AttributeError, TypeError, ValueError):
                result["k_neighbors"] = []
        return result
    uniq = valid_neighbors[target_col].dropna().unique()
    # If only one unique recommendation among valid neighbors, return it
    if len(uniq) == 1:
        recommendation = uniq[0]
        recommendation = _sanitize_recommendation(recommendation, allowed_list=allowed_list)
        # Clinical guardrail
        sec_cols = list(secondary_cols) if isinstance(secondary_cols, list) else []
        sec_ctx = {c: context_row.get(c) for c in sec_cols}
        flag_msg = _clinical_flag(context_row, recommendation, sec_ctx)
        if flag_msg:
            recommendation = _sanitize_recommendation("manual_review", allowed_list=allowed_list)
            result = {
                "recommendation": recommendation,
                "matched_rows": valid_neighbors,
                "match_level": "manual_review",
                "details": details + [f"clinically_flagged: {flag_msg}"],
                "similarity": float(_max_sim_knn),
                "candidate_feature_ids": cids,
                "candidate_counts": ccnt,
                "attempt_id": attempt_id,
                "attempt_reason": attempt_reason,
            }
            if return_k_neighbors:
                try:
                    _records = neighbor_rows.to_dict(orient="records")
                    k_neighbors: List[Dict[str, Any]] = []
                    if isinstance(_records, list):
                        for row in _records:
                            if isinstance(row, dict):
                                # نُجبر المفاتيح لتكون str حتى يرضى الفاحص
                                k_neighbors.append({str(k): v for k, v in row.items()})
                    result["k_neighbors"] = k_neighbors
                except (AttributeError, TypeError, ValueError):
                    result["k_neighbors"] = []
            return result
        result: Dict[str, Any] = {
            "recommendation": recommendation,
            "matched_rows": valid_neighbors,
            "match_level": "knn_recommendation",
            "details": ["unique_recommendation"],
            "similarity": float(_max_sim_knn),
            "candidate_feature_ids": cids,
            "candidate_counts": ccnt,
            "attempt_id": attempt_id,
            "attempt_reason": attempt_reason,
        }
        if return_k_neighbors:
            try:
                _records = neighbor_rows.to_dict(orient="records")
                k_neighbors: List[Dict[str, Any]] = []
                if isinstance(_records, list):
                    for row in _records:
                        if isinstance(row, dict):
                            # نُجبر المفاتيح لتكون str حتى يرضى الفاحص
                            k_neighbors.append({str(k): v for k, v in row.items()})
                result["k_neighbors"] = k_neighbors
            except (AttributeError, TypeError, ValueError):
                result["k_neighbors"] = []
        return result
    # If multiple recommendations, do majority voting with similarity tiebreak
    from collections import Counter
    cnt = Counter(valid_neighbors[target_col])
    def _feat_key(item):
        feat, count = item
        sim_vals = pd.to_numeric(
            valid_neighbors.loc[valid_neighbors[target_col] == feat, "similarity"],
            errors="coerce"
        )
        sim_mean = float(sim_vals.mean()) if sim_vals.notna().any() else 0.0
        return count, sim_mean
    best_feat = max(cnt.items(), key=_feat_key)[0]
    # Sanitize the selected recommendation to avoid leaking invalid labels
    best_feat = _sanitize_recommendation(best_feat, allowed_list=allowed_list)
    recommendation = best_feat
    # Clinical guardrail
    sec_cols = list(secondary_cols) if isinstance(secondary_cols, list) else []
    sec_ctx = {c: context_row.get(c) for c in sec_cols}
    flag_msg = _clinical_flag(context_row, recommendation, sec_ctx)
    if flag_msg:
        recommendation = _sanitize_recommendation("manual_review", allowed_list=allowed_list)
        result = {
            "recommendation": recommendation,
            "matched_rows": valid_neighbors,
            "match_level": "manual_review",
            "details": details + [f"clinically_flagged: {flag_msg}"],
            "similarity": float(_max_sim_knn),
            "candidate_feature_ids": cids,
            "candidate_counts": ccnt,
            "attempt_id": attempt_id,
            "attempt_reason": attempt_reason,
        }
        if return_k_neighbors:
            try:
                _records = neighbor_rows.to_dict(orient="records")
                k_neighbors: List[Dict[str, Any]] = []
                if isinstance(_records, list):
                    for row in _records:
                        if isinstance(row, dict):
                            # نُجبر المفاتيح لتكون str حتى يرضى الفاحص
                            k_neighbors.append({str(k): v for k, v in row.items()})
                result["k_neighbors"] = k_neighbors
            except (AttributeError, TypeError, ValueError):
                result["k_neighbors"] = []
        return result
    details.append("majority_voting_with_similarity_tiebreak")
    result: Dict[str, Any] = {
        "recommendation": recommendation,
        "matched_rows": valid_neighbors,
        "match_level": "knn_recommendation",
        "details": details,
        "similarity": float(_max_sim_knn),
        "candidate_feature_ids": cids,
        "candidate_counts": ccnt,
        "attempt_id": attempt_id,
        "attempt_reason": attempt_reason,
    }
    if return_k_neighbors:
        try:
            _records = neighbor_rows.to_dict(orient="records")
            k_neighbors: List[Dict[str, Any]] = []
            if isinstance(_records, list):
                for row in _records:
                    if isinstance(row, dict):
                        # نُجبر المفاتيح لتكون str حتى يرضى الفاحص
                        k_neighbors.append({str(k): v for k, v in row.items()})
            result["k_neighbors"] = k_neighbors
        except (AttributeError, TypeError, ValueError):
            result["k_neighbors"] = []
    return result


# -------------------------------------------------------------------------
# الدالة المركزية المتقدمة لحل تعارضات true_response سياقيًا
# يجب استدعاؤها من pipeline و cbf عند معالجة أو إعداد بيانات التوصية الطبية
# -------------------------------------------------------------------------
def resolve_true_response_conflict(
    df: pd.DataFrame,
    core_cols: list,
    secondary_cols: list,
    target_col: str = "true_response",
    review_label: str = "manual_review",
    verbose: bool = False,
    full_context_df: Optional[pd.DataFrame] = None
) -> pd.DataFrame:
    """
    الدالة المركزية المتقدمة لحل تعارضات true_response بشكل متسلسل باستخدام الأعمدة السياقية الرئيسية والثانوية.
    • تبدأ بمحاولة تطابق صارم على الأعمدة الرئيسية.
    • عند وجود تعارض (تكرار أكثر من true_response لنفس المفتاح) تضيق تدريجيًا باستخدام الأعمدة الثانوية واحدة تلو الأخرى، ثم جميعها دفعة واحدة.
    • إذا بقي التعارض: توسم manual_review مع تسجيل السبب.
    • تعيد DataFrame جديد فيه عمود final_true_response وعمود match_level وdetails.
    • قبل أي عملية groupby على الأعمدة الثانوية (أو جميعها)، إذا كان العمود المطلوب غير موجود أو يحوي جميع القيم NaN/unknown، تتم محاولة استرجاعه من ملف outputs/tmp/df_contextualized.csv (أو من full_context_df إذا مرر)، عبر الدمج على patient_id (إذا متوفر).
    • يتم توثيق/طباعة كل عملية استرجاع.
    • وسيط full_context_df يتيح تمرير DataFrame كامل للسياق لتسريع الاسترجاع، وإذا لم يُمرر يُحمّل تلقائيًا.

    Returns:
        pd.DataFrame بنفس الصفوف مع الأعمدة المضافة:
            - final_true_response
            - match_level (core/secondary_{col}/all_secondary/manual_review)
            - details (تسلسل القرارات)
    """
    import copy
    import os
    results = []
    # تأكد من تطبيع جميع الأعمدة المستعملة
    def _norm(val):
        if val is None:
            return "unknown"
        sval = str(val).strip().lower().replace(" ", "_")
        return sval if sval else "unknown"
    norm_df = df.copy()
    # --- استرجاع الأعمدة الثانوية الناقصة أو الفارغة من ملف السياق الكامل ---
    # تحميل df_contextualized فقط إذا لزم الأمر
    # helper to check if a column is missing or all unknown/NaN
    def _col_missing_or_unknown(df_in, col_in):
        if col_in not in df_in.columns:
            return True
        colvals = df_in[col_in]
        s = colvals.astype(str).str.strip().str.lower()
        # Compute booleans via Series reductions to avoid IDE/type check ambiguity
        all_na = bool(colvals.isna().all())
        s2 = s.replace({"nan": "unknown"})
        all_unknown = bool(s2.eq("unknown").all())
        return all_na or all_unknown
    # load full_context_df if needed
    if full_context_df is None:
        context_path = "outputs/tmp/df_contextualized.csv"
        if os.path.exists(context_path):
            try:
                full_context_df = pd.read_csv(context_path)
            except (OSError, pd.errors.EmptyDataError, pd.errors.ParserError) as e:
                print(f"[resolve_true_response_conflict] ⚠️ Failed to read {context_path}: {e}")
                full_context_df = None
        else:
            full_context_df = None
    # استرجاع الأعمدة الثانوية الناقصة أو الفارغة واحدة تلو الأخرى
    for col in secondary_cols:
        if _col_missing_or_unknown(norm_df, col):
            if (
                full_context_df is not None
                and "patient_id" in norm_df.columns
                and "patient_id" in full_context_df.columns
                and col in full_context_df.columns
            ):
                # prepare a deterministic DataFrame slice before merge to satisfy static analyzers
                before = norm_df.shape[1]
                # Static type guard to satisfy IDE linters (full_context_df is guaranteed non-None here)
                assert isinstance(full_context_df, pd.DataFrame)
                ctx_pair_df = full_context_df.loc[:, ["patient_id", col]].drop_duplicates()
                norm_df = norm_df.merge(
                    ctx_pair_df,
                    on="patient_id",
                    how="left",
                    suffixes=("", "_retrieved")
                )
                # prefer retrieved if original missing
                if col + "_retrieved" in norm_df.columns:
                    mask_missing = norm_df[col].isnull() | (norm_df[col].astype(str).str.lower() == "unknown")
                    norm_df.loc[mask_missing, col] = norm_df.loc[mask_missing, col + "_retrieved"]
                    norm_df = norm_df.drop(columns=[col + "_retrieved"])
                print(f"[resolve_true_response_conflict] استعانة بالعمود '{col}' من df_contextualized عبر patient_id ({norm_df.shape[1]-before:+} عمود).")
            else:
                print(f"[resolve_true_response_conflict] ⚠️ العمود '{col}' مفقود أو unknown بالكامل ولا يمكن استرجاعه (لا يوجد df_contextualized أو patient_id أو العمود المطلوب).")
    # تحقق من جميع الأعمدة الثانوية دفعة واحدة إذا كلها ناقصة أو unknown
    if secondary_cols:
        all_sec_missing = all(_col_missing_or_unknown(norm_df, c) for c in secondary_cols)
        if all_sec_missing:
            if (
                full_context_df is not None
                and "patient_id" in norm_df.columns
                and all(c in full_context_df.columns for c in secondary_cols)
            ):
                before = norm_df.shape[1]
                merge_cols = ["patient_id"] + list(secondary_cols)
                if full_context_df is not None and all(c in full_context_df.columns for c in merge_cols):
                    # prepare a deterministic DataFrame slice before merge to satisfy static analyzers
                    assert isinstance(full_context_df, pd.DataFrame)
                    ctx_block_df = full_context_df.loc[:, merge_cols].drop_duplicates()
                    norm_df = norm_df.merge(
                        ctx_block_df,
                        on="patient_id",
                        how="left",
                        suffixes=("", "_retrieved")
                    )
                    # for each col, fill missing/unknown from retrieved
                    for col in secondary_cols:
                        col_retr = col + "_retrieved"
                        if col_retr in norm_df.columns:
                            mask_missing = norm_df[col].isnull() | (norm_df[col].astype(str).str.lower() == "unknown")
                            norm_df.loc[mask_missing, col] = norm_df.loc[mask_missing, col_retr]
                            norm_df = norm_df.drop(columns=[col_retr])
                    print(f"[resolve_true_response_conflict] استعانة بجميع الأعمدة الثانوية دفعة واحدة من df_contextualized عبر patient_id ({norm_df.shape[1]-before:+} عمود).")
                else:
                    print(f"[resolve_true_response_conflict] ⚠️ جميع الأعمدة الثانوية ناقصة/unknown بالكامل ولا يمكن استرجاعها (df_contextualized لا يحوي جميع الأعمدة المطلوبة).")
            else:
                print(f"[resolve_true_response_conflict] ⚠️ جميع الأعمدة الثانوية ناقصة/unknown بالكامل ولا يمكن استرجاعها (لا يوجد df_contextualized أو patient_id أو جميع الأعمدة المطلوبة).")
    # تطبيع الأعمدة
    for col in core_cols + secondary_cols:
        if col in norm_df.columns:
            norm_df[col] = norm_df[col].map(_norm)
    # groupby على الأعمدة الأساسية والثانوية بالتدريج
    # group_cols_seq = [core_cols] + [[*core_cols, col] for col in secondary_cols] + [[*core_cols, *secondary_cols]]
    grouped = norm_df.groupby(core_cols, observed=True, sort=False)
    # [Patch] معالجة مشكلة القيم غير القابلة للتجزئة (مثل list/tuple) في عمود true_response لمنع TypeError عند استخدام unique().
    def _flatten_if_list(val):
        if isinstance(val, (list, tuple)):
            if len(val) == 1:
                return val[0]
            else:
                return review_label  # أو حسب منطقك السريري
        return val
    for core_key, group in grouped:
        # لكل مجموعة أساسية: تابع تضييق التعارض
        group_target_flat = group[target_col].apply(_flatten_if_list)
        unique_responses = pd.Series(group_target_flat).dropna().unique()
        trace = [f"Core: {core_key} -> {len(unique_responses)} responses"]
        final_val = None
        level = "core"
        # إذا فقط واحدة: نعتمدها مباشرة
        if len(unique_responses) == 1:
            final_val = unique_responses[0]
            trace.append(f"Resolved at core: {final_val}")
        else:
            # جرب تدريجيًا الأعمدة الثانوية واحدة تلو الأخرى
            resolved = False
            for col in secondary_cols:
                # تحقق من وجود العمود وعدم كونه unknown بالكامل في هذه المجموعة
                if _col_missing_or_unknown(group, col):
                    trace.append(f"Column '{col}' missing/unknown for group; skip.")
                    continue
                sub_groups = group.groupby(col, observed=True, sort=False)
                for sec_val, sub_group in sub_groups:
                    sub_group_target_flat = sub_group[target_col].apply(_flatten_if_list)
                    uniq_res_sec = pd.Series(sub_group_target_flat).dropna().unique()
                    if len(uniq_res_sec) == 1 and len(sub_group) == len(group):
                        final_val = uniq_res_sec[0]
                        level = f"secondary_{col}"
                        trace.append(f"Resolved at {col}: {final_val}")
                        resolved = True
                        break
                if resolved:
                    break
            # إذا لم يُحل: جرب كل الأعمدة الثانوية دفعة واحدة
            if not resolved and secondary_cols:
                # تحقق أن جميع الأعمدة الثانوية متوفرة وغير unknown بالكامل
                if all(c in group.columns and not _col_missing_or_unknown(group, c) for c in secondary_cols):
                    sec_group = group.groupby(secondary_cols, observed=True, sort=False)
                    for sec_keys, sec_group_df in sec_group:
                        sec_group_target_flat = sec_group_df[target_col].apply(_flatten_if_list)
                        uniq_res_all = pd.Series(sec_group_target_flat).dropna().unique()
                        if len(uniq_res_all) == 1 and len(sec_group_df) == len(group):
                            final_val = uniq_res_all[0]
                            level = "all_secondary"
                            trace.append(f"Resolved at all_secondary: {final_val}")
                            resolved = True
                            break
                else:
                    trace.append("All secondary columns missing/unknown for group; skip all_secondary.")
            # إذا بقي التعارض: manual_review
            if not resolved:
                final_val = review_label
                level = "manual_review"
                trace.append("Unresolved after all steps → manual_review")
        # ضع النتيجة لجميع الصفوف في المجموعة
        for idx, row in group.iterrows():
            result_row = copy.deepcopy(row.to_dict())
            result_row['final_true_response'] = final_val
            result_row['match_level'] = level
            result_row['details'] = " | ".join(trace)
            results.append(result_row)
    # بناء DataFrame جديد
    result_df = pd.DataFrame(results)
    if verbose:
        print("== Conflict resolution summary ==")
        print(result_df['match_level'].value_counts())
    return result_df

# تعريف جميع الدوال والأدوات العامة في الملف
__all__ = [
    "make_context_key",
    "resolve_context_key",
    "encode_context_features_cbf",
    "aggregate_contextual_groupings",
    "compute_context_similarity",
    "get_top_k_similar_contexts",
    "check_context_coverage",
    "log_contextual_stats",
    "export_uncovered_context_keys",
    "normalize_context_value",
    "cbf_split_data",
    "hide_sensitive_columns",
    "find_best_contextual_recommendation",
    "recommend_by_similarity",
    "fallback_knn_recommendation",
    "resolve_true_response_conflict",
    "pick_score_col",
    "evaluate_recommendations_loco",
    "evaluate_recommendations_loco_family",
    "prob_from_similarity",
    "fit_and_save_isotonic",
    "apply_isotonic_if_available",
    "apply_cbf_narratives",
    "_cap_topk_per_patient",
    "cap_topk_per_patient"
]

# === Unified narrative source of truth (reason -> explanation/advice/source) ===
from typing import Dict as _Dict
import pandas as _pd

def normalize_reason(raw: str) -> str:
    """
    Normalize raw reason labels to a compact set consumed by narrative generators.
    Returns one of: exact_or_context / knn / knn_fallback / final_fallback / unknown
    """
    r = (str(raw) if raw is not None else "").strip().lower()
    if r in {"recommended", "context_key_match", "exact", "contextual_rule", "context"}:
        return "exact_or_context"
    if r in {"knn_recommendation", "knn"}:
        return "knn"
    if r in {"knn_fallback", "similarity_fallback",
             "similarity_fallback_high", "similarity_fallback_medium", "similarity_fallback_low"}:
        return "knn_fallback"
    if r in {"final_fallback", "manual_review", "fallback"}:
        return "final_fallback"
    return "unknown"

def _advice_for_feature_id(_feat: str, _risk: str) -> str:
    """Lightweight advice text based on coarse feature category; risk softeners added below."""
    feat = (str(_feat) if _feat is not None else "").strip().lower()
    lifestyle = {"increase_exercise", "diet_control", "lifestyle_monitoring"}
    pharm     = {"amlodipine", "ace_inhibitor", "amlodipine_and_thiazide", "beta_blocker"}
    if feat in lifestyle:
        if feat == "increase_exercise":
            base = "نشاط بدني منتظم (≈150 دقيقة/أسبوع) ثم إعادة تقييم خلال 4–6 أسابيع."
        elif feat == "diet_control":
            base = "تقليل الصوديوم، حمية DASH، متابعة قياسات الضغط والدهون دورياً."
        else:
            base = "إجراءات نمط الحياة والمتابعة المنتظمة للضغط."
    elif feat in pharm:
        base = "مناقشة بدء/تعديل العلاج الدوائي الملائم، مع مراقبة الضغط والأعراض."
    else:
        base = "اتبع الإرشادات السريرية المناسبة مع متابعة قريبة."
    risk = (str(_risk) if _risk is not None else "").strip().lower()
    if risk == "high":
        base += " الحالة تُظهر خطورة مرتفعة؛ يُفضّل المتابعة اللصيقة."
    elif risk == "medium":
        base += " الحالة متوسطة الخطورة؛ فضّل تحسين نمط الحياة وإعادة التقييم قريباً."
    return base

def make_narratives(row: "_pd.Series") -> _Dict[str, str]:
    """Return a dict with explanation, advice, source derived only from normalized reason and context fields."""
    rs = normalize_reason(row.get("reason", ""))
    risk = str(row.get("risk_level", "")).strip().lower()
    feat = str(row.get("feature_id", "")).strip().lower()

    # Source mapping (strict)
    if rs == "exact_or_context":
        source = "CBF (exact/context match)"
    elif rs == "knn":
        source = "CBF (kNN)"
    elif rs == "knn_fallback":
        source = "CBF (fallback)"
    elif rs == "final_fallback":
        source = "CBF (final fallback)"
    else:
        source = "CBF"

    # Explanation tuned to reason
    if rs == "exact_or_context":
        explanation = "تطابق مباشر/سياقي مع أنماط سريرية مماثلة في النظام."
    elif rs == "knn":
        explanation = "توصية قائمة على أقرب سياقات مشابهة (kNN) ضمن CBF."
    elif rs == "knn_fallback":
        explanation = "توصية بالاعتماد على تشابه سياقي مقبول عند غياب تطابق مباشر."
    elif rs == "final_fallback":
        explanation = "تعذر إيجاد تطابقات كافية؛ هذه توصية احتياطية اعتماداً على مؤشرات عامة."
    else:
        explanation = "توصية مبنية على الترشيح المعتمد على المحتوى (CBF)."

    advice = _advice_for_feature_id(feat, risk)
    return {"explanation": explanation, "advice": advice, "source": source}

def populate_narratives(df: "_pd.DataFrame") -> "_pd.DataFrame":
    """
    Fill narrative fields only where empty: explanation, explanation_clinical, advice, source.
    explanation_clinical is set equal to explanation for backward-compat on newly filled rows.
    """
    if df is None or len(df) == 0:
        return df
    # Ensure columns exist
    for c in ("explanation", "explanation_clinical", "advice", "source"):
        if c not in df.columns:
            df[c] = _pd.NA
    # Mask of rows requiring backfill
    def _is_blank(s):
        try:
            return s.isna() | (s.astype(str).str.strip() == "")
        except (AttributeError, TypeError, ValueError):
            return s.isna()
    m_exp = _is_blank(df["explanation"]) if "explanation" in df.columns else None
    need_idx = m_exp.index[m_exp] if m_exp is not None else df.index
    if len(need_idx) == 0:
        return df
    rows = df.loc[need_idx].apply(make_narratives, axis=1)
    if len(rows) > 0:
        out = _pd.DataFrame(list(rows), index=rows.index)
        for col in ("explanation", "advice", "source"):
            df.loc[out.index, col] = out[col]
        # explanation_clinical mirrors explanation for the rows we just filled
        df.loc[out.index, "explanation_clinical"] = out["explanation"]
    return df

def assert_narrative_consistency(df: "_pd.DataFrame", log) -> "_pd.DataFrame":
    """Safety net: forbid any 'fallback' source under knn/context reasons; fix to generic 'CBF'."""
    if df is None or len(df) == 0:
        return df
    try:
        r = df["reason"].astype(str).str.lower().fillna("")
        s = df["source"].astype(str).str.lower().fillna("")
        bad = (r.isin(["knn_recommendation", "context_key_match"]) & s.str.contains("fallback"))
        if bad.any():
            try:
                log.warning("[CBF][narrative-consistency] Fixing %d row(s) with fallback source under non-fallback reason.", int(bad.sum()))
            except (AttributeError, TypeError, ValueError):
                pass
            df.loc[bad, "source"] = df.loc[bad, "source"].replace(to_replace=r".*", value="CBF", regex=True)
    except (KeyError, AttributeError, TypeError, ValueError):
        return df
    return df

# ——— Export ———
try:
    __all__  # noqa
    if "normalize_reason" not in __all__:
        __all__.extend(["normalize_reason", "make_narratives", "populate_narratives", "assert_narrative_consistency"])
except NameError:
    __all__ = ["normalize_reason", "make_narratives", "populate_narratives", "assert_narrative_consistency"]


# ============================== Evaluation Utilities (shared CF/CBF) ==============================
import pandas as pd

def pick_score_col(
    preds: Union[pd.DataFrame, Mapping[str, Any]],
    score_col: Optional[str] = None
) -> Optional[str]:
    """
    يختار عمود الدرجة للاستخدام في الترتيب/التقييم.
    الأولوية: score_col (إن كان صالحًا) ← score_cbf ← score_cf ← score ← None
    """
    # استخرج قائمة الأعمدة بشكل متسامح (DataFrame أو شبيه قاموسي)
    if isinstance(preds, pd.DataFrame):
        cols = preds.columns
    else:
        cols = getattr(preds, "keys", None)
        cols = cols() if callable(cols) else cols
        # fallback أخير: None إذا لم نستطع الحصول على أعمدة
        if cols is None:
            return score_col if score_col else None

    # 1) إن مُرِّر score_col وكان موجودًا فعلاً
    if score_col and score_col in cols:
        return score_col

    # 2) تفضيل CBF ثم CF ثم الاسم العام
    for c in ("score_cbf", "score_cf", "score"):
        if c in cols:
            return c

    # لا يوجد عمود درجة معروف
    return None

def _ensure_cols(df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    """Ensure columns exist as columns (not index); if found in index, move them back."""
    if not isinstance(df, pd.DataFrame):
        raise TypeError("preds/df_ctx must be a pandas DataFrame")
    out = df
    # If any requested col is in the index names, reset_index to bring them back
    idx_names = [n for n in list(getattr(out.index, "names", [])) if n is not None]
    if any(c in idx_names for c in cols):
        out = out.reset_index()
    missing = [c for c in cols if c not in out.columns]
    if missing:
        raise KeyError(f"Missing required columns: {missing}")
    return out

def _cap_topk_per_patient(df: pd.DataFrame, k: int, patient_col: str, feature_col: str, score_col: Optional[str]) -> pd.DataFrame:
    """Sort by score desc within patient and cap top-k unique (patient, feature)."""
    if k is None or k <= 0:
        return df.copy()
    if score_col is None or score_col not in df.columns:
        # fall back to deterministic order
        return (df.sort_values([patient_col, feature_col])
                  .drop_duplicates(subset=[patient_col, feature_col])
                  .groupby(patient_col, group_keys=False)
                  .head(k))
    df2 = df.copy()
    df2[score_col] = pd.to_numeric(df2[score_col], errors="coerce").fillna(0.0)
    df2 = (df2.sort_values([patient_col, score_col], ascending=[True, False])
               .drop_duplicates(subset=[patient_col, feature_col])
               .groupby(patient_col, group_keys=False)
               .head(k))
    return df2

# --- CBF-centric, linter-friendly cap_topk_per_patient ---
from typing import Optional  # ensure Optional is available at top of file

def cap_topk_per_patient(
    df: pd.DataFrame,
    k: int = 5,
    patient_col: str = "patient_id",
    feature_col: str = "feature_id",
    score_col: Optional[str] = None,
) -> pd.DataFrame:
    """
    Public wrapper around `_cap_topk_per_patient`.

    Defaults to **CBF** column when available:
      1) score_cbf → 2) score_cf → 3) score → None (stable order only)

    Parameters mirror the private helper to preserve call sites. Using Optional[str] for
    `score_col` avoids accidental CF bias and silences "shadows from outer scope" in some linters.
    """
    # Auto-pick a sensible score column if none was provided
    if score_col is None and isinstance(df, pd.DataFrame):
        for c in ("score_cbf", "score_cf", "score"):
            if c in df.columns:
                score_col = c
                break
    return _cap_topk_per_patient(
        df, k=k, patient_col=patient_col, feature_col=feature_col, score_col=score_col
    )

def _build_truth_map(df_ctx: pd.DataFrame, patient_col: str, feature_col: str, true_col: str) -> Dict[Any, Set[Any]]:
    """Return mapping patient_id -> set of true positive features."""
    dfc = df_ctx.copy()
    dfc[true_col] = pd.to_numeric(dfc[true_col], errors="coerce").fillna(0).astype(int)
    dfc = dfc[dfc[true_col] == 1]
    truth_map: Dict[Any, Set[Any]] = {}
    for pid, sub in dfc.groupby(patient_col):
        truth_map[pid] = set(sub[feature_col].astype(str))
    return truth_map

def _build_truth_family_map(df_ctx: pd.DataFrame, patient_col: str, family_col: str, true_col: str) -> Dict[Any, Set[Any]]:
    """Return mapping patient_id -> set of positive families."""
    dfc = df_ctx.copy()
    dfc[true_col] = pd.to_numeric(dfc[true_col], errors="coerce").fillna(0).astype(int)
    dfc = dfc[dfc[true_col] == 1]
    fam_map: Dict[Any, Set[Any]] = {}
    for pid, sub in dfc.groupby(patient_col):
        fam_map[pid] = set(sub[family_col].astype(str))
    return fam_map

def _rank_calibration_inplace(preds: pd.DataFrame, patient_col: str, score_col: Optional[str], use_eval_score_calibration: bool = True) -> Tuple[pd.DataFrame, Optional[str]]:
    """
    Adds 'score_eval' by rank-normalization per patient to break ties if enabled and a score_col exists.
    Returns (preds_df, score_to_use).
    """
    if not use_eval_score_calibration or score_col is None or score_col not in preds.columns:
        return preds, score_col
    def _add_eval_score(g: pd.DataFrame, sc: str) -> pd.DataFrame:
        g = g.copy()
        g[sc] = pd.to_numeric(g[sc], errors="coerce").fillna(0.0)
        ranks = g[sc].rank(method="first", ascending=False)
        n = float(len(g))
        g["score_eval"] = 1.0 if n <= 1.0 else 1.0 - (ranks - 1.0) / (n - 1.0)
        return g
    try:
        preds = (preds.groupby(patient_col, group_keys=False)
                      .apply(lambda gg: _add_eval_score(gg, score_col), include_groups=False))
    except TypeError:
        # Older pandas without include_groups
        preds = (preds.groupby(patient_col, group_keys=False)
                      .apply(lambda gg: _add_eval_score(gg, score_col)))
    return preds, "score_eval"

def _compute_at_k_metrics(y_true: List[int], y_score: Optional[List[float]], k: int) -> Dict[str, float]:
    # Ensure a valid k
    k = max(1, int(k))

    # Coerce y_true to binary ints and align lengths with scores if provided
    rel_full: List[int] = [1 if int(v) == 1 else 0 for v in (y_true or [])]

    # Determine effective slice length (n_eff) and optionally re-order by score
    if isinstance(y_score, (list, tuple)) and len(y_score) > 0:
        # Align to the available lengths and the requested k
        n_eff = min(len(rel_full), len(y_score), k)
        rel_k = rel_full[:n_eff]
        # Coerce scores to floats (invalid entries → 0.0)
        sc_k: List[float] = []
        for v in y_score[:n_eff]:
            try:
                sc_k.append(float(v))
            except (TypeError, ValueError):
                sc_k.append(0.0)
        # Stable sort indices by descending score
        idx = list(range(n_eff))
        idx.sort(key=lambda i: sc_k[i], reverse=True)
        rel = [rel_k[i] for i in idx]
    else:
        # No scores provided → assume rel is already ordered; cap to k
        n_eff = min(len(rel_full), k)
        rel = rel_full[:n_eff]

    # Precision@k (with effective k)
    denom_k = float(n_eff if n_eff > 0 else 1)
    prec = sum(rel) / denom_k

    # Recall@k — denominator: number of positives available in the considered list
    total_pos = sum(rel_full)
    recall_denom = float(total_pos if total_pos > 0 else max(1, sum(rel)))
    rec = sum(rel) / recall_denom

    # AP@k (Average Precision at k)
    cum_hits = 0
    ap = 0.0
    for i, r in enumerate(rel, start=1):
        if r == 1:
            cum_hits += 1
            ap += cum_hits / i
    ap = ap / max(1, sum(rel))

    # nDCG@k
    import math
    dcg = 0.0
    for i, r in enumerate(rel, start=1):
        if r == 1:
            dcg += 1.0 / math.log2(i + 1)
    ideal_ones = min(total_pos, n_eff)
    idcg = sum(1.0 / math.log2(i + 1) for i in range(1, ideal_ones + 1)) if ideal_ones > 0 else 1.0
    ndcg = dcg / idcg if idcg > 0 else 0.0

    return {
        "precision@k": float(prec),
        "recall@k": float(rec),
        "map@k": float(ap),
        "ndcg@k": float(ndcg),
    }

def evaluate_recommendations_loco(
    preds: pd.DataFrame,
    df_ctx: pd.DataFrame,
    patient_col: str = "patient_id",
    feature_col: str = "feature_id",
    true_col: str = "true_response",
    k: int = 5,
    eval_logger=None,
    log_id: str = "",
    use_eval_score_calibration: bool = True,
    score_col: Optional[str] = None,
) -> pd.DataFrame:
    logger = eval_logger
    log = (logger.info if (logger and hasattr(logger, "info")) else print)

    # --- Hard guards for required columns (restore from index if needed) ---
    if patient_col not in preds.columns:
        idx_names = list(getattr(preds.index, "names", []) or [])
        if patient_col in idx_names:
            preds = preds.reset_index()
            try:
                if logger and hasattr(logger, "info"):
                    logger.info(f"[{log_id}] Restored '{patient_col}' from index in preds.")
            except (AttributeError, TypeError, ValueError):
                pass
        else:
            raise KeyError(f"'{patient_col}' missing in predictions (columns & index).")

    preds = _ensure_cols(preds, [patient_col, feature_col])
    df_ctx = _ensure_cols(df_ctx, [patient_col, feature_col, true_col])

    # --- Unified score column selection (CBF-first), then CF, then generic 'score' —
    # use local pick_score_col directly (no self-imports to avoid "Import resolves to its containing file")
    _score_col = pick_score_col(preds, score_col)
    # Optional diag: if no score column is present, we will treat items as equally scored per patient.
    warn = (logger.warning if (logger and hasattr(logger, "warning")) else print)
    if _score_col is None:
        warn(f"[{log_id}] LOCO: No score column found in preds; assuming equal scores within each patient for ranking (stable order only).")

    preds, score_to_use = _rank_calibration_inplace(preds, patient_col, _score_col, use_eval_score_calibration)

    # In standard LOCO we cap directly to k after rank-calibration. (For LOCO-Family we pre-cap a larger pool before masks.)
    preds_k = _cap_topk_per_patient(preds, k, patient_col, feature_col, score_to_use)

    truth_map = _build_truth_map(df_ctx, patient_col, feature_col, true_col)

    rows = []
    for pid, g in preds_k.groupby(patient_col):
        feats = list(g[feature_col].astype(str))
        # mark hits relative to truth_map
        y_true = [1 if f in truth_map.get(pid, set()) else 0 for f in feats]
        # Use ordered scores
        y_score = list(pd.to_numeric(g[score_to_use], errors="coerce").fillna(0.0)) if score_to_use else [1.0] * len(y_true)
        m = _compute_at_k_metrics(y_true, y_score, k)
        rows.append({
            patient_col: pid,
            "precision@5": m["precision@k"],
            "recall@5": m["recall@k"],
            "map@5": m["map@k"],
            "ndcg@5": m["ndcg@k"],
        })
    out = pd.DataFrame(rows)
    log(f"[{log_id}] LOCO completed for {len(out)} patients with truth; returned {len(out)} aggregated rows.")
    return out

def evaluate_recommendations_loco_family(
    preds: pd.DataFrame,
    df_ctx: pd.DataFrame,
    patient_col: str = "patient_id",
    feature_col: str = "feature_id",
    true_col: str = "true_response",
    family_col: str = "feature_id_binned",
    k: int = 5,
    eval_logger=None,
    log_id: str = "",
    exclude_seen_families: bool = True,
    exclude_synonym_families: bool = True,
    synonym_families: Optional[Dict[str, List[str]]] = None,
    use_eval_score_calibration: bool = True,
    score_col: Optional[str] = None,
) -> pd.DataFrame:
    """
    LOCO-Family evaluation:
    - Builds per-patient set of positive families from df_ctx (true_col==1).
    - Optionally filters predictions to exclude families seen in positives and/or synonyms.
    - Ranks remaining candidates and computes metrics at k versus true features (not families).
    """
    logger = eval_logger
    log = (logger.info if (logger and hasattr(logger, "info")) else print)
    warn = (logger.warning if (logger and hasattr(logger, "warning")) else print)

    # --- Hard guards for required columns (restore from index if needed) ---
    if patient_col not in preds.columns:
        idx_names = list(getattr(preds.index, "names", []) or [])
        if patient_col in idx_names:
            preds = preds.reset_index()
            try:
                if logger and hasattr(logger, "info"):
                    logger.info(f"[{log_id}] Restored '{patient_col}' from index in preds.")
            except (AttributeError, TypeError, ValueError):
                pass
        else:
            raise KeyError(f"'{patient_col}' missing in predictions (columns & index).")

    # Try to attach/derive family columns in preds via context (before we fallback to 'unknown')
    if family_col not in preds.columns:
        try:
            from utils.context_utils import ensure_feature_id_binned_and_context
            preds = ensure_feature_id_binned_and_context(
                preds, log=logger if (logger and hasattr(logger, "info")) else None, log_id=f"{log_id}[preds_fam]"
            )
            if family_col not in preds.columns:
                if logger and hasattr(logger, "warning"):
                    logger.warning(f"[{log_id}] preds still missing '{family_col}' after ensure_feature_id_binned_and_context — falling back to 'unknown'.")
                preds[family_col] = "unknown"
        except (ImportError, ModuleNotFoundError, AttributeError, TypeError, KeyError, ValueError) as ex:
            try:
                if logger and hasattr(logger, "warning"):
                    logger.warning(f"[{log_id}] Failed to attach '{family_col}' to preds via context utils: {ex}; filling 'unknown'.")
            except (AttributeError, TypeError, ValueError):
                pass
            preds[family_col] = "unknown"

    preds = _ensure_cols(preds, [patient_col, feature_col])
    df_ctx = _ensure_cols(df_ctx, [patient_col, feature_col, true_col])

    # --- DIAG: distribution of positive families per patient (from df_ctx) ---
    try:
        fam_col = family_col
        if fam_col in df_ctx.columns:
            df_diag = df_ctx[[patient_col, fam_col, true_col]].copy()
            df_diag[true_col] = pd.to_numeric(df_diag[true_col], errors="coerce").fillna(0).astype(int)
            pos = df_diag[df_diag[true_col] == 1].dropna(subset=[patient_col, fam_col])
            fam_counts = pos.drop_duplicates([patient_col, fam_col]).groupby(patient_col)[fam_col].count()
            n_patients_posfam = int((fam_counts > 0).sum()) if len(fam_counts) else 0
            min_f = int(fam_counts.min()) if len(fam_counts) else 0
            max_f = int(fam_counts.max()) if len(fam_counts) else 0
            avg_f = float(fam_counts.mean()) if len(fam_counts) else 0.0
            log(f"[{log_id}] LOCO-Family guard — positive families per patient: "
                f"patients_with_pos_families={n_patients_posfam}, min={min_f}, max={max_f}, avg={avg_f:.2f}")
            if n_patients_posfam == 0:
                warn(f"[{log_id}] LOCO-Family: no patients with positive families in df_ctx; result may be empty.")
        else:
            warn(f"[{log_id}] LOCO-Family guard: df_ctx missing '{fam_col}' — skipping DIAG.")
    except (KeyError, ValueError, TypeError) as _e:
        warn(f"[{log_id}] LOCO-Family guard failed: {_e}")

    # If family_col is missing, try to proceed by filling 'unknown'
    if family_col not in preds.columns:
        preds = preds.copy()
        preds[family_col] = "unknown"
        warn(f"[{log_id}] LOCO-Family: '{family_col}' missing in preds after context attach; filled with 'unknown'.")
    if family_col not in df_ctx.columns:
        df_ctx = df_ctx.copy()
        df_ctx[family_col] = "unknown"
        warn(f"[{log_id}] LOCO-Family: '{family_col}' missing in df_ctx; filled with 'unknown'.")

    # Normalize family values to strings
    preds[family_col] = preds[family_col].astype(str)
    df_ctx[family_col] = df_ctx[family_col].astype(str)

    # --- Unified score column selection (CBF-first), then CF, then generic 'score' —
    # use local pick_score_col directly (no self-imports to avoid "Import resolves to its containing file")
    _score_col = pick_score_col(preds, score_col)
    # Optional diag: make it explicit when we fall back to equal per-patient scores.
    if _score_col is None:
        warn(f"[{log_id}] LOCO-Family: No score column found in preds; assuming equal scores within each patient for ranking (stable order only).")

    preds, score_to_use = _rank_calibration_inplace(preds, patient_col, _score_col, use_eval_score_calibration)

    # Pre-mask pool cap: use a larger candidate pool (max(k, 50)) before applying family/synonym masks,
    # then truncate again to k after masking. This mirrors CF behavior and improves stability.
    preds_k = _cap_topk_per_patient(preds, max(k, 50), patient_col, feature_col, score_to_use)

    # Build truth maps
    truth_map = _build_truth_map(df_ctx, patient_col, feature_col, true_col)
    fam_map = _build_truth_family_map(df_ctx, patient_col, family_col, true_col)

    # Synonyms map normalization
    syn_map: Dict[str, Set[str]] = {}
    if exclude_synonym_families and isinstance(synonym_families, dict):
        for kf, lst in synonym_families.items():
            syn_map[str(kf)] = set(map(str, lst))

    empty_targets = 0
    empty_pred_after_mask = 0

    rows = []
    for pid, g in preds_k.groupby(patient_col):
        # Apply family masking if requested
        gg = g.copy()
        if exclude_seen_families:
            seen_fams = fam_map.get(pid, set())
            if seen_fams:
                gg = gg[~gg[family_col].isin(seen_fams)]
        if exclude_synonym_families and syn_map:
            # Exclude any candidate whose family is in any synonym set of a seen family
            seen = fam_map.get(pid, set())
            if seen:
                syn_excl = set()
                for sf in seen:
                    for base, syns in syn_map.items():
                        if sf == base or sf in syns:
                            syn_excl |= {base} | set(syns)
                if syn_excl:
                    gg = gg[~gg[family_col].isin(syn_excl)]
        if gg.empty:
            empty_pred_after_mask += 1
            continue

        # Truncate to top-k after masking
        gg = _cap_topk_per_patient(gg, k, patient_col, feature_col, score_to_use)

        feats = list(gg[feature_col].astype(str))
        if not truth_map.get(pid):
            empty_targets += 1
            continue
        y_true = [1 if f in truth_map.get(pid, set()) else 0 for f in feats]
        y_score = list(pd.to_numeric(gg[score_to_use], errors="coerce").fillna(0.0)) if score_to_use else [1.0] * len(y_true)
        m = _compute_at_k_metrics(y_true, y_score, k)
        rows.append({
            patient_col: pid,
            "precision@5": m["precision@k"],
            "recall@5": m["recall@k"],
            "map@5": m["map@k"],
            "ndcg@5": m["ndcg@k"],
        })

    out = pd.DataFrame(rows)
    if out.empty:
        # Helpful context rate for hints
        try:
            if family_col in df_ctx.columns:
                ctx_unknown_pct = float(
                    df_ctx[family_col].astype(str).str.lower().eq("unknown").mean()
                )
            else:
                ctx_unknown_pct = 1.0
        except (KeyError, AttributeError, TypeError, ValueError):
            ctx_unknown_pct = -1.0
        hint = ("Hints: consider disabling `exclude_synonym_families` temporarily, "
                "increasing `evaluation.eval_cap`, or raising `cbf.raw_pool_cap` to enlarge candidate pool. "
                "Also ensure `feature_id_binned` exists in both preds and df_ctx.")
        warn(f"[{log_id}] LOCO-Family produced no rows. Reasons: "
             f"empty_targets={empty_targets}, empty_pred_after_mask={empty_pred_after_mask}, "
             f"ctx_unknown_family_pct={ctx_unknown_pct:.2f}. {hint}")
    else:
        log(f"[{log_id}] LOCO-Family completed for {len(out)} patients; returned {len(out)} aggregated rows.")
    return out
# -------- Isotonic utils (اختياري) --------
def apply_isotonic_if_available(
    series_or_df: Union[pd.Series, pd.DataFrame],
    col: Optional[str] = None,
    model_path: Optional[str] = None,
    iso_model: Optional[Any] = None,
    clip: bool = True,
    logger_obj=None
) -> Union[pd.Series, pd.DataFrame]:
    """
    يطبق IsotonicRegression إذا توفر نموذج صالح (محمّل من model_path أو مُمرر في iso_model).
    توقيع مرن:
      - إذا مُمرر Series: تعاد Series معايرة.
      - إذا مُمرر DataFrame: يجب تحديد col لإسم العمود المستهدف؛ تُعاد نسخة مع استبدال العمود فقط.
    الاستثناءات ضيقة، وإذا فشل التحميل/التحويل تُعاد البيانات دون تغيير.
    """
    try:
        from sklearn.isotonic import IsotonicRegression  # وجود المكتبة شرط أساسي
    except Exception as ex:
        if logger_obj is not None and hasattr(logger_obj, "debug"):
            logger_obj.debug("[helperscbf] Isotonic unavailable (sklearn import failed): %s", ex)
        return series_or_df

    # حدد النموذج
    model = iso_model
    if model is None and model_path:
        try:
            import joblib
            model = joblib.load(model_path)
        except (FileNotFoundError, OSError, ValueError, TypeError) as ex:
            if logger_obj is not None and hasattr(logger_obj, "warning"):
                logger_obj.warning("[helperscbf] Isotonic model load failed: %s", ex)
            return series_or_df

    if model is None or not isinstance(model, IsotonicRegression):
        return series_or_df

    def _apply(s: pd.Series) -> pd.Series:
        try:
            out = pd.Series(model.transform(pd.to_numeric(s, errors="coerce").astype(float)), index=s.index).astype(float)
            return out.clip(0.0, 1.0) if clip else out
        except (TypeError, ValueError, AttributeError, RuntimeError, OverflowError):
            return s

    if isinstance(series_or_df, pd.Series):
        return _apply(series_or_df)
    elif isinstance(series_or_df, pd.DataFrame):
        if not col or col not in series_or_df.columns:
            return series_or_df
        out_df = series_or_df.copy()
        out_df[col] = _apply(out_df[col])
        return out_df
    else:
        return series_or_df

def fit_and_save_isotonic(
    df_scores_labels: pd.DataFrame,
    score_col: str = "score_cbf",
    label_col: str = "true_response",
    min_samples: int = 20,
    model_path: Optional[str] = None,
    logger_obj=None
) -> Optional[Any]:
    """
    يدرّب IsotonicRegression إذا توفّرت ≥ min_samples عينة صحيحة ويعيد النموذج.
    إذا تم تمرير model_path فسيتم حفظه بـ joblib.
    """
    try:
        from sklearn.isotonic import IsotonicRegression
    except Exception as ex:
        if logger_obj is not None and hasattr(logger_obj, "warning"):
            logger_obj.warning("[helperscbf] Isotonic unavailable: %s", ex)
        return None

    df_local = df_scores_labels[[score_col, label_col]].copy()
    df_local = df_local.dropna()
    if len(df_local) < int(min_samples):
        return None
    try:
        x = pd.to_numeric(df_local[score_col], errors="coerce").astype(float)
        y = pd.to_numeric(df_local[label_col], errors="coerce").astype(float)
        ok = ~(x.isna() | y.isna())
        x, y = x[ok], y[ok]
        if len(x) < int(min_samples):
            return None
        iso = IsotonicRegression(out_of_bounds="clip")
        iso.fit(x.values, y.values)
        if model_path:
            try:
                import joblib
                joblib.dump(iso, model_path)
            except (OSError, ValueError, TypeError) as ex:
                if logger_obj is not None and hasattr(logger_obj, "warning"):
                    logger_obj.warning("[helperscbf] Failed to save isotonic model: %s", ex)
        return iso
    except Exception as ex:
        if logger_obj is not None and hasattr(logger_obj, "warning"):
            logger_obj.warning("[helperscbf] Isotonic fit failed: %s", ex)
        return None