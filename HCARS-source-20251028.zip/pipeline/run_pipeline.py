
"""
run_pipeline.py
---------------
This script serves as the main entry point for running the entire hypertension recommendation pipeline.
It can be invoked via CLI or directly as a Python module. It loads configuration, data, runs all pipeline
steps (cleaning, feature engineering, recommendation models, training, evaluation, reporting).
"""

import os
import sys
import json
import time
sys.path.append(".")

from utils.logging_utils import get_logger

# --- Logging configuration setup (ensure loaded early) ---
import logging
import logging.config
import yaml
with open("pipeline/config.yaml", "r") as file_handler:
    config = yaml.safe_load(file_handler)
    logging.config.dictConfig(config["logging"])

# Context mapping logger
context_logger = logging.getLogger("context_mapping")

import uuid
log_id = uuid.uuid4().hex[:8]

# --- Helper function to get config.yaml path ---
def get_config_path():
    return os.path.join(os.path.dirname(__file__), "config.yaml")

# --- Robust global config loader ---
def load_global_config():
    config_path = get_config_path()
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"❌ config.yaml not found at path: {config_path}")
    with open(config_path, 'r') as config_file:
        return yaml.safe_load(config_file)

# تعريف الـ logger مباشرة بعد الاستيراد أعلاه
pipeline_logger = get_logger("pipeline")


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from pipeline.cbf_pipeline import run_cbf_pipeline
from pipeline.cf_pipeline import run_cf_pipeline
from pipeline.hybrid_pipeline import run_hybrid_pipeline

# Import generate_feature_id_from_context if not already imported
from pipeline.core import generate_feature_id_from_context

pipeline_logger.info(f"[{log_id}] [Config Debug] Final resolved config path: {get_config_path()}")
config = load_global_config()
if config is None:
    raise ValueError("❌ Failed to load config — check config.yaml content or YAML format.")

data_path = config.get("data_paths", {}).get("hypertension", "outputs/tmp/df_contextualized.csv")
context_features = config.get("context_features", [])

import pandas as pd
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

from utils.restoration import restore_protected_columns
from utils.config_loader import get_config
from utils.logging_utils import setup_logger
from utils.validation import check_column_consistency
from preprocessing.imputation import impute_missing_values
from context.router import engineer_features
from preprocessing.integration import (
    process_post_split_hypertension
)

pipeline_logger.info(f"[CONFIG] Context features in use: {context_features}")

# --- CF context and feature filtering utilities ---
def prepare_cf_context(data: pd.DataFrame) -> dict:
    context_dict = {}
    for feat in context_features:
        if feat in data.columns:
            context_dict[feat] = data[feat].mode().iloc[0]
        else:
            context_dict[feat] = 'unknown'
            pipeline_logger.warning(f"⚠️ [CF Context] Missing context feature '{feat}'. Using default 'unknown'.")
    return context_dict

def filter_cf_features(columns: list) -> list:
    keywords = ["score", "rating", "interaction", "cf_"]
    return [col for col in columns if any(key in col.lower() for key in keywords)]

# Import context validation decorators and functions
from context.context_validation import requires_context_features, check_context_columns

def initialize_config():
    os.makedirs("logs", exist_ok=True)
    if not logging.getLogger("pipeline_logger").handlers:
        logging.basicConfig(level=logging.INFO)
    _pipeline_logger = setup_logger("pipeline_logger", "logs/pipeline.log")
    pipeline_log = _pipeline_logger  # Alias to avoid shadowing if needed elsewhere
    pipeline_log.setLevel(logging.DEBUG)
    try:
        if not os.path.exists("pipeline/logging_config.json"):
            raise FileNotFoundError("[Step 1 - Setup] ❌ logging_config.json not found. Please ensure it exists.")
        with open("pipeline/logging_config.json", "r") as f:
            config_dict = json.load(f)
        logging.config.dictConfig(config_dict)
        pipeline_log.info("[Step 1 - Setup] 🛡️ Logging configuration loaded.")
        config_local = get_config()
    except FileNotFoundError as config_error:
        logging.warning(f"[Step 1 - Setup] ⚠️ {config_error} — loading default test config.")
        config_local = {
            "target_column": "target",
            "dataset_name": "hypertension",
            "test_size": 0.2,
            "random_state": 42,
            "protected_columns": ["target"],
            "schemas": {"hypertension": ["age", "sex", "chol", "trestbps"]},
            "imputation": {"strategy": "median", "use_knn": False}
        }
    # Ensure 'target' is in protected columns
    if "protected_columns" in config_local and "target" not in config_local["protected_columns"]:
        config_local["protected_columns"].append("target")
    elif "protected_columns" not in config_local:
        config_local["protected_columns"] = ["target"]
    # Check required keys
    required_keys = ["target_column", "dataset_name", "schemas", "protected_columns"]
    for k in required_keys:
        if k not in config_local:
            raise PipelineExecutionError(f"Missing required config key: {k}")
    return config_local, pipeline_log

class PipelineExecutionError(Exception):
    """Custom exception for pipeline execution errors."""
    pass

try:
    from preprocessing.data_cleaning import MedicalDataCleaner
    cleaner = MedicalDataCleaner()
except ImportError as e:
    MedicalDataCleaner = None
    cleaner = None
    logging.error(f"[Step 1 - Setup] ❌ Failed to import MedicalDataCleaner: {e}")

def load_and_clean_data(input_data_path: str, dataset_name: str, local_log_id: str = None, run_self_test: bool = False):
    start_time = time.perf_counter()
    try:
        # Load production data using config-driven path
        df = pd.read_csv(input_data_path)
        pipeline_logger.info(f"[{local_log_id}] [Pipeline Entry] ✅ Loaded production data from: {input_data_path}")
        # --- Insert target_copy immediately after loading ---
        if "target" in df.columns:
            df["target_copy"] = df["target"]
        # ✅ Step 1: Apply feature engineering
        raw_df = engineer_features(df, dataset_name)
        cleaning_map = {
            "hypertension": cleaner.clean_hypertension_data
        }
        if dataset_name not in cleaning_map:
            logging.error(f"[Medical Context][load_and_clean_data] Unsupported dataset: {dataset_name}")
            raise PipelineExecutionError(f"Unsupported dataset: {dataset_name}")
        cleaned_df = cleaning_map[dataset_name](raw_df)
        # المرحلة 4: الفحص التجريبي
        print(f"[CLEAN] Columns after feature engineering: {raw_df.columns.tolist()}")
        print(f"[DEBUG] Columns after cleaning for {dataset_name}: {cleaned_df.columns.tolist()}")
        pipeline_logger.debug(f"[{local_log_id}] [Trace] Post-cleaning columns in '{dataset_name}': {cleaned_df.columns.tolist()}")
        pipeline_logger.warning(f"[{local_log_id}] [Columns Trace] After cleaning: {cleaned_df.columns.tolist()}")
        # Check for missing or null 'age'
        if "age" not in raw_df.columns or raw_df["age"].isnull().all():
            raise PipelineExecutionError("Missing or null 'age' column in raw dataset.")
        if run_self_test and hasattr(cleaner, "self_test"):
            cleaner.self_test(cleaned_df, dataset_name)
            logging.info(f"[load_and_clean_data] Self-test completed for {dataset_name}")
        # Remove any premature validation call for hypertension.yaml here.
        # (Validation for hypertension.yaml is now handled in main() after all derived columns.)
    except Exception:
        logging.exception("[Medical Context][load_and_clean_data] Failed during schema validation or cleaning.")
        raise
    pipeline_logger.info(f"[{local_log_id}] [Step 2] ✅ Step Completed: Data loading and schema validation done.")
    elapsed_time = time.perf_counter() - start_time
    logging.info(f"[Medical Context][load_and_clean_data] Time elapsed for Loading & Cleaning: {elapsed_time:.2f} seconds")
    return cleaned_df

def backup_targets(x_train, x_test, y_train, y_test):
    try:
        y_train_backup = y_train.copy()
        x_train["target_train_copy"] = y_train_backup
        x_test["target_test_copy"] = y_test.copy()
        logging.info("[Backup] Created 'target_train_copy' and 'target_test_copy' for safe restoration.")
        # Ensure 'target_copy' exists as backup in x_train if not already present
        if "target_copy" not in x_train.columns and y_train_backup.name:
            x_train["target_copy"] = y_train_backup
            logging.info("[Backup] Created 'target_copy' from y_train_backup as an alternative restoration path.")
        y_test_backup = pd.DataFrame({"target_test_copy": y_test})
        return y_train_backup, y_test_backup
    except Exception as backup_error:
        logging.error(f"[Backup] Failed to create target backups: {backup_error}")
        raise

def post_split_processing(x_train, x_test, y_train_bk, y_test_bk, dataset, cfg):
    try:
        post_split_map = {
            "hypertension": process_post_split_hypertension
        }
        if dataset in post_split_map:
            x_train, x_test = post_split_map[dataset](
                x_train, x_test, y_train_backup=y_train_bk, y_test_backup=y_test_bk
            )
            x_train = restore_protected_columns(
                x_train,
                cfg.get("protected_columns", []),
                fallback_data=y_train_bk.to_frame().rename(columns={y_train_bk.name: "target_copy"})
            )
            fallback_data_test = x_test["target_test_copy"].to_frame() if "target_test_copy" in x_test.columns else None
            for col in cfg.get("protected_columns", []):
                if fallback_data_test is not None and col in fallback_data_test.columns:
                    x_test[col] = fallback_data_test[col]
                    if x_test[col].dtype == object:
                        x_test[col] = x_test[col].astype(str)
                    if len(x_test) != len(fallback_data_test):
                        logging.warning(f"[Restore] ⚠️ Row mismatch in column {col}")
            # still call original restore_protected_columns for x_test for any additional logic
            x_test = restore_protected_columns(
                x_test,
                cfg.get("protected_columns", []),
                fallback_data=fallback_data_test
            )
            logging.info("[Security] Protected columns restored successfully.")
            # Safeguard for 'target' restoration in x_test
            if "target" not in x_test.columns or x_test["target"].isnull().all():
                if "target_test_copy" in x_test.columns:
                    x_test["target"] = x_test["target_test_copy"]
                    logging.info("[Restore] 'target' restored in x_test from 'target_test_copy'.")
                else:
                    logging.error("[Restore] 'target' column missing in x_test and no backup available.")
                    raise PipelineExecutionError("Missing 'target' column in test_df and no backup available.")
            # Verify presence of essential columns after restoration
            for col in ["risk_score", "chol_flag", "target"]:
                if col not in x_train.columns:
                    logging.error(f"[Restore] Column '{col}' missing in x_train after restoration.")
                    raise PipelineExecutionError(f"Expected column: {col} missing in x_train after restoration.")
                if col not in x_test.columns:
                    logging.error(f"[Restore] Column '{col}' missing in x_test after restoration.")
                    raise PipelineExecutionError(f"Expected column: {col} missing in x_test after restoration.")
        logging.info(f"[Post-Split] Training columns after processing: {x_train.columns.tolist()}")
        logging.info(f"[Post-Split] Test columns after processing: {x_test.columns.tolist()}")
        return x_train, x_test
    except Exception as _:
        logging.exception("[Post-Split Processing] Error during post-split processing or protected column restoration.")
        raise

def validate_and_restore_targets(x_train, x_test, y_train_backup, y_test):
    try:
        target_column = "target"
        if target_column in x_train.columns:
            y_train = x_train[target_column]
            x_train = x_train.drop(columns=[target_column])
        else:
            y_train = y_train_backup
        if target_column in x_test.columns:
            y_test = x_test[target_column]
            x_test = x_test.drop(columns=[target_column])
        # Restore 'risk_level' if missing from encoded data
        if "risk_level" not in x_train.columns:
            if "remainder__risk_level" in x_train.columns:
                x_train["risk_level"] = x_train["remainder__risk_level"]
                logging.info("[Restore] 'risk_level' restored from 'remainder__risk_level' in x_train.")
            elif "risk_level_copy" in x_train.columns:
                x_train["risk_level"] = x_train["risk_level_copy"]
                logging.info("[Restore] 'risk_level' restored from 'risk_level_copy' in x_train.")
            # --- OneHot fallback for x_train ---
            elif all(col in x_train.columns for col in ["multi__risk_level_low", "multi__risk_level_medium", "multi__risk_level_high"]):
                x_train["risk_level"] = x_train[["multi__risk_level_low", "multi__risk_level_medium", "multi__risk_level_high"]].idxmax(axis=1).str.replace("multi__risk_level_", "")
                logging.info("[Restore] 'risk_level' reconstructed in x_train from OneHot encoded components.")
            else:
                logging.warning("[Restore] 'risk_level' is missing and no backup found in x_train.")

        if "risk_level" not in x_test.columns:
            if "remainder__risk_level" in x_test.columns:
                x_test["risk_level"] = x_test["remainder__risk_level"]
                logging.info("[Restore] 'risk_level' restored from 'remainder__risk_level' in x_test.")
            elif "risk_level_copy" in x_test.columns:
                x_test["risk_level"] = x_test["risk_level_copy"]
                logging.info("[Restore] 'risk_level' restored from 'risk_level_copy' in x_test.")
            # --- OneHot fallback for x_test ---
            elif all(col in x_test.columns for col in ["multi__risk_level_low", "multi__risk_level_medium", "multi__risk_level_high"]):
                x_test["risk_level"] = x_test[["multi__risk_level_low", "multi__risk_level_medium", "multi__risk_level_high"]].idxmax(axis=1).str.replace("multi__risk_level_", "")
                logging.info("[Restore] 'risk_level' reconstructed in x_test from OneHot encoded components.")
            else:
                logging.warning("[Restore] 'risk_level' is missing and no backup found in x_test.")
        # Final check to log error if still missing
        if "risk_level" not in x_test.columns:
            logging.error("[Restore] ❌ Final fallback failed. 'risk_level' still missing in x_test.")
        # Fallbacks can be added here if needed
        return x_train, x_test, y_train, y_test
    except Exception as err:
        logging.error(f"[validate_and_restore_targets] Failed to restore targets: {err}")
        raise

def cleanup_backup_columns(x_train, x_test):
    try:
        protected_to_keep = ["target_test_copy", "target_train_copy"]
        to_drop_train = [col for col in x_train.columns if col.endswith("_copy") and col not in protected_to_keep]
        x_train.drop(columns=to_drop_train, inplace=True)
        logging.info(f"[Cleanup] Backup columns removed from X_train: {to_drop_train}")
        to_drop_test = [col for col in x_test.columns if col.endswith("_copy") and col not in protected_to_keep]
        x_test.drop(columns=to_drop_test, inplace=True)
        logging.info(f"[Cleanup] Backup columns removed from X_test: {to_drop_test}")
        return x_train, x_test
    except Exception as cleanup_error:
        logging.error(f"[Cleanup] Failed to cleanup backup columns: {cleanup_error}")
        raise

@requires_context_features
def split_and_process_data(df_cleaned, target_column, cfg, dataset_name):
    start_time = time.perf_counter()
    try:
        if target_column not in df_cleaned.columns:
            logging.error(f"[split_and_process_data] Target column '{target_column}' not found in dataset")
            raise PipelineExecutionError(f"Target column '{target_column}' not found in dataset")

        if "target" not in df_cleaned.columns:
            logging.error("[split_and_process_data] Column 'target' is missing before encoding.")
            raise PipelineExecutionError("Missing 'target' column in df_cleaned before encoding.")

        # Restore 'age_group', 'bp_category', and 'chol_category' if present in renamed columns
        if "age_group" not in df_cleaned.columns and "remainder__age_group" in df_cleaned.columns:
            df_cleaned["age_group"] = df_cleaned["remainder__age_group"]
            logging.info("[split_and_process_data] Restored 'age_group' from 'remainder__age_group' in df_cleaned")
        if "bp_category" not in df_cleaned.columns and "remainder__bp_category" in df_cleaned.columns:
            df_cleaned["bp_category"] = df_cleaned["remainder__bp_category"]
            logging.info("[split_and_process_data] Restored 'bp_category' from 'remainder__bp_category' in df_cleaned")
        if "chol_category" not in df_cleaned.columns and "remainder__chol_category" in df_cleaned.columns:
            df_cleaned["chol_category"] = df_cleaned["remainder__chol_category"]
            logging.info("[split_and_process_data] Restored 'chol_category' from 'remainder__chol_category' in df_cleaned")
        # Restore 'risk_level' from 'remainder__risk_level' if necessary
        if "risk_level" not in df_cleaned.columns and "remainder__risk_level" in df_cleaned.columns:
            df_cleaned["risk_level"] = df_cleaned["remainder__risk_level"]
            logging.info("[split_and_process_data] Restored 'risk_level' from 'remainder__risk_level' in df_cleaned")

        y_target = df_cleaned[target_column].copy()
        x_data = df_cleaned.drop(columns=[target_column])

        # First split: temp/test
        x_temp, x_test, y_temp, y_test = train_test_split(
            x_data, y_target,
            test_size=0.2,
            random_state=cfg.get("random_state", 42),
            stratify=y_target
        )
        # Second split: train/val
        x_train, x_val, y_train, y_val = train_test_split(
            x_temp, y_temp,
            test_size=0.15,
            random_state=cfg.get("random_state", 42),
            stratify=y_temp
        )
        # Backup and post-split processing for train/test only (validation handled like train)
        y_train_backup, y_test_backup = backup_targets(x_train, x_test, y_train, y_test)
        x_train, x_test = post_split_processing(
            x_train,
            x_test,
            y_train_backup,
            y_test_backup,
            dataset_name,
            cfg
        )
        x_train, x_test, y_train, y_test = validate_and_restore_targets(
            x_train,
            x_test,
            y_train_backup,
            y_test
        )
        x_train, x_test = cleanup_backup_columns(x_train, x_test)

        # No post_split_processing for validation set (could add if needed)

        pipeline_logger.info(f"[{log_id}] Train size: {x_train.shape}, Validation size: {x_val.shape}, Test size: {x_test.shape}")
        pipeline_logger.info(f"[{log_id}] [Step 3] ✅ Step Completed: Data split and backup completed.")
        elapsed_time = time.perf_counter() - start_time
        logging.info(f"[split_and_process_data] Time elapsed for Splitting: {elapsed_time:.2f} seconds")
        return x_train, x_val, x_test, y_train, y_val, y_test
    except Exception:
        logging.exception("[split_and_process_data] Failed during train/test splitting.")
        raise

def apply_feature_engineering(x_train, x_test, dataset_name):
    start_time = time.perf_counter()
    logging.info(f"[apply_feature_engineering] Training columns before feature engineering: {x_train.columns.tolist()}")
    logging.info(f"[apply_feature_engineering] Test columns before feature engineering: {x_test.columns.tolist()}")
    preserved_age_train = x_train.get("age") if "age" in x_train.columns else None
    preserved_age_test = x_test.get("age") if "age" in x_test.columns else None
    try:
        x_train = engineer_features(x_train, dataset_name)
        pipeline_logger.debug(f"[{log_id}] [Trace] x_train feature engineered columns: {x_train.columns.tolist()}")
        # Validate essential clinical columns after feature engineering (train)
        check_context_columns(x_train, ["risk_score", "chol_flag", "target"], context="Feature Engineering - x_train")
        logging.info("[apply_feature_engineering] Clinical safety: If any of these columns are missing, pipeline will fail as required for compliance.")
        # Restore age if missing
        if "age" not in x_train.columns and preserved_age_train is not None:
            x_train["age"] = preserved_age_train
        # Restore age_group features

        @requires_context_features
        def restore_age_group_features(df):
            for col in ["bp_category", "chol_category", "risk_level"]:
                if col not in df.columns:
                    for alt in [f"remainder__{col}", f"{col}_copy"]:
                        if alt in df.columns:
                            df[col] = df[alt]
            return df
        x_train = restore_age_group_features(x_train)
        # --- Insert context snapshot for preservation ---
        try:
            x_train["__original_context__"] = x_train[["bp_category", "chol_category", "risk_level", "age_group"]].to_dict(orient="records")
            pipeline_logger.info(f"[{log_id}] ✅ __original_context__ snapshot assigned for context preservation.")
        except Exception as inner_exc_train:
            pipeline_logger.warning(f"[{log_id}] ⚠️ Could not assign __original_context__ for x_train: {inner_exc_train}")
    except Exception as outer_exc_train:
        logging.exception("[apply_feature_engineering] Feature engineering failed for training set.")
        raise PipelineExecutionError(f"Feature engineering failed for training set: {outer_exc_train}")
    try:
        x_test = engineer_features(x_test, dataset_name)
        pipeline_logger.debug(f"[{log_id}] [Trace] x_test feature engineered columns: {x_test.columns.tolist()}")
        # Validate essential clinical columns after feature engineering (test)
        check_context_columns(x_test, ["risk_score", "chol_flag", "target"], context="Feature Engineering - x_test")
        logging.info("[apply_feature_engineering] Clinical safety: If any of these columns are missing, pipeline will fail as required for compliance.")
        if "age" not in x_test.columns and preserved_age_test is not None:
            x_test["age"] = preserved_age_test
        x_test = restore_age_group_features(x_test)
        # --- Insert context snapshot for preservation ---
        try:
            x_test["__original_context__"] = x_test[["bp_category", "chol_category", "risk_level", "age_group"]].to_dict(orient="records")
            pipeline_logger.info(f"[{log_id}] ✅ __original_context__ snapshot assigned for context preservation.")
        except Exception as inner_exc_test:
            pipeline_logger.warning(f"[{log_id}] ⚠️ Could not assign __original_context__ for x_test: {inner_exc_test}")
    except Exception as outer_exc_test:
        logging.exception("[apply_feature_engineering] Feature engineering failed for test set.")
        raise PipelineExecutionError(f"Feature engineering failed for test set: {outer_exc_test}")
    if "age" in x_train.columns and x_train["age"].isnull().all():
        logging.warning("[apply_feature_engineering] Warning: All 'age' values are NaN after feature engineering.")
    if x_train.isnull().all().any():
        logging.warning("[apply_feature_engineering] Warning: Some columns in x_train are all NaN after feature engineering.")
    pipeline_logger.info(f"[{log_id}] [Step 4] ✅ Feature engineering completed successfully.")
    elapsed_time = time.perf_counter() - start_time
    logging.info(f"[apply_feature_engineering] Time elapsed for feature engineering: {elapsed_time:.2f} seconds")
    return x_train, x_test

def main(dataset_name, cfg):
    try:
        df_cleaned = load_and_clean_data(dataset_name, cfg, run_self_test=True)
        from utils.safe_copy import safe_copy
        df_cleaned = safe_copy(df_cleaned)
        # 🧠 Load schema immediately after safe_copy to dynamically align column expectations
        from utils.config_loader import load_schema
        schema_key = 'schemas/clean_hypertension_data.yaml'
        post_fe_schema_path = "schemas/post-feature-engineering.yaml"

        # Ensure only string paths are passed to load_schema and handle type errors
        if not isinstance(schema_key, str):
            raise PipelineExecutionError(f"[main] Invalid schema_key: expected str, got {type(schema_key)}")
        if not isinstance(post_fe_schema_path, str):
            raise PipelineExecutionError(f"[main] Invalid post_fe_schema_path: expected str, got {type(post_fe_schema_path)}")

        post_fe_schema = load_schema("schemas/post-feature-engineering.yaml")
        expected_cols = post_fe_schema.get("columns", []) if isinstance(post_fe_schema, dict) else []
        missing_expected_cols = [col for col in expected_cols if col not in df_cleaned.columns]
        if missing_expected_cols:
            logging.warning(f"[main] ⚠️ Missing expected columns post-feature-engineering: {missing_expected_cols}")
        else:
            logging.info("[main] ✅ All expected post-feature-engineering columns are present.")

        print(f"[DEBUG] Columns before splitting: {df_cleaned.columns.tolist()}")

        logging.info("[main] Skipping manual risk_score and derived feature recomputation — handled in feature_engineering.")
        # Move validation call here, after all derived columns are created and before logging info
        if "target" not in df_cleaned.columns:
            raise PipelineExecutionError("[Step 2 - Loading & Cleaning] 'target' column missing in df_cleaned before feature engineering.")
        if "age" not in df_cleaned.columns or df_cleaned["age"].isnull().all():
            raise PipelineExecutionError("[Step 2 - Loading & Cleaning] 'age' column missing or fully null in original data.")
        # Only create target_copy after confirming target exists
        df_cleaned["target_copy"] = df_cleaned["target"].copy()
        # Print columns after cleaning and derived columns, before validation
        print("[DEBUG] Columns after cleaning:", df_cleaned.columns.tolist())
        # ✅ Validate after all derived columns are created
        from utils.validation import validate_schema
        print(f"[DEBUG] Columns before validation in main(): {df_cleaned.columns.tolist()}")
        # Defensive check: validate schema and handle errors gracefully
        try:
            validate_schema(df_cleaned, post_fe_schema)
        except Exception as validation_exception:
            raise PipelineExecutionError(f"[main] Schema validation failed for post-feature-engineering: {validation_exception}")
        logging.info("[Step 2 - Loading & Cleaning] ✅ Data loaded and cleaned.")
    except Exception:
        pipeline_logger.exception(f"[{log_id}] [Init] ❌ Failed to initialize pipeline.")
        raise


    try:
        x_train, x_val, x_test, y_train, y_val, y_test = split_and_process_data(df_cleaned, cfg["target_column"], cfg, dataset_name)
        logging.info("[Step 3 - Splitting & Backup] ✅ Data split and backups created.")
        if "age" not in x_train.columns:
            raise PipelineExecutionError("[Step 3 - Splitting & Backup] 'age' column dropped after splitting.")
        if x_train["age"].isnull().all():
            logging.warning("[Step 3 - Splitting & Backup] All age values in training set are NaN before feature engineering.")
        # Insert safe_copy before feature engineering (only once after split, not again after cleaning)
        x_train = safe_copy(x_train)
        x_val = safe_copy(x_val)
        x_test = safe_copy(x_test)
    except Exception:
        logging.error(f"[Step 3 - Splitting & Backup] ❌ Failed.")
        raise

    try:
        # 📌 Log top missing columns in x_train before feature engineering
        logging.info("📌 NaN diagnostics — Top missing columns in x_train (before feature engineering):")
        logging.info(x_train.isnull().sum().sort_values(ascending=False).head(10))
        # 📌 NaN diagnostics — Top missing columns in x_val (before feature engineering)
        logging.info("📌 NaN diagnostics — Top missing columns in x_val (before feature engineering):")
        logging.info(x_val.isnull().sum().sort_values(ascending=False).head(10))
        # 📌 NaN diagnostics — Top missing columns in x_test (before feature engineering)
        logging.info("📌 NaN diagnostics — Top missing columns in x_test (before feature engineering):")
        logging.info(x_test.isnull().sum().sort_values(ascending=False).head(10))
        x_train, x_test = apply_feature_engineering(x_train, x_test, dataset_name)
        x_val, _ = apply_feature_engineering(x_val, x_val.copy(), dataset_name)  # Use same logic for val, ignore second output
        # 📌 Log top missing columns in x_train after feature engineering
        logging.info("📌 NaN diagnostics — Top missing columns in x_train (after feature engineering):")
        logging.info(x_train.isnull().sum().sort_values(ascending=False).head(10))
        # 📌 NaN diagnostics — Top missing columns in x_val (after feature engineering)
        logging.info("📌 NaN diagnostics — Top missing columns in x_val (after feature engineering):")
        logging.info(x_val.isnull().sum().sort_values(ascending=False).head(10))
        # 📌 NaN diagnostics — Top missing columns in x_test (after feature engineering)
        logging.info("📌 NaN diagnostics — Top missing columns in x_test (after feature engineering):")
        logging.info(x_test.isnull().sum().sort_values(ascending=False).head(10))
        # 📌 NaN diagnostics — Check if 'risk_level' exists or is NaN:
        logging.info("📌 NaN diagnostics — Check if 'risk_level' exists or is NaN:")
        logging.info(f"risk_level in x_train: {'risk_level' in x_train.columns}")
        logging.info(f"NaNs in risk_level (x_train): {x_train['risk_level'].isnull().sum() if 'risk_level' in x_train.columns else 'Not Found'}")
        logging.info("[Step 4 - Feature Engineering] ✅ Feature engineering completed.")
        # Clinical safety: If any essential columns are missing, pipeline will fail immediately (see apply_feature_engineering).
        # No fallback or silent generation of missing clinical columns permitted by compliance.
        # Additional schema verification after engineering stage
        extended_required_cols = ["age_group", "bp_category", "chol_category", "chol_flag", "risk_score", "target_copy"]
        missing_engineered = [col for col in extended_required_cols if col not in x_train.columns]
        if missing_engineered:
            raise PipelineExecutionError(f"[Step 4 - Feature Engineering] Missing expected engineered columns: {missing_engineered}")
        # Only validate essential columns after feature engineering here (not redundantly elsewhere)
        check_context_columns(x_train, context="Pre-Imputation")

    except Exception:
        logging.error(f"[Step 4 - Feature Engineering] ❌ Failed.")
        raise

    # --- Imputation Helper Function ---
    def impute_and_validate_set(df_input, df_name):
        df_copy = safe_copy(df_input)
        df_copy = impute_missing_values(df_copy, strategy=cfg['imputation']['strategy'], use_knn=cfg['imputation']['use_knn'])
        logging.info(f"🧪 Top columns with NaNs in {df_name} after imputation:")
        logging.info(df_copy.isnull().sum().sort_values(ascending=False).head(10))
        assert not df_copy.isnull().any().any(), f"❌ {df_name} contains NaNs after imputation"
        for col in ["risk_score",  "chol_flag", "target"]:
            if col not in df_copy.columns:
                raise PipelineExecutionError(f"[Step 5 - Imputation] Missing expected column: {col} in {df_name} after imputation.")
        check_column_consistency(df_input, df_copy)
        return df_copy

    try:
        start_time = time.perf_counter()
        df_before = x_train.copy()
        # Insert safe_copy before imputation (train)
        x_train = safe_copy(x_train)
        x_train = impute_missing_values(x_train, strategy=cfg['imputation']['strategy'], use_knn=cfg['imputation']['use_knn'])
        # Log top columns with NaNs in x_train after imputation
        logging.info("🧪 Top columns with NaNs in x_train after imputation:")
        logging.info(x_train.isnull().sum().sort_values(ascending=False).head(10))
        pipeline_logger.warning(f"[{log_id}] [Columns Trace] After imputation: {x_train.columns.tolist()}")
        assert not x_train.isnull().any().any(), "❌ x_train contains NaNs after imputation"
        logging.info("[Step 5 - Imputation] ✅ Imputation completed for training data.")
        for col in ["risk_score",  "chol_flag", "target"]:
            if col not in x_train.columns:
                raise PipelineExecutionError(f"[Step 5 - Imputation] Missing expected column: {col} in x_train after imputation.")
        check_column_consistency(df_before, x_train)
        # Validation set imputation (refactored)
        df_before_val = x_val.copy()
        x_val = impute_and_validate_set(df_before_val, "x_val")
        # Test set imputation (refactored)
        df_before_test = x_test.copy()
        x_test = impute_and_validate_set(df_before_test, "x_test")
        # Validate schema for post-imputation
        from utils.config_loader import load_schema
        from utils.validation import validate_schema
        post_imputation_schema_path = "schemas/post-imputation.yaml"
        post_imputation_schema = load_schema(post_imputation_schema_path)
        validate_schema(x_train, schema=post_imputation_schema)
        # Only one validate_loaded_dataset call per dataset after imputation
        elapsed_time = time.perf_counter() - start_time
        logging.info(f"[Step 5 - Imputation] ⏱️ Time elapsed for Imputation: {elapsed_time:.2f} seconds")
        pipeline_logger.info(f"[{log_id}] [Step 5 - Imputation] ✅ Step Completed: Imputation completed without missing values.")

        post_encoding_schema_path = "schemas/post-encoding.yaml"
        post_encoding_schema = load_schema(post_encoding_schema_path)
        validate_schema(x_train, post_encoding_schema, dataset_name="hypertension")
        logging.info("[Step 5 - Imputation] ✅ Data loaded, cleaned, split, feature-engineered, and imputed successfully.")

        pipeline_logger.info(f"[{log_id}] [Step 6 - Recommendation] ✅ CBF, CF, and Hybrid recommendation completed.")
        _ = run_cbf_pipeline(data_path=dataset_name, log_id=log_id)
        _ = run_cf_pipeline(data_path=dataset_name, log_id=log_id)
        _ = run_hybrid_pipeline(data_path=dataset_name, features=[], local_log_id=log_id)
        # Check if recommendation results were saved properly
        import os
        if not os.path.exists("outputs/df_cbf_recommendations.csv"):
            pipeline_logger.warning(f"[{log_id}] [Save Check] ⚠️ df_cbf_recommendations.csv not found. Was it saved correctly?")
        if not os.path.exists("outputs/df_cf_recommendations.csv"):
            pipeline_logger.warning(f"[{log_id}] [Save Check] ⚠️ df_cf_recommendations.csv not found. Was it saved correctly?")
        if not os.path.exists("outputs/df_hybrid_recommendations.csv"):
            pipeline_logger.warning(f"[{log_id}] [Save Check] ⚠️ df_hybrid_recommendations.csv not found. Was it saved correctly?")

        # --- Verification block: check that outputs were saved correctly ---
        import os

        def check_if_results_saved():
            outputs = {
                "df_cbf_recommendations.csv": "CBF",
                "df_cf_recommendations.csv": "CF",
                "df_hybrid_recommendations.csv": "Hybrid"
            }
            for filename, label in outputs.items():
                path = os.path.join("outputs", filename)
                if os.path.exists(path):
                    logging.info(f"[Verification] ✅ {label} recommendation results found: {path}")
                else:
                    logging.warning(f"[Verification] ⚠️ {label} recommendation results NOT found at expected path: {path}")

        check_if_results_saved()

    except Exception:
        logging.error(f"[Step 5 - Imputation] ❌ Failed.")
        raise

    return {
        "X_train": x_train,
        "X_val": x_val,
        "X_test": x_test,
        "y_train": y_train,
        "y_val": y_val,
        "y_test": y_test,
        "df_cleaned": df_cleaned,
        "dataset_name": dataset_name
    }

try:
    from utils.hcars_utils import get_cbf_features
except ImportError as e:
    logging.error(f"❌ Critical import failure: {e}")
    raise PipelineExecutionError("Required module import failed. Please reinstall required packages.")
try:
    from utils.hcars_utils import filter_existing_features
except ImportError as e:
    logging.error(f"❌ Critical import failure: {e}")
    raise PipelineExecutionError("Required module import failed. Please reinstall required packages.")





def run_full_pipeline(dataset_name: str, config_local=None):
    """
    Executes the full hybrid recommendation pipeline for hypertension patient data.
    Loads the fully contextualized dataset as pipeline input, then proceeds with CBF, CF, Hybrid, and downstream steps.
    """
    from datetime import datetime

    from pathlib import Path
    import os
    # --- [Patch] Load global config at start ---
    if config_local is None:
        from utils.config_loader import load_global_config
        config_local = load_global_config()
        if config_local is None:
            pipeline_logger.critical("❌ [Config Error] load_global_config() returned None — config.yaml might be missing or malformed.")
            raise ValueError("❌ Failed to load config_local from load_global_config().")

    # --- [Step 0] Log dataset and start time ---
    pipeline_logger.info(f"[{log_id}] [Pipeline Start] Dataset: {dataset_name}")
    pipeline_logger.info(f"[{log_id}] [Pipeline Start] Start Time: {datetime.now().isoformat()}")

    # --- Logging utility for pipeline steps ---
    def log_pipeline_step(step_name):
        os.makedirs("outputs", exist_ok=True)
        with open("outputs/pipeline_steps_log.csv", "a") as f:
            f.write(f"{step_name},{datetime.now().isoformat()}\n")

    try:
        # --- [Step 1] Load Fully Contextualized Data ---
        log_pipeline_step("STEP 1: Load Fully Contextualized Data")
        # ✅ Load fully contextualized dataset
        context_data_path = Path(data_path)
        if not context_data_path.exists():
            raise FileNotFoundError(f"❌ Contextualized dataset not found at: {context_data_path}")
        df = pd.read_csv(context_data_path)
        print(f"✅ [Pipeline Input] Loaded contextualized data with shape: {df.shape}")

        # Ensure 'context_feature_id' is present before recommenders
        if "context_feature_id" not in df.columns:
            pipeline_logger.error("❌ 'context_feature_id' not found in input DataFrame. Cannot proceed with recommendation.")
            raise ValueError("Missing required column: context_feature_id")
        # Generate feature_id from context and log with context_logger
        _ = generate_feature_id_from_context(df)
        context_logger.info(f"[Context Mapping] Generated feature_id for {df.shape[0]} rows.")

        # Use df for all subsequent processing
        target_col = config_local.get("target_column", "target")
        if target_col not in df.columns:
            raise PipelineExecutionError(f"Target column '{target_col}' not found in contextualized dataset.")
        y = df[target_col]
        x = df.drop(columns=[target_col])
        # Split the data into train (68%), validation (12%), and test (20%)
        from sklearn.model_selection import train_test_split
        x_train_full, x_test, y_train_full, y_test = train_test_split(
            x, y, test_size=0.20, random_state=config_local.get("random_state", 42), stratify=y
        )
        x_train, x_val, y_train, y_val = train_test_split(
            x_train_full, y_train_full, test_size=0.15, random_state=config_local.get("random_state", 42), stratify=y_train_full
        )
        # If needed, drop any backup columns
        for df_ in [x_train, x_val, x_test]:
            for col in ["target_train_copy", "target_test_copy"]:
                if col in df_.columns:
                    df_.drop(columns=[col], inplace=True)

        # --- [Step 2] Run Recommendation Models ---
        # -------------------------------------------
        log_pipeline_step("STEP 2: Run Recommenders")
        from utils.hcars_utils import get_cbf_features_with_context
        cbf_features_all = get_cbf_features_with_context(config_local) if callable(get_cbf_features_with_context) else []
        from utils.hcars_utils import filter_existing_features
        cbf_features_all_mod = list(cbf_features_all) if cbf_features_all else []
        _risk_added_dynamically = False
        if "risk_score" in x_test.columns and "risk_score" not in cbf_features_all_mod:
            cbf_features_all_mod.append("risk_score")
            _risk_added_dynamically = True
            import logging
            logging.info("[run_full_pipeline] 'risk_score' detected in x_test and dynamically added to CBF features for CBF/Hybrid pipelines.")
        cbf_features = filter_existing_features(x_test, cbf_features_all_mod) if filter_existing_features else []
        if _risk_added_dynamically and "risk_score" in x_test.columns and "risk_score" not in cbf_features:
            cbf_features.append("risk_score")
            import logging
            logging.info("[run_full_pipeline] Ensured 'risk_score' is preserved in CBF features after filtering.")
        missing_cbf = list(set(cbf_features_all_mod) - set(cbf_features)) if cbf_features_all_mod and cbf_features else []
        if missing_cbf:
            import logging
            logging.warning(f"[run_full_pipeline] Some configured CBF features are missing: {missing_cbf}")
        if cbf_features and any(f in cbf_features for f in [ "chol_flag", "age_group"]):
            import logging
            logging.info("[run_full_pipeline] Using derived clinical features in CBF/Hybrid recommender.")
        # --- CBF Pipeline ---
        # All CBF logic is encapsulated in cbf_pipeline.run_cbf_pipeline
        try:
            run_cbf_pipeline(data_path="outputs/tmp/df_contextualized.csv", log_id=log_id)
            logger = pipeline_logger  # Use pipeline_logger for consistency
            logger.info("✅ Content-Based Filtering pipeline executed and results saved.")
        except Exception as cbf_err:
            pipeline_logger.warning(f"[run_full_pipeline] CBF Pipeline execution failed gracefully: {cbf_err}")
        # Load CBF results for downstream steps (e.g., hybrid pipeline) if needed
        _ = pd.read_csv("outputs/tmp/df_cbf_recommendations.csv")
        # --- Collaborative Filtering (CF) Pipeline ---
        try:
            # Ensure required columns before CF
            for col in ["bp_category", "chol_category", "risk_level", "age_group"]:
                if col not in x_val.columns:
                    pipeline_logger.warning(f"[{log_id}] ⚠️ Contextual column missing: {col} — attempting fallback recovery or halting.")
            for col in ["true_response", "bp_category", "risk_level"]:
                if col not in x_val.columns:
                    pipeline_logger.warning(f"[{log_id}] ⚠️ Missing required column '{col}' before running CF model.")
            if "context_feature_id" not in df.columns:
                pipeline_logger.error("❌ 'context_feature_id' not found in input DataFrame. Cannot proceed with recommendation.")
                raise ValueError("Missing required column: context_feature_id")
            # Run CF pipeline (results are saved to file by cf_pipeline.py)
            run_cf_pipeline(data_path="outputs/tmp/df_contextualized.csv", log_id=log_id)
            import logging
            logging.info(f"[run_full_pipeline] CF pipeline executed successfully.")
        except Exception as cf_err:
            pipeline_success = False
            import logging
            logging.warning(f"[run_full_pipeline] CF Pipeline execution failed gracefully: {cf_err}")
            logging.info(f"[run_full_pipeline] CF pipeline success: {pipeline_success}")
        # --- Hybrid Pipeline ---
        try:
            run_hybrid_pipeline(
                data_path="outputs/tmp/df_contextualized.csv", features=cbf_features_all, local_log_id=log_id
            )
            logger = pipeline_logger  # Use pipeline_logger for consistency
            logger.info("✅ Hybrid pipeline executed and results saved.")
        except Exception as hybrid_err:
            import logging
            logging.warning(f"[run_full_pipeline] Hybrid Pipeline execution failed gracefully: {hybrid_err}")
        # If needed later, retain a line to load the result:
        _ = pd.read_csv("outputs/tmp/df_hybrid_recommendations.csv")

        # --- Validate recommendation output files exist ---
        # --- Verify if recommendations were saved properly ---
        expected_outputs = {
            "df_cbf_recommendations.csv": "CBF",
            "df_cf_recommendations.csv": "CF",
            "df_hybrid_recommendations.csv": "Hybrid"
        }
        for filename, label in expected_outputs.items():
            filepath = os.path.join("outputs", filename)
            if not os.path.exists(filepath):
                pipeline_logger.warning(f"[{log_id}] [Save Check] ⚠️ {filename} not found. Was it saved correctly by {label} pipeline?")
            else:
                pipeline_logger.info(f"[{log_id}] [Save Check] ✅ {filename} found.")

        # --- [Step 4] SHAP Explanation ---
        # ----------------------------------

        # --- [Step 3] Train Final Model ---
        # ----------------------------------
        log_pipeline_step("STEP 3: Train Final Model")
        try:
            full_pipeline = train_model(x_train, y_train)
            # --- PATCH: Safe evaluation with validation ---
            from utils.validation import evaluate_with_validation
            if y_val is not None:
                _ = evaluate_with_validation(full_pipeline, x_val, y_val)
            else:
                import logging
                logging.warning("⚠️ y_val is None — skipping evaluation")
                _ = None
            report, report_path, output_dir = evaluate_model(full_pipeline, x_test, y_test, dataset_name)
            evaluation_results = report
        except Exception as eval_err:
            import logging
            logging.error("[Step 7 - Evaluation] ❌ Failed during evaluation phase.")
            _ = {"status": "error", "message": f"Evaluation phase failed: {str(eval_err)}"}
            raise PipelineExecutionError("Evaluation phase failed.") from eval_err

        # --- [Step 4] SHAP Explanation ---
        # ----------------------------------
        # ...unmodified downstream steps...
    except Exception as exec_err:
        pipeline_logger.error(f"❌ [Pipeline] Unexpected error: {str(exec_err)}")
        # If evaluation_results is not available, define a placeholder
        _ = {"status": "error", "message": f"Pipeline failed: {str(exec_err)}"}
        raise

    return {
        "evaluation_results": evaluation_results
    }

# === Future CLI/Streamlit Support Entrypoint ===
def run_full_pipeline_cli():
    from utils.config_loader import load_config
    config_local = load_config()
    run_full_pipeline(dataset_name="hypertension", config_local=config_local)

def create_preprocessor(numeric_features, categorical_features):
    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
    ])
    return ColumnTransformer(transformers=[
        ("num", numeric_transformer, numeric_features),
        ("cat", categorical_transformer, categorical_features)
    ])

def build_preprocessing_pipeline(numeric_features, categorical_features):
    return create_preprocessor(numeric_features, categorical_features)

def train_model(x_train_input, y_train_input):

    logging.info("[Step 7 - Training] ✅ Starting training step.")
    x_train = x_train_input
    y_train_ = y_train_input
    numeric_features = [col for col in x_train.select_dtypes(include=["int64", "float64"]).columns if x_train[col].notnull().any()]
    categorical_features = [col for col in x_train.select_dtypes(include=["object", "category"]).columns if x_train[col].notnull().any()]
    if x_train.empty or x_train.shape[1] == 0:
        logging.error("[Step 7 - Training] ❌ Training data is empty or has 0 features. Cannot train model.")
        raise PipelineExecutionError("Training data is empty or has 0 features. Cannot train model.")
    # --- Class distribution logging and imbalance detection ---
    class_distribution = y_train_.value_counts(normalize=True)
    logging.info(f"[Step 7 - Training] 🎯 Class distribution in y_train: {class_distribution.to_dict()}")
    if class_distribution.min() < 0.1:
        logging.warning("[Step 7 - Training] ⚠️ Class imbalance detected. Consider using stratification or class weights.")
    preprocessor = build_preprocessing_pipeline(numeric_features, categorical_features)
    full_pipeline = Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42))
    ])
    start_time = time.perf_counter()
    if x_train.isnull().any().any():
        logging.warning("[Step 7 - Training] ⚠️ Training data still contains missing values after imputation.")
    try:
        full_pipeline.fit(x_train, y_train_)
        elapsed_time = time.perf_counter() - start_time
        logging.info(f"[Step 7 - Training] ✅ Training completed in {elapsed_time:.2f} seconds.")
        return full_pipeline
    except Exception as train_exception:
        logging.exception("[Step 7 - Training] ❌ Model training failed.")
        raise PipelineExecutionError("Model training failed.") from train_exception


def evaluate_model(full_pipeline, x_test_input, y_test_input, dataset=None, local_log_id="global"):
    logging.info(f"[{local_log_id}] [Step 7 - Evaluation] ✅ Starting evaluation step.")
    start_time = time.perf_counter()
    x_test = x_test_input
    y_test_ = y_test_input
    try:
        critical_cols = ["age", "chol", "trestbps"]
        for col in critical_cols:
            if col not in x_test.columns or x_test[col].isnull().all():
                logging.error(f"[{local_log_id}] [Step 7 - Evaluation] ❌ Critical clinical feature '{col}' missing or empty before evaluation.")
                raise PipelineExecutionError(f"Missing or empty critical column: {col}")
        # --- Class distribution logging and prediction sanity check ---
        test_distribution = y_test_.value_counts(normalize=True)
        logging.info(f"[{local_log_id}] [Step 7 - Evaluation] 🎯 Class distribution in y_test: {test_distribution.to_dict()}")
        y_pred = full_pipeline.predict(x_test)
        if len(y_pred) != len(y_test_):
            raise PipelineExecutionError(f"[{local_log_id}] [Step 7 - Evaluation] ❌ Length mismatch: y_pred={len(y_pred)} vs y_test={len(y_test_)}")
        report = classification_report(y_test_, y_pred, output_dict=True)
        # --- Report validity check ---
        if not report or not isinstance(report, dict):
            raise PipelineExecutionError(f"[{local_log_id}] [Step 7 - Evaluation] ❌ Invalid classification report.")
        logging.info(f"[{local_log_id}] [Step 7 - Evaluation] ✅ Classification report verified and ready for export.")
        elapsed_time = time.perf_counter() - start_time
        logging.info(f"[{local_log_id}] [Step 7 - Evaluation] ✅ Evaluation completed in {elapsed_time:.2f} seconds.")
        # Log summary metrics (AUC, precision, recall) if possible
        try:
            if hasattr(full_pipeline, "predict_proba"):
                y_prob = full_pipeline.predict_proba(x_test)[:, 1]
                auc = roc_auc_score(y_test_, y_prob)
            else:
                auc = None
        except (AttributeError, IndexError, ValueError) as eval_error:
            logging.warning(f"[{local_log_id}] ⚠️ AUC computation failed: {eval_error}")
            auc = None
        try:
            precision = report["1"]["precision"] if "1" in report else None
            recall = report["1"]["recall"] if "1" in report else None
        except (KeyError, TypeError) as report_error:
            logging.warning(f"[{local_log_id}] ⚠️ Precision/Recall extraction failed: {report_error}")
            precision = None
            recall = None
        logging.info(f"[{local_log_id}] ✅ Evaluation completed. AUC: {auc:.3f}, Precision: {precision:.3f}, Recall: {recall:.3f}")
    except Exception as eval_exception:
        logging.exception(f"[{local_log_id}] [Step 7 - Evaluation] ❌ Model evaluation failed.")
        raise PipelineExecutionError("Model evaluation failed.") from eval_exception
    output_dir = os.path.join("outputs", "reports", dataset) if dataset is not None else os.path.join("outputs", "reports", "unknown")
    os.makedirs(output_dir, exist_ok=True)
    report_path = os.path.join(output_dir, "classification_report.csv")
    logging.info(f"[{local_log_id}] [Step 7 - Evaluation] 🛡️ Starting report save operation...")
    try:
        os.makedirs(os.path.dirname(report_path), exist_ok=True)
        import pandas as pandas_lib
        pandas_lib.DataFrame(report).transpose().to_csv(report_path)
        logging.info(f"[{local_log_id}] [Step 7 - Evaluation] ✅ Classification report saved successfully at {report_path}")
    except Exception as report_save_exception:
        logging.warning(f"[{local_log_id}] [Step 7 - Evaluation] ⚠️ Failed to save classification report at {report_path}: {report_save_exception}")
    logging.info(f"[{local_log_id}] [Step 7 - Evaluation] 🏁 Report save operation completed.")
    # Return report, path, output_dir as before
    return report, report_path, output_dir

def main():
    """
    Main entrypoint for running the full hypertension recommendation pipeline.
    Loads configuration, sets up logging, loads and cleans data, runs all pipeline steps,
    and reports outputs. Can be invoked from CLI or as a module.
    """

    print("=" * 80)
    print("🚀 Hybrid Context-Aware Recommendation System for Hypertension Problem")
    print("📦 Starting full pipeline execution:")
    print("1️⃣  Initialize configuration and logging")
    print("2️⃣  Load and clean the dataset (remove nulls, duplicates, high-missing columns)")
    print("3️⃣  Feature engineering and risk score derivation")
    print("4️⃣  Train/test split and target backup")
    print("5️⃣  Apply contextual feature engineering")
    print("6️⃣  Impute missing values")
    print("7️⃣  Run Content-Based Filtering (CBF)")
    print("8️⃣  Run Collaborative Filtering (CF)")
    print("9️⃣  Run Hybrid recommender")
    print("🔟  Train final classifier and evaluate")
    print("✅  Export SHAP, fairness, reports, model")
    print("=" * 80)

    pipeline_logger.info(f"[{log_id}] [Pipeline Init] Config and data path resolved successfully.")
    pipeline_logger.info(f"[{log_id}] [Config Debug] Final resolved config path: {get_config_path()}")
    pipeline_logger.info(f"[{log_id}] [Pipeline Init] ✅ Data and configuration loaded successfully from config.yaml.")
    # --- [Step 2] Run full pipeline ---
    try:
        # Always use the contextualized data_path as dataset_name
        results = run_full_pipeline(dataset_name="outputs/tmp/df_contextualized.csv")
        if results and isinstance(results, dict):
            summary = results.get("evaluation_results", "No results")
        else:
            summary = "No results (run_full_pipeline returned None or invalid type)"
        pipeline_logger.info(f"[{log_id}] [Pipeline] ✅ Pipeline executed successfully. Summary: {summary}")
    except Exception:
        pipeline_logger.exception(f"[{log_id}] [Pipeline] ❌ Pipeline execution failed with an unexpected error.")
        raise

    # --- [Step 3] Final logging and reporting ---
    pipeline_logger.info(f"[{log_id}] [Pipeline] ✅ Pipeline execution finished. See outputs and logs for results.")
    pipeline_logger.info(f"[{log_id}] 🎉 Pipeline execution completed. Check outputs/ and logs/ for results.")


# CLI/Script entrypoint

if __name__ == "__main__":
    data_path = "outputs/tmp/df_contextualized.csv"
    log_id = "run_pipeline"

    # --- Final check for recommendation outputs ---
    expected_files = {
        "df_cbf_recommendations.csv": "CBF",
        "df_cf_recommendations.csv": "CF",
        "df_hybrid_recommendations.csv": "Hybrid"
    }

    for file_name, model_type in expected_files.items():
        file_path = os.path.join("outputs", file_name)
        if not os.path.exists(file_path):
            pipeline_logger.warning(f"[{log_id}] [Save Check] ⚠️ {file_name} not found. Was it saved correctly by the {model_type} pipeline?")
