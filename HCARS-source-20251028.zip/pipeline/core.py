"""
ملاحظة هامة: يجب أن تُقرأ كل فلترة أو تخصيص من config وليس من ثابت برمجي.
"""


import pandas as pd
from pandas.api import types as pdt
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from utils.config_loader import load_global_config
from utils.constants import assign_feature_id_by_binned, BINNED_CONTEXT_COLUMNS, get_top_n_ui
import logging
import numpy as np


# ⚠️ جميع عمليات بناء feature_id النهائي تعتمد على تسلسل القواميس الرسمية:
# FEATURE_ID_BINNED_MAP → recommend_by_binned → manual_review fallback
# يجب تحديث القواميس في utils.constants عند أي تعديل للمعايير السريرية أو السياقية

# --- Helper: ensure feature_id_binned exists and is normalized (bp_bin4__chol_bins__age_q3) ---
def _ensure_feature_id_binned(df: pd.DataFrame, logger=None, log_id=None) -> pd.DataFrame:
    """
    If 'feature_id_binned' is absent but BINNED_CONTEXT_COLUMNS exist, synthesize it
    using the canonical triad key (bp_bin4__chol_bins__age_q3) with whitespace removed.
    """
    try:
        if "feature_id_binned" in df.columns and df["feature_id_binned"].notna().any():
            return df
        missing = [c for c in BINNED_CONTEXT_COLUMNS if c not in df.columns]
        if missing:
            if logger:
                logger.warning(f"[{log_id}] ⚠️ Cannot synthesize 'feature_id_binned'. Missing columns: {missing}")
            return df
        # Build normalized triad key for every row
        df["feature_id_binned"] = (
            df[BINNED_CONTEXT_COLUMNS[0]].astype(str).str.strip() + "__" +
            df[BINNED_CONTEXT_COLUMNS[1]].astype(str).str.strip() + "__" +
            df[BINNED_CONTEXT_COLUMNS[2]].astype(str).str.strip()
        ).str.replace(" ", "", regex=False)
        if logger:
            logger.info(f"[{log_id}] ✅ 'feature_id_binned' synthesized from {BINNED_CONTEXT_COLUMNS}.")
    except Exception as e:
        if logger:
            logger.error(f"[{log_id}] ❌ Failed to synthesize 'feature_id_binned': {e}")
    return df

def generate_feature_id_from_context(df: pd.DataFrame, logger=None, log_id=None) -> pd.DataFrame:
    """
    يستخدم القاموس المركزي أو دالة التوليد لتوليد feature_id من feature_id_binned.
    """
    # ملاحظة: أي تحديث على القواميس أو الأعمدة السياقية (CONTEXT_COLUMNS) يجب أن ينعكس في utils.constants وجميع الدوال التابعة
    if "feature_id_binned" in df.columns:
        df = assign_feature_id_by_binned(df, use_map=True, log=logger, log_id=log_id)
        if logger:
            logger.info(f"[{log_id}] ✅ feature_id generated using assign_feature_id_by_binned")
    else:
        if logger:
            logger.warning(f"[{log_id}] ❌ feature_id_binned not found; cannot generate feature_id")
    return df

# ---------------- Schema Checking Utility ----------------
def check_schema(df: pd.DataFrame, required_columns: list, stage_name: str | None = None, logger=None, log_id=None) -> bool:
    """
    Strict schema checker.
    - Raises ValueError when any required column is missing.
    - `stage_name` provides a clear context in the error message/logs.
    - Returns True when all columns are present.
    """
    if not isinstance(required_columns, (list, tuple)):
        raise TypeError(f"[check_schema] required_columns must be a list/tuple, got {type(required_columns)}")
    missing = [col for col in required_columns if col not in df.columns]
    stage = stage_name or (log_id if isinstance(log_id, str) else "unknown_stage")
    if missing:
        msg = f"[{stage}] ❌ Missing columns: {missing}"
        if logger:
            logger.error(msg)
        else:
            print(msg)
        raise ValueError(msg)
    ok_msg = f"[{stage}] ✅ All required columns present."
    if logger:
        logger.info(ok_msg)
    else:
        print(ok_msg)
    return True

# ---------------- Score Normalization Utility ----------------


def normalize_scores(df: pd.DataFrame, col: str, clamp: tuple[float, float] = (0.0, 1.0)) -> pd.DataFrame:
    """Clamp a numeric score column into a fixed range (default [0,1]) in-place and return df."""
    if df is None or col not in df.columns:
        return df
    lo, hi = clamp
    df[col] = df[col].clip(lo, hi)
    return df


# --- Lightweight clinical feature engineering: comorbidities & labs ---
def add_clinical_comorbidities_and_labs(df: pd.DataFrame, log_id="core") -> pd.DataFrame:
    """
    Lightweight clinical feature engineering to enrich CF/CBF without changing the family key (feature_id_binned).
    Adds comorbidity flags and common lab categorizations when available. Safe no-op if columns are absent.
    """
    plog = logging.getLogger("pipeline_logger")
    df = df.copy()

    # Comorbidity flags (0/1) if source columns exist
    for col in ["diabetes", "smoker", "ckd", "cad"]:
        if col in df.columns:
            df[f"{col}_flag"] = (pd.to_numeric(df[col], errors="coerce").fillna(0) > 0).astype(int)

    # Common labs (bucketized) if available
    if "hba1c" in df.columns:
        df["hba1c_cat"] = pd.cut(pd.to_numeric(df["hba1c"], errors="coerce"),
                                 bins=[-np.inf, 5.6, 6.4, np.inf],
                                 labels=["normal", "prediabetes", "diabetes"])
    if "egfr" in df.columns:
        df["egfr_cat"] = pd.cut(pd.to_numeric(df["egfr"], errors="coerce"),
                                bins=[-np.inf, 30, 60, 90, np.inf],
                                labels=["severe", "moderate", "mild", "normal"])
    if "ldl" in df.columns:
        df["ldl_cat"] = pd.cut(pd.to_numeric(df["ldl"], errors="coerce"),
                               bins=[-np.inf, 100, 130, 160, np.inf],
                               labels=["optimal", "near_opt", "borderline", "high"])
    if "bmi" in df.columns:
        df["bmi_cat"] = pd.cut(pd.to_numeric(df["bmi"], errors="coerce"),
                               bins=[-np.inf, 18.5, 25, 30, np.inf],
                               labels=["under", "normal", "over", "obese"])

    plog.info(f"[{log_id}] Added comorbidity & lab features where available.")
    return df

def prepare_data(dataset: pd.DataFrame, config=None, logger=None, log_id=None):
    """
    prepares the dataset by applying necessary transformations before splitting.
    this includes schema validation, null removal, column renaming, and feature synthesis.

    Parameters:
        dataset (pd.DataFrame): The original dataset loaded.
        config (dict, optional): Configuration dictionary. if None, global config will be loaded.
        logger (logging.Logger, optional): Logger instance for reporting and debugging.
        log_id (str, optional): Identifier for logging/debug.

    Returns:
        pd.DataFrame: The cleaned and feature-enhanced dataset.
    """
    if config is None:
        config = load_global_config()

    # Ensure input behaves like a DataFrame (duck-typing) to avoid static "unreachable" warnings
    try:
        _ = dataset.shape  # probe attribute used below
    except Exception as e:
        msg = f"[prepare_data] Expected a pandas DataFrame-like object with `.shape`, got {type(dataset)} instead."
        if logger:
            logger.error(msg, extra={'log_id': log_id})
        raise TypeError(msg) from e
    msg = f"[Pipeline Core] ✅ Received dataset with shape: {dataset.shape}"
    if logger:
        logger.info(msg, extra={'log_id': log_id})
    else:
        print(msg)
    msg = f"[Pipeline Core] 🧑‍⚕️ Number of unique patients before cleaning: {dataset['patient_id'].nunique() if 'patient_id' in dataset.columns else 'N/A'}"
    if logger:
        logger.info(msg, extra={'log_id': log_id})
    else:
        print(msg)

    # Drop unwanted columns if specified
    columns_to_drop = config.get("columns_to_drop", [])
    if columns_to_drop:
        dataset = dataset.drop(columns=[col for col in columns_to_drop if col in dataset.columns], errors='ignore')
        msg = f"[prepare_data] Dropped columns: {columns_to_drop}"
        if logger:
            logger.info(msg, extra={'log_id': log_id})
        else:
            print(msg)

    # Replace known placeholders with NaN
    placeholders = config.get("nan_placeholders", ["NA", "N/A", "", " "])
    dataset = dataset.replace(to_replace=placeholders, value=pd.NA)
    msg = f"[prepare_data] Replaced placeholders {placeholders} with NaN"
    if logger:
        logger.info(msg, extra={'log_id': log_id})
    else:
        print(msg)

    # Drop rows with critical missing values
    required_cols = config.get("required_columns", [])
    if required_cols:
        before_drop = dataset.shape[0]
        dataset.dropna(subset=required_cols, inplace=True)
        after_drop = dataset.shape[0]
        msg = f"[prepare_data] Dropped rows with missing values in {required_cols}: {before_drop - after_drop} rows removed"
        if logger:
            logger.info(msg, extra={'log_id': log_id})
        else:
            print(msg)

    # Type enforcement
    dtype_enforcement = config.get("force_types", {})
    for col, dtype in dtype_enforcement.items():
        if col in dataset.columns:
            try:
                dataset[col] = dataset[col].astype(dtype)
                msg = f"[prepare_data] Column '{col}' converted to type {dtype}"
                if logger:
                    logger.info(msg, extra={'log_id': log_id})
                else:
                    print(msg)
            except (ValueError, TypeError) as conversion_error:
                msg = f"[Type Enforcement Warning] Could not convert column '{col}' to {dtype}: {conversion_error}"
                if logger:
                    logger.warning(msg, extra={'log_id': log_id})
                else:
                    print(msg)

    # Rename columns if specified
    rename_map = config.get("rename_columns", {})
    if rename_map:
        dataset.rename(columns=rename_map, inplace=True)
        msg = f"[prepare_data] Renamed columns as per map: {rename_map}"
        if logger:
            logger.info(msg, extra={'log_id': log_id})
        else:
            print(msg)

    # Encode categorical columns if specified
    encode_cols = config.get("encode_columns", [])
    for col in encode_cols:
        if col in dataset.columns and pdt.is_object_dtype(dataset[col]):
            dataset[col] = dataset[col].astype("category").cat.codes
            msg = f"[prepare_data] Encoded categorical column '{col}' to category codes"
            if logger:
                logger.info(msg, extra={'log_id': log_id})
            else:
                print(msg)

    # Enrich with clinical comorbidities & labs (does not alter the family key)
    dataset = add_clinical_comorbidities_and_labs(dataset, log_id=log_id)
    # Ensure feature_id_binned exists (uses BINNED_CONTEXT_COLUMNS) before generating feature_id
    dataset = _ensure_feature_id_binned(dataset, logger=logger, log_id=log_id)

    msg = f"[prepare_data] Final dataset shape: {dataset.shape}"
    if logger:
        logger.info(msg, extra={'log_id': log_id})
    else:
        print(msg)
    msg = f"[prepare_data] 🧑‍⚕️ Number of unique patients after cleaning: {dataset['patient_id'].nunique() if 'patient_id' in dataset.columns else 'N/A'}"
    if logger:
        logger.info(msg, extra={'log_id': log_id})
    else:
        print(msg)
    if "feature_id_binned" in dataset.columns:
        dataset = generate_feature_id_from_context(dataset, logger=logger, log_id=log_id)
        msg = "[prepare_data] ✅ feature_id column generated from feature_id_binned using new mapping."
        if logger:
            logger.info(msg, extra={'log_id': log_id})
        else:
            print(msg)
        if "feature_id" in dataset.columns:
            unique_ids = dataset["feature_id"].unique()
            manual_count = (dataset["feature_id"] == "manual_review").sum()
            msg = f"[{log_id}] feature_id unique values: {unique_ids[:10]}, manual_review count: {manual_count}"
            if logger:
                logger.info(msg, extra={'log_id': log_id})
            else:
                print(msg)
    return dataset


def _temporal_split(df: pd.DataFrame, config: dict, log_id=None, logger=None):
    """
    Time-based split to reduce leakage.
    Requires a timestamp column name in config['split']['timestamp_col'].
    Splits by chronological order: oldest -> train, middle -> val, newest -> test.
    """
    ts_col = (config.get("split", {}) or {}).get("timestamp_col")
    if not ts_col or ts_col not in df.columns:
        raise ValueError(f"[{log_id}] ❌ temporal_split requested but timestamp column '{ts_col}' not found.")
    # Ensure datetime
    _df = df.copy()
    _df[ts_col] = pd.to_datetime(_df[ts_col], errors="coerce")
    _df = _df.sort_values(ts_col).reset_index(drop=True)

    test_frac = float(config.get("split", {}).get("test", 0.20))
    val_frac  = float(config.get("split", {}).get("val", 0.12))
    n = len(_df)
    n_test = int(round(n * test_frac))
    n_val  = int(round(n * val_frac))
    n_train = max(0, n - n_test - n_val)

    train_df = _df.iloc[:n_train].copy()
    val_df   = _df.iloc[n_train:n_train + n_val].copy()
    test_df  = _df.iloc[n_train + n_val:].copy()

    train_df["split"] = "train"
    val_df["split"]   = "val"
    test_df["split"]  = "test"

    if logger:
        logger.info(f"[{log_id}] ⏱️ Temporal split with ts='{ts_col}': train={train_df.shape}, val={val_df.shape}, test={test_df.shape}")
    return train_df, val_df, test_df


def _grouped_patient_split(df: pd.DataFrame, config: dict, log_id=None, logger=None):
    """
    Patient-grouped split: ensures no patient appears across splits (prevents leakage).
    Uses GroupShuffleSplit twice to get (train, val, test) by grouping on 'patient_id'.
    """
    from sklearn.model_selection import GroupShuffleSplit

    if "patient_id" not in df.columns:
        raise ValueError(f"[{log_id}] ❌ grouped_patient split requires 'patient_id' column.")
    gss = GroupShuffleSplit(n_splits=1, test_size=config.get("split", {}).get("test", 0.20), random_state=42)
    groups = df["patient_id"]
    idx = df.index.to_numpy()

    train_val_idx, test_idx = next(gss.split(idx, groups=groups))
    train_val_df = df.loc[idx[train_val_idx]].copy()
    test_df      = df.loc[idx[test_idx]].copy()
    test_df["split"] = "test"

    # Now split train/val from train_val_df with grouping
    groups_tv = train_val_df["patient_id"]
    gss2 = GroupShuffleSplit(n_splits=1, test_size=config.get("split", {}).get("val", 0.12) /
                                           (1.0 - config.get("split", {}).get("test", 0.20)), random_state=42)
    tv_idx = train_val_df.index.to_numpy()
    train_idx, val_idx = next(gss2.split(tv_idx, groups=groups_tv))

    train_df = train_val_df.loc[train_idx].copy()
    val_df   = train_val_df.loc[val_idx].copy()
    train_df["split"] = "train"
    val_df["split"]   = "val"

    if logger:
        logger.info(f"[{log_id}] 👥 Grouped-by-patient split: train={train_df.shape}, val={val_df.shape}, test={test_df.shape}; "
                    f"unique patients — train={train_df['patient_id'].nunique()}, val={val_df['patient_id'].nunique()}, test={test_df['patient_id'].nunique()}")
    return train_df, val_df, test_df


def _loo_per_patient_split(df: pd.DataFrame, config: dict, log_id=None, logger=None):
    """
    Leave-One-Out per patient:
      - For each patient with >=2 interactions: last interaction -> test (by timestamp if provided, else by row order).
      - Optionally, for patients with >=3 interactions, the second last -> val (controlled by split['val_use_second_last']=True).
      - Remaining go to train.
    """
    ts_col = (config.get("split", {}) or {}).get("timestamp_col")
    use_second_last_for_val = bool((config.get("split", {}) or {}).get("val_use_second_last", True))

    if "patient_id" not in df.columns:
        raise ValueError(f"[{log_id}] ❌ LOO split requires 'patient_id' column.")

    frames = {"train": [], "val": [], "test": []}
    for pid, g in df.groupby("patient_id", sort=False):
        g_sorted = g.copy()
        if ts_col and ts_col in g_sorted.columns:
            g_sorted[ts_col] = pd.to_datetime(g_sorted[ts_col], errors="coerce")
            g_sorted = g_sorted.sort_values(ts_col)
        else:
            g_sorted = g_sorted.reset_index(drop=False).sort_values("index")  # stable order fallback

        if len(g_sorted) == 1:
            g_sorted["split"] = "train"
            frames["train"].append(g_sorted)
            continue

        # Assign last to test
        test_row = g_sorted.iloc[[-1]].copy()
        test_row["split"] = "test"
        frames["test"].append(test_row)

        remaining = g_sorted.iloc[:-1].copy()
        if use_second_last_for_val and len(remaining) >= 2:
            val_row = remaining.iloc[[-1]].copy()
            val_row["split"] = "val"
            frames["val"].append(val_row)
            train_part = remaining.iloc[:-1].copy()
        else:
            train_part = remaining

        if not train_part.empty:
            train_part["split"] = "train"
            frames["train"].append(train_part)

    train_df = pd.concat(frames["train"], ignore_index=True) if frames["train"] else df.iloc[0:0].copy()
    val_df   = pd.concat(frames["val"],   ignore_index=True) if frames["val"]   else df.iloc[0:0].copy()
    test_df  = pd.concat(frames["test"],  ignore_index=True) if frames["test"]  else df.iloc[0:0].copy()

    if logger:
        logger.info(f"[{log_id}] 🧪 LOO-per-patient split: train={train_df.shape}, val={val_df.shape}, test={test_df.shape}")
    return train_df, val_df, test_df


def prepare_train_val_test_split(df: pd.DataFrame, config: dict, log_id=None, logger=None):
    """
    splits contextualized dataset into train/validation/test sets using stratified logic based on 'feature_id'.

    Note:
        Schema validation here should only check raw columns such as ["patient_id", "feature_id", "target", "true_response"].
        do NOT check final recommendation output columns (e.g., score_cf, reason) at this stage.

    Parameters:
        df (pd.DataFrame): Fully processed and contextualized dataset.
        config (dict): Loaded pipeline configuration.
        log_id (str, optional): Identifier for logging/debugging.
        logger (logging.Logger, optional): Logger instance for reporting and debugging.

    Returns:
        Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]: train_df, val_df, test_df
    """
    from sklearn.model_selection import train_test_split

    # Duck-typing check to keep code reachable for static analyzers
    try:
        _ = df.columns  # used later
    except Exception as e:
        msg = f"[{log_id}] ❌ Input is not a DataFrame-like object (missing `.columns`). Got: {type(df)}"
        if logger:
            logger.error(msg)
        raise TypeError(msg) from e

    # Optional leakage-aware split strategies
    split_method = (config.get("split", {}) or {}).get("method", "stratified_feature")
    if split_method in {"temporal", "grouped_patient", "loo_per_patient"}:
        if split_method == "temporal":
            return _temporal_split(df, config, log_id=log_id, logger=logger)
        elif split_method == "grouped_patient":
            return _grouped_patient_split(df, config, log_id=log_id, logger=logger)
        elif split_method == "loo_per_patient":
            return _loo_per_patient_split(df, config, log_id=log_id, logger=logger)

    if "feature_id" not in df.columns:
        raise ValueError(f"[{log_id}] ❌ 'feature_id' column missing. Cannot stratify properly.")

    test_size = config.get("split", {}).get("test", 0.20)
    val_size = config.get("split", {}).get("val", 0.12)
    train_size = 1.0 - test_size - val_size

    stratify_col = df["feature_id"].apply(lambda x: x if pd.notna(x) else "unknown")

    train_val_df, test_df = train_test_split(
        df,
        test_size=test_size,
        stratify=stratify_col,
        random_state=42
    )
    test_df["split"] = "test"

    stratify_col_tv = train_val_df["feature_id"].apply(lambda x: x if pd.notna(x) else "unknown")
    val_relative_size = val_size / (train_size + val_size)

    train_df, val_df = train_test_split(
        train_val_df,
        test_size=val_relative_size,
        stratify=stratify_col_tv,
        random_state=42
    )
    train_df["split"] = "train"
    val_df["split"] = "val"

    # Ensure all original columns including 'split' are preserved in the returned DataFrames
    train_df = train_df.loc[:, df.columns.tolist() + ["split"]]
    val_df = val_df.loc[:, df.columns.tolist() + ["split"]]
    test_df = test_df.loc[:, df.columns.tolist() + ["split"]]

    print(f"[{log_id}] ✅ Train/Val/Test sizes: {train_df.shape}, {val_df.shape}, {test_df.shape}")
    print(f"[{log_id}] 🧑‍⚕️ Unique patients in Train: {train_df['patient_id'].nunique() if 'patient_id' in train_df.columns else 'N/A'} | Val: {val_df['patient_id'].nunique() if 'patient_id' in val_df.columns else 'N/A'} | Test: {test_df['patient_id'].nunique() if 'patient_id' in test_df.columns else 'N/A'}")
    # --- Schema validation for each split ---
    output_columns_cfg = config.get("output_columns")
    required_out_cols = []

    # Gather potential required output columns from config (if provided)
    if isinstance(output_columns_cfg, dict):
        rec_type = config.get("recommendation_type")
        if rec_type and rec_type in output_columns_cfg:
            required_out_cols = list(output_columns_cfg.get(rec_type, []))
        else:
            for v in output_columns_cfg.values():
                if isinstance(v, (list, tuple)):
                    required_out_cols.extend(v)
        # de-duplicate while preserving order
        seen = set()
        required_out_cols = [c for c in required_out_cols if not (c in seen or seen.add(c))]
    elif isinstance(output_columns_cfg, (list, tuple)):
        required_out_cols = list(output_columns_cfg)

    # Filter to only the raw columns we check at this stage
    raw_columns = ["patient_id", "feature_id", "target", "true_response"]
    required_out_cols = [col for col in required_out_cols if col in raw_columns]

    # Only check if any raw columns were found
    if required_out_cols:
        check_schema(train_df, required_out_cols, stage_name=f"{log_id or 'split'}:train", logger=logger, log_id=log_id)
        check_schema(val_df, required_out_cols, stage_name=f"{log_id or 'split'}:val", logger=logger, log_id=log_id)
        check_schema(test_df, required_out_cols, stage_name=f"{log_id or 'split'}:test", logger=logger, log_id=log_id)

    # All original columns including 'split' are preserved in each DataFrame.
    # This ensures no original columns are dropped during any filtering or processing steps after this point.

    return train_df, val_df, test_df


def evaluate_with_validation(model, x_test, y_test, pipeline_config=None, log_id: str = "global"):
    """
    evaluates the model on the validation/test set and logs performance metrics.

    Parameters:
        model: Trained scikit-learn compatible model.
        x_test (pd.DataFrame): Test features.
        y_test (pd.Series): True test labels.
        pipeline_config (dict, optional): Configuration for report verbosity.
        log_id (str): Identifier for logging output.

    Returns:
        dict: Evaluation metrics including accuracy and classification report.

    performs a check for required columns: 'target' and 'true_response', logging warnings if any are missing.
    """
    if pipeline_config is None:
        pipeline_config = load_global_config()

    required_cols = ["target", "true_response"]
    missing_cols = [col for col in required_cols if col not in x_test.columns and col != y_test.name]
    if missing_cols:
        print(f"[{log_id}] ⚠️ Missing expected columns: {missing_cols}")

    y_pred = model.predict(x_test)

    precision, recall, map_k, ndcg_k = None, None, None, None

    report = classification_report(y_test, y_pred, output_dict=True)
    matrix = confusion_matrix(y_test, y_pred)
    accuracy = accuracy_score(y_test, y_pred)

    print(f"[{log_id}] ✅ Final Model Evaluation")
    print(f"[{log_id}] Confusion Matrix:")
    print(matrix)
    print(f"\n[{log_id}] Classification Report:")
    print(classification_report(y_test, y_pred))

    if pipeline_config and pipeline_config.get("save_report_path"):
        import json
        save_path = pipeline_config["save_report_path"]
        with open(save_path, "w") as f:
            json.dump({
                "accuracy": accuracy,
                "confusion_matrix": matrix.tolist(),
                "classification_report": report,
                "precision_at_k": precision,
                "recall_at_k": recall,
                "map_at_k": map_k,
                "ndcg_at_k": ndcg_k,
            }, f, indent=4)
        print(f"[{log_id}] [evaluate_with_validation] Report saved to: {save_path}")

    return {
        "accuracy": accuracy,
        "confusion_matrix": matrix,
        "classification_report": report,
        "precision_at_k": precision,
        "recall_at_k": recall,
        "map_at_k": map_k,
        "ndcg_at_k": ndcg_k,
    }

def evaluate_recommendations(df_recommendations: pd.DataFrame, true_col: str, pred_col: str, k: int = 5, log_id=None) -> dict:
    """
    evaluates recommendation quality using top-K metrics like precision@k, recall@k, MAP@k, and nDCG@k.

    Parameters:
        df_recommendations (pd.DataFrame): DataFrame with columns for true and predicted feature_ids.
        true_col (str): Column with ground-truth feature_id.
        pred_col (str): Column with list of recommended feature_ids per user.
        k (int): Number of top predictions to evaluate.
        log_id (str): Optional log identifier.

    Returns:
        dict: Dictionary of evaluation metrics.
    """
    from utils.eval_metrics import precision_at_k, recall_at_k, map_at_k, ndcg_at_k

    if df_recommendations[true_col].isnull().any():
        print(f"[{log_id}] ⚠️ Missing true values in column '{true_col}'")
    if df_recommendations[pred_col].isnull().any():
        print(f"[{log_id}] ⚠️ Missing predicted values in column '{pred_col}'")

    y_true = df_recommendations[true_col]
    y_pred = df_recommendations[pred_col]

    y_true_list = [[val] for val in y_true.tolist()]
    y_pred_list = y_pred.tolist()

    precision = precision_at_k(y_true_list, y_pred_list, k)
    recall = recall_at_k(y_true_list, y_pred_list, k)
    map_k_val = map_at_k(y_true_list, y_pred_list, k)
    ndcg = ndcg_at_k(y_true_list, y_pred_list, k)

    print(f"[{log_id}] 📊 Evaluation @K={k} — Precision: {precision:.4f}, Recall: {recall:.4f}, MAP: {map_k_val:.4f}, nDCG: {ndcg:.4f}")

    return {
        "precision_at_k": precision,
        "recall_at_k": recall,
        "map_at_k": map_k_val,
        "ndcg_at_k": ndcg
    }


# ---------------- Recommendation Merge Utility ----------------
def merge_recommendations_from_sources(recs_list, config, all_patient_ids=None, logger=None, log_id=None):
    """
    recs_list: قائمة DataFrames لكل مصدر توصية (مثلاً [cf_df, cbf_df, cold_start_df])
    config: الإعدادات الكاملة
    all_patient_ids: قائمة بجميع معرفات المرضى من البيانات الأصلية (اختياري)
    """
    # إذا لم يمرر config، استورده
    if config is None:
        from utils.config_loader import load_global_config
        config = load_global_config()
    merged = pd.concat(recs_list, ignore_index=True)
    # إعداد المتغيرات من config
    top_n = get_top_n_ui(config)
    score_threshold_enabled = config["recommendation"].get("score_threshold_enabled", True)
    score_threshold = config["recommendation"].get("score_threshold", 0.1)
    fallback_list = config["recommendation"].get("safe_fallback_recommendations", ["lifestyle_monitoring"])
    fallback_score = config["recommendation"].get("fallback_score_cf", 0.01)
    # فلترة score إذا مفعل
    if score_threshold_enabled and "score_cf" in merged.columns:
        before = len(merged)
        merged = merged[merged["score_cf"] >= score_threshold]
        after = len(merged)
        if logger:
            logger.info(f"[{log_id}] تم حذف {before - after} صف بناءً على score_cf threshold")
    elif score_threshold_enabled and "score_cf" not in merged.columns and logger:
        logger.warning(f"[{log_id}] ⚠️ 'score_cf' not found; skipping score threshold filtering.")
    # تصفية Top-N لكل مريض
    if "score_cf" in merged.columns:
        merged = (merged.groupby("patient_id", group_keys=False)
                          .apply(lambda g: g.nlargest(top_n, "score_cf"))
                          .reset_index(drop=True))
    else:
        # If score is absent, keep first-N per patient deterministically
        merged = (merged.sort_values(by=["patient_id"])
                          .groupby("patient_id", group_keys=False)
                          .head(top_n)
                          .reset_index(drop=True))
    # إضافة fallback إذا لم يجد توصية
    if all_patient_ids is not None:
        missing_patients = set(all_patient_ids) - set(merged["patient_id"].unique())
        for patient_id in missing_patients:
            for fid in fallback_list:
                fallback_row = {
                    "patient_id": patient_id,
                    "feature_id": fid,
                    "score_cf": fallback_score,
                    "reason": "forced_safe_default_no_recommendation"
                }
                merged = pd.concat([merged, pd.DataFrame([fallback_row])], ignore_index=True)
                if logger:
                    logger.warning(f"[{log_id}] Fallback recommendation added for patient {patient_id}: {fid}")
    # أخذ الأعمدة النهائية فقط
    output_cols = config.get("output_columns", {}).get("final", list(merged.columns))
    merged = merged.loc[:, [col for col in output_cols if col in merged.columns]]
    return merged