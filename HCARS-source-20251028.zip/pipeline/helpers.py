import uuid
import os
import sys
import logging
import yaml
import pandas as pd
import numpy as np

from logging import getLogger
import hashlib
from utils.logging_utils import setup_logger
from utils.constants import assign_feature_id_by_binned, BINNED_CONTEXT_COLUMNS

"""
===============================================================================
ملف helpers.py - أدوات مساعدة وتحقق للبيانات في نظام توصية ارتفاع ضغط الدم.
------------------------------------------------------------------------------
ملاحظة توثيقية هامة:
- أثناء التحضير وتقسيم البيانات (مثل split_train_val_test)، يتم التحقق فقط من الأعمدة "الخام" الأساسية
  (مثل: patient_id, feature_id, target, true_response). لا يتم التحقق من أعمدة التوصية النهائية
  (مثل: score_cf, reason, ...).
- التحقق النهائي لأعمدة التوصية النهائية يتم فقط بعد إنتاج النتائج النهائية (مثلاً بعد evaluate_recommendations
  أو بعد بناء DataFrame النتائج النهائية).
===============================================================================
"""

# استيراد check_schema من core.py (تكامل مع التحقق المركزي للأعمدة)
from pipeline.core import check_schema

# وتسجيل أي نقص بدقة في مَلف
def validate_columns(df, required_columns, context="CBF"):
    """
    تعمل هذه الدالة دائمًا على الأعمدة السياقية الأساسية (CONTEXT_COLUMNS) فقط لأي تحقق أو تلخيص أو إخراج.
    تحقق من وجود جميع الأعمدة المطلوبة في DataFrame لنظام توصية CBF.
    إذا كان هناك أعمدة ناقصة، يُرفع استثناء ويوضح الأعمدة الناقصة.
    مخصصة لضمان سلامة مدخلات ومخرجات نظام توصية CBF (content-based filtering).
    Args:
        df (pd.DataFrame): إطار البيانات المطلوب التحقق منه.
        required_columns (list[str]): قائمة الأعمدة المطلوبة.
        context (str): اسم السياق لغرض التسجيل (افتراضي "CBF").
    Raises:
        ValueError: إذا كان هناك أعمدة ناقصة.
    """
    if df is None:
        pipeline_logger.error(f"[{context}] ❌ [validate_columns] DataFrame input is None.")
        raise ValueError(f"[{context}] validate_columns - Input DataFrame is None.")
    missing = [col for col in required_columns if col not in df.columns]
    if missing:
        pipeline_logger.error(f"[{context}] ❌ [validate_columns] Missing required columns: {missing}")
        raise ValueError(f"[{context}] Missing required columns: {missing}")
    pipeline_logger.info(f"[{context}] ✅ [validate_columns] All required columns found: {required_columns}")
    # تلخيص الأعمدة السياقية الأساسية (CONTEXT_COLUMNS) فقط.
    for col in ["feature_id", "feature_id_binned", "context_feature_id"]:
        if col in df.columns:
            pipeline_logger.info(f"[{context}] {col}: unique={df[col].nunique()}, sample={df[col].value_counts().head(3).to_dict()}")

# ------------------------------------------------------------------------------
# الدالة التالية مخصصة فقط لوحدة توصية CBF (Content-Based Filtering)
# This function is intended ONLY for the CBF (Content-Based Filtering) recommendation unit
# ------------------------------------------------------------------------------
from sklearn.preprocessing import LabelEncoder

def encode_categorical_features_cbf(df, features, return_encoders: bool = False):
    """
    دالة مخصصة لترميز الأعمدة التصنيفية المطلوبة لنظام توصية CBF (Content-Based Filtering).
    تقوم بتحويل الأعمدة التصنيفية (categorical) إلى قيم عددية باستخدام LabelEncoder.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame يحتوي الأعمدة الأصلية.
    features : list
        قائمة الأعمدة المراد ترميزها.
    return_encoders : bool, optional (default=False)
        إذا كانت True، تُعيد الدالة أيضًا قاموس الـ LabelEncoders المستخدم لكل عمود.
        إذا كانت False (افتراضيًا)، تُعيد فقط DataFrame المرمز.

    Returns
    -------
    df_encoded : pd.DataFrame
        نسخة من df مع الأعمدة المرمزة.
    encoders : dict (اختياري)
        قاموس بكل عمود وLabelEncoder الخاص به (للاستخدام أو فك الترميز لاحقًا)،
        يُعاد فقط إذا كان return_encoders=True.
    """
    df_encoded = df.copy()
    encoders = {}
    for col in features:
        if df_encoded[col].dtype == "object" or df_encoded[col].dtype.name == "category":
            encoder = LabelEncoder()
            df_encoded[col] = encoder.fit_transform(df_encoded[col].astype(str))
            encoders[col] = encoder
    if return_encoders:
        return df_encoded, encoders
    return df_encoded
# Import evaluation metrics for recommendation evaluation
from utils.eval_metrics import precision_at_k, recall_at_k, map_at_k, ndcg_at_k
pipeline_logger = setup_logger("pipeline_logger", "logs/pipeline.log")
data_quality_logger = setup_logger("data_quality_logger", "logs/data_quality.log")

from utils.safe_copy import safe_copy
from utils.risk_score_transformer import RiskScoreTransformer
from utils.config_loader import load_global_config

logger = getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)


pipeline_logger.info("[Validation Check] 🛠️ helpers.py module loaded and ready for utility operations.")

# --- Helper: ensure feature_id_binned exists and is normalized (bp_bin4__chol_bins__age_q3)
# Kept local in helpers.py to avoid cross-module import cycles.

def _ensure_feature_id_binned(df: pd.DataFrame, log=None, log_id=None) -> pd.DataFrame:
    try:
        if df is None or df.empty:
            return df
        if "feature_id_binned" in df.columns and df["feature_id_binned"].notna().any():
            return df
        missing = [c for c in BINNED_CONTEXT_COLUMNS if c not in df.columns]
        if missing:
            if log:
                log.warning(f"[{log_id or 'helpers'}] ⚠️ Cannot synthesize 'feature_id_binned'. Missing columns: {missing}")
            return df
        df["feature_id_binned"] = (
            df[BINNED_CONTEXT_COLUMNS[0]].astype(str).str.strip() + "__" +
            df[BINNED_CONTEXT_COLUMNS[1]].astype(str).str.strip() + "__" +
            df[BINNED_CONTEXT_COLUMNS[2]].astype(str).str.strip()
        ).str.replace(" ", "", regex=False)
        if log:
            log.info(f"[{log_id or 'helpers'}] ✅ 'feature_id_binned' synthesized from {BINNED_CONTEXT_COLUMNS}.")
    except Exception as e:
        if log:
            log.error(f"[{log_id or 'helpers'}] ❌ Failed to synthesize 'feature_id_binned': {e}")
    return df


# Helper: Build ground-truth items per patient from rows where true_response == 1.
def _build_patient_truth(df: pd.DataFrame,
                         patient_col: str = "patient_id",
                         feature_col: str = "feature_id",
                         true_col: str = "true_response") -> dict:
    """
    Build ground-truth items per patient from rows where true_response == 1.
    Returns a dict: patient_id -> list of unique feature_id.
    """
    if df is None or df.empty or true_col not in df.columns or feature_col not in df.columns:
        return {}
    df_pos = df.loc[df[true_col] == 1, [patient_col, feature_col]].dropna().drop_duplicates()
    return (df_pos.groupby(patient_col)[feature_col]
                 .apply(lambda s: list(s.unique()))
                 .to_dict())



class HCARSUtils:
    @staticmethod
    def get_section(section: str) -> dict:
        config = HCARSUtils.load_config()
        return config.get(section, {})

    @staticmethod
    def log_feature_summary(df: pd.DataFrame, stage_name: str = ""):
        if df is None:
            data_quality_logger.warning(f"[Clinical Warning] [{stage_name}] ⚠️ log_feature_summary received None DataFrame.")
            return
        pipeline_logger.info(f"[Validation Check] [{stage_name}] 🔍 DataFrame Shape: {df.shape}")
        pipeline_logger.info(f"[Validation Check] [{stage_name}] Columns: {list(df.columns)}")
        pipeline_logger.info(f"[Validation Check] [{stage_name}] Missing values: {df.isnull().sum().to_dict()}")
        # تلخيص الأعمدة السياقية الأساسية (CONTEXT_COLUMNS) فقط.
        for col in ["feature_id", "feature_id_binned", "context_feature_id"]:
            if col in df.columns:
                pipeline_logger.info(f"[{stage_name}] {col}: unique={df[col].nunique()}, sample={df[col].value_counts().head(3).to_dict()}")

    @staticmethod
    def count_unknown_context(context_dict: dict) -> int:
        if not context_dict:
            return 0
        return sum(1 for v in context_dict.values() if v == "unknown")
    _config_cache = None

    @staticmethod
    def load_config(path: str = None) -> dict:
        """
        Load configuration safely.
        - If a file path is provided, read YAML from that path (with hash-based cache).
        - If no path is provided, fall back to `load_global_config()` and cache the object.
        """
        if HCARSUtils._config_cache is not None:
            pipeline_logger.info("[Validation Check] ✅ Configuration loaded from cache.")
            return HCARSUtils._config_cache or {}

        # Fallback to global config when no explicit path is provided
        if path is None:
            try:
                cfg = load_global_config() or {}
                HCARSUtils._config_cache = cfg
                pipeline_logger.info("[Validation Check] ✅ Global configuration loaded via load_global_config().")
                return HCARSUtils._config_cache or {}
            except (FileNotFoundError, OSError, ValueError, yaml.YAMLError) as e:
                pipeline_logger.error(f"[Data Integrity] ❌ Failed to load global configuration: {e}")
                raise

        if not os.path.exists(path):
            pipeline_logger.error(f"[Data Integrity] ❌ Configuration file not found: {path}")
            raise FileNotFoundError(f"Configuration file not found: {path}")
        try:
            with open(path, "r") as file:
                config_content = file.read()
                config_hash = hashlib.sha256(config_content.encode()).hexdigest()
                if getattr(HCARSUtils, "_last_config_hash", None) == config_hash:
                    pipeline_logger.info("[Config Watch] 🔁 No change in config.yaml hash — using cached config.")
                    return HCARSUtils._config_cache or {}
                HCARSUtils._last_config_hash = config_hash
                HCARSUtils._config_cache = yaml.safe_load(config_content) or {}
            pipeline_logger.info(f"[Validation Check] ✅ Configuration loaded successfully from {path}")
        except (OSError, ValueError, yaml.YAMLError) as e:
            pipeline_logger.error(f"[Data Integrity] ❌ Failed to load configuration: {e}")
            raise
        return HCARSUtils._config_cache or {}

    @staticmethod
    def get_dataset_path(disease: str, config: dict) -> str:
        try:
            path = config['data_paths'][disease]
            pipeline_logger.info(f"[Validation Check] ✅ Dataset path retrieved for disease '{disease}': {path}")
            return path
        except KeyError:
            pipeline_logger.error(f"[Data Integrity] ❌ Dataset path not found for disease: {disease}")
            raise ValueError(f"Dataset path not found for disease: {disease}")

    @staticmethod
    def get_cleaning_function_name(config: dict) -> str:
        func_name = config.get('preprocessing', {}).get('cleaning_function', 'clean_generic')
        pipeline_logger.info(f"[Validation Check] ✅ Cleaning function name extracted: {func_name}")
        return func_name

    @staticmethod
    def append_log_entry(log_path: str, log_dict: dict):
        try:
            from datetime import datetime
            log_dict["timestamp"] = datetime.now().isoformat()
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            log_df = pd.DataFrame([log_dict])
            if log_df.empty or not all(col in log_df.columns for col in sorted(log_dict.keys())):
                pipeline_logger.warning(f"[Data Integrity] ⚠️ [append_log_entry] Skipped writing malformed log entry to {log_path}")
                return
            log_df = log_df.reindex(columns=sorted(log_dict.keys()))
            if os.path.exists(log_path):
                log_df.to_csv(log_path, mode="a", header=False, index=False)
                pipeline_logger.info(f"[Validation Check] [append_log_entry] ✅ Appended log entry to {log_path}")
            else:
                log_df.to_csv(log_path, index=False)
                pipeline_logger.info(f"[Validation Check] [append_log_entry] ✅ Created log file and wrote entry to {log_path}")
        except (OSError, ValueError, TypeError) as e:
            pipeline_logger.error(f"[Data Integrity] ❌ [append_log_entry] Failed to append log entry to {log_path}: {e}")
            raise

    @staticmethod
    def backup_protected_columns(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
        if df is None:
            pipeline_logger.error("[Data Integrity] ❌ [backup_protected_columns] [Function: backup_protected_columns] Input dataframe is None.")
            raise ValueError("backup_protected_columns - Input dataframe cannot be None.")
        for col in columns:
            backup_col = f"{col}_copy"
            if col in df.columns:
                if col == 'target' and backup_col not in df.columns:
                    df[backup_col] = df[col]
                    pipeline_logger.warning(f"[Data Integrity] [backup_protected_columns] ⚠️ [Backup-Fix] Target backup created explicitly as '{backup_col}'")
                elif backup_col not in df.columns:
                    df[backup_col] = df[col]
                    pipeline_logger.info(f"[Validation Check] [backup_protected_columns] ✅ [Backup] Column '{col}' backed up as '{backup_col}'")
                else:
                    pipeline_logger.info(f"[Validation Check] [backup_protected_columns] ⚠️ [Backup] Backup column '{backup_col}' already exists. Skipping backup.")
            else:
                pipeline_logger.warning(f"[Data Integrity] [backup_protected_columns] ⚠️ [Backup] Column '{col}' not found for backup.")
        return df

    @staticmethod
    def restore_protected_columns(df: pd.DataFrame, columns: list[str], fallback_data: pd.DataFrame = None) -> pd.DataFrame:
        if df is None:
            raise ValueError("[restore_protected_columns] Input dataframe is None.")
        for col in columns:
            backup_col = f"{col}_copy"
            if col not in df.columns and backup_col in df.columns:
                df[col] = df[backup_col]
                pipeline_logger.info(f"[Restore] Column '{col}' restored from '{backup_col}'")
            elif col not in df.columns and fallback_data is not None and col in fallback_data.columns:
                df[col] = fallback_data[col]
                pipeline_logger.warning(f"[Fallback-Restore] Column '{col}' restored from fallback_data.")
        return df

    @staticmethod
    def finalize_recommendation_output(df: pd.DataFrame) -> pd.DataFrame:
        """
        تعمل هذه الدالة دائمًا على الأعمدة السياقية الأساسية (CONTEXT_COLUMNS) فقط لأي تحقق أو تلخيص أو إخراج.
        Deduplicates and optionally shuffles the final recommendation output to ensure clinical clarity.
        Intended to be called before saving final recommendation CSVs.
        """
        if df is None or df.empty:
            pipeline_logger.warning("[Finalize Output] ⚠️ Recommendation DataFrame is empty or None.")
            return df
        before = len(df)
        # 1) Deduplicate (patient, feature)
        df = df.drop_duplicates(subset=["patient_id", "feature_id"])
        after = len(df)
        pipeline_logger.info(f"[Finalize Output] ✅ Deduplicated recommendations: {before} → {after}")

        # 2) Optional Top-K capping per patient using score (if available) and config cap
        try:
            cfg = load_global_config() or {}
            k_cap = cfg.get("recommendation", {}).get("per_patient_topn_cap", None)
        except Exception as _ex:
            k_cap = None
            pipeline_logger.warning(f"[Finalize Output] ⚠️ Could not read per_patient_topn_cap from config: {_ex}")

        if k_cap and isinstance(k_cap, int) and k_cap > 0:
            # Prefer CF score if available, otherwise a generic 'score' column
            score_col = "score_cf" if "score_cf" in df.columns else ("score" if "score" in df.columns else None)
            if score_col is not None:
                df = (df.sort_values(["patient_id", score_col], ascending=[True, False])
                        .drop_duplicates(subset=["patient_id", "feature_id"]))
                df["rank_k"] = df.groupby("patient_id")[score_col].rank(method="first", ascending=False)
                df = df[df["rank_k"] <= k_cap].drop(columns=["rank_k"])
                pipeline_logger.info(f"[Finalize Output] 🎯 Applied Top-{k_cap} cap per patient using '{score_col}'.")
            else:
                pipeline_logger.info("[Finalize Output] ℹ️ Top-K cap requested but no score column found; skipping cap.")

        # 3) Shuffle for fairness (stable random state)
        df = df.sample(frac=1, random_state=42).reset_index(drop=True)
        pipeline_logger.info(f"[Finalize Output] 🔀 Shuffled recommendation order for fairness.")

        # 4) Context columns quick summary
        for col in ["feature_id", "feature_id_binned", "context_feature_id"]:
            if col in df.columns:
                pipeline_logger.info(f"[Finalize Output] {col}: unique={df[col].nunique()}, sample={df[col].value_counts().head(3).to_dict()}")
        return df

class ClinicalValidator:
    @staticmethod
    def validate_required_columns(df: pd.DataFrame, required_columns: list[str], context: str = ""):
        if df is None:
            pipeline_logger.error("[Data Integrity] ❌ [validate_required_columns] [Function: validate_required_columns] Input dataframe is None.")
            raise ValueError("validate_required_columns - Input dataframe cannot be None.")
        config = load_global_config()
        strict_mode = config.get("global", {}).get("strict_mode", False)
        protected = config.get("preprocessing", {}).get("protected_columns", [])
        missing = [col for col in required_columns if col not in df.columns and col not in protected]
        if missing:
            if strict_mode:
                pipeline_logger.warning(f"[Validation Check] [validate_required_columns] Strict mode active — dropping missing columns: {missing}")
                df.drop(columns=missing, errors='ignore', inplace=True)
            else:
                pipeline_logger.error(f"[Data Integrity] ❌ [validate_required_columns] {context} - Missing required columns: {missing}")
                raise ValueError(f"{context} - Missing required columns: {missing}")
        pipeline_logger.info(f"[Validation Check] [validate_required_columns] ✅ {context} - All required columns validated: {required_columns}")

    @staticmethod
    def apply_risk_score(df: pd.DataFrame, context_label: str = "unspecified") -> pd.DataFrame:
        """
        Dynamically applies RiskScoreTransformer if enabled in config and required columns exist.
        Args:
            df (pd.DataFrame): DataFrame to apply risk scoring.
            context_label (str): Context label for logging.
        Returns:
            pd.DataFrame: Updated DataFrame with 'risk_score' and 'risk_level' if applicable.
        🚑 Medical Note: This function ensures input integrity aligned with modern medical recommendation safety standards to prevent computational errors during treatment decision support.
        """
        if df is None:
            pipeline_logger.error(
                "[Data Integrity] ❌ [apply_risk_score] [Function: apply_risk_score] Input dataframe is None.")
            raise ValueError("apply_risk_score - Input dataframe cannot be None.")
        df = safe_copy(df, context="apply_risk_score")
        try:
            config = load_global_config()
            if config.get("global", {}).get("enable_risk_score", False):
                if "age" not in df.columns or df["age"].isnull().any():
                    data_quality_logger.warning(
                        "[Clinical Warning] [apply_risk_score] ⚠️ Risk scoring skipped due to missing or invalid 'age' values.")
                else:
                    transformer = RiskScoreTransformer()
                    df = transformer.transform(df)
                    pipeline_logger.info(
                        f"[Validation Check] [apply_risk_score] 🩺 Risk scoring applied. Context: {context_label}")
            else:
                pipeline_logger.info(
                    "[Validation Check] [apply_risk_score] ℹ️ Risk scoring disabled via configuration.")
        except (KeyError, AttributeError, TypeError) as e:
            data_quality_logger.error(f"[Validation Check] [apply_risk_score] ❌ Risk scoring failed: {e}")
        return df

    @staticmethod
    def ensure_columns_exist(df: pd.DataFrame, required_columns: list[str]):
        if df is None:
            pipeline_logger.error("[Data Integrity] ❌ [ensure_columns_exist] [Function: ensure_columns_exist] Input dataframe is None.")
            raise ValueError("ensure_columns_exist - Input dataframe cannot be None.")
        missing = [col for col in required_columns if col not in df.columns]
        if missing:
            pipeline_logger.error(f"[Data Integrity] ❌ [ensure_columns_exist] Missing required columns: {missing}")
            raise ValueError(f"Missing required columns: {missing}")
        pipeline_logger.info(f"[Validation Check] [ensure_columns_exist] ✅ All required columns exist: {required_columns}")


# ------------------- Inserted helper functions -------------------

def _cap_topk_per_patient(df: pd.DataFrame,
                          k: int = 5,
                          patient_col: str = "patient_id",
                          feature_col: str = "feature_id",
                          score_col: str = "score_cf") -> pd.DataFrame:
    """
    Sort by score within each patient, drop duplicate items, and keep Top-K per patient.
    """
    if df is None or df.empty:
        return df
    if score_col not in df.columns:
        return df.drop_duplicates(subset=[patient_col, feature_col])
    df = (df.sort_values([patient_col, score_col], ascending=[True, False])
            .drop_duplicates(subset=[patient_col, feature_col]))
    df["rank_k"] = df.groupby(patient_col)[score_col].rank(method="first", ascending=False)
    df = df[df["rank_k"] <= k].drop(columns=["rank_k"])
    return df


def coverage_ge_k(df: pd.DataFrame,
                  k: int = 5,
                  patient_col: str = "patient_id",
                  feature_col: str = "feature_id"):
    """
    Compute coverage stats based on unique (patient, feature) pairs.
    Returns: (n_patients, pct_ge_k, min_recs, max_recs, avg_recs)
    """
    if df is None or df.empty:
        return 0, 0.0, 0, 0, 0.0
    counts = (df.drop_duplicates([patient_col, feature_col])
                .groupby(patient_col)[feature_col].count())
    n = int(counts.shape[0])
    pct = float((counts >= k).sum()) / n if n else 0.0
    return n, pct, int(counts.min() if n else 0), int(counts.max() if n else 0), float(counts.mean() if n else 0.0)


# --- Public wrappers for recommendation output utilities ---
def finalize_recommendation_output(df: pd.DataFrame) -> pd.DataFrame:
    """
    Public wrapper for HCARSUtils.finalize_recommendation_output to allow direct import:
    from pipeline.helpers import finalize_recommendation_output
    """
    return HCARSUtils.finalize_recommendation_output(df)


def cap_topk_per_patient(df: pd.DataFrame,
                         k: int = 5,
                         patient_col: str = "patient_id",
                         feature_col: str = "feature_id",
                         score_col: str = "score_cf") -> pd.DataFrame:
    """
    Public wrapper (non-underscored) for _cap_topk_per_patient to avoid 'protected member' warnings.
    """
    return _cap_topk_per_patient(
        df, k=k, patient_col=patient_col, feature_col=feature_col, score_col=score_col
    )


__all__ = [
    "HCARSUtils",
    "ClinicalValidator",
    "validate_columns",
    "encode_categorical_features_cbf",
    "load_contextualized_data",
    "split_train_val_test",
    "generate_unique_log_id",
    "get_logger",
    "evaluate_recommendations",
    "coverage_ge_k",
    "_cap_topk_per_patient",
    "finalize_recommendation_output",
    "cap_topk_per_patient",
    "evaluate_recommendations_loco",
    "evaluate_recommendations_loco_family",
]


pipeline_logger.info("[Validation Check] ✅ helpers.py fully initialized.")

def generate_unique_log_id(prefix: str = "CF") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def get_logger(name: str, log_path: str = "logs/cf_pipeline.log") -> logging.Logger:
    return setup_logger(name, log_path)


def split_train_val_test(
    df: pd.DataFrame,
    config: dict,
    split_logger=None,
    log_id=None,
    seed: int = 42
):
    _logger = split_logger if split_logger is not None else pipeline_logger
    _log_id = log_id or "split_train_val_test"
    if df is None or df.empty:
        _logger.error(f"[{_log_id}] ❌ Input DataFrame is empty or None.")
        raise ValueError("❌ Input DataFrame is empty or None.")

    # تحميل نسب التقسيم من config
    split_settings = config.get("split_settings", {})
    train_ratio = split_settings.get("train_ratio", 0.68)
    val_ratio = split_settings.get("val_ratio", 0.12)
    stratified = split_settings.get("stratified", False)
    stratify_col = split_settings.get("stratify_col")

    from sklearn.model_selection import train_test_split
    try:
        if stratified and stratify_col and stratify_col in df.columns:
            # Stratified split
            df_train, df_temp = train_test_split(
                df, train_size=train_ratio, random_state=seed, stratify=df[stratify_col]
            )
            val_test_ratio = val_ratio / (1 - train_ratio)
            df_val, df_test = train_test_split(
                df_temp, test_size=1 - val_test_ratio, random_state=seed, stratify=df_temp[stratify_col]
            )
            _logger.info(f"[{_log_id}] [Data Split] ✅ Stratified split using '{stratify_col}' into train={len(df_train)}, val={len(df_val)}, test={len(df_test)}")
        else:
            # Random shuffle and split
            df_shuffled = df.sample(frac=1, random_state=seed).reset_index(drop=True)
            total_len = len(df_shuffled)
            train_end = int(total_len * train_ratio)
            val_end = train_end + int(total_len * val_ratio)
            df_train = df_shuffled.iloc[:train_end].copy()
            df_val = df_shuffled.iloc[train_end:val_end].copy()
            df_test = df_shuffled.iloc[val_end:].copy()
            _logger.info(f"[{_log_id}] [Data Split] ✅ Split into train={len(df_train)}, val={len(df_val)}, test={len(df_test)}")
    except ValueError as e:
        _logger.error(f"[{_log_id}] ❌ Split failed: {e}")
        raise

    # رصد إحصائي بعد التقسيم (عدد الصفوف وعدد المرضى الفريدين) وتلخيص الأعمدة السياقية
    for split_name, split_df in [("train", df_train), ("val", df_val), ("test", df_test)]:
        if "patient_id" in split_df.columns:
            n_rows = len(split_df)
            n_unique_patients = split_df["patient_id"].nunique()
            _logger.info(f"[{_log_id}] [Data Split] ⚡ {split_name} split: {n_rows} rows, {n_unique_patients} unique patients")
        else:
            _logger.warning(f"[{_log_id}] [Data Split] ⚠️ {split_name} split: 'patient_id' column missing; rows={len(split_df)}")
        # تلخيص القيم الفريدة للأعمدة السياقية
        for col in ["feature_id", "feature_id_binned", "context_feature_id"]:
            if col in split_df.columns:
                _logger.info(f"[{_log_id}] [{split_name}] {col}: unique={split_df[col].nunique()}, sample={split_df[col].value_counts().head(3).to_dict()}")

    # التحقق فقط من الأعمدة الخام الأساسية ["patient_id", "feature_id", "target", "true_response"] أثناء التقسيم
    # ولا يتم التحقق من أعمدة التوصية النهائية هنا.
    raw_required_cols = ["patient_id", "feature_id", "target", "true_response"]
    for split_name, split_df in [("train", df_train), ("val", df_val), ("test", df_test)]:
        missing_cols = check_schema(split_df, raw_required_cols)
        if missing_cols:
            _logger.warning(f"[{_log_id}] [Schema] ⚠️ {split_name} split missing raw columns: {missing_cols}")
        else:
            _logger.info(f"[{_log_id}] [Schema] ✅ {split_name} split raw columns OK.")
    # ملاحظة: أي تحقق من أعمدة التوصية النهائية (مثل score_cf, reason, ...) يجب أن يتم فقط بعد إنتاج النتائج النهائية.
    # مثال: لا يوجد تحقق من output_columns هنا.
    return df_train, df_val, df_test

def load_contextualized_data(path="outputs/tmp/df_contextualized.csv", log_id=None):
    """
    Loads the contextualized hypertension dataset from a CSV file.

    Parameters
    ----------
    path : str, default "outputs/tmp/df_contextualized.csv"
        Path to the contextualized data file.
    log_id : str, optional
        Identifier used for logging purposes.

    Returns
    -------
    pd.DataFrame
        Loaded contextualized DataFrame.
    """
    try:
        df = pd.read_csv(path)
        pipeline_logger.info(f"[{log_id or 'load_contextualized_data'}] ✅ Contextualized data loaded from: {path}")
        pipeline_logger.info(f"[{log_id or 'load_contextualized_data'}] 🔍 Shape: {df.shape}, Columns: {list(df.columns)}")
        return df
    except (FileNotFoundError, pd.errors.ParserError, OSError) as e:
        pipeline_logger.error(f"[{log_id or 'load_contextualized_data'}] ❌ Failed to load contextualized data from {path}: {e}")
        raise

def engineer_hypertension_features(df, log_id: str = "global"):
    """
    تعمل هذه الدالة دائمًا على الأعمدة السياقية الأساسية (CONTEXT_COLUMNS) فقط لأي تحقق أو تلخيص أو إخراج.
    Engineer clinical features for hypertension dataset.

    Parameters
    ----------
    df : pd.DataFrame
        Input medical data.
    log_id : str, default "global"
        Identifier used for consistent logging across pipeline stages.

    Returns
    -------
    pd.DataFrame
        DataFrame with added engineered features.
    """
    pipeline_log = pipeline_logger

    # 2. Create chol_flag (flag if cholesterol >= 239)
    df["chol_flag"] = np.where(df["cholesterol"] >= 239, 1, 0)
    pipeline_log.debug(f"[{log_id}] [Trace] Feature 'chol_flag' created. Null count: {df['chol_flag'].isnull().sum()}")
    pipeline_log.debug(f"[{log_id}] [Trace] Sample 'chol_flag' values: {df['chol_flag'].dropna().unique().tolist()}")

    # 3. Create bp_category (categorical binning)
    bins = [0, 120, 130, 140, 180, float("inf")]
    labels = ["Normal", "Elevated", "Hypertension Stage 1", "Hypertension Stage 2", "Hypertensive Crisis"]
    df["bp_category"] = pd.cut(df["ap_hi"], bins=bins, labels=labels, right=False)

    # 4. Create chol_category (categorical binning)
    chol_labels = ["Desirable", "Borderline High", "High"]
    df["chol_category"] = pd.Categorical.from_codes(df["cholesterol"] - 1, chol_labels)

    # 5. Create age_group (categorical binning)
    bins_age = [0, 30, 45, 60, 75, float('inf')]
    labels_age = ["Young", "Middle-Age", "Senior", "Older", "Elder"]
    df["age_group"] = pd.cut(df["age"], bins=bins_age, labels=labels_age)
    pipeline_log.debug(f"[{log_id}] [Trace] Feature 'age_group' created. Null count: {df['age_group'].isnull().sum()}")
    pipeline_log.debug(f"[{log_id}] Sample 'age_group' values: {df['age_group'].dropna().unique().tolist()}")

    pipeline_log.debug(f"[{log_id}] [Trace] Categorical BP and Chol features created.")
    pipeline_log.debug(f"[{log_id}] Updated bp_category samples: {df['bp_category'].dropna().unique().tolist()}")
    pipeline_log.debug(f"[{log_id}] Updated chol_category samples: {df['chol_category'].dropna().unique().tolist()}")

    # Final trace summary
    pipeline_log.debug(f"[{log_id}] [Trace] Final engineered columns: {df.columns.tolist()}")
    pipeline_log.debug(f"[{log_id}] [Trace] Null summary:\n{df[['chol_flag', 'bp_category', 'chol_category']].isnull().sum()}")
    # Log final context values after creation
    pipeline_log.debug(f"[{log_id}] [Trace] Final clinical context values — bp_category: {df['bp_category'].dropna().unique().tolist()}, chol_category: {df['chol_category'].dropna().unique().tolist()}")
    # Ensure 'true_response' exists for downstream recommendation modules
    if "true_response" not in df.columns:
        if "target" in df.columns:
            df["true_response"] = df["target"]
            pipeline_log.info(f"[{log_id}] [Validation Check] ✅ 'true_response' column created from 'target'")
        elif "target_copy" in df.columns:
            df["true_response"] = df["target_copy"]
            pipeline_log.warning(f"[{log_id}] [Backup-Restore] ⚠️ 'true_response' created from 'target_copy' due to missing 'target'")
        else:
            pipeline_log.error(f"[{log_id}] [Data Integrity] ❌ 'true_response' could not be created — missing both 'target' and 'target_copy'")
    # Ensure binned key exists before assigning feature_id via central mapping
    df = _ensure_feature_id_binned(df, log=pipeline_logger, log_id=log_id)
    # إعادة تعيين feature_id باستخدام القاموس المركزي
    df = assign_feature_id_by_binned(df, log=pipeline_logger, log_id=log_id)
    # يتم تعيين feature_id فقط باستخدام الأعمدة السياقية الأساسية المذكورة في CONTEXT_COLUMNS.
    pipeline_log.info(f"[{log_id}] ✅ feature_id assigned using central mapping.")
    # تلخيص الأعمدة السياقية الأساسية (CONTEXT_COLUMNS) فقط.
    for col in ["feature_id", "feature_id_binned", "context_feature_id"]:
        if col in df.columns:
            pipeline_log.info(f"[{log_id}] {col}: unique={df[col].nunique()}, sample={df[col].value_counts().head(3).to_dict()}")
    return df


def evaluate_recommendations(
    df_recommendations,
    df_contextualized=None,
    true_col="true_response",
    patient_col="patient_id",
    feature_col="feature_id",
    k=None,
    metrics=("precision","recall","map","ndcg"),
    group_by=None,
    return_grouped: bool = False,
    grouped_save_dir: str | None = None,
    add_metrics_to_df=True,
    save_path=None,
    eval_logger=None,
    log_id=None,
    return_coverage_stats=False,
    require_external_truth: bool = True,
):
    """
    تقييم توصيات النظام باستخدام مقاييس قابلة للتخصيص، مع دعم التقييم الطبقي (grouped).
    - يبني الحقيقة الأرضية من feature_id حيث true_response=1.
    - يجعل التنبؤات فريدة لكل مريض ويقصّها إلى Top-K منطقيًا عند الحاجة.
    - يحسب التغطية بناءً على أزواج (patient, feature) الفريدة.

    ملاحظة صارمة (Strict Mode):
    - إذا كان require_external_truth=True (افتراضيًا)، يتم بناء الحقيقة الأرضية حصريًا من df_contextualized.
    - في هذا الوضع، إذا لم يُمرَّر df_contextualized صالح (أو ينقصه أي من أعمدة الحقيقة)، سيتم رفع استثناء ValueError لإيقاف التقييم ومنع أي تسرّب.
    """
    # 0) k from config if not provided
    if k is None:
        try:
            from utils.config_loader import load_global_config
            _cfg = load_global_config() or {}
            k = (
                _cfg.get("recommendation", {}).get("top_n_eval")
                or _cfg.get("evaluation", {}).get("top_n_for_evaluation")
                or _cfg.get("evaluation", {}).get("k")
                or 5
            )
        except Exception as e:
            log = eval_logger if eval_logger is not None else pipeline_logger
            log.warning(f"[{log_id or 'evaluate_recommendations'}] ⚠️ Could not load k from config due to: {e} — using default k=5")
            k = 5

    log = eval_logger if eval_logger is not None else pipeline_logger
    _log_id = log_id or "evaluate_recommendations"

    # 1) Prepare base dataframe
    df = df_recommendations.copy()

    # 1.a) Strict truth sourcing: enforce external ground-truth if requested
    required_truth_cols = [patient_col, feature_col, true_col]
    if require_external_truth:
        if (
            df_contextualized is None
            or df_contextualized.empty
            or not all(c in df_contextualized.columns for c in required_truth_cols)
        ):
            raise ValueError(
                f"[{_log_id}] Strict evaluation requires external ground-truth (df_contextualized with columns {required_truth_cols})."
            )
        # Build ground-truth exclusively from external context to avoid leakage
        patient_true = _build_patient_truth(
            df_contextualized[required_truth_cols],
            patient_col=patient_col,
            feature_col=feature_col,
            true_col=true_col
        )
        log.info(f"[{_log_id}] 🔒 Strict mode: ground truth built exclusively from external df_contextualized.")
        # Optionally join true_col for export/diagnostics only
        if true_col not in df.columns:
            df = pd.merge(
                df,
                df_contextualized[required_truth_cols],
                on=[patient_col, feature_col],
                how="left",
            )
    else:
        # Non-strict fallback: prefer external if valid, otherwise fall back to df
        if (
            df_contextualized is not None
            and not df_contextualized.empty
            and all(c in df_contextualized.columns for c in required_truth_cols)
        ):
            patient_true = _build_patient_truth(
                df_contextualized[required_truth_cols],
                patient_col=patient_col,
                feature_col=feature_col,
                true_col=true_col
            )
            log.info(f"[{_log_id}] Ground truth built from external df_contextualized (non-strict).")
            if true_col not in df.columns:
                df = pd.merge(
                    df,
                    df_contextualized[required_truth_cols],
                    on=[patient_col, feature_col],
                    how="left",
                )
        else:
            if true_col not in df.columns:
                log.warning(f"[{_log_id}] External truth not provided and '{true_col}' missing in df; evaluation may be lenient.")
            patient_true = _build_patient_truth(
                df,
                patient_col=patient_col,
                feature_col=feature_col,
                true_col=true_col
            )

    # 3) Build prediction lists: unique, ordered by score if available
    score_col = "score_cf" if "score_cf" in df.columns else ("score" if "score" in df.columns else None)
    if score_col:
        df_pred = (df.sort_values([patient_col, score_col], ascending=[True, False])
                     .drop_duplicates([patient_col, feature_col]))
    else:
        df_pred = (df.sort_values([patient_col, feature_col])
                     .drop_duplicates([patient_col, feature_col]))
    patient_pred = df_pred.groupby(patient_col)[feature_col].apply(list).to_dict()

    # 4) Coverage stats on unique (patient, feature)
    cov_df = df.drop_duplicates([patient_col, feature_col])
    coverage_counts = cov_df.groupby(patient_col)[feature_col].count()
    n_patients = coverage_counts.shape[0]
    min_recs = int(coverage_counts.min()) if not coverage_counts.empty else 0
    max_recs = int(coverage_counts.max()) if not coverage_counts.empty else 0
    avg_recs = float(coverage_counts.mean()) if not coverage_counts.empty else 0.0
    pct_patients_with_k_or_more = float((coverage_counts >= k).sum()) / n_patients if n_patients > 0 else 0.0
    n_patients_no_true = len(set(patient_pred.keys()) - set(patient_true.keys()))
    n_patients_with_true = len(set(patient_pred.keys()) & set(patient_true.keys()))
    reason_dist = df["reason"].value_counts().to_dict() if "reason" in df.columns else {}
    only_manual_review = (
        df.groupby(patient_col)[feature_col].apply(lambda x: set(x) == {"manual_review"}).sum()
        if feature_col in df.columns else None
    )
    only_fallback = (
        df.groupby(patient_col)["reason"].apply(lambda x: set(x) <= {"forced_safe_default_no_recommendation", "score_below_threshold"}).sum()
        if "reason" in df.columns else None
    )
    coverage_report = {
        "total_patients": n_patients,
        "min_recommendations_per_patient": min_recs,
        "max_recommendations_per_patient": max_recs,
        "avg_recommendations_per_patient": avg_recs,
        f"pct_patients_with_{k}_or_more_recommendations": pct_patients_with_k_or_more,
        "n_patients_with_true_response": n_patients_with_true,
        "n_patients_without_true_response": n_patients_no_true,
        "reason_distribution": reason_dist,
        "patients_only_manual_review": only_manual_review,
        "patients_only_fallback": only_fallback,
    }
    log.info(
        f"[{_log_id}] Coverage stats (unique pairs): patients={n_patients}, min={min_recs}, max={max_recs}, avg={avg_recs:.2f}, "
        f"pct_with_{k}_or_more={pct_patients_with_k_or_more:.2%}, n_patients_without_true={n_patients_no_true}"
    )

    # 5) Metrics computation
    metric_funcs = {
        "precision": precision_at_k,
        "recall": recall_at_k,
        "map": map_at_k,
        "ndcg": ndcg_at_k,
    }
    active_metrics = [m for m in metrics if m in metric_funcs]

    results = []
    for pid, pred_items in patient_pred.items():
        true_items = patient_true.get(pid, [])
        row = {patient_col: pid}
        for m in active_metrics:
            val = metric_funcs[m](true_items, pred_items, k)
            row[f"{m}@{k}"] = val
        results.append(row)
    df_metrics = pd.DataFrame(results)

    # 6) Grouped evaluation (optional)
    grouped_results = {}
    if group_by:
        src_for_groups = df_contextualized if df_contextualized is not None else df.copy()
        group_cols = [group_by] if isinstance(group_by, str) else list(group_by)
        candidate_cols = [patient_col] + [c for c in group_cols if c in src_for_groups.columns]
        group_df = src_for_groups[candidate_cols].drop_duplicates()
        df_metrics = pd.merge(df_metrics, group_df, on=patient_col, how="left")
        for col in [c for c in group_cols if c in df_metrics.columns]:
            agg_cols = [c for c in df_metrics.columns if c.endswith(f"@{k}")]
            if not agg_cols:
                continue
            gdf = (
                df_metrics.dropna(subset=[col])
                         .groupby(col)[agg_cols]
                         .mean()
                         .reset_index()
            )
            grouped_results[col] = gdf
            out_dir = grouped_save_dir or "outputs/CF/diagnostics"
            try:
                os.makedirs(out_dir, exist_ok=True)
                gdf.to_csv(os.path.join(out_dir, f"metrics_by_{col}.csv"), index=False)
            except Exception as _ex:
                log.warning(f"[{_log_id}] ⚠️ Could not save grouped metrics for {col}: {_ex}")

    # 7) Attach metrics to per-row recommendations (optional)
    if add_metrics_to_df:
        df = pd.merge(df, df_metrics[[patient_col] + [c for c in df_metrics.columns if c.endswith(f"@{k}")]], on=patient_col, how="left")

    # 8) Ensure (patient, feature) uniqueness before saving evaluation file
    df = df.drop_duplicates(subset=[patient_col, feature_col])

    # 9) Persist if requested
    if save_path:
        df.to_csv(save_path, index=False)
        log.info(f"[{_log_id}] ✅ تم حفظ نتائج التقييم النهائية في: {save_path} ({len(df)})")

    if return_coverage_stats and return_grouped:
        return df, coverage_report, grouped_results
    if return_grouped:
        return df, grouped_results
    if return_coverage_stats:
        return df, coverage_report
    return df


def self_test_utils():
    pipeline_logger.info("[Validation Check] 🧪 Running HCARS Utils integrated self-tests...")

    # Test configuration loading
    config = load_global_config()
    assert isinstance(config, dict)
    assert "data_paths" in config

    # Test get_section
    preprocessing_config = HCARSUtils.get_section("preprocessing")
    assert isinstance(preprocessing_config, dict)

    # Test backup/restore
    df = pd.DataFrame({"target": [1, 0, 1], "age": [55, 40, 62]})
    backed_up = HCARSUtils.backup_protected_columns(df, ["target", "age"])
    assert "target_copy" in backed_up.columns and "age_copy" in backed_up.columns
    restored = HCARSUtils.restore_protected_columns(backed_up.drop(columns=["target"]), ["target"], fallback_data=backed_up)
    assert "target" in restored.columns

    # Test ClinicalValidator
    ClinicalValidator.validate_required_columns(df, ["target", "age"])
    df2 = ClinicalValidator.apply_risk_score(df)
    assert "risk_score" in df2.columns or config.get("global", {}).get("enable_risk_score", False) is False

    # Test count_unknown_context
    unknowns = HCARSUtils.count_unknown_context({'risk_level': 'unknown', 'bp_category': 'stage1'})
    assert unknowns == 1
    pipeline_logger.info(f"[Validation Check] ✅ count_unknown_context passed with {unknowns} unknown(s)")

    # Test get_cbf_features_with_context (renamed from get_cbf_features)
    from utils.hcars_utils import get_cbf_features_with_context
    cbf_features = get_cbf_features_with_context(config)
    assert isinstance(cbf_features, list)
    pipeline_logger.info(f"[Validation Check] ✅ get_cbf_features_with_context returned: {cbf_features}")

    # Test engineer_hypertension_features with log_id
    engineer_hypertension_features(df, log_id="self_test")

    pipeline_logger.info("[Validation Check] ✅ All HCARS Utils self-tests passed.")


if __name__ == "__main__":
    self_test_utils()
    pipeline_logger.info("[Validation Check] ✅ helpers.py main self-test completed successfully.")

def prepare_recommendation_data(df, log_id="prepare"):
    df = _ensure_feature_id_binned(df, log=pipeline_logger, log_id=log_id)
    df = assign_feature_id_by_binned(df, log=pipeline_logger, log_id=log_id)
    pipeline_logger.info(f"[{log_id}] ✅ feature_id assigned using central mapping.")
    # تلخيص الأعمدة السياقية الأساسية (CONTEXT_COLUMNS) فقط.
    for col in ["feature_id", "feature_id_binned", "context_feature_id"]:
        if col in df.columns:
            pipeline_logger.info(
                f"[{log_id}] {col} | Unique: {df[col].nunique()} | Sample: {df[col].value_counts().head(3).to_dict()}"
            )
    return df

def evaluate_recommendations_loco(
    df_recommendations: pd.DataFrame,
    df_contextualized: pd.DataFrame,
    patient_col: str = "patient_id",
    feature_col: str = "feature_id",
    true_col: str = "true_response",
    k: int = 5,
    eval_logger: logging.Logger | None = None,
    log_id: str | None = None,
) -> pd.DataFrame:
    """
    LOCO: Leave-One-Context-Out evaluation.
    - تبني الحقيقة الأرضية من df_contextualized فقط لمنع أي تسرّب.
    - تجعل توقعات كل مريض فريدة ومرتّبة بالدرجة إن وُجدت (score_cf > score).
    - لكل عنصر حقيقي (held_out) لمريض ما:
        * العناصر "المعروفة/المرئية" = true_items \\ {held_out}
        * قائمة التنبؤ تُفلتر لاستبعاد العناصر المعروفة (keep only unseen + held_out)
        * تُحسب المقاييس @k على هدف وحيد هو held_out

    Returns
    -------
    pd.DataFrame
        إطار بمقاييس متوسّطة لكل مريض (mean over LOCO folds per patient).
    """
    log = eval_logger if eval_logger is not None else pipeline_logger
    _log_id = log_id or "LOCO"

    # حراسة المدخلات
    if df_recommendations is None or df_recommendations.empty:
        log.warning(f"[{_log_id}] LOCO: df_recommendations is empty or None.")
        return pd.DataFrame()
    if (
        df_contextualized is None
        or df_contextualized.empty
        or not all(c in df_contextualized.columns for c in [patient_col, feature_col, true_col])
    ):
        log.warning(f"[{_log_id}] LOCO: df_contextualized is missing/invalid; skipping LOCO.")
        return pd.DataFrame()

    # 1) الحقيقة الأرضية من المصدر الخارجي فقط
    truth_src = df_contextualized[[patient_col, feature_col, true_col]].copy()
    truth_src = truth_src.dropna(subset=[patient_col, feature_col])
    truth_src[true_col] = pd.to_numeric(truth_src[true_col], errors="coerce").fillna(0).astype(int)
    df_pos = truth_src.loc[truth_src[true_col] == 1, [patient_col, feature_col]].drop_duplicates()
    patient_true: dict[str, list] = (
        df_pos.groupby(patient_col)[feature_col]
             .apply(lambda s: list(pd.Series(s, dtype=object).astype(str).unique()))
             .to_dict()
    )

    # 2) توقعات فريدة مرتّبة (score_cf > score > alphabetical fallback)
    df_pred = df_recommendations.dropna(subset=[patient_col, feature_col]).copy()
    # اختيار عمود الدرجة
    score_col = "score_cf" if "score_cf" in df_pred.columns else ("score" if "score" in df_pred.columns else None)
    if score_col:
        df_pred[score_col] = pd.to_numeric(df_pred[score_col], errors="coerce").fillna(0.0)
        df_pred = (
            df_pred.sort_values([patient_col, score_col], ascending=[True, False])
                   .drop_duplicates(subset=[patient_col, feature_col])
        )
    else:
        df_pred = (
            df_pred.sort_values([patient_col, feature_col])
                   .drop_duplicates(subset=[patient_col, feature_col])
        )
    # خرائط توقعات لكل مريض (قائمة مرتبة)
    patient_pred: dict[str, list] = (
        df_pred.groupby(patient_col)[feature_col].apply(lambda s: list(pd.Series(s).astype(str))).to_dict()
    )

    # 3) تنفيذ LOCO
    rows = []
    n_patients_with_truth = 0
    for pid, true_items in patient_true.items():
        # قائمة التنبؤ للمريض
        pred_list = patient_pred.get(pid, [])
        # إزالة أي تكرارات والمحافظة على الترتيب
        pred_unique = list(dict.fromkeys(pred_list))
        if not true_items:
            continue
        n_patients_with_truth += 1

        # لكل عنصر حقيقي: احجبه وقيّم
        for held_out in true_items:
            seen = set(true_items) - {held_out}
            # المرشحون لتقييم هذا الـ fold: استبعد العناصر "المعروفة" وأبقِ العنصر المحجوب ضمن المرشحين
            candidate_pred = [x for x in pred_unique if x not in seen]

            # اجعل الهدف مجموعة مكونة من عنصر واحد (الـ held_out)
            target_set = {str(held_out)}
            # قصّ إلى K
            pred_at_k = candidate_pred[:k]

            # حساب المقاييس
            prec = precision_at_k(target_set, pred_at_k, k)
            rec = recall_at_k(target_set, pred_at_k, k)
            ap = map_at_k(target_set, pred_at_k, k)
            nd = ndcg_at_k(target_set, pred_at_k, k)

            rows.append({
                patient_col: pid,
                f"precision@{k}": prec,
                f"recall@{k}": rec,
                f"map@{k}": ap,
                f"ndcg@{k}": nd,
            })

    if not rows:
        log.warning(f"[{_log_id}] LOCO produced no rows (no patients with truth or no predictions).")
        return pd.DataFrame()

    df_loco = pd.DataFrame(rows)
    # نجمع على مستوى المريض (متوسط عبر الطيات/العناصر المحجوبة)
    df_loco_agg = (
        df_loco.groupby(patient_col, as_index=False)[[c for c in df_loco.columns if c.endswith(f"@{k}")]].mean()
    )

    log.info(
        f"[{_log_id}] LOCO completed for {n_patients_with_truth} patients with truth; "
        f"returned {len(df_loco_agg)} aggregated rows."
    )
    return df_loco_agg


def evaluate_recommendations_loco_family(
    df_recommendations: pd.DataFrame,
    df_contextualized: pd.DataFrame,
    patient_col: str = "patient_id",
    feature_col: str = "feature_id",
    true_col: str = "true_response",
    family_col: str = "feature_id_binned",
    k: int = 5,
    eval_logger: logging.Logger | None = None,
    log_id: str | None = None,
    exclude_seen_families: bool = True,
    exclude_synonym_families: bool = False,
    synonym_families: dict | None = None,
    use_eval_score_calibration: bool = True,
) -> pd.DataFrame:
    """
    LOCO-Family: Leave-One-Family-Out evaluation (أكثر صرامة من LOCO التقليدي).
    - الحقيقة تبنى حصريًا من df_contextualized لمنع أي تسرّب.
    - "العائلة" تُعرّف عبر family_col (افتراضيًا: feature_id_binned). إذا لم تتوفر سنحاول توليدها.
    - لكل مريض ولكل عائلة حقيقية لديه:
        * الهدف = جميع عناصر تلك العائلة (held_family).
        * نستبعد من المرشّحين أي عنصر عائلته ضمن العائلات "المعروفة" الأخرى (masking أقوى).
        * نسمح بعناصر العائلة المحجوبة ضمن المرشّحين (حتى نقيس: هل سيصيب النظام العائلة الصحيحة؟).
    - تُحتسب المقاييس @k على مجموعة أهداف متعددة (targets=set).
    تحسينات احترافية:
    - ربط آمن لعائلة العنصر عبر خريطة feature→family مع معالجة فجوات (synthesis + fillna).
    - فرز تنبؤات المريض بالدرجة (score_cf>score)، إزالة تكرارات مع الحفاظ على الترتيب.
    - دعم k ديناميكي مع قراءته من config عند الحاجة.

    خيارات متقدمة:
    - exclude_seen_families: استبعاد عائلات الحقيقة الأخرى (غير المحجوبة) من المرشحين (افتراضي=True).
    - exclude_synonym_families: إذا تم تمرير synonym_families (قاموس عائلة -> قائمة مرادفات)،
      سيتم توسيع قائمة العائلات المستبعدة لتشمل المرادفات (افتراضي=False).
    - use_eval_score_calibration: تفعيل معايرة ترتيبية للدرجات داخل كل مريض (rank-normalization) لاستخدام
      عمود 'score_eval' للفرز أثناء التقييم، مما يكسر التعادلات ويرفع حساسية nDCG.
    """
    log = eval_logger if eval_logger is not None else pipeline_logger
    _log_id = (log_id or "LOCO-FAMILY")

    # حراسة مدخلات
    if df_recommendations is None or df_recommendations.empty:
        log.warning(f"[{_log_id}] LOCO-Family: df_recommendations is empty or None.")
        return pd.DataFrame()
    if (
        df_contextualized is None
        or df_contextualized.empty
        or not all(c in df_contextualized.columns for c in [patient_col, feature_col, true_col])
    ):
        log.warning(f"[{_log_id}] LOCO-Family: df_contextualized missing required columns; skipping.")
        return pd.DataFrame()

    # اجعل k من الإعدادات إن لزم
    if k is None:
        try:
            _cfg = load_global_config() or {}
            k = (
                _cfg.get("recommendation", {}).get("top_n_eval")
                or _cfg.get("evaluation", {}).get("top_n_for_evaluation")
                or _cfg.get("evaluation", {}).get("k")
                or 5
            )
        except (OSError, ValueError, KeyError, yaml.YAMLError):
            k = 5

    # 1) تحضير الحقيقة والعائلة
    ctx_cols = [patient_col, feature_col, true_col, family_col] if family_col in df_contextualized.columns else [patient_col, feature_col, true_col]
    ctx = df_contextualized[ctx_cols].dropna(subset=[patient_col, feature_col]).copy()
    ctx[feature_col] = ctx[feature_col].astype(str)
    ctx[true_col] = pd.to_numeric(ctx[true_col], errors="coerce").fillna(0).astype(int)

    # إذا لم تتوفر family_col، سنحاول توليدها من الأعمدة المعيارية (bp/chol/age) ثم ملؤها "unknown"
    if family_col not in ctx.columns:
        tmp = _ensure_feature_id_binned(df_contextualized.copy(), log=log, log_id=_log_id)
        if family_col in tmp.columns:
            ctx = ctx.merge(
                tmp[[feature_col, family_col]].drop_duplicates().astype({feature_col: str}),
                on=feature_col, how="left"
            )
        else:
            ctx[family_col] = "unknown"

    ctx[family_col] = ctx[family_col].astype(str).fillna("unknown")

    df_pos = ctx.loc[ctx[true_col] == 1, [patient_col, feature_col, family_col]].drop_duplicates()
    # الحقيقة: عناصر إيجابية فريدة لكل مريض
    patient_true = (
        df_pos.groupby(patient_col)[feature_col]
             .apply(lambda s: list(pd.Series(s, dtype=object).astype(str).unique()))
             .to_dict()
    )
    # عائلات الحقيقة لكل مريض
    patient_true_families = (
        df_pos.groupby(patient_col)[family_col]
             .apply(lambda s: set(pd.Series(s, dtype=object).astype(str)))
             .to_dict()
    )
    # خريطة عائلة كل عنصر (لتكوين مجموعة الأهداف)
    feature_to_family = dict(
        ctx[[feature_col, family_col]].drop_duplicates().astype({feature_col: str}).values
    )

    # 2) توقعات فريدة مرتبة
    preds = df_recommendations.dropna(subset=[patient_col, feature_col]).copy()
    preds[feature_col] = preds[feature_col].astype(str)

    # اربط family_col بالتوقعات لو مفقود
    if family_col not in preds.columns:
        preds = preds.merge(
            ctx[[feature_col, family_col]].drop_duplicates().astype({feature_col: str}),
            on=feature_col, how="left"
        )
    preds[family_col] = preds[family_col].astype(str).fillna("unknown")

    # --- Calibration for evaluation ranking (break ties, stabilize nDCG)
    score_col = "score_cf" if "score_cf" in preds.columns else ("score" if "score" in preds.columns else None)

    if use_eval_score_calibration and score_col is not None:
        # Use groupby-transform to keep grouping columns and avoid FutureWarning
        preds[score_col] = pd.to_numeric(preds[score_col], errors="coerce").fillna(0.0)
        ranks = preds.groupby(patient_col)[score_col].rank(method="first", ascending=False)
        group_sizes = preds.groupby(patient_col)[score_col].transform("size").astype(float)
        # Normalize ranks to [0,1] (higher score gets closer to 1.0). Handle singleton groups safely.
        preds["score_eval"] = np.where(group_sizes <= 1.0, 1.0, 1.0 - (ranks - 1.0) / (group_sizes - 1.0))
        score_to_use = "score_eval"
    else:
        score_to_use = score_col

    # Guard: ensure patient_col is a column (not index) after calibration
    if patient_col not in preds.columns:
        if preds.index.name == patient_col:
            preds = preds.reset_index()
        else:
            log.error(f"[{_log_id}] LOCO-Family: missing '{patient_col}' after calibration step; aborting evaluation.")
            return pd.DataFrame()

    if score_to_use:
        preds = (
            preds.sort_values([patient_col, score_to_use], ascending=[True, False])
                 .drop_duplicates(subset=[patient_col, feature_col])
        )
    else:
        preds = (
            preds.sort_values([patient_col, feature_col])
                 .drop_duplicates(subset=[patient_col, feature_col])
        )

    patient_pred_items = preds.groupby(patient_col)[feature_col].apply(lambda s: list(pd.Series(s, dtype=object).astype(str))).to_dict()
    patient_pred_families = preds.groupby(patient_col)[family_col].apply(lambda s: list(pd.Series(s, dtype=object).astype(str))).to_dict()

    # === DIAGNOSTICS (won't change logic) ===
    try:
        # 1) counts of patients with positive families and with predictions
        n_patients_with_true_fams = sum(1 for v in patient_true_families.values() if isinstance(v, set) and len(v) > 0)
        n_patients_with_preds = sum(1 for v in patient_pred_items.values() if isinstance(v, list) and len(v) > 0)

        # 2) unknown family percentages in context and predictions
        fam_vals_ctx = ctx[family_col].astype(str)
        pct_unknown_ctx = float((fam_vals_ctx == "unknown").mean()) if len(fam_vals_ctx) else 0.0
        fam_vals_pred = preds[family_col].astype(str)
        pct_unknown_pred = float((fam_vals_pred == "unknown").mean()) if len(fam_vals_pred) else 0.0

        # 3) quick sample for a patient (if available)
        sample_pid = next(iter(patient_true.keys()), None)
        sample_true = patient_true.get(sample_pid, [])[:3] if sample_pid is not None else []
        sample_pred = patient_pred_items.get(sample_pid, [])[:3] if sample_pid is not None else []

        log.info(
            f"[{_log_id}] DIAG: patients_with_true_families={n_patients_with_true_fams}, "
            f"patients_with_predictions={n_patients_with_preds}, "
            f"ctx_unknown_family_pct={pct_unknown_ctx:.2%}, pred_unknown_family_pct={pct_unknown_pred:.2%}, "
            f"sample_patient={sample_pid}, sample_true={sample_true}, sample_pred={sample_pred}"
        )
    except Exception as _ex:
        log.warning(f"[{_log_id}] DIAG failed (pre-loop): {_ex}")

    # 3) تنفيذ LOCO-Family مع Masking أقوى
    rows = []
    reasons = {"empty_targets": 0, "empty_pred_after_mask": 0}
    n_patients_eval = 0
    for pid, true_items in patient_true.items():
        pred_items = patient_pred_items.get(pid, [])
        pred_fams  = patient_pred_families.get(pid, [])
        true_fams  = patient_true_families.get(pid, set())
        if not true_items or not pred_items or not true_fams:
            continue
        n_patients_eval += 1

        for held_family in true_fams:
            # الهدف = جميع العناصر من العائلة المحجوبة
            targets = {it for it in true_items if feature_to_family.get(it, "unknown") == held_family}
            if not targets:
                reasons["empty_targets"] += 1
                continue

            # العائلات المرئية (باستثناء المحجوبة) — سنستبعدها من المرشحين
            seen_families = set(true_fams) - {held_family}
            if exclude_synonym_families and synonym_families:
                expanded = set()
                for fam in list(seen_families):
                    expanded.add(str(fam))
                    for syn in synonym_families.get(str(fam), []):
                        expanded.add(str(syn))
                seen_families = expanded

            # Masking أقوى: استبعد أي عنصر تنتمي عائلته إلى العائلات المرئية الأخرى
            if exclude_seen_families:
                filtered_pred = [it for it, fam in zip(pred_items, pred_fams) if str(fam) not in seen_families]
            else:
                filtered_pred = list(pred_items)

            if not filtered_pred:
                reasons["empty_pred_after_mask"] += 1
                continue

            # قصّ إلى K
            pred_at_k = filtered_pred[:k]

            # المقاييس
            prec = precision_at_k(targets, pred_at_k, k)
            rec  = recall_at_k(targets, pred_at_k, k)
            ap   = map_at_k(targets, pred_at_k, k)
            nd   = ndcg_at_k(targets, pred_at_k, k)

            rows.append({
                patient_col: pid,
                f"precision@{k}": prec,
                f"recall@{k}": rec,
                f"map@{k}": ap,
                f"ndcg@{k}": nd,
            })

    if not rows:
        # Detailed reasons emitted above in the per-loop counters
        try:
            empty_targets = reasons.get("empty_targets", 0)
            empty_masked = reasons.get("empty_pred_after_mask", 0)
        except (KeyError, TypeError, ValueError) as _ex:
            empty_targets, empty_masked = 0, 0
            log.warning(f"[{_log_id}] LOCO-Family reason counters failed to read: {_ex}")
        log.warning(
            f"[{_log_id}] LOCO-Family produced no rows. "
            f"Reasons: empty_targets={empty_targets}, empty_pred_after_mask={empty_masked}. "
            f"Hint: ensure family mapping is available and not 'unknown' for most items, "
            f"increase evaluation cap or relax masking, and expand CF raw_pool_cap."
        )
        return pd.DataFrame()

    df_family = pd.DataFrame(rows)
    df_family_agg = (
        df_family.groupby(patient_col, as_index=False)[[c for c in df_family.columns if c.endswith(f"@{k}")]].mean()
    )
    log.info(f"[{_log_id}] LOCO-Family completed for {n_patients_eval} patients; returned {len(df_family_agg)} rows.")
    return df_family_agg