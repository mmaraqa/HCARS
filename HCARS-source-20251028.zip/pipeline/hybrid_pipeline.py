# -*- coding: utf-8 -*-
"""
hybrid_pipeline.py
------------------
خط أنابيب تشغيل الهجين CF+CBF بالاعتماد على وحدات hybrid.py.
- تحميل ملفات CF/CBF والسياق وملفات التقييم (اختياري).
- معايرة الدرجات (Isotonic) لكل من CF و CBF.
- حساب أوزان سياقية اختيارية لكل مجموعة سريرية (bp_category + chol_category).
- دمج الدرجات مع تعديل بالـ sim_norm وتطبيق البوابات السريرية.
- تنويع وفكّ التعادلات ثم أخذ Top-K لكل مريض.
- حفظ المخرجات النهائية مع تقارير تشخيصية واختيارية للتقييم.

المؤلف: (أنت)
"""

from __future__ import annotations

# ---------- Logger Setup ----------
import logging
logger = logging.getLogger("hybrid_pipeline")
if not logger.handlers:
    logger.addHandler(logging.StreamHandler())
logger.setLevel(logging.INFO)

import os
import json
import argparse
from typing import Optional, Dict

import numpy as np
import pandas as pd

import matplotlib.pyplot as plt  # plotting for optional group metrics

# Helpers from constants (for robust source normalization + guideline tags), with fallback if not present
try:
    from utils.constants import clean_source_text, get_guideline_tags  # type: ignore
except (ImportError, ModuleNotFoundError, AttributeError):  # pragma: no cover
    def clean_source_text(text):
        # minimal fallback: strip and remove trailing ", true/false"
        if text is None:
            return ""
        s = str(text).strip()
        if s.endswith(", true"):
            s = s[:-6].rstrip()
        if s.endswith(", false"):
            s = s[:-7].rstrip()
        return s
    def get_guideline_tags(source_text: str):
        # minimal fallback: tag AHA2023 if it looks like CBF; else []
        s = str(source_text or "").lower()
        if "cbf" in s:
            return ["AHA2023"]
        return []

# وحدات الهجين
from recommender.hybrid import (
    HybridConfig,
    unify_schema,
    fit_calibrators_from_eval,
    compute_group_weights,
    blend_scores,
    apply_clinical_gates,
    diversify_and_tiebreak,
    topk_per_patient,
    attach_hybrid_reason,
    attach_hybrid_advice,
    ensure_columns,  # type: ignore
    hybrid_end_to_end,  # متاح عند الحاجة لمسار مختصر
    #finalize_hybrid_outputs,
)

# ===================== إعداد اللوجر =====================
def _setup_logger(name: str = "hybrid_logger", level: str = "INFO", log_path: Optional[str] = None) -> logging.Logger:
    log = logging.getLogger(name)
    # مستوى اللوج
    log.setLevel(getattr(logging, level.upper(), logging.INFO))
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")

    # تأكد من وجود StreamHandler واحد فقط
    has_stream = any(isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler) for h in log.handlers)
    if not has_stream:
        ch = logging.StreamHandler()
        ch.setFormatter(fmt)
        log.addHandler(ch)

    # أضف FileHandler إذا طُلب (بدون تكرار نفس الملف)
    if log_path:
        try:
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
        except (OSError, TypeError, ValueError):
            pass
        existing_files = {getattr(h, "baseFilename", None) for h in log.handlers if isinstance(h, logging.FileHandler)}
        if log_path not in existing_files:
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setFormatter(fmt)
            log.addHandler(fh)

    # Add a second file handler for compatibility: logs/hybrid_pipeline.log
    # (Some environments expect both 'hybrid.log' and 'hybrid_pipeline.log')
    alt_log_path = None
    if log_path:
        try:
            base_dir = os.path.dirname(log_path)
            alt_log_path = os.path.join(base_dir if base_dir else ".", "hybrid_pipeline.log")
            # Avoid duplicating the same file handler
            existing_files = {getattr(h, "baseFilename", None) for h in log.handlers if isinstance(h, logging.FileHandler)}
            if alt_log_path not in existing_files and alt_log_path != log_path:
                fh2 = logging.FileHandler(alt_log_path, encoding="utf-8")
                fh2.setFormatter(fmt)
                log.addHandler(fh2)
        except (OSError, TypeError, ValueError):
            alt_log_path = None

    # Informative logs about logger destinations and level
    if log_path:
        log.info("📄 Logger '%s' will write to: %s", name, log_path)
    if alt_log_path:
        log.info("📄 Logger '%s' will also write to: %s", name, alt_log_path)
    log.info("🔧 Logger '%s' configured at level: %s", name, level.upper())
    log.info("✅ Logger '%s' setup complete.", name)

    # مزامنة لوجر 'hybrid' مع نفس الهاندلرز (بدون تكرار)
    hybrid_logger = logging.getLogger("hybrid")
    hybrid_logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    exist = {(type(h), getattr(h, "baseFilename", None)) for h in hybrid_logger.handlers}
    for h in log.handlers:
        key = (type(h), getattr(h, "baseFilename", None))
        if key not in exist:
            hybrid_logger.addHandler(h)
    return log


# ===================== أدوات مساعدة =====================

def _read_yaml(path: str) -> Dict:
    try:
        import yaml  # type: ignore
    except (ImportError, ModuleNotFoundError):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except (OSError, ValueError, AttributeError):
        return {}
    except (yaml.YAMLError, UnicodeDecodeError):
        return {}

def _safe_read_csv(path: str, log: Optional[logging.Logger] = None) -> Optional[pd.DataFrame]:
    if path is None:
        return None
    if not os.path.exists(path):
        if log:
            log.warning("CSV not found: %s", path)
        return None
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            df = pd.read_csv(path, encoding=enc)
            if log:
                log.info("Loaded CSV: %s (rows=%s, cols=%s, encoding=%s)", path, len(df), len(df.columns), enc)
            return df
        except (pd.errors.ParserError, UnicodeDecodeError, OSError, ValueError) as ex:
            if log:
                log.debug("Failed reading %s with %s: %s", path, enc, ex)
    if log:
        log.error("Failed to read CSV: %s", path)
    return None

def _ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)


def _dump_json(obj, path: str, log: Optional[logging.Logger] = None):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
        if log:
            log.info("Saved JSON: %s", path)
    except (OSError, TypeError, ValueError) as ex:
        if log:
            log.warning("Failed to save JSON %s: %s", path, ex)

# --- Global canonical key helpers (avoid redefining in branches) ---
def _canon_pid(sr: pd.Series) -> pd.Series:
    return sr.astype(str).str.strip()

def _canon_fid(sr: pd.Series) -> pd.Series:
    return sr.astype(str).str.strip().str.lower()

# --- Academic bridge CSV helper ---
def _write_hybrid_eval_bridge(df_top: pd.DataFrame,
                              cbf_raw_df: Optional[pd.DataFrame],
                              out_dir: str,
                              log: Optional[logging.Logger] = None) -> None:
    """
    Create a rich per-row bridge table that links CBF and Hybrid signals for academic reporting.

    Writes: outputs/Hybrid/hybrid_eval_bridge.csv with (at least):
      - patient_id, feature_id, true_response
      - reason, explanation, source
      - p_cf, weight_cf, weight_cbf, hybrid_score, clinical_flags
      - from CBF: score_cbf (or score_cbf_raw), p_cbf, sim_norm, cbf_present
      - per-patient LOCO metrics replicated on rows: precision@5, recall@5, map@5, ndcg@5
    """
    if not isinstance(df_top, pd.DataFrame) or df_top.empty:
        return

    # Load per-patient LOCO metrics (prefer per-row LOCO if available, canonicalize keys)
    path_rows = "outputs/CBF/cbf_recs_loco_rows.csv"
    path_loco = "outputs/CBF/cbf_recs_loco.csv"
    loco_rows = _safe_read_csv(path_rows, log)
    loco = _safe_read_csv(path_loco, log)

    metrics = None
    # Prefer per-row LOCO (patient_id + feature_id) if available
    if isinstance(loco_rows, pd.DataFrame) and not loco_rows.empty and "patient_id" in loco_rows.columns:
        keep_cols = ["patient_id","feature_id","precision@5","recall@5","map@5","ndcg@5"]
        keep = [c for c in keep_cols if c in loco_rows.columns]
        if "feature_id" in keep:
            metrics = loco_rows[keep].copy()
            # canonicalize keys for robust join
            metrics["patient_id"] = metrics["patient_id"].astype(str).str.strip()
            metrics["feature_id"] = metrics["feature_id"].astype(str).str.strip().str.lower()
        else:
            # rows file without feature_id → fall back to patient-level only
            keep = [c for c in ["patient_id","precision@5","recall@5","map@5","ndcg@5"] if c in loco_rows.columns]
            metrics = loco_rows[keep].copy()
            metrics["patient_id"] = metrics["patient_id"].astype(str).str.strip()
    elif isinstance(loco, pd.DataFrame) and not loco.empty and "patient_id" in loco.columns:
        keep = [c for c in ["patient_id","precision@5","recall@5","map@5","ndcg@5"] if c in loco.columns]
        metrics = loco[keep].copy()
        metrics["patient_id"] = metrics["patient_id"].astype(str).str.strip()

    d = df_top.copy()

    # Canonical interpretability fields
    d["reason"] = d.get("hybrid_reason", pd.Series([pd.NA] * len(d), index=d.index))
    # Prefer CBF explanation when present, fall back to CF
    expl_cbf = d.get("explanation_cbf", pd.Series([pd.NA] * len(d), index=d.index))
    expl_cf  = d.get("explanation_cf",  pd.Series([pd.NA] * len(d), index=d.index))
    d["explanation"] = expl_cbf.fillna(expl_cf)
    d["source"] = d.get("source_unified", d.get("hybrid_sources", pd.Series([""] * len(d), index=d.index))).astype(str)

    # Ensure numeric fields exist (None-safe)
    for col in ["p_cf","weight_cf","weight_cbf","hybrid_score","p_cbf","sim_norm","cbf_present"]:
        if col not in d.columns:
            d[col] = pd.NA

    # Base bridge columns from HYB
    cols = [
        "patient_id","feature_id","true_response",
        "reason","explanation","source",
        "p_cf","weight_cf","weight_cbf","hybrid_score","clinical_flags",
        "p_cbf","sim_norm","cbf_present"
    ]
    bridge = d[[c for c in cols if c in d.columns]].copy()

    # Attach CBF raw score if available
    if isinstance(cbf_raw_df, pd.DataFrame) and not cbf_raw_df.empty:
        sel = []
        for c in ["patient_id","feature_id","score_cbf","score_cbf_raw","sim_norm"]:
            if c in cbf_raw_df.columns:
                sel.append(c)
        if sel:
            cbf_min = cbf_raw_df[sel].drop_duplicates(subset=["patient_id","feature_id"])
            bridge = bridge.merge(cbf_min, on=["patient_id","feature_id"], how="left", suffixes=("","_cbfraw"))

    # Attach LOCO metrics — prefer (patient_id, feature_id), else patient-level
    if isinstance(metrics, pd.DataFrame) and not metrics.empty and "patient_id" in bridge.columns:
        # canonicalize bridge keys
        bridge["patient_id"] = bridge["patient_id"].astype(str).str.strip()
        if "feature_id" in bridge.columns:
            bridge["feature_id"] = bridge["feature_id"].astype(str).str.strip().str.lower()
        if "feature_id" in metrics.columns and "feature_id" in bridge.columns:
            merge_keys = ["patient_id","feature_id"]
            bridge = bridge.merge(metrics.drop_duplicates(merge_keys), on=merge_keys, how="left")
        else:
            bridge = bridge.merge(metrics.drop_duplicates("patient_id"), on="patient_id", how="left")

    # Save
    out_path = os.path.join(out_dir, "hybrid_eval_bridge.csv")
    try:
        bridge.to_csv(out_path, index=False, encoding="utf-8-sig")
        if log:
            log.info("Saved bridge CSV: %s (rows=%d, cols=%d)", out_path, len(bridge), len(bridge.columns))
    except (OSError, ValueError) as ex:
        if log:
            log.warning("Failed to save bridge CSV %s: %s", out_path, ex)

def _coerce01(s: pd.Series) -> pd.Series:
    """Helper: force 0/1 (or nan) for true_response."""
    return pd.to_numeric(s, errors="coerce").map(lambda x: 1 if x == 1 else (0 if x == 0 else np.nan))

# --- String cleaning helpers for provenance fields ---
def _clean_str(val: str) -> str:
    if val is None:
        return ""
    s = str(val).strip()
    # remove trailing ", true" / ", false" if leaked from CSV joins
    if s.endswith(", true"):
        s = s[:-6].rstrip()
    if s.endswith(", false"):
        s = s[:-7].rstrip()
    # remove surrounding parentheses when they become empty, then re-trim
    s = s.strip()
    return s


def _clean_series(ser: pd.Series) -> pd.Series:
    return ser.astype(str).map(_clean_str)

# --- Pipeline-level guard: ensure advice_text for specific flag combo ---
def _apply_advice_combo_guard(df_top: pd.DataFrame) -> pd.DataFrame:
    """If clinical_flags contain the trio (gateH_cbf_high_similarity; gateL_lifestyle_counsel; gateF_follow_up)
    and advice_text is empty/NaN, fill with a sensible lifestyle/follow-up template; also normalize advice_type/source.
    Idempotent and safe to call multiple times.
    """
    if df_top is None or df_top.empty:
        return df_top
    needed = {"clinical_flags","advice_text","advice_type","advice_source","feature_id"}
    if not needed.issubset(set(df_top.columns)):
        return df_top

    d = df_top.copy()
    flags = d["clinical_flags"].astype(str)
    has_H = flags.str.contains("gateH_cbf_high_similarity", na=False)
    has_L = flags.str.contains("gateL_lifestyle_counsel", na=False)
    has_F = flags.str.contains("gateF_follow_up", na=False)
    combo_mask = has_H & has_L & has_F

    adv_txt = d["advice_text"]
    empty_adv = (
            adv_txt.isna()
            | adv_txt.astype(str).str.strip().eq("")
            | adv_txt.astype(str).str.strip().str.lower().isin({"nan", "none", "null", "na", "n/a"})
    )
    fix_mask = combo_mask & empty_adv

    if fix_mask.any():
        # Minimal lifestyle templates keyed by feature_id
        _templates = {
            "increase_exercise": "زِد النشاط الهوائي المعتدل 150 دقيقة/أسبوع (أو 75 دقيقة شديد) + تمارين مقاومة مرتين أسبوعيًا.",
            "reduce_salt": "خفّض الصوديوم إلى < 1500–2000 ملغ/يوم، وتجنّب الأطعمة العالية بالملح والمعالجة.",
            "weight_reduction": "استهدف خفض 5–10% من الوزن خلال 3–6 أشهر بدعم غذائي وسلوكي.",
            "smoking_cessation": "أوقف التدخين تمامًا؛ اعرض بدائل النيكوتين/الإحالة لعيادة الإقلاع حسب التوفر.",
        }
        def _fill_from_feature(fid: str) -> str:
            key = str(fid or "").strip().lower()
            return _templates.get(key, "حدّد متابعة بعد 2–4 أسابيع لضبط الضغط، مراجعة الالتزام والآثار الجانبية، وضبط الخطة عند الحاجة.")

        d.loc[fix_mask, "advice_text"] = d.loc[fix_mask, "feature_id"].map(_fill_from_feature)

        # Normalize advice_type to 'lifestyle' if missing/neutral/other
        cur_type = d["advice_type"].astype(str).str.strip().str.lower()
        bad_type = cur_type.isna() | cur_type.eq("") | cur_type.isin(["other","neutral","none","nan"])
        d.loc[fix_mask & bad_type, "advice_type"] = "lifestyle"

        # Fill advice_source from clinical_flags if empty
        src = d["advice_source"].astype(str)
        empty_src = src.isna() | src.str.strip().eq("") | src.str.lower().isin(["nan","none"])
        d.loc[fix_mask & empty_src, "advice_source"] = d.loc[fix_mask, "clinical_flags"].astype(str)

    return d

# ===================== أدوات مساعدة إضافية =====================

# --- BACKFILL TRUE RESPONSE ---
def _backfill_true_response(df_out: pd.DataFrame, sources: list[pd.DataFrame], key_cols=("patient_id","feature_id")) -> pd.DataFrame:
    """يملأ true_response إن غاب، من اتحاد مصادر CF/CBF."""
    d = df_out.copy()
    if "true_response" in d.columns and d["true_response"].notna().any():
        return d
    label = None
    for src in sources:
        if src is None:
            continue
        if all(c in src.columns for c in key_cols) and "true_response" in src.columns:
            part = src[list(key_cols)+["true_response"]].copy()
            label = part if label is None else pd.concat([label, part], axis=0, ignore_index=True)
    if label is None or label.empty:
        d["true_response"] = np.nan
        return d
    label = label.dropna(subset=["true_response"]).drop_duplicates(list(key_cols))
    d = d.merge(label, on=list(key_cols), how="left", suffixes=("", "_lbl"))
    if "true_response_lbl" in d.columns:
        d["true_response"] = d["true_response"].fillna(d["true_response_lbl"])
        d = d.drop(columns=["true_response_lbl"])
    return d

def _to_num(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce")

def precision_recall_ndcg_map_at_k(df: pd.DataFrame, k: int = 5, score_col: str = "hybrid_score",
                                   group_col: str = "patient_id", true_col: str = "true_response") -> Dict[str, float]:
    """
    تقييم بسيط على @K داخل كل patient_id ثم المتوسط.
    """
    if df is None or df.empty:
        return {"precision": np.nan, "recall": np.nan, "ndcg": np.nan, "map": np.nan}

    d = df.copy()
    if score_col not in d.columns or true_col not in d.columns or group_col not in d.columns:
        return {"precision": np.nan, "recall": np.nan, "ndcg": np.nan, "map": np.nan}

    d[score_col] = _to_num(d[score_col])
    d[true_col] = _to_num(d[true_col]).fillna(0).astype(int)
    d = d.sort_values([group_col, score_col], ascending=[True, False])

    # top-k و رتب
    d["rank"] = d.groupby(group_col).cumcount() + 1
    topk = d[d["rank"] <= k].copy()

    # precision@k و recall@k
    grp = topk.groupby(group_col)[true_col].agg(["mean", "sum"])
    prec = float(grp["mean"].mean()) if not grp.empty else np.nan

    # --- Robust recall@k: average only over patients that actually have positives ---
    tot_pos = d.groupby(group_col)[true_col].sum()  # do NOT replace 0 with NaN yet
    recalls = []
    topk_pos_by_pid = topk.groupby(group_col)[true_col].sum()

    for pid, total in tot_pos.items():
        if total <= 0:
            # لا أهداف لهذا المريض -> لا نحتسبه في المتوسط (أو عدّه 0.0 إن رغبت)
            continue
        hit = float(topk_pos_by_pid.get(pid, 0.0))
        recalls.append(hit / float(total))

    rec = float(np.mean(recalls)) if len(recalls) > 0 else 0.0

    # nDCG@k
    topk["dcg"] = topk[true_col] / np.log2(topk["rank"] + 1)
    dcg = topk.groupby(group_col)["dcg"].sum()
    # ideal DCG بافتراض كل الإيجابيات أولًا
    ideal = (
        d.sort_values([group_col, true_col], ascending=[True, False])
         .groupby(group_col).head(k)
         .assign(rank=lambda x: x.groupby(group_col).cumcount() + 1)
    )
    ideal["dcg"] = ideal[true_col] / np.log2(ideal["rank"] + 1)
    idcg = ideal.groupby(group_col)["dcg"].sum().replace(0, np.nan)
    ndcg = float((dcg / idcg).mean())

    # MAP@k
    # لكل مريض، متوسط precision عند كل أصابة إيجابية ضمن أعلى k
    ap_vals = []
    for pid, g in topk.groupby(group_col):
        # cumulative positives
        g = g.sort_values("rank")
        cpos = g[true_col].cumsum()
        # precision عند كل نقطة إيجابية
        prec_at_i = (cpos / g["rank"])[g[true_col] == 1]
        if not prec_at_i.empty:
            ap_vals.append(float(prec_at_i.mean()))
        else:
            ap_vals.append(0.0)
    mapk = float(np.mean(ap_vals)) if len(ap_vals) > 0 else np.nan

    # If there are no positives in the entire sample, make metrics well-defined
    if d[true_col].sum() <= 0:
        return {"precision": float(prec), "recall": 0.0, "ndcg": 0.0, "map": 0.0}
    return {"precision": prec, "recall": rec, "ndcg": ndcg, "map": mapk}

# ===================== المسار الرئيسي =====================

def main():
    parser = argparse.ArgumentParser(description="Run Hybrid CF+CBF pipeline")
    parser.add_argument("--config", type=str, default="config.yaml", help="Path to config.yaml (optional).")
    parser.add_argument("--cf_csv", type=str, default="outputs/CF/df_cf_recommendations.csv")
    parser.add_argument("--cbf_csv", type=str, default="outputs/CBF/df_cbf_recommendations.csv")
    parser.add_argument("--ctx_csv", type=str, default="outputs/tmp/df_contextualized.csv")
    parser.add_argument("--eval_cf_csv", type=str, default="outputs/CF/df_cf_recommendations_eval.csv")
    parser.add_argument("--eval_cbf_csv", type=str, default="outputs/CBF/df_cbf_recommendations_eval.csv")
    parser.add_argument("--out_dir", type=str, default="outputs/Hybrid")
    parser.add_argument("--topk", type=int, default=5)
    parser.add_argument("--log_path", type=str, default="logs/hybrid.log")
    parser.add_argument("--log_level", type=str, default="INFO")
    parser.add_argument("--use_group_weights", action="store_true", help="Enable per-group weights (bp+chol).")
    parser.add_argument("--e2e", action="store_true", help="Use the end-to-end hybrid path (unify→calibrate→blend→gates→topK) instead of the step-by-step path.")
    parser.add_argument("--make_plots", action="store_true", help="Write per-group comparison plots (CF vs CBF vs Hybrid) and CSV under outputs/Hybrid/plots.")
    args = parser.parse_args()

    log = _setup_logger("hybrid_pipeline", level=args.log_level, log_path=args.log_path)
    _ensure_dir(args.out_dir)

    # Defaults for new CBF controls (defined upfront to satisfy static analyzers)
    cbf_input_source: str = 'full'              # {'full','trimmed'}
    cbf_score_field: str = 'score_cbf'          # raw score column name in FULL CBF file
    gateE_treat_nan_as_low: bool = False        # treat NaN similarity as low when True
    cbf_weak_enabled: bool = True               # default enabled unless YAML overrides
    cbf_weak_min: float = 0.30                  # default threshold for weak CBF flag

    eval_base_df = None  # will hold pre-filter, pre-topK dataframe for evaluation
    df_hyb_base: Optional[pd.DataFrame] = None  # will point to unified base frame in non-e2e path
    df_cbf_full: Optional[pd.DataFrame] = None  # will hold FULL CBF frame with calibrated p_cbf
    # تحميل/دمج الضبط من yaml
    cfg = HybridConfig()
    yaml_cfg = _read_yaml(args.config)
    # Defaults for CBF rescue thresholds (ensure defined regardless of YAML parsing outcome)
    _rescue_sim_min: float = 0.65
    _rescue_pcbf_min: float = 0.55
    _rescue_require_src: bool = True
    if yaml_cfg:
        # تحديث بعض الحقول إن وُجدت بالـ yaml
        try:
            hy = yaml_cfg.get("hybrid", {}) or {}

            # global_weight_cf (robust parsing; ignore None/blank)
            _gw = hy.get("global_weight_cf", None)
            if isinstance(_gw, (int, float)) and not isinstance(_gw, bool):
                cfg.global_weight_cf = float(_gw)
            elif isinstance(_gw, str):
                _s = _gw.strip()
                if _s:
                    try:
                        cfg.global_weight_cf = float(_s)
                    except (TypeError, ValueError):
                        pass

            # sim_mod
            sim_cfg = hy.get("sim_mod", {}) or {}
            _iv = sim_cfg.get("intercept", None)
            if isinstance(_iv, (int, float)) and not isinstance(_iv, bool):
                cfg.sim_mod_intercept = float(_iv)
            elif isinstance(_iv, str):
                _s = _iv.strip()
                if _s:
                    try:
                        cfg.sim_mod_intercept = float(_s)
                    except (TypeError, ValueError):
                        pass

            _sv = sim_cfg.get("slope", None)
            if isinstance(_sv, (int, float)) and not isinstance(_sv, bool):
                cfg.sim_mod_slope = float(_sv)
            elif isinstance(_sv, str):
                _s = _sv.strip()
                if _s:
                    try:
                        cfg.sim_mod_slope = float(_s)
                    except (TypeError, ValueError):
                        pass

            # sim_thresholds
            thr_cfg = hy.get("sim_thresholds", {}) or {}
            _bt = thr_cfg.get("boost_threshold", None)
            if isinstance(_bt, (int, float)) and not isinstance(_bt, bool):
                cfg.sim_boost_threshold = float(_bt)
            elif isinstance(_bt, str):
                _s = _bt.strip()
                if _s:
                    try:
                        cfg.sim_boost_threshold = float(_s)
                    except (TypeError, ValueError):
                        pass

            _bf = thr_cfg.get("boost_factor", None)
            if isinstance(_bf, (int, float)) and not isinstance(_bf, bool):
                cfg.sim_boost_factor = float(_bf)
            elif isinstance(_bf, str):
                _s = _bf.strip()
                if _s:
                    try:
                        cfg.sim_boost_factor = float(_s)
                    except (TypeError, ValueError):
                        pass

            _dt = thr_cfg.get("damp_threshold", None)
            if isinstance(_dt, (int, float)) and not isinstance(_dt, bool):
                cfg.sim_damp_threshold = float(_dt)
            elif isinstance(_dt, str):
                _s = _dt.strip()
                if _s:
                    try:
                        cfg.sim_damp_threshold = float(_s)
                    except (TypeError, ValueError):
                        pass

            _df = thr_cfg.get("damp_factor", None)
            if isinstance(_df, (int, float)) and not isinstance(_df, bool):
                cfg.sim_damp_factor = float(_df)
            elif isinstance(_df, str):
                _s = _df.strip()
                if _s:
                    try:
                        cfg.sim_damp_factor = float(_s)
                    except (TypeError, ValueError):
                        pass

            # --- cbf_rescue config (robust & None-safe) ---
            res_cfg = (yaml_cfg.get("hybrid", {}) or {}).get("cbf_rescue", {}) or {}

            _v = res_cfg.get("sim_min", None)
            if isinstance(_v, (int, float)) and not isinstance(_v, bool):
                _rescue_sim_min = float(_v)
            elif isinstance(_v, str) and _v.strip():
                try:
                    _rescue_sim_min = float(_v.strip())
                except (TypeError, ValueError):
                    pass

            _v = res_cfg.get("p_cbf_min", None)
            if isinstance(_v, (int, float)) and not isinstance(_v, bool):
                _rescue_pcbf_min = float(_v)
            elif isinstance(_v, str) and _v.strip():
                try:
                    _rescue_pcbf_min = float(_v.strip())
                except (TypeError, ValueError):
                    pass

            _v = res_cfg.get("require_cbf_source", None)
            if isinstance(_v, bool):
                _rescue_require_src = _v
            elif isinstance(_v, str):
                _rescue_require_src = _v.strip().lower() in {"1","true","yes","y","on"}

            # --- NEW: Read CBF source & score field (robust & None-safe) ---
            hyb_cfg = (yaml_cfg.get("hybrid", {}) or {})
            cbf_input_source = str(hyb_cfg.get("cbf_input_source", "full")).strip().lower()
            if cbf_input_source not in {"full", "trimmed"}:
                cbf_input_source = "full"
            cbf_score_field = str(hyb_cfg.get("cbf_score_field", "score_cbf")).strip() or "score_cbf"

            # --- NEW: GateE option ---
            gates_cfg = (hyb_cfg.get("gates", {}) or {})
            gateE_cfg = (gates_cfg.get("gateE", {}) or {})
            gateE_treat_nan_as_low = bool(str(gateE_cfg.get("treat_nan_as_low", "false")).strip().lower() in {"1","true","yes","y","on"})

            # --- NEW: cbf_weak option ---
            cbf_weak_cfg = (gates_cfg.get("cbf_weak", {}) or {})
            try:
                _cbf_weak_enabled_raw = str(cbf_weak_cfg.get("enabled", "true")).strip().lower()
                cbf_weak_enabled = _cbf_weak_enabled_raw in {"1","true","yes","y","on"}
            except (TypeError, ValueError, AttributeError):
                cbf_weak_enabled = True
            try:
                cbf_weak_min = float(cbf_weak_cfg.get("p_cbf_min", 0.30))
            except (TypeError, ValueError, AttributeError):
                cbf_weak_min = 0.30
        except (TypeError, ValueError, AttributeError) as ex:
            log.warning("Config YAML parsing partial: %s", ex)

    # (Defaults for cbf_input_source, cbf_score_field, gateE_treat_nan_as_low are now set above)

    # Hybrid-only policy (topK & score threshold) — optional override from config.yaml
    policy = yaml_cfg.get("hybrid_policy", {}) if yaml_cfg else {}
    try:
        _policy_topk = policy.get("top_n_eval", None)
        if isinstance(_policy_topk, (int, float)) and not isinstance(_policy_topk, bool):
            args.topk = int(_policy_topk)
        elif isinstance(_policy_topk, str) and _policy_topk.strip():
            args.topk = int(float(_policy_topk.strip()))
    except (TypeError, ValueError):
        pass  # keep args.topk from CLI
    _policy_thr_enabled = bool(policy.get("score_threshold_enabled", True)) if policy else True
    _policy_thr = policy.get("score_threshold", 0.25) if policy else 0.25
    try:
        _policy_thr = float(_policy_thr)
    except (TypeError, ValueError):
        _policy_thr = 0.25

    # Minimum samples for isotonic calibration (guard)
    # Parse robustly and avoid passing None to int()
    iso_min: int = 20
    raw_iso = None
    if yaml_cfg:
        try:
            raw_iso = yaml_cfg.get("scoring", {}).get("isotonic_min_samples", None)
        except (AttributeError, TypeError):
            raw_iso = None
    if isinstance(raw_iso, (int, float)) and not isinstance(raw_iso, bool):
        iso_min = int(raw_iso)
    elif isinstance(raw_iso, str):
        s = raw_iso.strip()
        try:
            iso_min = int(float(s))
        except (TypeError, ValueError):
            pass  # keep default 20
    # optional: debug log
    log.debug("[HYB] isotonic_min_samples=%s", iso_min)

    # تحميل البيانات
    df_cf = _safe_read_csv(args.cf_csv, log)
    # Load chosen CBF source (full | trimmed)
    if cbf_input_source == "full":
        cbf_path = "outputs/CBF/df_cbf_recommendations_full.csv"
    else:
        cbf_path = args.cbf_csv
    cbf_raw_df = _safe_read_csv(cbf_path, log)

    # --- [CBF CALIBRATOR] prefer persisted isotonic; else fit on LOCO rows ---
    cbf_calibrator = None
    try:
        models_cfg = (yaml_cfg.get("models", {}) or {}) if isinstance(yaml_cfg, dict) else {}
        iso_path = str(models_cfg.get("cbf_isotonic_path", "")).strip()
        if iso_path and os.path.exists(iso_path):
            import joblib  # type: ignore
            cbf_calibrator = joblib.load(iso_path)
            log.info("[HYB][CAL] Loaded CBF isotonic from %s", iso_path)
        else:
            _cal_src = "outputs/CBF/cbf_recs_loco_rows.csv"
            if os.path.exists(_cal_src):
                tmp = pd.read_csv(_cal_src)
                if {"score_cbf","true_response"}.issubset(tmp.columns):
                    s = pd.to_numeric(tmp["score_cbf"], errors="coerce")
                    y = pd.to_numeric(tmp["true_response"], errors="coerce")
                    m = ~(s.isna() | y.isna())
                    # robust parse of min samples
                    try:
                        min_n_raw = (yaml_cfg.get("scoring", {}) or {}).get("isotonic_min_samples", 20) if isinstance(yaml_cfg, dict) else 20
                        min_n = int(float(str(min_n_raw).strip())) if str(min_n_raw).strip() else 20
                    except (TypeError, ValueError, AttributeError):
                        min_n = 20
                    if int(m.sum()) >= min_n:
                        from sklearn.isotonic import IsotonicRegression  # type: ignore
                        cbf_calibrator = IsotonicRegression(out_of_bounds="clip").fit(s[m].values, y[m].values)
                        log.info("[HYB][CAL] Fitted fallback isotonic on LOCO rows (n=%d).", int(m.sum()))
    except (FileNotFoundError, ValueError, TypeError) as e:
        log.warning("[HYB][CAL] Non-fatal calibrator load failure: %s", e)

    # --- Derive p_cbf on the CBF FULL frame itself (do NOT overwrite raw score) ---
    if cbf_raw_df is not None and not cbf_raw_df.empty:
        df_cbf_full = cbf_raw_df.copy()
        if "score_cbf" in df_cbf_full.columns:
            df_cbf_full["p_cbf"] = pd.to_numeric(df_cbf_full["score_cbf"], errors="coerce").clip(0.0, 1.0)
        elif "score_cbf_raw" in df_cbf_full.columns:
            df_cbf_full["p_cbf"] = pd.to_numeric(df_cbf_full["score_cbf_raw"], errors="coerce").clip(0.0, 1.0)
        else:
            df_cbf_full["p_cbf"] = np.nan

        if cbf_calibrator is not None and df_cbf_full["p_cbf"].notna().any():
            try:
                arr1d = df_cbf_full["p_cbf"].astype(float).values  # 1D only
                df_cbf_full["p_cbf"] = np.asarray(
                    cbf_calibrator.transform(arr1d), dtype=float
                ).clip(0.0, 1.0)
                log.info("[HYB][CAL] Applied isotonic to CBF FULL frame.")
            except (ValueError, TypeError) as e:
                log.warning("[HYB][CAL] Transform to FULL failed; using identity: %s", e)

        # make calibrated p_cbf available downstream in cbf_raw_df
        cbf_raw_df = df_cbf_full
    # Keep legacy df_cbf for compatibility (trimmed)
    df_cbf = cbf_raw_df if cbf_input_source != "full" else cbf_raw_df
    df_ctx = _safe_read_csv(args.ctx_csv, log)

    if df_cf is None and df_cbf is None:
        log.error("Both CF and CBF CSVs are missing. Abort.")
        return

    # ملفات تقييم للمعايرة
    eval_cf = _safe_read_csv(args.eval_cf_csv, log)
    eval_cbf = _safe_read_csv(args.eval_cbf_csv, log)

    # Guard: disable calibration if eval rows are too few
    if eval_cf is not None and len(eval_cf) < iso_min:
        log.info("[HYB] CF eval rows (%d) < isotonic_min_samples (%d): using identity calibrator.", len(eval_cf), iso_min)
        eval_cf = None
    if eval_cbf is not None and len(eval_cbf) < iso_min:
        log.info("[HYB] CBF eval rows (%d) < isotonic_min_samples (%d): using identity calibrator.", len(eval_cbf), iso_min)
        eval_cbf = None

    # Initialize group-weight variables to safe defaults (used later for saving/logging)
    gw = {}
    wcf_g = cfg.global_weight_cf
    wcbf_g = 1.0 - wcf_g

    # --- unify + calibrate + (optional) group weights + blend + gates + diversify + topK ---
    # --- Prepare CBF raw fields (cbf_score_raw, sim_norm) ---
    if cbf_raw_df is not None and not cbf_raw_df.empty:
        df_cbf_raw = cbf_raw_df.copy()
        # ensure cbf_score_raw present
        if cbf_score_field in df_cbf_raw.columns:
            df_cbf_raw["cbf_score_raw"] = pd.to_numeric(df_cbf_raw[cbf_score_field], errors="coerce")
        else:
            logger.warning("[HYB] CBF score field '%s' not found in %s — falling back to 'score_cbf'",
                           cbf_score_field, cbf_path)
            fallback = "score_cbf" if "score_cbf" in df_cbf_raw.columns else None
            df_cbf_raw["cbf_score_raw"] = pd.to_numeric(df_cbf_raw.get(fallback, np.nan), errors="coerce")
        # normalize sim_norm
        if "sim_norm" in df_cbf_raw.columns:
            df_cbf_raw["sim_norm"] = pd.to_numeric(df_cbf_raw["sim_norm"], errors="coerce")
        elif "similarity" in df_cbf_raw.columns:
            df_cbf_raw["sim_norm"] = pd.to_numeric(df_cbf_raw["similarity"], errors="coerce")
        else:
            df_cbf_raw["sim_norm"] = np.nan
    else:
        df_cbf_raw = pd.DataFrame()
    if args.e2e:
        # مسار مختصر/مجمّع
        df_top = hybrid_end_to_end(
            df_cf=df_cf if df_cf is not None else pd.DataFrame(),
            df_cbf=df_cbf_raw if df_cbf_raw is not None else pd.DataFrame(),
            df_ctx=df_ctx,
            eval_cf=eval_cf,
            eval_cbf=eval_cbf,
            k=args.topk,
            cfg=cfg,
            use_group_weights=args.use_group_weights,
            isotonic_min_samples=iso_min,
        )
        eval_base_df = None  # no pre-filter DF available in e2e path

        # --- HYBRID: sanitize columns before any saving ---
        if "sim_norm" in df_top.columns:
            df_top["sim_norm"] = pd.to_numeric(df_top["sim_norm"], errors="coerce").fillna(0.0)

        # لا تسقط أعمدة النصيحة/الأعلام الجديدة
        for col_x in [
            "advice_text", "advice_type", "advice_source", "guideline_tags",
            "conflict_flag", "confidence_bucket", "sim_bucket",
            "clinical_flags", "source_unified",
        ]:
            if col_x not in df_top.columns:
                df_top[col_x] = pd.NA

        # Ensure advice fields are present (idempotent if already added inside hybrid_end_to_end)
        df_top = attach_hybrid_advice(df_top, cfg)

        # --- Advice typing enrichment (diverse medical categories; no Nulls) ---
        try:
            from recommender.hybrid import enrich_advice_types  # مُعرّفة في hybrid.py
            if callable(enrich_advice_types):
                df_top = enrich_advice_types(df_top)
        except (ImportError, AttributeError, TypeError) as _adv_ex:
            logger.debug("Advice typing enrichment skipped: %s", _adv_ex)

        # توزيع تشخيصي
        if "advice_type" in df_top.columns:
            _counts = df_top["advice_type"].fillna("other").astype(str).value_counts().to_dict()
            logger.info("[HYB][ADV] advice_type distribution: %s", _counts)
        # Pipeline-level guard for the (H + L + F) combo → ensure advice_text present
        try:
            df_top = _apply_advice_combo_guard(df_top)
        except (TypeError, ValueError, KeyError, AttributeError) as _guard_ex:
            logger.debug("Advice combo guard (e2e) skipped: %s", _guard_ex)
        # Ensure new advice/flags fields are present before saving
        for col_name in [
            "advice_text","advice_type","advice_source","guideline_tags",
            "conflict_flag","confidence_bucket","sim_bucket",
            "clinical_flags","source_unified"
        ]:
            if col_name not in df_top.columns:
                df_top[col_name] = pd.NA

        # تنويع: ضمّن عنصر CBF واحد إن وُجد وقوي بما يكفي (لا يزيد K)
        try:
            from recommender.hybrid import ensure_one_cbf_if_available  # قد يكون غير موجود في إصدارات أقدم
            if callable(ensure_one_cbf_if_available):
                df_top = ensure_one_cbf_if_available(df_top, score_thr=_policy_thr)
        except (ImportError, AttributeError, NameError, TypeError) as _e:
            logger.debug("Diversity step (one CBF) skipped: %s", _e)

        # ---- HYB FILTER (two-branch): keep strong CBF even if hybrid_score just under threshold ----
        if "hybrid_score" in df_top.columns and _policy_thr_enabled:
            _before = len(df_top)
            _hs = pd.to_numeric(df_top["hybrid_score"], errors="coerce")
            _sim_src = df_top["sim_norm"] if "sim_norm" in df_top.columns else pd.Series([np.nan] * len(df_top), index=df_top.index)
            _sim = pd.to_numeric(_sim_src, errors="coerce").fillna(0.0)

            _pcf_src = df_top["p_cf"] if "p_cf" in df_top.columns else pd.Series([np.nan] * len(df_top), index=df_top.index)
            _pcb_src = df_top["p_cbf"] if "p_cbf" in df_top.columns else pd.Series([np.nan] * len(df_top), index=df_top.index)
            _pcf = pd.to_numeric(_pcf_src, errors="coerce").fillna(np.nan)
            _pcb = pd.to_numeric(_pcb_src, errors="coerce").fillna(np.nan)

            _src = (df_top["advice_source"] if "advice_source" in df_top.columns else pd.Series([""] * len(df_top), index=df_top.index)).astype(str)

            # A) الشرط القياسي
            mask_main = (_hs > _policy_thr)

            # B) إنقاذ CBF الجيد: تشابه عالي + p_cbf معقول + (اختياري) مصدر CBF
            _src_ok = (~pd.Series([_rescue_require_src]*len(df_top), index=df_top.index)) \
                      | _src.str.contains("CBF", case=False, na=False)
            mask_cbf_strong = (
                _sim.ge(_rescue_sim_min)
                & _pcb.ge(_rescue_pcbf_min)
                & _src_ok
            )

            keep_mask = mask_main | mask_cbf_strong
            df_top = df_top[keep_mask].copy()
            _after = len(df_top)
            if _before != _after:
                logger.info("[HYB] Filtered by hybrid_score (%.2f) with CBF rescue: kept %d / %d rows",
                            _policy_thr, _after, _before)
    else:
        # مسار تفصيلي للتشخيص
        df_cf_input = df_cf if df_cf is not None else pd.DataFrame()
        df_cbf_input = df_cbf_raw if df_cbf_raw is not None else pd.DataFrame()
        df_u = unify_schema(df_cf_input, df_cbf_input, df_ctx, cfg)
        # --- Mark cbf_present robustly (canonical keys + inner merge) ---
        df_cbf_input = df_cbf_input.copy()
        df_u = df_u.copy()


        for _df in (df_cbf_input, df_u):
            if "patient_id" in _df.columns:
                _df["patient_id"] = _canon_pid(_df["patient_id"])
            if "feature_id" in _df.columns:
                _df["feature_id"] = _canon_fid(_df["feature_id"])

        cbf_present_series = pd.Series(0, index=df_u.index, dtype=int)
        if all(c in df_cbf_input.columns for c in ["patient_id","feature_id"]) and \
           all(c in df_u.columns for c in ["patient_id","feature_id"]):
            cbf_keys = df_cbf_input[["patient_id","feature_id"]].drop_duplicates()
            cbf_keys["cbf_present"] = 1
            df_u = df_u.merge(cbf_keys, on=["patient_id","feature_id"], how="left")
            if "cbf_present" in df_u.columns:
                df_u["cbf_present"] = pd.to_numeric(df_u["cbf_present"], errors="coerce").fillna(0).astype(int)
            else:
                df_u["cbf_present"] = 0
        else:
            # fallbacks: (patient_id, advice_id) or (patient_id, advice_code)
            df_u["cbf_present"] = 0
            for alt in (("advice_id","feature_id"), ("advice_code","feature_id")):
                pid_ok = "patient_id" in df_u.columns and "patient_id" in df_cbf_input.columns
                left_ok = alt[0] in df_u.columns and alt[0] in df_cbf_input.columns
                if not (pid_ok and left_ok):
                    continue
                # canonicalize the alt key
                df_u["_alt_key"] = df_u[alt[0]].astype(str).str.strip().str.lower()
                df_cbf_input["_alt_key"] = df_cbf_input[alt[0]].astype(str).str.strip().str.lower()
                alt_keys = df_cbf_input[["patient_id","_alt_key"]].drop_duplicates()
                alt_keys["__hit__"] = 1
                m = df_u[["patient_id","_alt_key"]].merge(alt_keys, on=["patient_id","_alt_key"], how="left")
                hit_idx = m["__hit__"].notna().values
                if hit_idx.any():
                    df_u.loc[hit_idx, "cbf_present"] = 1
                    df_u = df_u.drop(columns=["_alt_key"], errors="ignore")
                    break
                df_u = df_u.drop(columns=["_alt_key"], errors="ignore")

        log.info("[HYB] Unified schema: rows=%s, cols=%s", len(df_u), len(df_u.columns))

        # Keep a named base frame that already carries cbf_present
        df_hyb_base = df_u.copy()

        # --- Robust cbf_present with canonical join on (patient_id, feature_id) ---
        # Prefer the FULL CBF frame (with calibrated p_cbf) if available; else fall back to the local CBF input
        cbf_ref = df_cbf_full if (isinstance(df_cbf_full, pd.DataFrame) and not df_cbf_full.empty) else None
        if cbf_ref is None:
            cbf_ref = df_cbf_input if (isinstance(df_cbf_input, pd.DataFrame) and not df_cbf_input.empty) else pd.DataFrame()

        # Work on copies to avoid mutating upstream references
        df_hyb_base = df_hyb_base.copy()
        cbf_ref = cbf_ref.copy()


        # Canonicalize keys on both frames
        if "patient_id" in df_hyb_base.columns:
            df_hyb_base["patient_id"] = _canon_pid(df_hyb_base["patient_id"])
        if "feature_id" in df_hyb_base.columns:
            df_hyb_base["feature_id"] = _canon_fid(df_hyb_base["feature_id"])

        if isinstance(cbf_ref, pd.DataFrame) and not cbf_ref.empty:
            if "patient_id" in cbf_ref.columns:
                cbf_ref["patient_id"] = _canon_pid(cbf_ref["patient_id"])
            if "feature_id" in cbf_ref.columns:
                cbf_ref["feature_id"] = _canon_fid(cbf_ref["feature_id"])
        else:
            cbf_ref = pd.DataFrame(columns=["patient_id","feature_id"])  # safe empty

        # (1) primary join on (patient_id, feature_id)
        if {"patient_id","feature_id"}.issubset(cbf_ref.columns) and not cbf_ref.empty:
            cbf_keys = cbf_ref[["patient_id","feature_id"]].drop_duplicates().assign(cbf_present=1)
            df_hyb_base = df_hyb_base.merge(cbf_keys, on=["patient_id","feature_id"], how="left")
            if "cbf_present" in df_hyb_base.columns:
                df_hyb_base["cbf_present"] = pd.to_numeric(df_hyb_base["cbf_present"], errors="coerce").fillna(0).astype(int)
            else:
                df_hyb_base["cbf_present"] = 0
        else:
            # Ensure the column exists even if the primary join path is skipped
            if "cbf_present" not in df_hyb_base.columns:
                df_hyb_base["cbf_present"] = 0

        # (2) fallbacks if still all zeros: try (patient_id, advice_id) then (patient_id, advice_code)
        try:
            if ("cbf_present" not in df_hyb_base.columns or int(pd.to_numeric(df_hyb_base["cbf_present"], errors="coerce").fillna(0).sum()) == 0) \
                and isinstance(cbf_ref, pd.DataFrame) and not cbf_ref.empty:
                for alt in ("advice_id", "advice_code"):
                    if alt in df_hyb_base.columns and alt in cbf_ref.columns:
                        _base = df_hyb_base[["patient_id", alt]].copy()
                        _base["_key"] = _canon_pid(_base["patient_id"]) + "|" + _base[alt].astype(str).str.strip().str.lower()
                        _cbf = cbf_ref[["patient_id", alt]].copy()
                        _cbf["_key"] = _canon_pid(_cbf["patient_id"]) + "|" + _cbf[alt].astype(str).str.strip().str.lower()
                        _cbf = _cbf[["_key"]].drop_duplicates().assign(_present=1)
                        df_hyb_base = df_hyb_base.merge(_base[["_key"]], how="left", left_index=False, right_index=False)
                        df_hyb_base = df_hyb_base.merge(_cbf, on="_key", how="left")
                        df_hyb_base["cbf_present"] = np.where(df_hyb_base["_present"].fillna(0).eq(1), 1, df_hyb_base["cbf_present"])
                        df_hyb_base.drop(columns=["_key", "_present"], errors="ignore", inplace=True)
                        if int(df_hyb_base["cbf_present"].sum()) > 0:
                            break
        except (TypeError, ValueError, KeyError):
            # leave cbf_present as-is if any key issue occurs
            pass

        # Safety: ensure cbf_present column exists and is int
        if "cbf_present" not in df_hyb_base.columns:
            df_hyb_base["cbf_present"] = 0
        else:
            df_hyb_base["cbf_present"] = pd.to_numeric(df_hyb_base["cbf_present"], errors="coerce").fillna(0).astype(int)

        logger.info(
            "[HYB] cbf_present stats (canonical join): yes=%d no=%d",
            int((df_hyb_base["cbf_present"] == 1).sum()),
            int((df_hyb_base["cbf_present"] == 0).sum())
        )
        try:
            if "p_cbf" in df_u.columns:
                _pcbf = pd.to_numeric(df_u["p_cbf"], errors="coerce")
                log.info("[HYB][DBG] p_cbf stats before blend — n: %d | nan: %d | ==0: %d | >0: %d",
                         int(_pcbf.shape[0]), int(_pcbf.isna().sum()),
                         int((_pcbf.fillna(0)==0).sum()),
                         int((_pcbf.fillna(0)>0).sum()))
        except (TypeError, ValueError, KeyError, AttributeError):
            pass

        cal_cf, cal_cbf = fit_calibrators_from_eval(eval_cf, eval_cbf, cfg)
        log.info("[HYB] Calibrators ready.")


        # Recompute p_cbf using persisted/fallback calibrator if available
        try:
            # Compute p_cbf only for rows that actually have CBF
            if cbf_calibrator is not None and hasattr(cbf_calibrator, "transform") and "cbf_present" in df_u.columns:
                if "p_cbf" not in df_u.columns:
                    df_u["p_cbf"] = np.nan

                mask_present = df_u["cbf_present"].astype(int).eq(1)
                score_col = "cbf_score_raw" if "cbf_score_raw" in df_u.columns else ("score_cbf" if "score_cbf" in df_u.columns else None)
                if score_col is not None:
                    s = pd.to_numeric(df_u[score_col], errors="coerce")
                    mask = mask_present & s.notna()
                    if mask.any():
                        arr1d = s[mask].astype(float).values  # 1D only
                        df_u.loc[mask, "p_cbf"] = np.asarray(
                            cbf_calibrator.transform(arr1d), dtype=float
                        ).clip(0.0, 1.0)
                    # leave others as NaN
        except (ValueError, TypeError, KeyError) as _cal_tr_ex:
            log.warning("[HYB][CAL] Transform failed; kept previous p_cbf. Details: %s", _cal_tr_ex)

        gw, wcf_g, wcbf_g = (compute_group_weights(eval_cf, eval_cbf, cfg) if args.use_group_weights
                             else ({}, cfg.global_weight_cf, 1-cfg.global_weight_cf))
        if gw:
            log.info("[HYB] Group weights computed (samples): %s ...", list(gw.items())[:5])
        log.info("[HYB] Global weights => CF=%.3f | CBF=%.3f", wcf_g, wcbf_g)

        df_h = blend_scores(
            df_hyb_base, cal_cf, cal_cbf, cfg,
            group_weights=gw if args.use_group_weights else None,
            w_cf_global=wcf_g
        )
        # Ensure cbf_present is preserved after blending
        if "cbf_present" not in df_h.columns and "cbf_present" in df_hyb_base.columns:
            try:
                _keys = ["patient_id", "feature_id"]
                if all(k in df_h.columns for k in _keys) and all(k in df_hyb_base.columns for k in _keys):
                    df_h = df_h.merge(
                        df_hyb_base[_keys + ["cbf_present"]].drop_duplicates(_keys),
                        on=_keys, how="left"
                    )
                    df_h["cbf_present"] = df_h["cbf_present"].fillna(0).astype(int)
                else:
                    # fall back to align by index if keys are missing (unlikely)
                    df_h["cbf_present"] = (
                        df_h.get("cbf_present")
                        if "cbf_present" in df_h.columns
                        else df_hyb_base.get("cbf_present", pd.Series([0]*len(df_h), index=df_h.index))
                    )
            except Exception as _cbf_pres_ex:
                logger.debug("[HYB] cbf_present propagation skipped: %s", _cbf_pres_ex)

        # --- Canonical cbf_present derivation (pipeline-level guard, pre-gates) ---
        if "cbf_present" not in df_h.columns:
            df_h["cbf_present"] = 0

        _pcbf_ser = pd.to_numeric(df_h.get("p_cbf", np.nan), errors="coerce").fillna(0.0)
        _sim_ser = pd.to_numeric(df_h.get(getattr(cfg, "cbf_sim_col", "sim_norm"), np.nan), errors="coerce").fillna(0.0)
        _src_uni = df_h.get("source_unified", pd.Series("", index=df_h.index)).astype(str)

        _derived_cbf_present = (
                _pcbf_ser.gt(0.02) |
                _sim_ser.gt(0.0) |
                _src_uni.str.contains(r"CBF\s*\(", regex=True, na=False)
        ).astype(int)

        df_h["cbf_present"] = np.maximum(
            pd.to_numeric(df_h["cbf_present"], errors="coerce").fillna(0).astype(int),
            _derived_cbf_present
        )

        df_h = apply_clinical_gates(
            df_h.assign(
                _gateE_treat_nan_as_low = gateE_treat_nan_as_low,
                _cbf_weak_enabled = cbf_weak_enabled,
                _cbf_weak_min     = cbf_weak_min
            ),
            cfg
        )
        # Re-assert cbf_present after gates (idempotent if already present)
        if "cbf_present" not in df_h.columns and "cbf_present" in df_hyb_base.columns:
            try:
                _keys = ["patient_id", "feature_id"]
                if all(k in df_h.columns for k in _keys) and all(k in df_hyb_base.columns for k in _keys):
                    df_h = df_h.merge(
                        df_hyb_base[_keys + ["cbf_present"]].drop_duplicates(_keys),
                        on=_keys, how="left"
                    )
                    df_h["cbf_present"] = df_h["cbf_present"].fillna(0).astype(int)
                else:
                    df_h["cbf_present"] = (
                        df_h.get("cbf_present")
                        if "cbf_present" in df_h.columns
                        else df_hyb_base.get("cbf_present", pd.Series([0]*len(df_h), index=df_h.index))
                    )
            except Exception as _cbf_pres2_ex:
                logger.debug("[HYB] cbf_present post-gates propagation skipped: %s", _cbf_pres2_ex)
        df_h = diversify_and_tiebreak(df_h, cfg)
        # Re-assert cbf_present after diversify/tiebreak
        if "cbf_present" not in df_h.columns and "cbf_present" in df_hyb_base.columns:
            try:
                _keys = ["patient_id", "feature_id"]
                if all(k in df_h.columns for k in _keys) and all(k in df_hyb_base.columns for k in _keys):
                    df_h = df_h.merge(
                        df_hyb_base[_keys + ["cbf_present"]].drop_duplicates(_keys),
                        on=_keys, how="left"
                    )
                    df_h["cbf_present"] = df_h["cbf_present"].fillna(0).astype(int)
                else:
                    df_h["cbf_present"] = (
                        df_h.get("cbf_present")
                        if "cbf_present" in df_h.columns
                        else df_hyb_base.get("cbf_present", pd.Series([0]*len(df_h), index=df_h.index))
                    )
            except Exception as _cbf_pres3_ex:
                logger.debug("[HYB] cbf_present post-diversify propagation skipped: %s", _cbf_pres3_ex)
        eval_base_df = df_h.copy()
        df_top = topk_per_patient(df_h, k=args.topk, use_rrf_when_missing=True, cfg=cfg)
        # Keep cbf_present in the Top-K frame as well
        if "cbf_present" not in df_top.columns:
            try:
                _keys = ["patient_id", "feature_id"]
                if all(k in df_top.columns for k in _keys) and all(k in df_hyb_base.columns for k in _keys):
                    df_top = df_top.merge(
                        df_hyb_base[_keys + ["cbf_present"]].drop_duplicates(_keys),
                        on=_keys, how="left"
                    )
                    df_top["cbf_present"] = df_top["cbf_present"].fillna(0).astype(int)
            except Exception as _cbf_top_ex:
                logger.debug("[HYB] cbf_present propagation to Top-K skipped: %s", _cbf_top_ex)
        df_top = attach_hybrid_reason(df_top, cfg)
        df_top = attach_hybrid_advice(df_top, cfg)

        # --- Advice typing enrichment (diverse medical categories; no Nulls) ---
        try:
            from recommender.hybrid import enrich_advice_types  # مُعرّفة في hybrid.py
            if callable(enrich_advice_types):
                df_top = enrich_advice_types(df_top)
        except (ImportError, AttributeError, TypeError) as _adv_ex:
            logger.debug("Advice typing enrichment skipped: %s", _adv_ex)

        # توزيع تشخيصي
        if "advice_type" in df_top.columns:
            _counts = df_top["advice_type"].fillna("other").astype(str).value_counts().to_dict()
            logger.info("[HYB][ADV] advice_type distribution: %s", _counts)
        # Pipeline-level guard for the (H + L + F) combo → ensure advice_text present
        try:
            df_top = _apply_advice_combo_guard(df_top)
        except (TypeError, ValueError, KeyError, AttributeError) as _guard_ex:
            logger.debug("Advice combo guard skipped: %s", _guard_ex)
        # Ensure new advice/flags fields are present before saving
        for col_name in [
            "advice_text","advice_type","advice_source","guideline_tags",
            "conflict_flag","confidence_bucket","sim_bucket",
            "clinical_flags","source_unified"
        ]:
            if col_name not in df_top.columns:
                df_top[col_name] = pd.NA

        # --- HYBRID: sanitize sim_norm before filtering ---
        if "sim_norm" in df_top.columns:
            df_top["sim_norm"] = pd.to_numeric(df_top["sim_norm"], errors="coerce").fillna(0.0)

        # ---- HYB FILTER: drop ultra-low hybrid scores to avoid trivial R=1.0 saturation ----
        # تنويع: ضمّن عنصر CBF واحد إن وُجد وقوي بما يكفي (لا يزيد K)
        try:
            from recommender.hybrid import ensure_one_cbf_if_available  # قد يكون غير موجود في إصدارات أقدم
            if callable(ensure_one_cbf_if_available):
                df_top = ensure_one_cbf_if_available(df_top, score_thr=_policy_thr)
        except (ImportError, AttributeError, NameError, TypeError) as _e:
            logger.debug("Diversity step (one CBF) skipped: %s", _e)

        # ---- HYB FILTER (two-branch): keep strong CBF even if hybrid_score just under threshold ----
        if "hybrid_score" in df_top.columns and _policy_thr_enabled:
            _before = len(df_top)
            _hs = pd.to_numeric(df_top["hybrid_score"], errors="coerce")
            _sim_src = df_top["sim_norm"] if "sim_norm" in df_top.columns else pd.Series([np.nan] * len(df_top), index=df_top.index)
            _sim = pd.to_numeric(_sim_src, errors="coerce").fillna(0.0)

            _pcf_src = df_top["p_cf"] if "p_cf" in df_top.columns else pd.Series([np.nan] * len(df_top), index=df_top.index)
            _pcb_src = df_top["p_cbf"] if "p_cbf" in df_top.columns else pd.Series([np.nan] * len(df_top), index=df_top.index)
            _pcf = pd.to_numeric(_pcf_src, errors="coerce").fillna(np.nan)
            _pcb = pd.to_numeric(_pcb_src, errors="coerce").fillna(np.nan)

            _src = (df_top["advice_source"] if "advice_source" in df_top.columns else pd.Series([""] * len(df_top), index=df_top.index)).astype(str)

            # A) الشرط القياسي
            mask_main = (_hs > _policy_thr)

            # B) إنقاذ CBF الجيد: تشابه عالي + p_cbf معقول + (اختياري) مصدر CBF
            _src_ok = (~pd.Series([_rescue_require_src]*len(df_top), index=df_top.index)) \
                      | _src.str.contains("CBF", case=False, na=False)
            mask_cbf_strong = (
                _sim.ge(_rescue_sim_min)
                & _pcb.ge(_rescue_pcbf_min)
                & _src_ok
            )

            keep_mask = mask_main | mask_cbf_strong
            df_top = df_top[keep_mask].copy()
            _after = len(df_top)
            if _before != _after:
                logger.info("[HYB] Filtered by hybrid_score (%.2f) with CBF rescue: kept %d / %d rows",
                            _policy_thr, _after, _before)

    # (HYB FILTER moved into both branches above; removed _HYB_SCORE_MIN)
    # ---- Exclude cold_start rows from hybrid output/evaluation if configured ----
    try:
        cs_exclude = bool(yaml_cfg.get("cold_start", {}).get("exclude_from_hybrid_output", True))
    except (AttributeError, TypeError, ValueError, KeyError):
        cs_exclude = True

    if cs_exclude and df_top is not None and not df_top.empty:
        _before_cs = len(df_top)
        _status_cf = df_top.get("status_cf", pd.Series("", index=df_top.index)).astype(str)
        _source_cf = df_top.get("source_cf", pd.Series("", index=df_top.index)).astype(str)
        _src_uni   = df_top.get("source_unified", pd.Series("", index=df_top.index)).astype(str)

        _mask_cs = (
            _status_cf.str.contains("cold_start_safe_default", case=False, na=False) |
            _source_cf.str.contains("cold_start_safe_default", case=False, na=False) |
            _src_uni.str.contains("cold_start_safe_default", case=False, na=False)
        )
        if _mask_cs.any():
            df_top = df_top[~_mask_cs].copy()
            _after_cs = len(df_top)
            logger.info(
                "[HYB] Dropped cold_start rows from hybrid output: %d",
                _before_cs - _after_cs
            )

    # Final guard: ensure cbf_present exists before downstream reporting/bridge
    if "cbf_present" not in df_top.columns:
        try:
            _keys = ["patient_id", "feature_id"]
            # Ensure df_hyb_base is a DataFrame before accessing attributes
            if isinstance(df_hyb_base, pd.DataFrame) and \
               all(k in df_top.columns for k in _keys) and \
               all(k in df_hyb_base.columns for k in _keys + ["cbf_present"]):
                base_keys = _keys + ["cbf_present"]
                # Use a local DataFrame variable to satisfy static analyzers
                _base: pd.DataFrame = df_hyb_base
                base_df = _base.loc[:, base_keys].drop_duplicates(subset=_keys)
                df_top = df_top.merge(base_df, on=_keys, how="left")
                df_top["cbf_present"] = df_top["cbf_present"].fillna(0).astype(int)
        except Exception as _cbf_final_ex:
            logger.debug("[HYB] final cbf_present propagation skipped: %s", _cbf_final_ex)
    # --- normalize textual provenance fields (remove ", true/false" leaks, unify aliases) ---
    for _col in ("source_cf", "source_cbf", "source_cbf_norm", "hybrid_sources", "hybrid_reason", "status_cf", "source_unified"):
        if _col in df_top.columns:
            # normalize using constants.clean_source_text first (handles aliasing), then extra strip
            df_top[_col] = df_top[_col].map(clean_source_text)
            df_top[_col] = _clean_series(df_top[_col])

    # Backfill true_response من مصادر CF/CBF إن غاب
    df_top = _backfill_true_response(df_top, [df_cf, df_cbf])

    # --- Backfill guideline_tags from provenance if empty/[] ---
    def _needs_backfill(v):
        if pd.isna(v):
            return True
        txt_val = str(v).strip()
        return (txt_val == "") or (txt_val == "[]") or (txt_val == "[ ]")
    if "guideline_tags" in df_top.columns:
        _src_series = None
        if "source_cbf_norm" in df_top.columns:
            _src_series = df_top["source_cbf_norm"].map(clean_source_text)
        elif "source_unified" in df_top.columns:
            _src_series = df_top["source_unified"].map(clean_source_text)
        if _src_series is not None:
            _mask = df_top["guideline_tags"].map(_needs_backfill)
            if _mask.any():
                _fid_series = df_top.get("feature_id", pd.Series([""] * len(df_top), index=df_top.index)).astype(str).str.strip().str.lower()
                df_top.loc[_mask, "guideline_tags"] = [
                    json.dumps(get_guideline_tags(_src_series.iloc[i], feature_id=_fid_series.iloc[i]), ensure_ascii=False)
                    for i in _mask[_mask].index
                ]

    # تأكيد وترتيب أعمدة الخرج النهائي (متوافق مع config.yaml → output_columns.hybrid)
    desired_cols = [
        "patient_id","feature_id","hybrid_score","rank_hybrid",
        "p_cf","p_cbf","weight_cf","weight_cbf","confidence",
        "sim_norm","bp_category","chol_category","risk_level",
        "reason_cf","reason_cbf","explanation_cf","explanation_cbf","explanation_clinical_cbf",
        "source_cf","source_cbf","status_cf","source_cbf_norm","source_unified",
        "hybrid_reason","hybrid_sources",
        # advice / interpretability fields produced by hybrid.py
        "clinical_flags","advice_text","advice_type","advice_source","guideline_tags",
        "conflict_flag","confidence_bucket","sim_bucket",
        # supervision
        "true_response","status",
    ]
    # compute confidence if missing: |p_cf - p_cbf|, only if both are present (do not mask with fillna(0))
    if "confidence" not in df_top.columns:
        p_cf_series  = pd.to_numeric(df_top.get("p_cf"), errors="coerce")
        p_cbf_series = pd.to_numeric(df_top.get("p_cbf"), errors="coerce")
        df_top["confidence"] = (p_cf_series - p_cbf_series).abs()
    # If unified source is missing (older hybrid.py), derive a minimal version here (normalized CBF tag)
    if "source_unified" not in df_top.columns:
        cf_status = df_top.get("status_cf", pd.Series([""] * len(df_top), index=df_top.index))
        src_cbf_norm = df_top.get("source_cbf_norm", pd.Series([""] * len(df_top), index=df_top.index))

        cf_status = _clean_series(cf_status)
        src_cbf_norm = _clean_series(src_cbf_norm)

        def _norm_cbf_tag(x: str) -> str:
            x = x.strip()
            # incoming examples: "CBF (kNN)", "CBF (fallback)", "CBF (exact/context match)"
            if x.startswith("CBF (") and x.endswith(")"):
                x = x[5:-1].strip()
            x = x.replace("CBF ", "").strip()
            return x

        tags = []
        for i in range(len(df_top)):
            t = []
            cf_tag = cf_status.iloc[i]
            if cf_tag in ("cold_start_safe_default", "collaborative_filtering"):
                t.append("(CF) " + cf_tag)
            cbf_tag = src_cbf_norm.iloc[i]
            if cbf_tag:
                t.append("(CBF) " + _norm_cbf_tag(cbf_tag))
            tags.append(" | ".join(t))
        df_top["source_unified"] = tags
    else:
        # even if present, ensure it's cleaned
        df_top["source_unified"] = _clean_series(df_top["source_unified"])
    for out_col in desired_cols:
        if out_col not in df_top.columns:
            df_top[out_col] = np.nan
    for _col in [
        "advice_text","advice_type","advice_source","guideline_tags",
        "conflict_flag","confidence_bucket","sim_bucket",
        "clinical_flags","source_unified",
    ]:
        if _col not in df_top.columns:
            df_top[_col] = pd.NA
    df_top["status"] = "ok"
    df_top = df_top[desired_cols].copy()

    # فلترة اختيارية: إزالة الصفوف التي لا تحتوي على مصدر موحّد ولا أي احتمال من CF/CBF
    try:
        before_rows = int(len(df_top))
        mask_src = df_top["source_unified"].astype(str).str.strip().ne("")
        p_cf_num = pd.to_numeric(df_top.get("p_cf"), errors="coerce").fillna(0)
        p_cbf_num = pd.to_numeric(df_top.get("p_cbf"), errors="coerce").fillna(0)
        mask_scores = (p_cf_num + p_cbf_num) > 0
        df_top = df_top[mask_src | mask_scores].copy()
        after_rows = int(len(df_top))
        removed = before_rows - after_rows
        if removed > 0:
            log.info("[HYB] Filtered rows with no provenance and zero scores: removed=%s (from %s to %s)", removed, before_rows, after_rows)
    except (TypeError, ValueError, KeyError, AttributeError) as ex:
        log.warning("[HYB] Filtering step skipped due to: %s", ex)



    # --- Canonicalize keys, propagate cbf_present from base, and finalize null-free outputs ---

    # Canonicalize keys on df_top
    if "patient_id" in df_top.columns:
        df_top["patient_id"] = _canon_pid(df_top["patient_id"])
    if "feature_id" in df_top.columns:
        df_top["feature_id"] = _canon_fid(df_top["feature_id"])

    # Propagate cbf_present from unified base (if available) using canonical keys
    if isinstance(df_hyb_base, pd.DataFrame) and all(c in df_hyb_base.columns for c in ["patient_id","feature_id","cbf_present"]):
        base_norm = df_hyb_base.copy()
        base_norm["patient_id"] = _canon_pid(base_norm["patient_id"])
        base_norm["feature_id"]  = _canon_fid(base_norm["feature_id"])
        df_top = df_top.merge(
            base_norm[["patient_id","feature_id","cbf_present"]].drop_duplicates(["patient_id","feature_id"]),
            on=["patient_id","feature_id"], how="left"
        )
        df_top["cbf_present"] = pd.to_numeric(df_top["cbf_present"], errors="coerce").fillna(0).astype(int)
    else:
        if "cbf_present" not in df_top.columns:
            df_top["cbf_present"] = 0

    # --- Canonical cbf_present derivation (pipeline-level guard) ---
    if "cbf_present" not in df_top.columns:
        df_top["cbf_present"] = 0

    p_cbf_series = pd.to_numeric(df_top.get("p_cbf", np.nan), errors="coerce").fillna(0.0)
    sim_series = pd.to_numeric(df_top.get("sim_norm", np.nan), errors="coerce").fillna(0.0)
    src_unified = df_top.get("source_unified", pd.Series("", index=df_top.index)).astype(str)

    # Build component masks explicitly to satisfy linters and improve clarity
    mask_cbf_prob = p_cbf_series.gt(0.02)
    mask_sim = sim_series.gt(0.0)
    mask_src = src_unified.str.contains(r"CBF\s*\(", regex=True, na=False)

    derived_cbf_present = (mask_cbf_prob | mask_sim | mask_src).astype(int)

    df_top["cbf_present"] = np.maximum(
        pd.to_numeric(df_top["cbf_present"], errors="coerce").fillna(0).astype(int),
        derived_cbf_present
    )

    # Finalize (null-free buckets/flags/sources) — نداء ديناميكي آمن
    try:
        _callable_finalize = callable(_finalize_hyb)  # type: ignore[name-defined]
    except NameError:
            _callable_finalize = False

    if _callable_finalize:
        df_top = _finalize_hyb(df_top, cfg)  # type: ignore[name-defined]

    # --- Clean up NaN advice_text before saving ---
    if "advice_text" in df_top.columns:
        df_top["advice_text"] = df_top["advice_text"].replace({np.nan: ""}).astype(str)
        df_top["advice_text"] = df_top["advice_text"].fillna("").str.strip()

    # --- Final guard: drop rows with empty advice_text (extremely rare after sanitizers) ---

    if "advice_text" in df_top.columns:
        _s = df_top["advice_text"].astype(str)
        _drop_mask = (
            _s.isna()
             | _s.str.strip().eq("")
             | _s.str.strip().str.lower().isin({"nan", "none", "null", "na", "n/a"})
        )
        _dropped = int(_drop_mask.sum())
        if _dropped > 0:
            log.info("[HYB][CLEAN] dropping %d rows with empty advice_text before export", _dropped)
            df_top = df_top.loc[~_drop_mask].copy()

    # --- Coverage diagnostics (after finalize; null-free) ---
    try:
        _pcf_diag = pd.to_numeric(df_top.get("p_cf"), errors="coerce")
        _pcb_diag = pd.to_numeric(df_top.get("p_cbf"), errors="coerce")
        _pcf_present = int(_pcf_diag.notna().sum())
        _pcf_nan = int(_pcf_diag.isna().sum())
        _pcb_present = int(_pcb_diag.notna().sum())
        _pcb_nan = int(_pcb_diag.isna().sum())
        log.info("[HYB][COV] p_cf — present=%d | NaN=%d ; p_cbf — present=%d | NaN=%d",
                 _pcf_present, _pcf_nan, _pcb_present, _pcb_nan)

        _hs_diag = df_top.get("hybrid_sources", pd.Series([""] * len(df_top), index=df_top.index)).astype(str)
        _has_cf_tag = _hs_diag.str.contains(r"\(CF\)", regex=True, na=False)
        _has_cbf_tag = _hs_diag.str.contains(r"CBF\s*\(", regex=True, na=False)

        _ct_cf = pd.crosstab(_has_cf_tag, _pcf_diag.notna(), dropna=False)
        _ct_cbf = pd.crosstab(_has_cbf_tag, _pcb_diag.notna(), dropna=False)

        log.info("[HYB][COV] crosstab (has CF tag) vs (p_cf present):\n%s", _ct_cf.to_string())
        log.info("[HYB][COV] crosstab (has CBF tag) vs (p_cbf present):\n%s", _ct_cbf.to_string())
    except (TypeError, ValueError, KeyError, AttributeError) as _cov_ex:
        log.debug("[HYB][COV] coverage diagnostics skipped: %s", _cov_ex)

    # حفظ
    out_main = os.path.join(args.out_dir, "df_hybrid_recommendations.csv")
    df_top.to_csv(out_main, index=False, encoding="utf-8-sig")
    log.info("\U0001F4BE Saved: %s (rows=%s, cols=%s)", out_main, len(df_top), len(df_top.columns))
    # Optional: lean export (only essentials for analysis)
    lean_cols = [
        "patient_id","feature_id","rank_hybrid","hybrid_score",
        "p_cf","p_cbf","confidence","sim_norm","confidence_bucket","sim_bucket",
        "advice_text","advice_type","advice_source","guideline_tags",
        "source_unified","true_response",
    ]

    lean_cols = [c for c in lean_cols if c in df_top.columns]
    try:
        _lean_path = os.path.join(args.out_dir, "df_hybrid_recommendations.min.csv")
        df_top[lean_cols].to_csv(_lean_path, index=False, encoding="utf-8")
        logger.info("Saved lean CSV with essential columns: %s", _lean_path)
    except (ValueError, OSError) as _e:
        logger.warning("Could not save lean CSV: %s", _e)

    # --- Write academic bridge CSV (CBF ↔ HYB) ---
    try:
        _write_hybrid_eval_bridge(
            df_top=df_top,
            cbf_raw_df=(df_cbf_raw if 'df_cbf_raw' in locals() else pd.DataFrame()),
            out_dir=args.out_dir,
            log=log
        )
    except Exception as _bridge_ex:
        log.warning("Bridge CSV step skipped: %s", _bridge_ex)

    # حفظ أوزان المجموعات (إن وُجدت)
    if args.use_group_weights and gw:
        _dump_json({"global": {"w_cf": wcf_g, "w_cbf": wcbf_g}, "per_group": gw},
                   os.path.join(args.out_dir, "hybrid_weights.json"), log)

    # تقييم اختياري: احتسب على الإطار قبل الفلترة/قبل TopK لتجنّب تشبّع R@K=1.0
    if isinstance(eval_base_df, pd.DataFrame):
        eval_base_labeled = _backfill_true_response(eval_base_df, [df_cf, df_cbf])
    else:
        eval_base_labeled = None

    # Guarded checks to satisfy static analyzers and avoid None attribute access
    has_labels_base = False
    if isinstance(eval_base_labeled, pd.DataFrame):
        eb_col = eval_base_labeled.get("true_response", None)
        if isinstance(eb_col, pd.Series):
            _eb_true = pd.to_numeric(eb_col, errors="coerce")
            has_labels_base = bool(_eb_true.notna().any())
        else:
            has_labels_base = False

    has_labels_top = False
    if isinstance(df_top, pd.DataFrame):
        top_col = df_top.get("true_response", None)
        if isinstance(top_col, pd.Series):
            _top_true = pd.to_numeric(top_col, errors="coerce")
            has_labels_top = bool(_top_true.notna().any())
        else:
            has_labels_top = False

    if has_labels_base:
        metrics_pre = precision_recall_ndcg_map_at_k(
            eval_base_labeled, k=args.topk, score_col="hybrid_score",
            group_col="patient_id", true_col="true_response"
        )
        # احسب أيضًا مؤشّرات ما بعد الفلترة للمقارنة إن توفرت
        metrics_post = None
        if has_labels_top:
            metrics_post = precision_recall_ndcg_map_at_k(
                df_top, k=args.topk, score_col="hybrid_score",
                group_col="patient_id", true_col="true_response"
            )
        # احفظ تقريرًا متوافقًا للخلف: المفاتيح الأساسية من القياس قبل الفلترة
        out_metrics = {
            "precision": metrics_pre.get("precision"),
            "recall": metrics_pre.get("recall"),
            "ndcg": metrics_pre.get("ndcg"),
            "map": metrics_pre.get("map"),
            "basis": "pre_filter_pre_topk",
        }
        if isinstance(metrics_post, dict):
            out_metrics.update({
                "precision_post": metrics_post.get("precision"),
                "recall_post": metrics_post.get("recall"),
                "ndcg_post": metrics_post.get("ndcg"),
                "map_post": metrics_post.get("map"),
            })
        _dump_json(out_metrics, os.path.join(args.out_dir, "hybrid_eval_summary.json"), log)
        log.info(
            "[EVAL][@%d][pre] P=%.4f | R=%.4f | nDCG=%.4f | MAP=%.4f",
            args.topk, out_metrics["precision"], out_metrics["recall"], out_metrics["ndcg"], out_metrics["map"]
        )
        if isinstance(metrics_post, dict):
            log.info(
                "[EVAL][@%d][post] P=%.4f | R=%.4f | nDCG=%.4f | MAP=%.4f",
                args.topk, metrics_post["precision"], metrics_post["recall"], metrics_post["ndcg"], metrics_post["map"]
            )
    elif has_labels_top:
        # fallback: نحسب على ما بعد الفلترة إذا لم يتوفر إطار قبل الفلترة (مثلاً في مسار e2e)
        metrics = precision_recall_ndcg_map_at_k(
            df_top, k=args.topk, score_col="hybrid_score",
            group_col="patient_id", true_col="true_response"
        )
        _dump_json(metrics, os.path.join(args.out_dir, "hybrid_eval_summary.json"), log)
        log.info("[EVAL][@%d] P=%.4f | R=%.4f | nDCG=%.4f | MAP=%.4f",
                 args.topk, metrics["precision"], metrics["recall"], metrics["ndcg"], metrics["map"])
    else:
        log.info("[EVAL] No true_response present; skipped @K computation.")

    # -------- Quality Report --------
    try:
        conf_series = pd.to_numeric(df_top.get("confidence", np.nan), errors="coerce")
        has_label = ("true_response" in df_top.columns) and df_top["true_response"].notna().any()
        top_features = (df_top.groupby("feature_id")["hybrid_score"].mean()
                        .sort_values(ascending=False).head(10).index.tolist()) if "feature_id" in df_top.columns else []
        quality = {
            "rows": int(len(df_top)),
            "unique_patients": int(df_top["patient_id"].nunique()) if "patient_id" in df_top.columns else 0,
            "avg_hybrid_score": float(pd.to_numeric(df_top["hybrid_score"], errors="coerce").mean()) if "hybrid_score" in df_top.columns else None,
            "avg_confidence": float(pd.to_numeric(df_top["confidence"], errors="coerce").mean()) if "confidence" in df_top.columns else None,
            "pct_confidence_ge_0_2": float((conf_series >= 0.2).mean()) if conf_series.notna().any() else None,
            "label_available": bool(has_label),
            "label_positive_rate": (float(pd.to_numeric(df_top["true_response"], errors="coerce").mean()) if has_label else None),
            "top_features_by_avg_score": top_features,
        }
        # enrich quality report with advice/glossary stats (if present)
        try:
            # advice type counts
            if "advice_type" in df_top.columns:
                counts = df_top["advice_type"].fillna("").astype(str).value_counts().to_dict()
                quality["advice_type_counts"] = {k: int(v) for k, v in counts.items()}
            # conflict rate
            if "conflict_flag" in df_top.columns:
                cf_series = df_top["conflict_flag"]
                if cf_series.dtype != bool:
                    cf_series = cf_series.astype(str).str.lower().isin(["true", "1", "yes"])
                quality["conflict_rate"] = float(cf_series.mean())
            # guideline tag coverage
            tag_counts: dict[str, int] = {}
            if "guideline_tags" in df_top.columns:
                def _parse_tags(x_val):
                    if pd.isna(x_val):
                        return []
                    txt_val = str(x_val).strip()
                    if txt_val.startswith("[") and txt_val.endswith("]"):
                        try:
                            parsed = json.loads(txt_val)
                            return [str(item).strip() for item in parsed if item]
                        except (json.JSONDecodeError, ValueError, TypeError):
                            pass
                    for sep_char in ("|", ";", ","):
                        if sep_char in txt_val:
                            return [part.strip() for part in txt_val.split(sep_char) if part.strip()]
                    return [txt_val] if txt_val else []
                for tag_list in df_top["guideline_tags"].map(_parse_tags):
                    for gtag in tag_list:
                        tag_counts[gtag] = tag_counts.get(gtag, 0) + 1
            if tag_counts:
                quality["guideline_tag_counts"] = {k: int(v) for k, v in tag_counts.items()}
            # confidence & similarity bucket distributions
            if "confidence_bucket" in df_top.columns:
                quality["confidence_bucket_counts"] = {k: int(v) for k, v in df_top["confidence_bucket"].fillna("na").astype(str).value_counts().to_dict().items()}
            if "sim_bucket" in df_top.columns:
                quality["sim_bucket_counts"] = {k: int(v) for k, v in df_top["sim_bucket"].fillna("na").astype(str).value_counts().to_dict().items()}
            # top-10 provenance sources (source_unified preferred, then hybrid_sources)
            prov_col = "source_unified" if "source_unified" in df_top.columns else ("hybrid_sources" if "hybrid_sources" in df_top.columns else None)
            if prov_col:
                prov_counts = df_top[prov_col].fillna("").astype(str).value_counts().head(10).to_dict()
                quality["top_provenance_sources"] = {k: int(v) for k, v in prov_counts.items()}
        except (TypeError, ValueError, KeyError, AttributeError) as _ex:
            log.debug("Quality enrichment skipped: %s", _ex)
        _dump_json(quality, os.path.join(args.out_dir, "hybrid_quality_report.json"), log)
    except (OSError, TypeError, ValueError) as ex:
        log.warning("Failed to write quality report: %s", ex)

    # =========== Optional: per-group comparison metrics & plots ===========
    if getattr(args, "make_plots", False):
        plots_dir = os.path.join(args.out_dir, "plots")
        _ensure_dir(plots_dir)

        def _ensure_group_context(df_src: pd.DataFrame, ctx: Optional[pd.DataFrame], cfg_obj: HybridConfig) -> pd.DataFrame:
            d = df_src.copy()
            need_cols = [cfg_obj.bp_col, cfg_obj.chol_col]
            have_all = all(cname in d.columns for cname in need_cols)
            if not have_all and ctx is not None and "patient_id" in d.columns and "patient_id" in ctx.columns:
                ctx_keep = ["patient_id"] + [cname for cname in need_cols if cname in ctx.columns]
                d = d.merge(ctx[ctx_keep].drop_duplicates("patient_id"), on="patient_id", how="left")
            return d

        def _group_key(d: pd.DataFrame, cfg_obj: HybridConfig) -> pd.Series:
            cols = [cname for cname in [cfg_obj.bp_col, cfg_obj.chol_col] if cname in d.columns]
            if not cols:
                return pd.Series(["__ALL__"] * len(d), index=d.index)
            return d[cols].astype(str).agg("+".join, axis=1)

        def _metrics_by_group(df_src: Optional[pd.DataFrame], score_col_name: str, label: str, k_param: int, ctx: Optional[pd.DataFrame], cfg_obj: HybridConfig) -> pd.DataFrame:
            if df_src is None or df_src.empty or score_col_name not in df_src.columns:
                return pd.DataFrame(columns=["method","group","n","positives","precision","recall","ndcg","map"])
            d = _ensure_group_context(df_src, ctx, cfg_obj).copy()
            if "patient_id" not in d.columns or "feature_id" not in d.columns:
                return pd.DataFrame(columns=["method","group","n","positives","precision","recall","ndcg","map"])

            # normalize types
            d[score_col_name] = pd.to_numeric(d[score_col_name], errors="coerce")
            if "true_response" in d.columns:
                d["true_response"] = pd.to_numeric(d["true_response"], errors="coerce").fillna(0).astype(int)
            else:
                d["true_response"] = 0

            d["__g__"] = _group_key(d, cfg_obj)
            d = d.sort_values(["patient_id", score_col_name], ascending=[True, False])
            d["rank"] = d.groupby("patient_id").cumcount() + 1
            topk = d[d["rank"] <= k_param].copy()

            # precision@k (per patient then average) within each group key
            def _agg_group(gdf: pd.DataFrame) -> pd.Series:
                grp_pat = gdf.groupby("patient_id")["true_response"].agg(["mean","sum"])
                prec = float(grp_pat["mean"].mean()) if not grp_pat.empty else float("nan")
                tot_pos = d.loc[d["__g__"] == gdf["__g__"].iloc[0]].groupby("patient_id")["true_response"].sum().replace(0, np.nan)
                rec = float((gdf.groupby("patient_id")["true_response"].sum() / tot_pos).mean())

                # nDCG
                gdf = gdf.copy()
                gdf["dcg"] = gdf["true_response"] / np.log2(gdf["rank"] + 1)
                dcg = gdf.groupby("patient_id")["dcg"].sum()
                ideal = (
                    d.loc[d["__g__"] == gdf["__g__"].iloc[0]]
                     .sort_values(["patient_id","true_response"], ascending=[True, False])
                     .groupby("patient_id").head(k_param)
                     .assign(rank=lambda x: x.groupby("patient_id").cumcount() + 1)
                )
                ideal["dcg"] = ideal["true_response"] / np.log2(ideal["rank"] + 1)
                idcg = ideal.groupby("patient_id")["dcg"].sum().replace(0, np.nan)
                ndcg = float((dcg / idcg).mean())

                # MAP@k
                ap_vals = []
                for _, gg in gdf.groupby("patient_id"):
                    gg = gg.sort_values("rank")
                    cpos = gg["true_response"].cumsum()
                    prec_at_i = (cpos / gg["rank"])[gg["true_response"] == 1]
                    ap_vals.append(float(prec_at_i.mean()) if not prec_at_i.empty else 0.0)
                mapk = float(np.mean(ap_vals)) if len(ap_vals) > 0 else float("nan")

                n_rows = int(len(gdf))
                positives = int(gdf["true_response"].sum())
                return pd.Series({"n": n_rows, "positives": positives, "precision": prec, "recall": rec, "ndcg": ndcg, "map": mapk})

            res = topk.groupby("__g__").apply(_agg_group).reset_index().rename(columns={"__g__":"group"})
            res.insert(0, "method", label)
            return res

        # collect metrics
        top_k = int(args.topk)
        df_cf_src = df_cf if df_cf is not None else pd.DataFrame()
        df_cbf_src = df_cbf if df_cbf is not None else pd.DataFrame()
        df_hyb_src = df_top.copy()

        metrics_cf  = _metrics_by_group(df_cf_src,  "score_cf",    "CF",     top_k, df_ctx, cfg)
        metrics_cbf = _metrics_by_group(df_cbf_src, "score_cbf",   "CBF",    top_k, df_ctx, cfg)
        metrics_hyb = _metrics_by_group(df_hyb_src, "hybrid_score","Hybrid", top_k, df_ctx, cfg)

        metrics_all = pd.concat([metrics_cf, metrics_cbf, metrics_hyb], ignore_index=True, sort=False)
        csv_path = os.path.join(plots_dir, "hybrid_group_metrics.csv")
        metrics_all.to_csv(csv_path, index=False, encoding="utf-8-sig")
        log.info("Saved per-group metrics CSV: %s", csv_path)

        # pick top-10 groups by sample size (sum of n across methods)
        size_by_group = metrics_all.groupby("group")["n"].sum().sort_values(ascending=False)
        top_groups = size_by_group.head(10).index.tolist()

        # Pivot for plotting nDCG comparison across methods
        m_ndcg = (metrics_all.pivot_table(index="group", columns="method", values="ndcg", aggfunc="mean")
                             .reindex(size_by_group.index))
        # full plot
        plt.figure(figsize=(10, 6))
        m_ndcg.plot(kind="bar")
        plt.title(f"nDCG@{top_k} by group (CF vs CBF vs Hybrid)")
        plt.ylabel("nDCG")
        plt.xlabel("group (bp+chol)")
        plt.xticks(rotation=45, ha="right")
        plt.tight_layout()
        full_png = os.path.join(plots_dir, "metrics_by_group.png")
        plt.savefig(full_png, dpi=150)
        plt.close()
        log.info("Saved plot: %s", full_png)

        # top-10 plot
        if top_groups:
            m_top = m_ndcg.loc[top_groups]
            plt.figure(figsize=(10, 6))
            m_top.plot(kind="bar")
            plt.title(f"Top-10 groups by size — nDCG@{top_k} (CF vs CBF vs Hybrid)")
            plt.ylabel("nDCG")
            plt.xlabel("group (bp+chol)")
            plt.xticks(rotation=45, ha="right")
            plt.tight_layout()
            top_png = os.path.join(plots_dir, "metrics_by_group_top10.png")
            plt.savefig(top_png, dpi=150)
            plt.close()
            log.info("Saved plot: %s", top_png)

    log.info("✅ HYBRID pipeline finished successfully.")

    # --- Diagnostic log: cbf_present and CBF source ---
    if 'df_top' in locals() and isinstance(df_top, pd.DataFrame) and not df_top.empty:
        try:
            cbf_series = pd.to_numeric(
                df_top.get("cbf_present", pd.Series([0] * len(df_top))),
                errors="coerce"
            ).fillna(0)
            cbf_series = cbf_series.astype(int)
            n_present = int((cbf_series == 1).sum())
            n_absent = int(len(df_top) - n_present)
            src_name = cbf_input_source if 'cbf_input_source' in locals() else 'full'
            score_field = cbf_score_field if 'cbf_score_field' in locals() else 'score_cbf'
            log.info(
                "[HYB] Using CBF source='%s' score_field='%s' | cbf_present: yes=%d no=%d",
                src_name, score_field, n_present, n_absent
            )
        except (TypeError, ValueError, AttributeError, KeyError) as _diag_ex:
            log.debug("[HYB] Diagnostic log skipped: %s", _diag_ex)
        try:
            if "p_cbf" in df_top.columns:
                _pcbf_top = pd.to_numeric(df_top["p_cbf"], errors="coerce")
                log.info("[HYB][DBG] p_cbf stats in TOP — n: %d | nan: %d | ==0: %d | >0: %d",
                         int(_pcbf_top.shape[0]), int(_pcbf_top.isna().sum()),
                         int((_pcbf_top.fillna(0)==0).sum()),
                         int((_pcbf_top.fillna(0)>0).sum()))
        except (TypeError, ValueError, KeyError, AttributeError) as _diag_ex:
            log.debug("[HYB] p_cbf TOP stats diagnostic skipped: %s", _diag_ex)

if __name__ == "__main__":
    main()

