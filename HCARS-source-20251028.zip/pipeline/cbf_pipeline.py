
import pandas as pd
from pandas.api.types import CategoricalDtype
import yaml
import logging
import os
import gc
from pandas.errors import MergeError

from utils.constants import (
    RECOMMENDATION_EXPLAIN,
    RECOMMENDATION_SOURCE,
    ADVICE_MAP as _ADVICE_MAP,
    canonicalize_feature_id as _canonicalize_feature_id,# type: ignore
)

# --- Strict evaluation mode imports (LOCO / GroupKFold)
from utils.context_utils import make_core_context_key, assert_no_many_to_many
try:
    from sklearn.model_selection import GroupKFold
except ImportError:  # sklearn may be optional in some builds
    GroupKFold = None  # type: ignore

# --------- حماية feature_id من القيم الرقمية ---------
from utils.constants import CONTEXT_COLUMNS, SECONDARY_CONTEXT_COLUMNS
# Ensure unified CBF scoring is available
try:
    from recommender.cbf import ensure_cbf_scores
except ImportError:
    # Fallback if package layout differs
    from cbf import ensure_cbf_scores  # type: ignore

# Ensure family/context utilities are available early (to avoid NameError in _ensure_eval_ready)
try:
    from utils.context_utils import ensure_feature_id_binned_and_context
except ImportError:
    # Safe no-op fallback; returns the input DataFrame unchanged if the module path differs during local runs
    def ensure_feature_id_binned_and_context(df_in, *args, **kwargs):
        # touch args/kwargs to silence "unused parameters" linters without affecting behavior
        if args or kwargs:
            _ = (args, kwargs)
        return df_in

from utils.constants import get_cbf_scoring_policy
from pipeline.helperscbf import apply_cbf_narratives, apply_isotonic_if_available, fit_and_save_isotonic
# --- One-time mix policy logger and similarity injector (single definition) ---
import logging as _logging_mod
# Initialize module logger early to avoid 'Name "logger" can be undefined' warnings.
logger = _logging_mod.getLogger("cbf_pipeline")

_MIX_POLICY_LOGGED = False  # module-scope guard

def _log_mix_policy_once(cfg, logger_obj=logger):
    global _MIX_POLICY_LOGGED
    # Read centralized policy
    try:
        from utils.constants import get_cbf_scoring_policy as _gpol
        _, __, mix = _gpol(cfg)  # (score_map, accept_threshold, mix_cfg)
    except (ImportError, KeyError, TypeError, AttributeError, ValueError) as exc:
        logger_obj.warning("[CBF][INIT] Failed to read scoring policy; using safe defaults. %s", exc)
        mix = {
            "w_similarity": 0.75,
            "w_reason": 0.25,
            "sim_clip_min": 0.0,
            "sim_clip_max": 0.98,
            "exact_match_cap": 0.98,
            "post_calibration": "minmax",
            "epsilon_jitter": 1.0e-6,
            "prior_mod_base": 0.30,
            "prior_mod_gain": 0.70,
        }
    # Rescale weights to sum to 1.0 if necessary
    try:
        w_sim = float(mix.get("w_similarity", 0.75))
        w_reason = float(mix.get("w_reason", 0.25))
        sum_w = w_sim + w_reason
        if sum_w <= 0:
            w_sim, w_reason = 0.75, 0.25
            sum_w = 1.0
        if abs(sum_w - 1.0) > 1e-6:
            w_sim, w_reason = w_sim / sum_w, w_reason / sum_w
            mix["w_similarity"], mix["w_reason"] = w_sim, w_reason
            logger_obj.warning(
                "[CBF][INIT] Rescaled mix weights to sum=1.0 → w_similarity=%.3f, w_reason=%.3f",
                w_sim, w_reason
            )
    except (TypeError, ValueError):
        pass

    exact_cap = float(mix.get("exact_match_cap", 0.98))
    if not _MIX_POLICY_LOGGED:
        _MIX_POLICY_LOGGED = True
        dump = {k: (round(v, 6) if isinstance(v, (int, float)) else v) for k, v in mix.items()}
        logger_obj.info("[CBF][INIT] mix_cfg=%s | exact_match_cap=%.3f", dump, exact_cap)
    return exact_cap, mix


def _inject_sim_cbf_raw(df_in, cfg):
    if not isinstance(df_in, pd.DataFrame):
        return df_in
    df_local = df_in.copy()
    if "sim_cbf_raw" not in df_local.columns:
        df_local["sim_cbf_raw"] = pd.NA

    try:
        exact_cap, _mix_local = _log_mix_policy_once(cfg, logger_obj=logger)
    except (KeyError, TypeError, AttributeError, ValueError):
        exact_cap = 0.98

    # Numeric similarity capture if present
    if "similarity" in df_local.columns:
        df_local["sim_cbf_raw"] = df_local["sim_cbf_raw"].fillna(
            pd.to_numeric(df_local["similarity"], errors="coerce")
        )

    # Exact-match capping
    if "reason" in df_local.columns:
        _exact_mask = df_local["reason"].astype(str).isin({"recommended", "context_key_match"})
        # set cap if missing
        df_local.loc[_exact_mask & df_local["sim_cbf_raw"].isna(), "sim_cbf_raw"] = float(exact_cap)
        # Safely cap exact-match similarity even if duplicate 'sim_cbf_raw' columns exist
        _masked_df = df_local.loc[_exact_mask, ["sim_cbf_raw"]]  # always a DataFrame
        _masked_series = _masked_df.iloc[:, 0]  # take the first occurrence as a Series
        _masked_series = pd.to_numeric(_masked_series, errors="coerce").clip(upper=float(exact_cap))
        df_local.loc[_exact_mask, "sim_cbf_raw"] = _masked_series.values

    # Final clip and fill
    try:
        sim_min = float((cfg or {}).get("model_settings", {}).get("scoring", {}).get("cbf_mix", {}).get("sim_clip_min", 0.0))
        sim_max = float((cfg or {}).get("model_settings", {}).get("scoring", {}).get("cbf_mix", {}).get("sim_clip_max", 1.0))
    except (KeyError, TypeError, AttributeError, ValueError):
        sim_min, sim_max = 0.0, 1.0

    df_local["sim_cbf_raw"] = pd.to_numeric(df_local["sim_cbf_raw"], errors="coerce").fillna(0.0).clip(lower=sim_min, upper=sim_max)
    return df_local

# -- حقن explanation و source من القواميس المركزية إن كانت فارغة --
def _fill_algo_explain_and_source(_df):
    if not isinstance(_df, pd.DataFrame) or _df.empty:
        return _df
    # تجهيز series للـ map (بعد canonicalize + lowercase)
    _fid = _df.get("feature_id")
    if _fid is None:
        return _df
    _fid_canon = _fid.map(_canonicalize_feature_id).fillna(_fid)
    _fid_canon = _fid_canon.astype(str).str.strip().str.lower()

    # explanation — املأ فقط الفراغ
    if "explanation" in _df.columns:
        _mask_expl = _df["explanation"].astype(str).str.strip().eq("") | _df["explanation"].isna()
        if _mask_expl.any():
            _df.loc[_mask_expl, "explanation"] = (
                _fid_canon[_mask_expl].map(RECOMMENDATION_EXPLAIN).fillna(_df.loc[_mask_expl, "explanation"])
            )

    # source — املأ فقط الفراغ
    if "source" in _df.columns:
        _mask_src = _df["source"].astype(str).str.strip().eq("") | _df["source"].isna()
        if _mask_src.any():
            _df.loc[_mask_src, "source"] = (
                _fid_canon[_mask_src].map(RECOMMENDATION_SOURCE).fillna("CBF (policy)")
            )
    return _df


# -- تقوية fallback لعمود النصيحة advice لمنع (null) --
def _fill_advice_fallbacks(_df):
    if not isinstance(_df, pd.DataFrame) or _df.empty or "advice" not in _df.columns:
        return _df
    _mask_adv_local = _df["advice"].astype(str).str.strip().eq("") | _df["advice"].isna()
    if not _mask_adv_local.any():
        return _df

    _fid_canon = _df.loc[_mask_adv_local, "feature_id"].map(_canonicalize_feature_id).fillna(_df.loc[_mask_adv_local, "feature_id"])
    _fid_canon = _fid_canon.astype(str).str.strip().str.lower()

    # أولوية 1: خرائطك الأربع (الموثقة في constants)
    _df.loc[_mask_adv_local, "advice"] = _fid_canon.map(_ADVICE_MAP).fillna(_df.loc[_mask_adv_local, "advice"])

    # أولوية 2: قواعد عامة — دوائي vs نمط حياة vs غير ذلك
    _still = _df["advice"].astype(str).str.strip().eq("") | _df["advice"].isna()
    if _still.any():
        pharm = {"ace_inhibitor", "amlodipine", "beta_blocker", "thiazide_diuretic", "amlodipine_and_thiazide", "statin"}
        lifestyle = {"diet_control", "low_sodium_diet", "increase_exercise", "lifestyle_monitoring"}

        _fid_now = _df.loc[_still, "feature_id"].astype(str).str.lower()
        _df.loc[_still & _fid_now.isin(lifestyle), "advice"] = (
            "إجراءات نمط حياة أولًا مع متابعة ضغط الدم والدهون دوريًا."
        )
        _df.loc[_still & _fid_now.isin(pharm), "advice"] = (
            "مناقشة ملاءمة العلاج الدوائي وفق الإرشادات والمتابعة اللصيقة للضغط والأعراض."
        )
        # الباقي — افتراضي آمن
        _still2 = _df["advice"].astype(str).str.strip().eq("") | _df["advice"].isna()
        _df.loc[_still2, "advice"] = "اتّبع الإرشادات السريرية المناسبة للحالة مع متابعة القياسات."
    return _df

import numpy as np
# === Ensure similarity audit columns in FINAL export ===
def _ensure_similarity_audit_cols(_df, _cfg=None):
    """
    تضمن وجود الأعمدة:
    - sim_cbf_raw
    - similarity
    - sim_norm  (تطبيع min–max حسب scoring.cbf_mix إن وُجد)
    - max_similarity (أقصى تشابه لكل مريض إن توفر patient_id؛ وإلا عالمي)
    """
    if not isinstance(_df, pd.DataFrame) or _df.empty:
        return _df

    # 1) الربط بين sim_cbf_raw و similarity إن كان أحدهما مفقود
    if "sim_cbf_raw" not in _df.columns and "similarity" in _df.columns:
        _df["sim_cbf_raw"] = pd.to_numeric(_df["similarity"], errors="coerce")
    if "similarity" not in _df.columns and "sim_cbf_raw" in _df.columns:
        _df["similarity"] = pd.to_numeric(_df["sim_cbf_raw"], errors="coerce")

    # 2) sim_norm من min-max في config.scoring.cbf_mix وإلا [0,1]
    if "sim_norm" not in _df.columns:
        try:
            _scoring_cfg = ((_cfg or {}).get("scoring") or {})
            _mix = (_scoring_cfg.get("cbf_mix") or {})
            _sim_min = float(_mix.get("sim_clip_min", 0.0))
            _sim_max = float(_mix.get("sim_clip_max", 1.0))
        except (TypeError, ValueError, AttributeError, KeyError):
            _sim_min, _sim_max = 0.0, 1.0
        _x = pd.to_numeric(_df.get("similarity", _df.get("sim_cbf_raw", 0.0)),
                           errors="coerce").fillna(_sim_min)
        _rng = (_sim_max - _sim_min) if (_sim_max > _sim_min + 1e-12) else 1.0
        _df["sim_norm"] = (_x.clip(_sim_min, _sim_max) - _sim_min) / _rng

    # 3) max_similarity: أقصى تشابه لكل مريض إن توفر، وإلا عالمي
    if "max_similarity" not in _df.columns:
        try:
            if "patient_id" in _df.columns:
                _df["max_similarity"] = _df.groupby("patient_id")["similarity"] \
                    .transform(lambda s: pd.to_numeric(s, errors="coerce").max())
            else:
                _df["max_similarity"] = float(pd.to_numeric(_df["similarity"], errors="coerce").max())
        except (TypeError, ValueError, KeyError, AttributeError):
            _df["max_similarity"] = np.nan
    return _df

from utils.constants import FEATURE_ID_ALLOWED as ALLOWED_FEATURE_IDS
# --- Strict evaluation (LOCO / GroupKFold) will be wired below based on config["evaluation"]

def sanitize_feature_id(val):
    if val in ALLOWED_FEATURE_IDS:
        return val
    if val == 0 or val == '0':
        return "manual_review"
    if val == 1 or val == '1':
        return "manual_review"
    # دعم أي قيم غير متوقعة بإرجاع manual_review
    return "manual_review"

# --------- Coverage Reporting Function ---------
def report_coverage(df_input, context_columns, local_logger=None):
    n_unique = df_input[context_columns].drop_duplicates().shape[0]
    if local_logger:
        local_logger.info(f"[COVERAGE] عدد التركيبات السياقية الفريدة: {n_unique}")
    else:
        print(f"[COVERAGE] عدد التركيبات السياقية الفريدة: {n_unique}")

from pipeline.helperscbf import recommend_by_similarity
from pipeline.helperscbf import resolve_true_response_conflict
from pipeline.helperscbf import normalize_context_value
from pipeline.helperscbf import (
    encode_context_features_cbf,
    aggregate_contextual_groupings,
    check_context_coverage,
    log_contextual_stats,
    export_uncovered_context_keys,
    make_context_key,
)
from pipeline.helperscbf import cbf_split_data, hide_sensitive_columns
from recommender.cbf import CBFRecommender

# Try to import finalize_feature_id to convert manual_review using contextual fallbacks
try:
    from recommender.cbf import finalize_feature_id  # type: ignore
except (ImportError, AttributeError):
    # Optional hook: finalize_feature_id may not exist in some builds; fall back gracefully.
    finalize_feature_id = None  # type: ignore

# --- Flexible contextual recommendation imports ---
from pipeline.helperscbf import find_best_contextual_recommendation


# ---------- Logger Setup ----------
logger = logging.getLogger("cbf_pipeline")
os.makedirs("logs", exist_ok=True)
if not logger.handlers:
    # Try to load pipeline log path from config; fallback to default
    _log_path = "logs/cbf_pipeline.log"
    try:
        with open("pipeline/config.yaml", "r", encoding="utf-8") as _f:
            _cfg_tmp = yaml.safe_load(_f) or {}
            _log_path = _cfg_tmp.get("logging", {}).get("cbf_pipeline_log_path", _log_path)
    except (OSError, yaml.YAMLError, ValueError, TypeError):
        pass
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler(_log_path)
    fh.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    fh.setFormatter(formatter)
    logger.addHandler(fh)

# --- Global model fit cache to avoid undefined errors ---
_CBF_FIT_CACHE: dict = {}

# Memory helpers
def _downcast_context_cats(df_in: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    for c in cols:
        if c in df_in.columns:
            try:
                if not isinstance(df_in[c].dtype, CategoricalDtype):
                    df_in[c] = df_in[c].astype("category")
            except (TypeError, ValueError):
                pass
    return df_in

def _safe_normalize_context_cols_inplace(df_in: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    for col in cols:
        if col in df_in.columns:
            col_series = df_in[col]
            try:
                # Ensure destination column is 'string' dtype before assignment to avoid incompatible dtype setitem
                col_series = col_series.astype("string")
            except (TypeError, ValueError):
                col_series = col_series.astype(object).astype("string")
            # Map normalization and keep as pandas 'string' dtype
            normalized = col_series.map(normalize_context_value).astype("string")
            df_in[col] = normalized
    return df_in

# ---------- Ensure output directory exists ----------
os.makedirs("outputs/CBF", exist_ok=True)
# ---- Pipeline control flag (avoid mid-file sys.exit to prevent unreachable-code warnings)
proceed_pipeline = True
# Safe pre-initialization to avoid "undefined" warnings in static analyzers
recommendations_final = None  # type: ignore[assignment]
# --- Helpers to avoid ambiguous Series truth checks and duplicated true_response columns ---
from typing import Tuple, Optional, List

def _canonicalize_true_response(df_in: pd.DataFrame) -> Tuple[Optional[pd.Series], List[str]]:
    tr_cols = [c for c in df_in.columns if (c == "true_response") or c.startswith("true_response")]
    if not tr_cols:
        return None, []
    if len(tr_cols) == 1:
        tr_series = df_in[tr_cols[0]]
        if isinstance(tr_series, pd.DataFrame):  # guard if a DataFrame slipped in
            tr_series = tr_series.iloc[:, 0]
        return tr_series, tr_cols
    tr_series = df_in[tr_cols].bfill(axis=1).iloc[:, 0]
    return tr_series, tr_cols

def _drop_merge_suffix_cols(df_in: pd.DataFrame) -> pd.DataFrame:
    preserve = {"reason", "explanation", "advice", "source", "explanation_clinical"}
    cols_to_drop = []
    for c in df_in.columns:
        if c.endswith(("_test", "_byfid", "_x", "_y")):
            # do not drop narrative base columns
            base = c[:-2] if c.endswith(("_x","_y")) else c.rsplit("_", 1)[0]
            if base in preserve:
                continue
            cols_to_drop.append(c)
    if cols_to_drop:
        return df_in.drop(columns=list(dict.fromkeys(cols_to_drop)), errors="ignore")
    return df_in

from typing import Optional
def _ensure_eval_ready(df_in: Optional[pd.DataFrame], cfg: Optional[dict] = None) -> pd.DataFrame:
    if not isinstance(df_in, pd.DataFrame):
        # Return empty DataFrame to satisfy downstream type expectations
        return pd.DataFrame()

    df_out = df_in.copy()

    # Ensure patient_id exists
    if "patient_id" not in df_out.columns:
        try:
            df_out["patient_id"] = df_out.index.astype(str)
        except (AttributeError, TypeError, ValueError):
            df_out["patient_id"] = "unknown"

    # Build family/context columns with optional cfg
    try:
        # Prefer callable that accepts cfg keyword if available
        try:
            df_out = ensure_feature_id_binned_and_context(df_out, cfg=cfg)  # type: ignore[call-arg]
        except TypeError:
            # Backward-compatible signature without cfg
            df_out = ensure_feature_id_binned_and_context(df_out)  # type: ignore[misc]
    except (TypeError, ValueError, KeyError) as _ctx_prep_err:
        logger.warning("[CBF][EVAL_READY] ensure_feature_id_binned_and_context failed non-fatally: %s", _ctx_prep_err)

    # Mark cfg as used to appease static analyzers in paths where it's not consumed
    _ = cfg

    return df_out

# ---------- Config Loader ----------
def load_config(path: str = "pipeline/config.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as config_file:
        return yaml.safe_load(config_file)

config = load_config()
cbf_config = config.get("model_settings", {}).get("cbf", {})
data_path = config["data_paths"]["hypertension"]
output_path = config.get("hybrid_paths", {}).get("cbf_recommendations", "outputs/CBF/df_cbf_recommendations.csv")
cbf_output_columns = config["output_columns"]["cbf"]
feature_columns = cbf_config.get("features", ["age", "chol_flag", "risk_score", "age_group"])
context_cols = CONTEXT_COLUMNS
top_n = config["recommendation"].get("top_n_for_evaluation", 5)
min_context_freq = 1  # لا يتم دمج أو حذف أي مجموعة نادرة افتراضيًا

# --- Debug / heavy artifacts export flag (config-driven) ---
debug_cfg = (config.get("debug", {}) or {}) if isinstance(config, dict) else {}
export_heavy = bool(debug_cfg.get("export_heavy_artifacts", False))

# Backward-compat: وحّدنا الفلاج القديم على السويتش الجديد
_EXPORT_AUDIT_ARTIFACTS = export_heavy

def _maybe_export_heavy_csv(df_obj, path: str, label: str = "heavy_artifact"):
    import os
    if not export_heavy:
        logger.debug("[DEBUG] Heavy artifact export disabled: %s", os.path.basename(path))
        return
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        df_obj.to_csv(path, index=False, encoding="utf-8-sig")
        logger.info("🗂️ Exported heavy artifact: %s", path)
    except (OSError, ValueError) as exc_heavy_export:
        logger.warning("[DEBUG] Failed to export %s (%s): %s", label, path, exc_heavy_export)

_DEBUG_FLAGS = (config.get("debug", {}) if isinstance(config, dict) else {}) or {}
_EXPORT_AUDIT_ARTIFACTS = bool(_DEBUG_FLAGS.get("export_audit_artifacts", False))

try:
    _score_map, _thr, _mix_cfg = get_cbf_scoring_policy(config)
    _EXACT_CAP = float(_mix_cfg.get("exact_match_cap", 0.98))
except (KeyError, TypeError, ValueError) as _err:
    logger.warning("[CBF][CONFIG] Falling back to default exact_match_cap due to: %s", _err)
    _EXACT_CAP = 0.98

# --------- Consistency check with config (do not override imported constants) ---------
_cfg_ctx = config.get("contextual_columns")
_cfg_sec = config.get("secondary_contextual_columns")
if isinstance(_cfg_ctx, list) and [str(x) for x in _cfg_ctx] != [str(x) for x in CONTEXT_COLUMNS]:
    logger.warning("[CBF] contextual_columns in config differ from utils.constants.CONTEXT_COLUMNS. Using constants and continuing. config=%s constants=%s", _cfg_ctx, list(CONTEXT_COLUMNS))
if isinstance(_cfg_sec, list) and [str(x) for x in _cfg_sec] != [str(x) for x in SECONDARY_CONTEXT_COLUMNS]:
    logger.warning("[CBF] secondary_contextual_columns in config differ from utils.constants.SECONDARY_CONTEXT_COLUMNS. Using constants and continuing. config=%s constants=%s", _cfg_sec, list(SECONDARY_CONTEXT_COLUMNS))

# --------- Log contextual columns for audit ---------
logger.info(f"[CBF] الأعمدة السياقية الأساسية: {CONTEXT_COLUMNS}")
logger.info(f"[CBF] الأعمدة السياقية الثانوية: {SECONDARY_CONTEXT_COLUMNS}")

# ---------- 1. Load Data ----------
logger.info(f"📊 Loading data from: {data_path}")
df = pd.read_csv(data_path)
# ----------- تطبيع الأعمدة السياقية مباشرة بعد قراءة البيانات -----------
_safe_normalize_context_cols_inplace(df, CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS)
_downcast_context_cats(df, CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS)

# ----------- كشف وتصدير التكرارات السياقية قبل أي معالجة -----------
# 1. كشف التكرار على CONTEXT_COLUMNS فقط (للتدقيق فقط)
full_cols = CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS
df_dups_primary = df[df.duplicated(subset=CONTEXT_COLUMNS, keep=False)]
if not df_dups_primary.empty:
    if export_heavy:
        _maybe_export_heavy_csv(
            df_dups_primary,
            "outputs/CBF/duplicated_context_groups_primary.csv",
            "duplicated_context_groups_primary"
        )
        logger.warning(
            f"[CBF] (encoded/raw) تم العثور على {len(df_dups_primary)} صف مكرر بناءً على CONTEXT_COLUMNS. (export_heavy=True)")
    else:
        logger.debug("[DEBUG] Heavy artifact export disabled: duplicated_context_groups_primary.csv")
        logger.warning(f"[CBF] (encoded/raw) تم العثور على {len(df_dups_primary)} صف مكرر بناءً على CONTEXT_COLUMNS.")
        # 2. كشف التكرار على CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS (للتدقيق فقط)
df_dups_full = df[df.duplicated(subset=full_cols, keep=False)]
if not df_dups_full.empty:
    if export_heavy:
        _maybe_export_heavy_csv(
            df_dups_full,
            "outputs/CBF/duplicated_context_groups_full.csv",
            "duplicated_context_groups_full"
        )
        logger.warning(
            f"[CBF] تم العثور على {len(df_dups_full)} صف مكرر بناءً على جميع الأعمدة السياقية. (export_heavy=True)")
    else:
        logger.debug("[DEBUG] Heavy artifact export disabled: duplicated_context_groups_full.csv")
        logger.warning(f"[CBF] تم العثور على {len(df_dups_full)} صف مكرر بناءً على جميع الأعمدة السياقية.")

# 3. تحقق من uniqueness قبل أي حذف
logger.info(f"[CBF] تحقق من uniqueness قبل حذف التكرار: عدد الصفوف الكلي: {df.shape[0]}")
logger.info(f"[CBF] عدد الصفوف الفريدة على CONTEXT_COLUMNS فقط: {df.drop_duplicates(subset=CONTEXT_COLUMNS).shape[0]}")
logger.info(f"[CBF] عدد الصفوف الفريدة على CONTEXT_COLUMNS+SECONDARY_CONTEXT_COLUMNS: {df.drop_duplicates(subset=full_cols).shape[0]}")
logger.info(f"[CBF] عدد الصفوف الفريدة على CONTEXT_COLUMNS+SECONDARY_CONTEXT_COLUMNS+['feature_id']: {df.drop_duplicates(subset=full_cols+['feature_id']).shape[0]}")
# 4. حذف التكرار فقط إذا كان هناك صف مطابق 100% في كل الأعمدة
# --- Deduplication with score_cbf check ---
before_dedup = df.shape[0]
df = df.drop_duplicates()
after_dedup = df.shape[0]
logger.info(f"[CBF] حذف التكرار على جميع الأعمدة (مطابقة تامة فقط). عدد الصفوف قبل: {before_dedup} | بعد: {after_dedup} | الفرق: {before_dedup - after_dedup}")
logger.info(f"[CBF] تحقق uniqueness بعد الحذف: {df.duplicated().sum()} صف مكرر متبقٍ (يجب أن يكون 0)")
# [PATCH] Ensure score_cbf is preserved after deduplication
if "score_cbf" not in df.columns:
    logger.warning("[PATCH] score_cbf column was missing after operation, filling with None.")
    df["score_cbf"] = None
# ----------- تطبيع الأعمدة السياقية بعد أي معالجة أو دمج بيانات -----------
_safe_normalize_context_cols_inplace(df, CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS)
_downcast_context_cats(df, CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS)

# --- كشف التكرار والتضارب في true_response وتصديره للملف (لا يتم حذف أي صف) ---
agg_keys = ["patient_id", "bp_category", "chol_category", "age_group", "feature_id"]
if "true_response" in df.columns:
    df_dup = df[df.duplicated(subset=agg_keys, keep=False)]
    if not df_dup.empty:
        # استخراج المجموعات المتضاربة فقط
        df_conflict = df_dup.groupby(agg_keys, observed=False)["true_response"].nunique().reset_index()
        df_conflict = df_conflict[df_conflict["true_response"] > 1]
        if not df_conflict.empty:
            # ضم الصفوف المتضاربة
            conflict_rows = df.merge(df_conflict[agg_keys], on=agg_keys, how="inner")
            if export_heavy:
                _maybe_export_heavy_csv(
                    conflict_rows,
                    "outputs/CBF/warnings_true_response.csv",
                    "warnings_true_response"
                )
                logger.warning(f"⚠️ تم العثور على {len(conflict_rows)} صف متضارب في true_response. (export_heavy=True)")
                print(f"⚠️ تم العثور على {len(conflict_rows)} صف متضارب في true_response. (export_heavy=True)")
            else:
                logger.debug("[DEBUG] Heavy artifact export disabled: warnings_true_response.csv")
                logger.warning(f"⚠️ تم العثور على {len(conflict_rows)} صف متضارب في true_response.")

# ----- توحيد target و true_response -----
if "target" in df.columns and "true_response" not in df.columns:
    df["true_response"] = df["target"]
elif "true_response" in df.columns and "target" not in df.columns:
    df["target"] = df["true_response"]
elif "target" in df.columns and "true_response" in df.columns:
    mismatch = (df["target"] != df["true_response"]).sum()
    if mismatch > 0:
        logger.warning(f"⚠️ يوجد {mismatch} صفوف يختلف فيها target عن true_response! سيتم استخدام target.")
        print(f"⚠️ يوجد {mismatch} صفوف يختلف فيها target عن true_response! سيتم استخدام target.")
    df["true_response"] = df["target"]

if "age_group" not in df.columns and "age" in df.columns:
    # مثال على اشتقاق age_group (يمكنك تخصيصه بحسب قواعدك)
    df["age_group"] = pd.cut(df["age"], bins=[0, 35, 50, 120], labels=["young", "middle", "old"])

df["context_key"] = df.apply(lambda r: make_context_key(r, context_columns=context_cols), axis=1)
# سجل عدد التركيبات السياقية الفريدة قبل التجميع
n_unique_before = df[context_cols].drop_duplicates().shape[0]
logger.info(f"🔍 عدد التركيبات السياقية الفريدة قبل aggregation: {n_unique_before}")

assert isinstance(df, pd.DataFrame), f"Loaded data is not a DataFrame, got {type(df)}"
logger.info(f"✅ Data loaded. Shape: {df.shape}")

# ---------- 2. Context Coverage & Stats ----------
logger.info("🔍 Checking context coverage and stats...")
assert isinstance(df, pd.DataFrame), "df must be a DataFrame before context coverage check"
context_report = check_context_coverage(df, context_cols)
logger.info(f"Context coverage report:\n{context_report}")
log_contextual_stats(df, context_cols, logger=logger)

# ---------- 3. Aggregate Rare Contexts ----------
df = aggregate_contextual_groupings(df, context_cols, min_freq=min_context_freq)
assert isinstance(df, pd.DataFrame), "After aggregate_contextual_groupings, df must be a DataFrame"
logger.info(f"✅ Rare context aggregation done (min_freq={min_context_freq})")
# سجل عدد التركيبات السياقية الفريدة بعد التجميع
n_unique_after = df[context_cols].drop_duplicates().shape[0]
logger.info(f"🔍 عدد التركيبات السياقية الفريدة بعد aggregation: {n_unique_after}")
if n_unique_after < n_unique_before * 0.8:
    logger.warning(f"⚠️ More than 20% drop in context combinations after aggregation ({n_unique_before} → {n_unique_after})")

# ---------- 4. Check Required Columns ----------
required_cols_for_cbf = set(feature_columns + ["patient_id"] + context_cols)
missing = [col for col in required_cols_for_cbf if col not in df.columns]
if missing:
    logger.error(f"❌ Missing columns: {missing}. Cannot proceed with pipeline.")
    raise ValueError(f"Missing columns required for CBF: {missing}")

# ---------------- تقسيم البيانات إلى train/val/test ----------------
df_train, df_val, df_test = cbf_split_data(df, config, logger=logger, random_state=42)

# --- Build stable core context keys for strict evaluation (LOCO / GroupKFold)
try:
    EVAL_CFG = config.get("evaluation", {}) or {}
    _group_cols = list(EVAL_CFG.get("group_cols", list(CONTEXT_COLUMNS)))
    # If group_cols explicitly equals the core triad, use the optimized core-key builder; otherwise, use generic make_context_key
    _is_core_triad = set(map(str, _group_cols)) == {"bp_category", "chol_category", "risk_level"}

    if _is_core_triad:
        df_train["__core_key__"] = df_train.apply(make_core_context_key, axis=1)
        df_val["__core_key__"] = df_val.apply(make_core_context_key, axis=1)
        df_test["__core_key__"] = df_test.apply(make_core_context_key, axis=1)
    else:
        # Generic stable key from configured columns
        df_train["__core_key__"] = df_train.apply(lambda r: make_context_key(r, context_columns=_group_cols), axis=1)
        df_val["__core_key__"] = df_val.apply(lambda r: make_context_key(r, context_columns=_group_cols), axis=1)
        df_test["__core_key__"] = df_test.apply(lambda r: make_context_key(r, context_columns=_group_cols), axis=1)
except (TypeError, ValueError, KeyError, AttributeError) as _e:
    logger.warning("[EVAL][STRICT] Unable to construct __core_key__: %s", _e)

# ----------- تقرير التغطية بعد التقسيم -----------
report_coverage(df_train, CONTEXT_COLUMNS, local_logger=logger)
report_coverage(df_val, CONTEXT_COLUMNS, local_logger=logger)
report_coverage(df_test, CONTEXT_COLUMNS, local_logger=logger)

df_train_nopriv = hide_sensitive_columns(df_train, config)
df_val_nopriv = hide_sensitive_columns(df_val, config)
df_test_nopriv = hide_sensitive_columns(df_test, config)

# ----------- تطبيع الأعمدة السياقية بعد أي معالجة أو دمج بيانات -----------
_safe_normalize_context_cols_inplace(df_train, CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS)
_safe_normalize_context_cols_inplace(df_val, CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS)
_safe_normalize_context_cols_inplace(df_test, CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS)
_downcast_context_cats(df_train, CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS)
_downcast_context_cats(df_val, CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS)
_downcast_context_cats(df_test, CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS)

# ---------- 5. Encode Contextual Features ----------
df_encoded = encode_context_features_cbf(df, feature_columns + context_cols)
assert isinstance(df_encoded, pd.DataFrame), f"Returned type: {type(df_encoded)}"
logger.info("✅ Contextual features encoded.")
# ----------- كشف وتصدير التكرارات السياقية بعد الترميز (df_encoded) -----------
df_dups_primary_enc = df_encoded[df_encoded.duplicated(subset=CONTEXT_COLUMNS, keep=False)]
if not df_dups_primary_enc.empty:
    if export_heavy:
        _maybe_export_heavy_csv(
            df_dups_primary_enc,
            "outputs/CBF/duplicated_context_groups_primary_encoded.csv",
            "duplicated_context_groups_primary_encoded"
        )
        logger.warning(
            f"[CBF] (encoded) تم العثور على {len(df_dups_primary_enc)} صف مكرر بناءً على CONTEXT_COLUMNS بعد الترميز. (export_heavy=True)")
    else:
        logger.debug("[DEBUG] Heavy artifact export disabled: duplicated_context_groups_primary_encoded.csv")
        logger.warning(
            f"[CBF] (encoded) تم العثور على {len(df_dups_primary_enc)} صف مكرر بناءً على CONTEXT_COLUMNS بعد الترميز.")

full_cols_enc = CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS
df_dups_full_enc = df_encoded[df_encoded.duplicated(subset=full_cols_enc, keep=False)]
if not df_dups_full_enc.empty:
    if export_heavy:
        _maybe_export_heavy_csv(
            df_dups_full_enc,
            "outputs/CBF/duplicated_context_groups_full_encoded.csv",
            "duplicated_context_groups_full_encoded"
        )
        logger.warning(
            f"[CBF] (encoded) تم العثور على {len(df_dups_full_enc)} صف مكرر بناءً على جميع الأعمدة السياقية بعد الترميز. (export_heavy=True)")
    else:
        logger.debug("[DEBUG] Heavy artifact export disabled: duplicated_context_groups_full_encoded.csv")
        logger.warning(
            f"[CBF] (encoded) تم العثور على {len(df_dups_full_enc)} صف مكرر بناءً على جميع الأعمدة السياقية بعد الترميز.")

# --- Deduplication with score_cbf check ---
before_dedup_enc = df_encoded.shape[0]
df_encoded = df_encoded.drop_duplicates()
after_dedup_enc = df_encoded.shape[0]
logger.info(f"[CBF] (encoded) حذف التكرار على جميع الأعمدة (مطابقة تامة فقط). عدد الصفوف قبل: {before_dedup_enc} | بعد: {after_dedup_enc} | الفرق: {before_dedup_enc - after_dedup_enc}")
logger.info(f"[CBF] (encoded) تحقق uniqueness بعد الحذف: {df_encoded.duplicated().sum()} صف مكرر متبقٍ (يجب أن يكون 0)")
# [PATCH] Ensure score_cbf is preserved after deduplication
if "score_cbf" not in df_encoded.columns:
    logger.warning("[PATCH] score_cbf column was missing after operation, filling with None.")
    df_encoded["score_cbf"] = None

# ---------- 6. Initialize Recommender ----------
logger.info("🔧 Initializing Content-Based Recommender...")
recommender = CBFRecommender(config)

# --- Cache-aware fit: reuse model when CONTEXT_COLUMNS schema is unchanged ---
_fit_cache_key = tuple(sorted(CONTEXT_COLUMNS))
_cached_model = _CBF_FIT_CACHE.get(_fit_cache_key)
if _cached_model is not None:
    recommender = _cached_model
    logger.info("[CBF][FIT] Reusing cached fitted model for key=%s", _fit_cache_key)
else:
    recommender.fit(df_train_nopriv)
    _CBF_FIT_CACHE[_fit_cache_key] = recommender
    logger.info("[CBF][FIT] Model fitted and cached for key=%s", _fit_cache_key)

# ----------- تدقيق وتصدير تغطية قاموس التوصية السياقية -----------
model_combinations = set()
if hasattr(recommender, "agg_table"):
    try:
        if isinstance(recommender.agg_table, dict):
            model_combinations = set(recommender.agg_table.keys())
            df_model_ctx = pd.DataFrame(list(model_combinations), columns=CONTEXT_COLUMNS)
        elif isinstance(recommender.agg_table, pd.DataFrame):
            if all(c in recommender.agg_table.columns for c in CONTEXT_COLUMNS):
                df_model_ctx = recommender.agg_table[CONTEXT_COLUMNS].drop_duplicates()
                model_combinations = set(tuple(x) for x in df_model_ctx.values)
            else:
                raise KeyError("CONTEXT_COLUMNS not fully present in agg_table DataFrame")
        else:
            raise TypeError(f"Unsupported agg_table type: {type(recommender.agg_table)}")
        if _EXPORT_AUDIT_ARTIFACTS:
            df_model_ctx.to_csv("outputs/CBF/context_combinations_in_model.csv", index=False, encoding="utf-8-sig")
            logger.info("✅ Exported context_combinations_in_model.csv for audit.")
        else:
            logger.info("ℹ️ Skipped exporting context_combinations_in_model.csv (export_audit_artifacts=False).")
    except (OSError, ValueError, AttributeError, TypeError, KeyError) as e:
        logger.error(f"❌ Could not export context_combinations_in_model.csv: {e}")

# جمع جميع التركيبات السياقية الفعلية في الداتا
data_combinations = set([tuple(x) for x in df[CONTEXT_COLUMNS].drop_duplicates().values])
n_model = len(model_combinations)
n_data = len(data_combinations)
covered = len(model_combinations & data_combinations)
not_covered = len(data_combinations - model_combinations)
coverage_ratio = covered / n_data if n_data > 0 else 0



# ---------- 7. Recommendations For Test Patients Only ----------
# ----------- Flexible contextual recommendation (find_best_contextual_recommendation) -----------
logger.info("💡 Running recommendations for test patients only...")
assert isinstance(df_test_nopriv, pd.DataFrame), "df_test_nopriv must be a DataFrame before iterrows"
# إعداد القاموس من df_train للأعمدة الأساسية والثانوية وعمود true_response فقط
# عند بناء dictionary أو aggregation للتوصية: اجمع كل true_response المرتبطة بكل مفتاح سياقي (لا تختار أول واحدة فقط)
df_dict = df_train[CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS + ['true_response']].copy()
recommendation_rows = []
_CHUNK_SIZE = 10000
_chunk_counter = 0
_tmp_dir = "outputs/CBF/tmp_chunks"
os.makedirs(_tmp_dir, exist_ok=True)
_tmp_paths = []

# --- Similarity / KNN hyperparameters from config (with safe defaults) ---
_sim_cfg = config.get("model_settings", {}).get("cbf", {}).get("similarity", {})
_SIM_K = int(_sim_cfg.get("k", 3))
_SIM_MIN = float(_sim_cfg.get("min_similarity", 0.7))
_knn_cfg = config.get("model_settings", {}).get("cbf", {}).get("knn", {})
_KNN_K = int(_knn_cfg.get("k", 5))
_KNN_MIN = float(_knn_cfg.get("min_similarity", 0.7))

for idx, row in df_test_nopriv.iterrows():
    assert isinstance(row, pd.Series), f"Row at idx {idx} is not a Series, got {type(row)}"
    # Normalize context columns in row before recommendation
    for col in CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS:
        if col in row.index:
            row[col] = normalize_context_value(row[col])
    # --- Fast-path: exact context match from CBFRecommender before helpers ---
    row_ctx_series = pd.Series({c: row.get(c, "unknown") for c in CONTEXT_COLUMNS})
    direct = []
    try:
        direct = recommender.recommend(row_ctx_series, top_n=1)
    except (AssertionError, KeyError, ValueError, TypeError) as _e:
        direct = []

    if direct and isinstance(direct, list) and len(direct) > 0:
        # Use the unified, re-ranked top-1 from CBFRecommender (already unioned + gated + scored if available)
        payload = direct[0] if isinstance(direct[0], dict) else {}
        if not isinstance(payload, dict):
            payload = {}
        try:
            logger.debug(
                "[CBF][direct] Using unified recommender payload: feature_id=%s | reason=%s | sim=%.4f",
                payload.get("feature_id"),
                payload.get("reason"),
                float(payload.get("sim_cbf_raw", payload.get("similarity", 0.0)) or 0.0),
            )
        except (TypeError, ValueError):
            pass

        def _as_float(val, default=0.0):
            try:
                return float(val)
            except (TypeError, ValueError):
                return default
        recommendation_rows.append({
            "patient_id": row["patient_id"],
            **{col: row[col] for col in context_cols if col in row},
            "feature_id": payload.get("feature_id", "manual_review"),
            # keep model-provided score if present; it will be validated/filled by ensure_cbf_scores downstream
            "score_cbf": payload.get("score_cbf"),
            "reason": payload.get("reason", "similarity"),
            "explanation": payload.get("explanation"),
            "advice": payload.get("advice"),
            "source": payload.get("source", "cbf"),
            "explanation_clinical": payload.get("explanation_clinical"),
            # prefer sim_cbf_raw from model; fallback to any "similarity" field; else 0.0
            "sim_cbf_raw": _as_float(payload.get("sim_cbf_raw", payload.get("similarity", None)), 0.0),
        })
        # We have a valid unified recommendation; skip helper fallbacks for this row
        continue
    # Prepare flexible context dict
    context_dict = {col: row[col] for col in CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS if col in row}
    rec_report = find_best_contextual_recommendation(
        context=context_dict,
        dictionary=df_dict,
        secondary_cols=SECONDARY_CONTEXT_COLUMNS,
        target_col="true_response",
        review_label="manual_review",
        verbose=False
    )
    rec_main={
        "feature_id": None,
        "score_cbf": None,
        "reason": rec_report['match_level'],
        "explanation": "; ".join(rec_report.get('details', [])),
        "advice": None,
        "source": "manual_review" if rec_report['match_level'] == "unresolved" else "recommended",
        "explanation_clinical": None,
    }

    if rec_report["recommendation"] not in [None, "manual_review"]:
        rec_main["feature_id"] = rec_report["recommendation"]
        rec_main["score_cbf"] = None  # defer to ensure_cbf_scores
        rec_main["source"] = "recommended"
        _rep_sim = rec_report.get("similarity", None)
        try:
            if (_rep_sim is None) or pd.isna(_rep_sim):
                rec_main["sim_cbf_raw"] = float(_EXACT_CAP)
            else:
                rec_main["sim_cbf_raw"] = float(_rep_sim)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            rec_main["sim_cbf_raw"] = float(_EXACT_CAP)


    # --- Fallback: similarity-based recommendation if unresolved ---
    if rec_report['match_level'] == "unresolved":
        try:
            similarity_report = recommend_by_similarity(
                context=context_dict,
                dictionary=df_dict,
                target_col="true_response",
                k=_SIM_K,
                min_similarity=_SIM_MIN,
                verbose=False,
                context_cols=CONTEXT_COLUMNS
            )
        except (KeyError, ValueError, TypeError) as _sim_err:
            logger.warning("[CBF][SIM] similarity-fallback failed non-fatally: %s", _sim_err)
            similarity_report = {
                "recommendation": "manual_review",
                "match_level": "unresolved",
                "details": [f"similarity exception: {_sim_err}"]
            }
        if similarity_report['recommendation'] not in [None, "manual_review"]:
            rec_main["feature_id"] = similarity_report['recommendation']
            rec_main["score_cbf"] = None  # defer scoring to centralized mapping
            rec_main["reason"] = similarity_report.get('match_level', "similarity_fallback_low")
            rec_main["explanation"] += " | SIMILARITY: " + "; ".join(similarity_report.get('details', []))
            rec_main["source"] = "similarity_fallback"
            try:
                rec_main["sim_cbf_raw"] = float(similarity_report.get("similarity", 0.0))
            except (TypeError, ValueError):
                rec_main["sim_cbf_raw"] = 0.0
        else:
            rec_main["explanation"] += " | No similar context found by similarity-fallback."
    # --- Fallback KNN Recommendation (to be implemented in helperscbf.py) ---
    from pipeline.helperscbf import fallback_knn_recommendation
    if rec_main["feature_id"] is None or rec_main["feature_id"] == "manual_review":
        rec_fallback = fallback_knn_recommendation(
            context_row=context_dict,
            df_train=df_train,
            context_cols=CONTEXT_COLUMNS,
            secondary_cols=SECONDARY_CONTEXT_COLUMNS,
            n_neighbors=_KNN_K,
            min_similarity=_KNN_MIN,
            return_k_neighbors=True  # Always return the top k neighbors for more robust fallback
        )
        if rec_fallback and isinstance(rec_fallback, dict) and rec_fallback.get("recommendation") not in [None, "manual_review"]:
            rec_main["feature_id"] = rec_fallback["recommendation"]
            rec_main["reason"] = rec_fallback.get("match_level", "knn_fallback")
            rec_main["score_cbf"] = None  # defer scoring to centralized mapping
            rec_main["source"] = "knn_fallback"
            try:
                rec_main["sim_cbf_raw"] = float(rec_fallback.get("similarity", 0.0))
            except (TypeError, ValueError):
                rec_main["sim_cbf_raw"] = rec_main.get("sim_cbf_raw", 0.0) or 0.0

            rec_main["explanation"] += " | KNN Fallback: " + "; ".join(rec_fallback.get("details", []))
        # If match_level is knn_unique, set reason accordingly (but keep score as None)
        if rec_fallback and rec_fallback.get("match_level") == "knn_unique":
            rec_main["reason"] = "knn_unique"
        # Optional: attach k_neighbors info for deeper analysis/debugging (if returned)
        kneigh = rec_fallback.get("k_neighbors", None) if isinstance(rec_fallback, dict) else None
        if isinstance(kneigh, (list, tuple)):
            if len(kneigh) > 0:
                rec_main["explanation"] += f" | KNN Neighbors: {len(kneigh)}"
        elif isinstance(kneigh, set):
            if len(kneigh) > 0:
                rec_main["explanation"] += f" | KNN Neighbors: {len(kneigh)}"
        # Avoid DataFrame/other ambiguous truthiness; intentionally ignore other types.
    # --- If still None, set to manual_review ---
    if rec_main["feature_id"] is None:
        rec_main["feature_id"] = "manual_review"
        rec_main["score_cbf"] = 0.0
        rec_main["source"] = "manual_review"
    # Log and warn if unresolved/manual_review
    if rec_report['match_level'] == "unresolved":
        logger.warning(
            f"Manual review/unresolved context for patient_id={row.get('patient_id')}, "
            f"context={context_dict} | Details: {rec_report.get('details', '')}"
        )
    recommendation_rows.append({
        "patient_id": row["patient_id"],
        **{col: row[col] for col in context_cols if col in row},
        "feature_id": rec_main.get("feature_id"),
        "score_cbf": rec_main.get("score_cbf"),
        "reason": rec_main.get("reason"),
        "explanation": rec_main.get("explanation"),
        "advice": rec_main.get("advice"),
        "source": rec_main.get("source"),
        "explanation_clinical": rec_main.get("explanation_clinical"),
        "sim_cbf_raw": float(rec_main.get("sim_cbf_raw", _EXACT_CAP if str(rec_main.get("reason","")) in ("recommended","context_key_match") else 0.0)),
    })
    if len(recommendation_rows) >= _CHUNK_SIZE:
        _chunk_path = os.path.join(_tmp_dir, f"recs_chunk_{_chunk_counter}.csv.gz")
        pd.DataFrame(recommendation_rows).to_csv(_chunk_path, index=False, encoding="utf-8-sig", compression="gzip")
        _tmp_paths.append(_chunk_path)
        _chunk_counter += 1
        recommendation_rows.clear()
        if _chunk_counter % 3 == 0:
            gc.collect()
# إنشاء DataFrame التوصيات (chunked)
# Flush remainder and concatenate chunks
if recommendation_rows:
    _chunk_path = os.path.join(_tmp_dir, f"recs_chunk_{_chunk_counter}.csv.gz")
    pd.DataFrame(recommendation_rows).to_csv(_chunk_path, index=False, encoding="utf-8-sig", compression="gzip")
    _tmp_paths.append(_chunk_path)
    recommendation_rows.clear()
# --- Concatenate chunk files and compute dynamic CBF scores using reason + sim_cbf_raw ---
if _tmp_paths:
    recommendations = pd.concat((pd.read_csv(p) for p in _tmp_paths), ignore_index=True)

    # --- Compute dynamic CBF scores early (uses reason + sim_cbf_raw)
    try:
        try:
            from recommender.cbf import ensure_cbf_scores  # preferred path
        except ImportError:
            from recommender.cbf import ensure_cbf_scores  # fallback to project root
        recommendations = ensure_cbf_scores(recommendations, config, reason_col="reason", sim_col="sim_cbf_raw")
        recommendations = _ensure_eval_ready(recommendations, config)
        # Prepare recommendations for evaluation (ensures family/context columns)
        try:
            recommendations = _ensure_eval_ready(recommendations, config)
        except (KeyError, TypeError, AttributeError, ValueError) as _e:
            logger.warning("[CBF][EVAL_READY] Skipped non-fatal prep on recommendations: %s", _e)
    except (ImportError, AttributeError, TypeError, ValueError) as _sc_err:
        logger.warning("[CBF][SCORE] ensure_cbf_scores failed; leaving score_cbf as-is: %s", _sc_err)
else:
    recommendations = pd.DataFrame(columns=["patient_id"] + list(context_cols) + ["feature_id","score_cbf","reason","explanation","advice","source","explanation_clinical"])
    # --- Compute dynamic CBF scores even if currently empty (safe no-op)
    try:
        try:
            from recommender.cbf import ensure_cbf_scores
        except ImportError:
            from recommender.cbf import ensure_cbf_scores
        recommendations = ensure_cbf_scores(recommendations, config, reason_col="reason", sim_col="sim_cbf_raw")
        # Prepare recommendations for evaluation (ensures family/context columns)
        try:
            recommendations = _ensure_eval_ready(recommendations, config)
        except (KeyError, TypeError, AttributeError, ValueError) as _e:
            logger.warning("[CBF][EVAL_READY] Skipped non-fatal prep on recommendations: %s", _e)
    except (ImportError, AttributeError, TypeError, ValueError) as _sc_err:
        logger.warning("[CBF][SCORE] ensure_cbf_scores failed on empty frame; safe to continue: %s", _sc_err)
# ----- CHECKPOINT: توزيع القيم بعد التوصية -----
if "feature_id" in recommendations.columns:
    feat_counts = recommendations["feature_id"].value_counts(dropna=False)
    logger.info(f"[CBF] توزيع feature_id في التوصيات: {feat_counts.to_dict()}")
    if feat_counts.get("manual_review", 0) / len(recommendations) > 0.7:
        logger.error("[CRITICAL] معظم التوصيات manual_review: تحقق من منطق التوصية في cbf.py وhelperscbf.py!")
        print("أمثلة من التوصيات:", recommendations.head(10))
# [PATCH] sanitize feature_id to prevent numeric/unknown labels
if "feature_id" in recommendations.columns:
    recommendations['feature_id'] = recommendations['feature_id'].apply(sanitize_feature_id)
    unknown_ids = set(recommendations['feature_id'].unique()) - ALLOWED_FEATURE_IDS
    if unknown_ids:
        logger.warning(f"[CBF] تحذير: توجد قيم غير معروفة في feature_id: {unknown_ids}")

# Safety cap before merges to prevent accidental explosion
try:
    _cfg = load_config()
    _max_rows = int(_cfg.get("debug", {}).get("max_context_combos", 1_000_000))
except (ImportError, AttributeError, KeyError, ValueError, TypeError) as _getpol_err:
    logger.warning("[CBF][CONFIG] Fallback to defaults due to error: %s", _getpol_err)
    _max_rows = 1_000_000
if len(recommendations) > _max_rows:
    logger.warning("[CBF] Recommendations rows (%d) exceed cap (%d). Truncating to head(%d) to prevent OOM.", len(recommendations), _max_rows, _max_rows)
    recommendations = recommendations.head(_max_rows).copy()
# [PATCH] Ensure score_cbf is preserved after recommendations creation
if "score_cbf" not in recommendations.columns:
    logger.warning("[PATCH] score_cbf column was missing after operation, filling with None.")
    recommendations["score_cbf"] = None

# ----------- كشف وتصدير التكرارات السياقية في توصيات test قبل أي دمج لاحق -----------
df_dups_rec_primary = recommendations[recommendations.duplicated(subset=CONTEXT_COLUMNS, keep=False)]
if not df_dups_rec_primary.empty:
    if export_heavy:
        _maybe_export_heavy_csv(
            df_dups_rec_primary,
            "outputs/CBF/duplicated_context_groups_primary_recommendations.csv",
            "duplicated_context_groups_primary_recommendations"
        )
        logger.warning(
            f"[CBF] (recommendations) تم العثور على {len(df_dups_rec_primary)} صف مكرر بناءً على CONTEXT_COLUMNS في توصيات test. (export_heavy=True)")
    else:
        logger.debug("[DEBUG] Heavy artifact export disabled: duplicated_context_groups_primary_recommendations.csv")
        logger.warning(
            f"[CBF] (recommendations) تم العثور على {len(df_dups_rec_primary)} صف مكرر بناءً على CONTEXT_COLUMNS في توصيات test.")

    # PATCH: تأكد أن جميع الأعمدة الثانوية موجودة، وإن لم تكن، اجلبها من مصادر متعددة بترتيب أولويات واضح.
missing_secondary_cols = [col for col in SECONDARY_CONTEXT_COLUMNS if col not in recommendations.columns]
if missing_secondary_cols:
    logger.warning(f"[CBF][PATCH] الأعمدة الثانوية الناقصة في توصيات test: {missing_secondary_cols}. سنحاول جلبها من مصادر متعددة.")
    def _safe_left_merge(left_df, right_df, keys, payload_cols, tag):
        if not keys:
            return left_df
        right_cols = list(dict.fromkeys(keys + payload_cols))
        right_df = right_df.drop_duplicates(subset=keys, keep="first")[right_cols]
        before = len(left_df)
        try:
            out = left_df.merge(
                right_df,
                on=keys,
                how="left",
                validate="many_to_one",
                suffixes=("", f"_{tag}")
            )
            logger.info("[CBF][PATCH] (%s) merge ok: %d -> %d rows (keys=%s, payload=%s)", tag, before, len(out), keys, payload_cols)
            return out
        except MergeError as merge_err:
            logger.error("[CBF][PATCH] (%s) many-to-many detected, skipping this source. Keys=%s | Error=%s", tag, keys, merge_err)
            return left_df

    # ❶ المصدر الأول: outputs/tmp/df_contextualized.csv
    _merged_ok = False
    try:
        df_contextualized = pd.read_csv("outputs/tmp/df_contextualized.csv")
        _downcast_context_cats(df_contextualized, CONTEXT_COLUMNS + SECONDARY_CONTEXT_COLUMNS + ["patient_id"])
        merge_keys = [col for col in ["patient_id"] + CONTEXT_COLUMNS if col in recommendations.columns and col in df_contextualized.columns]
        if merge_keys:
            recommendations = _safe_left_merge(recommendations, df_contextualized, merge_keys, missing_secondary_cols, "sec")
            _merged_ok = True
        else:
            logger.warning("[CBF][PATCH] df_contextualized lacks required merge keys; skipping.")
    except (OSError, ValueError, TypeError) as e:
        logger.warning(f"[CBF][PATCH] قراءة df_contextualized فشلت: {e}")

    # ❷ المصدر الثاني (fallback): df_test نفسه
    still_missing = [c for c in SECONDARY_CONTEXT_COLUMNS if c not in recommendations.columns]
    if still_missing:
        keys2 = [col for col in ["patient_id"] + CONTEXT_COLUMNS if col in recommendations.columns and col in df_test.columns]
        if keys2:
            recommendations = _safe_left_merge(recommendations, df_test, keys2, still_missing, "test")
        else:
            logger.warning("[CBF][PATCH] لا توجد مفاتيح مشتركة كافية للدمج مع df_test كـ fallback.")

    # ❸ المصدر الثالث (fallback): df الأصلي الكامل (إن فشل المصدران السابقان)
    still_missing = [c for c in SECONDARY_CONTEXT_COLUMNS if c not in recommendations.columns]
    if still_missing:
        keys3 = [col for col in ["patient_id"] + CONTEXT_COLUMNS if col in recommendations.columns and col in df.columns]
        if keys3:
            recommendations = _safe_left_merge(recommendations, df, keys3, still_missing, "raw")
        else:
            logger.warning("[CBF][PATCH] لا توجد مفاتيح مشتركة كافية للدمج مع df الخام كـ fallback.")

    # بعد جميع المحاولات، إذا بقيت أعمدة ناقصة، أنشئها بقيم NaN بدل تركها غائبة (لتوحيد المخطط)
    for col in SECONDARY_CONTEXT_COLUMNS:
        if col not in recommendations.columns:
            recommendations[col] = pd.NA

    logger.info(f"[CBF][PATCH] الأعمدة الثانوية المتوفرة الآن: {[c for c in SECONDARY_CONTEXT_COLUMNS if c in recommendations.columns]}")

    # --- ضمان explanation_clinical قبل تصدير FULL ---
    if "explanation_clinical" not in recommendations.columns:
        # تعريف سريع محلي لتوليد شرح سريري؛ مطابق للدالة السفلية لكن وضعناه هنا قبل التصدير
        def _clinical_explanation_local(ctx_row):
            bp = str(ctx_row.get('bp_category', '')).strip().lower()
            chol = str(ctx_row.get('chol_category', '')).strip().lower()
            if bp == "hypertension_stage_2" and chol == "high":
                return "❗️مريض في مرحلة خطرة جدًا (ضغط مرتفع جدًا وكوليسترول مرتفع): يجب مراجعة العلاج الدوائي فورًا."
            elif bp == "hypertension_stage_2" and chol == "borderline_high":
                return "⚠️ ضغط شديد وكوليسترول حدودي: قيّم ضرورة العلاج الدوائي."
            elif bp == "hypertension_stage_1" and chol == "high":
                return "🔹 ضغط مرتفع (درجة أولى) + كوليسترول مرتفع: راقب وقيّم بدء الدواء حسب المخاطر."
            else:
                return "مستوى الخطورة متوسط/منخفض؛ اتبع الإرشادات السريرية العامة."
        try:
            # لا تعتمد على الأعمدة الثانوية؛ لكن لو كانت موجودة فهي مفيدة مستقبلًا
            if all(col in recommendations.columns for col in ["bp_category", "chol_category"]):
                recommendations["explanation_clinical"] = recommendations.apply(_clinical_explanation_local, axis=1)
            else:
                recommendations["explanation_clinical"] = pd.NA
        except (KeyError, TypeError, ValueError) as e:
            logger.warning(f"[CBF][PATCH] تعذّر توليد explanation_clinical تلقائيًا: {e}")
            recommendations["explanation_clinical"] = pd.NA

existing_full_cols = [col for col in full_cols if col in recommendations.columns]
if existing_full_cols:
    df_dups_rec_full = recommendations[recommendations.duplicated(subset=existing_full_cols, keep=False)]
    if not df_dups_rec_full.empty:
        if _EXPORT_AUDIT_ARTIFACTS:
            df_dups_rec_full.to_csv("outputs/CBF/duplicated_context_groups_full_recommendations.csv", index=False,
                                    encoding="utf-8-sig")
            logger.warning(
                f"[CBF] (recommendations) تم العثور على {len(df_dups_rec_full)} صف مكرر بناءً على جميع الأعمدة السياقية في توصيات test. تم تصديرهم لملف duplicated_context_groups_full_recommendations.csv (لم يتم حذف أي صف).")
        else:
            logger.warning(
                f"[CBF] (recommendations) تم العثور على {len(df_dups_rec_full)} صف مكرر بناءً على جميع الأعمدة السياقية في توصيات test. (تم تعطيل التصدير)")
before_dedup_rec = recommendations.shape[0]
recommendations = recommendations.drop_duplicates()
after_dedup_rec = recommendations.shape[0]
logger.info(f"[CBF] (recommendations) حذف التكرار على جميع الأعمدة (مطابقة تامة فقط). عدد الصفوف قبل: {before_dedup_rec} | بعد: {after_dedup_rec} | الفرق: {before_dedup_rec - after_dedup_rec}")
logger.info(f"[CBF] (recommendations) تحقق uniqueness بعد الحذف: {recommendations.duplicated().sum()} صف مكرر متبقٍ (يجب أن يكون 0)")
# [PATCH] Ensure score_cbf is preserved after deduplication
if "score_cbf" not in recommendations.columns:
    logger.warning("[PATCH] score_cbf column was missing after operation, filling with None.")
    recommendations["score_cbf"] = None

# --- Convert manual_review to contextual fallback feature_id if possible ---
if "feature_id" in recommendations.columns and callable(finalize_feature_id):
    try:
        recommendations = finalize_feature_id(recommendations, context_cols=CONTEXT_COLUMNS)
    except (TypeError, ValueError, KeyError) as e:
        logger.warning(f"[CBF] finalize_feature_id failed: {e}")

# ❶ إعداد مفاتيح الدمج الأساسية: patient_id + CONTEXT_COLUMNS (الموجودة في كلا الجدولين)
core_keys_all = ["patient_id"] + CONTEXT_COLUMNS
core_keys = [c for c in core_keys_all if c in recommendations.columns and c in df_test.columns]
if not core_keys:
    logger.error("❌ No common core keys between recommendations and df_test for merge.")
    proceed_pipeline = False
else:
    # ❷ بناء df_test الداعم بالاعتماد على المفاتيح الأساسية فقط + true_response
    df_test_core = df_test[core_keys + (["true_response"] if "true_response" in df_test.columns else [])].copy()
    # إذا لم تتوفر true_response في df_test، نحاول استخدامها من target
    if "true_response" not in df_test_core.columns and "target" in df_test.columns:
        df_test_core = df_test[core_keys + ["target"]].copy()
        df_test_core = df_test_core.rename(columns={"target": "true_response"})
        logger.warning("[CBF][MERGE] Using 'target' as true_response for merge stage-1 (temporary fallback).")

    # تطبيع المفاتيح (نوعًا وشكلًا) لضمان تطابق دقيق
    for col in core_keys:
        if col in df_test_core.columns:
            df_test_core.loc[:, col] = df_test_core[col].astype(str).apply(normalize_context_value)
    for col in core_keys:
        if col in recommendations.columns:
            recommendations.loc[:, col] = recommendations[col].astype(str).apply(normalize_context_value)

    # إزالة التكرارات على المفاتيح الأساسية — نحتاج صفًا واحدًا لكل سياق أساسي
    df_test_core = (
        df_test_core
        .sort_values(core_keys)
        .drop_duplicates(subset=core_keys, keep="first")
    )

    # Dedup LHS (recommendations) on the same keys to avoid many-to-many
    recommendations = (
        recommendations
        .sort_values(core_keys)
        .drop_duplicates(subset=core_keys, keep="first")
    )

    # (اختياري) حسم التعارضات إن وجدت عبر الدالة المركزية
    try:
        df_core_resolved = resolve_true_response_conflict(
            df=df_test_core,
            core_cols=core_keys,
            secondary_cols=SECONDARY_CONTEXT_COLUMNS,
            target_col="true_response"
        ).rename(columns={"final_true_response": "true_response"})
    except (TypeError, ValueError, KeyError) as e:
        logger.warning(f"[CBF][MERGE] Conflict resolution skipped due to error: {e}")
        df_core_resolved = df_test_core

    # --- Pre-merge dedup to avoid many-to-many explosions ---
    _pre_keys = ["patient_id"] + list(CONTEXT_COLUMNS)
    if "feature_id" in recommendations.columns:
        _pre_keys.append("feature_id")
    _pre_keys = [k for k in _pre_keys if k in recommendations.columns]

    if _pre_keys:
        _b_rec = len(recommendations)
        recommendations = recommendations.drop_duplicates(subset=_pre_keys, keep="first")
        logger.info("[CBF][MERGE] Pre-merge dedup (LHS) by %s: %d → %d", _pre_keys, _b_rec, len(recommendations))

    _rhs_keys = [k for k in _pre_keys if k in df_test.columns]
    if _rhs_keys:
        _b_rhs = len(df_test)
        df_test = df_test.drop_duplicates(subset=_rhs_keys, keep="first")
        logger.info("[CBF][MERGE] Pre-merge dedup (RHS) by %s: %d → %d", _rhs_keys, _b_rhs, len(df_test))

    # ❸ الدمج الأساسي (Join-1): بدون feature_id
    # Assert that the right-hand keys are unique (protect many_to_one contract)
    try:
        assert_no_many_to_many(df_core_resolved, core_keys)
    except Exception as _e:
        logger.warning("[CBF][MERGE] Right-hand keys not unique for %s: %s. Deduplicating RHS before merge.", core_keys,
                       _e)
        df_core_resolved = df_core_resolved.drop_duplicates(subset=core_keys, keep="first")
    try:
        merged = recommendations.merge(
            df_core_resolved[core_keys + ["true_response"]],
            on=core_keys,
            how="left",
            validate="many_to_one",
            suffixes=("", "_test")
        )
    except MergeError as me:
        logger.error("[CBF][MERGE] Stage-1 rejected due to many-to-many merge on keys %s: %s", core_keys, me)
        # Fallback to a deduplicated right-hand side and retry once
        rhs = df_core_resolved[core_keys + ["true_response"]].drop_duplicates(subset=core_keys, keep="first")
        merged = recommendations.merge(rhs, on=core_keys, how="left", validate="many_to_one", suffixes=("", "_test"))

    # Canonicalize any duplicate true_response columns and compute missing Stage-1
    s_tr1, tr_cols1 = _canonicalize_true_response(merged)
    if s_tr1 is not None:
        merged = merged.drop(columns=[c for c in tr_cols1 if c != "true_response"], errors="ignore")
        if "true_response" not in merged.columns:
            merged["true_response"] = s_tr1
        else:
            merged["true_response"] = s_tr1
    # Compute missing count safely whether true_response existed or not
    if s_tr1 is None:
        missing_stage1 = int(len(merged))
    else:
        try:
            missing_stage1 = int(s_tr1.isna().sum())
        except (AttributeError, ValueError, TypeError) as e:
            logger.debug("[CBF][MERGE] Stage-1 missing count fallback due to %s", e.__class__.__name__)
            missing_stage1 = int(merged[[c for c in merged.columns if (c == "true_response") or c.startswith("true_response")]].isna().all(axis=1).sum())

    if missing_stage1 > 0:
        # Build a mask robustly for rows missing true_response
        if "true_response" in merged.columns:
            miss_mask = merged["true_response"].isna()
        else:
            miss_mask = pd.Series(True, index=merged.index)
        miss_rows = merged.loc[miss_mask].copy()
        sample_cols = [c for c in (core_keys + (["feature_id"] if "feature_id" in merged.columns else [])) if c in miss_rows.columns]
        if export_heavy:
            _maybe_export_heavy_csv(
                miss_rows[sample_cols].head(50),
                "outputs/CBF/debug/unmatched_keys_stage1.csv",
                "unmatched_keys_stage1"
            )

    # ❹ (اختياري) تحسين الدمج بالمطابقة عبر feature_id إذا كان متوفرًا في df_test
    if ("feature_id" in merged.columns) and ("feature_id" in df_test.columns):
        try:
            # Normalize feature_id on the left side before filtering NA mask
            if "feature_id" in merged.columns:
                merged.loc[:, "feature_id"] = merged["feature_id"].astype(str).apply(normalize_context_value)
            df_test_fid = df_test[core_keys + ["feature_id", "true_response"]].copy()
            # Guard: ensure required columns exist in df_test_fid before normalization/merge
            missing_fid_cols = [c for c in (core_keys + ["feature_id"]) if c not in df_test_fid.columns]
            if missing_fid_cols:
                logger.warning(f"[CBF][MERGE] Stage-2 skipped: missing columns in df_test for feature_id match: {missing_fid_cols}")
                raise KeyError(f"Missing columns for Stage-2 merge: {missing_fid_cols}")
            for col in core_keys + ["feature_id"]:
                if col in df_test_fid.columns:
                    df_test_fid.loc[:, col] = df_test_fid[col].astype(str).apply(normalize_context_value)
            df_test_fid = df_test_fid.drop_duplicates(subset=core_keys + ["feature_id"], keep="first")

            mask_na = merged["true_response"].isna()
            if mask_na.any():
                merged_na = merged.loc[mask_na, core_keys + ["feature_id"]].copy()
                # Guard: ensure RHS key uniqueness before Stage-2 merge-by-feature_id
                try:
                    assert_no_many_to_many(df_test_fid, core_keys + ["feature_id"])  # raises ValueError if duplicates
                except (ValueError, KeyError, TypeError) as _rhs_err:
                    logger.warning(
                        "[CBF][MERGE] Stage-2 RHS keys not unique for %s: %s. Deduplicating RHS before merge.",
                        core_keys + ["feature_id"], _rhs_err
                    )
                    df_test_fid = df_test_fid.drop_duplicates(subset=core_keys + ["feature_id"], keep="first")
                try:
                    merged2 = merged_na.merge(
                        df_test_fid,
                        on=core_keys + ["feature_id"],
                        how="left",
                        validate="many_to_one",
                        suffixes=("", "_byfid")
                    )
                except MergeError as me2:
                    logger.warning("[CBF][MERGE] Stage-2 by feature_id rejected (many-to-many). Keys=%s | %s", core_keys + ["feature_id"], me2)
                    merged2 = merged_na.merge(
                        df_test_fid.drop_duplicates(subset=core_keys + ["feature_id"], keep="first"),
                        on=core_keys + ["feature_id"],
                        how="left",
                        validate="many_to_one",
                        suffixes=("", "_byfid")
                    )
                if "true_response" in merged2.columns:
                    merged.loc[mask_na, "true_response"] = merged2["true_response"].values
        except (KeyError, ValueError, AttributeError, MergeError) as e:
            logger.warning(f"[CBF][MERGE] Stage-2 by feature_id failed: {e}")

    # Stage-2: canonicalize and count missing robustly
    s_tr2, tr_cols2 = _canonicalize_true_response(merged)
    if s_tr2 is not None:
        merged = merged.drop(columns=[c for c in tr_cols2 if c != "true_response"], errors="ignore")
        if "true_response" not in merged.columns:
            merged["true_response"] = s_tr2
        else:
            merged["true_response"] = s_tr2
    if s_tr2 is None:
        missing_stage2 = int(len(merged))
    else:
        try:
            missing_stage2 = int(s_tr2.isna().sum())
        except (AttributeError, ValueError, TypeError) as e:
            logger.debug("[CBF][MERGE] Stage-2 missing count fallback due to %s", e.__class__.__name__)
            missing_stage2 = int(merged[[c for c in merged.columns if (c == "true_response") or c.startswith("true_response")]].isna().all(axis=1).sum())

    # build mask via the canonical series
    miss_mask2 = pd.Series(True, index=merged.index) if s_tr2 is None else s_tr2.isna()

    if missing_stage2 > 0:
        miss_rows2 = merged.loc[miss_mask2].copy()
        sample_cols2 = [c for c in (core_keys + (["feature_id"] if "feature_id" in merged.columns else [])) if c in miss_rows2.columns]
        if export_heavy:
            _maybe_export_heavy_csv(
                miss_rows2[sample_cols2].head(200),
                "outputs/CBF/debug/unmatched_keys_stage2.csv",
                "unmatched_keys_stage2"
            )
            proceed_pipeline = False

    # تنظيف أعمدة الدمج المكررة (_test أو _byfid)
    merged = merged.loc[:, ~merged.columns.duplicated()]
    drop_cols = [c for c in merged.columns if c.endswith("_test") or c.endswith("_byfid") or c.endswith("_x") or c.endswith("_y")]
    if drop_cols:
        merged = merged.drop(columns=drop_cols, errors="ignore")

    # تأكد من وجود score_cbf بعد الدمج
    if "score_cbf" not in merged.columns:
        merged["score_cbf"] = None

    # تثبيت الداتا بعد الدمج كـ recommendations
    recommendations = merged

    # [CBF][INIT] Log mix policy, inject similarity, and compute unified scores
    try:
        _EXACT_CAP_LOG, _MIX_LOG = _log_mix_policy_once(config)
    except (KeyError, TypeError, AttributeError, ValueError) as _mix_err:
        logger.warning("[CBF][INIT] mix-policy logging failed: %s", _mix_err)
        _EXACT_CAP_LOG = 0.98

    # Inject sim_cbf_raw respecting exact-match cap and numeric similarity
    try:
        recommendations = _inject_sim_cbf_raw(recommendations, config)
    except (KeyError, TypeError, AttributeError, ValueError) as _inj_err:
        logger.warning("[CBF][SIM] Injection of sim_cbf_raw failed: %s", _inj_err)
        if "sim_cbf_raw" not in recommendations.columns:
            recommendations["sim_cbf_raw"] = 0.0

    # Unified CBF score computation (no hard 1.0 anywhere)
    try:
        recommendations = ensure_cbf_scores(recommendations, config, reason_col="reason", sim_col="sim_cbf_raw")
    except (KeyError, TypeError, AttributeError, ValueError) as _sc_err:
        logger.error("[CBF][SCORE] ensure_cbf_scores failed: %s", _sc_err)

    # Prepare recommendations for evaluation (ensures family/context columns)
    try:
        recommendations = _ensure_eval_ready(recommendations, config)
    except (KeyError, TypeError, AttributeError, ValueError) as _e:
        logger.warning("[CBF][EVAL_READY] Skipped non-fatal prep on recommendations: %s", _e)

    # === [CBF][EVAL][pre] — قياس LOCO قبل أي فلترة/Top-K ===
    try:
        # Local import to avoid circulars if evaluation imports pipeline symbols
        from evaluation import ranking_at_k, summarize_loco  # type: ignore

        # Resolve evaluation parameters with safe fallbacks
        _eval_cfg = (config.get("evaluation", {}) or {}) if isinstance(config, dict) else {}
        _glob_cols = (config.get("global", {}) or {}).get("columns", {}) if isinstance(config, dict) else {}
        _K_AT = int(_eval_cfg.get("k_at", 5))
        _SCORE_COL = str(_eval_cfg.get("score_col", "score_cbf"))
        _TRUTH_COL = str(_glob_cols.get("response", "true_response"))

        # Grouping key — default per patient; override here if you evaluate by context-family
        _group_key = ("patient_id",)

        # Guard: ensure required columns exist before evaluation
        _eval_base = recommendations.copy()
        if _SCORE_COL not in _eval_base.columns:
            # last chance: coerce from any existing score_cbf* columns
            score_like = [c for c in _eval_base.columns if c.startswith("score_cbf")]
            if "score_cbf" in score_like:
                _eval_base[_SCORE_COL] = pd.to_numeric(_eval_base["score_cbf"], errors="coerce").fillna(0.0)
            elif score_like:
                _eval_base[_SCORE_COL] = pd.to_numeric(_eval_base[score_like[0]], errors="coerce").fillna(0.0)
            else:
                _eval_base[_SCORE_COL] = 0.0
        if _TRUTH_COL not in _eval_base.columns:
            # fall back to target if available
            if "target" in _eval_base.columns:
                _eval_base[_TRUTH_COL] = pd.to_numeric(_eval_base["target"], errors="coerce").fillna(0).astype(int)
            else:
                _eval_base[_TRUTH_COL] = 0

        # Compute LOCO metrics per patient (replicate_per_row=True also emits per-row metrics stream)
        _rows_parts = []
        _loco_df = None
        for _kind, _payload in ranking_at_k(
            _eval_base,
            k=_K_AT,
            score_col=_SCORE_COL,
            truth_col=_TRUTH_COL,
            group_key=_group_key,
            replicate_per_row=True
        ):
            if _kind == "loco":
                _loco_df = _payload
            elif _kind == "rows":
                _rows_parts.append(_payload)

        # Persist outputs
        if _loco_df is not None and not _loco_df.empty:
            _loco_path = "outputs/CBF/cbf_recs_loco.csv"
            _summ_path = "outputs/CBF/cbf_eval_loco.csv"
            os.makedirs(os.path.dirname(_loco_path), exist_ok=True)
            _loco_df.to_csv(_loco_path, index=False, encoding="utf-8-sig")
            summarize_loco(_loco_df).to_csv(_summ_path, index=False, encoding="utf-8-sig")
            logger.info("[CBF][EVAL][pre] Wrote LOCO per-patient metrics to %s and summary to %s", _loco_path, _summ_path)
        else:
            logger.info("[CBF][EVAL][pre] No LOCO metrics written (empty loco_df).")

        if _rows_parts:
            _rows_df = pd.concat(_rows_parts, ignore_index=True)
            _rows_path = "outputs/CBF/cbf_recs_loco_rows.csv"
            _rows_df.to_csv(_rows_path, index=False, encoding="utf-8-sig")
            logger.info("[CBF][EVAL][pre] Wrote per-row replicated metrics to %s", _rows_path)

    except (OSError, ValueError) as _eval_io_err:
        logger.warning("[CBF][EVAL][pre] File I/O during LOCO export failed non-fatally: %s", _eval_io_err)
    except (ImportError, AttributeError, KeyError, TypeError) as _eval_err:
        logger.warning("[CBF][EVAL][pre] Evaluation step skipped due to: %s", _eval_err)

    # --- Centralized coalescing of score columns (NO remapping/override) ---
    def _coalesce_score_cols(df_in: pd.DataFrame) -> pd.DataFrame:
        sc_cols = [c for c in df_in.columns if c.startswith("score_cbf")]
        if "score_cbf" not in sc_cols:
            left = pd.to_numeric(df_in.get("score_cbf_x"), errors="coerce") if "score_cbf_x" in df_in.columns else None
            right = pd.to_numeric(df_in.get("score_cbf_y"), errors="coerce") if "score_cbf_y" in df_in.columns else None
            if left is not None or right is not None:
                df_in["score_cbf"] = (left if left is not None else pd.Series([pd.NA]*len(df_in), index=df_in.index)).combine_first(
                    right if right is not None else pd.Series([pd.NA]*len(df_in), index=df_in.index)
                )
        # Drop merge suffix columns if present
        score_suffix_cols = [c for c in sc_cols if c not in ("score_cbf",)]
        if score_suffix_cols:
            df_in.drop(columns=score_suffix_cols, errors="ignore", inplace=True)
        return df_in

def _log_split_summary(df_tr, df_va, df_te, log=None):
    logger_obj = log or logger

    def _summ(frame):
        if not isinstance(frame, pd.DataFrame) or frame.empty:
            return 0, 0, 0.0
        n = int(len(frame))
        try:
            pos = int(pd.to_numeric(frame.get("true_response", 0), errors="coerce").fillna(0).sum())
        except (TypeError, ValueError, AttributeError, KeyError):
            pos = 0
        rate = (pos / n) if n else 0.0
        return n, pos, rate

    nt, pt, rt = _summ(df_tr)
    nv, pv, rv = _summ(df_va)
    ne, pe, re = _summ(df_te)
    tot = max(nt + nv + ne, 1)

    logger_obj.info(
        "[SPLIT] rows: train=%d (%.1f%%) | val=%d (%.1f%%) | test=%d (%.1f%%) | total=%d",
        nt, 100.0 * nt / tot, nv, 100.0 * nv / tot, ne, 100.0 * ne / tot, tot
    )
    logger_obj.info(
        "[SPLIT] positives: train=%d (%.1f%%) | val=%d (%.1f%%) | test=%d (%.1f%%)",
        pt, 100.0 * rt, pv, 100.0 * rv, pe, 100.0 * re
    )

# Robust, pandas‑free list coercion helper (used across the pipeline)
def _to_list_safe(x):
    import math

    # 1) list/tuple fast-path
    if isinstance(x, (list, tuple)):
        return [str(i).strip().strip("'\"") for i in x if str(i).strip()]

    # 2) None / NaN-like
    if x is None:
        return []
    try:
        if isinstance(x, float) and math.isnan(x):
            return []
    except (TypeError, ValueError):
        pass
    try:
        if x != x:  # NaN check via self-inequality
            return []
    except (TypeError, ValueError, AttributeError):
        # Restrict overly-broad exception; handle only comparison-related errors
        pass

    xs = str(x).strip()
    if not xs:
        return []
    if xs.lower() in {"nan", "none", "null", "unknown"}:
        return []

    # 3) Parse bracketed list string: "[a, b]" or "['a', "b"]"
    if xs.startswith("[") and xs.endswith("]"):
        inner = xs[1:-1].strip()
        if not inner:
            return []
        tokens = []
        buf = []
        in_quote = False
        qchar = ''
        for ch in inner:
            if ch in ('"', "'"):
                if not in_quote:
                    in_quote = True
                    qchar = ch
                elif ch == qchar:
                    in_quote = False
                    qchar = ''
                buf.append(ch)
                continue
            if ch == ',' and not in_quote:
                tok = ''.join(buf).strip().strip("'\"")
                if tok:
                    tokens.append(tok)
                buf = []
            else:
                buf.append(ch)
        tok = ''.join(buf).strip().strip("'\"")
        if tok:
            tokens.append(tok)
        return [t for t in (t.strip() for t in tokens) if t]

    # 4) Fallback single value
    return [xs]

def _log_context_coverage(
    df_in,
    name: str,
    log=None,
    *,
    ctx_cols=None,
    sec_cols=None,
    topn: int = 5,
    return_dict: bool = False,
    **_compat_kwargs,
):
    # توافق رجعي مع نداءات قديمة: context_cols/secondary_cols
    if ctx_cols is None and "context_cols" in _compat_kwargs:
        ctx_cols = _compat_kwargs.pop("context_cols")
    if sec_cols is None and "secondary_cols" in _compat_kwargs:
        sec_cols = _compat_kwargs.pop("secondary_cols")

    # استيرادات محليّة محروسة
    import logging as _logging
    try:
        import pandas as _pd
    except ImportError as _pd_imp_err:
        (_logging.getLogger(__name__) if log is None else log).warning(
            "[SPLIT] pandas import failed in _log_context_coverage: %s", _pd_imp_err
        )
        return {} if return_dict else None

    logger_obj = log if log is not None else _logging.getLogger(__name__)

    # تحقّق الإطار
    if not isinstance(df_in, _pd.DataFrame) or df_in.empty:
        logger_obj.info("[SPLIT] %s: empty or invalid DataFrame; skipping coverage log.", name)
        return {} if return_dict else None

    # أعمدة السياق
    if ctx_cols is None:
        try:
            from utils.constants import CONTEXT_COLUMNS as _CTX
            ctx_cols = list(_CTX) if _CTX is not None else ["bp_category", "chol_category", "risk_level"]
        except (ImportError, AttributeError, TypeError, ValueError):
            ctx_cols = ["bp_category", "chol_category", "risk_level"]
    else:
        ctx_cols = list(ctx_cols)

    # أعمدة ثانوية (اختياري)
    sec_cols = list(sec_cols) if sec_cols is not None else []

    # تحقق الأعمدة المطلوبة
    missing_ctx = [c for c in ctx_cols if c not in df_in.columns]
    if missing_ctx:
        logger_obj.warning("[SPLIT] %s missing context columns: %s", name, missing_ctx)
        ctx_cols = [c for c in ctx_cols if c in df_in.columns]
        if not ctx_cols:
            return {} if return_dict else None

    # مُطبِّع بسيط
    def _norm_str(x):
        try:
            _s_norm = str(x).strip().lower()
            return "unknown" if _s_norm in {"", "nan", "na", "none", "null", "unknown"} else _s_norm
        except (TypeError, ValueError):
            return "unknown"

    # اختيار وتطبيع أعمدة السياق
    try:
        sub = df_in.loc[:, ctx_cols].copy()
        for _ctx_col in list(sub.columns):
            try:
                sub[_ctx_col] = sub[_ctx_col].apply(_norm_str)
            except (TypeError, ValueError, AttributeError):
                sub[_ctx_col] = sub[_ctx_col].astype("object").map(_norm_str)
        ctx_df = sub
    except (TypeError, ValueError, KeyError, AttributeError) as _prep_err:
        logger_obj.warning("[SPLIT] %s: failed to normalize context columns: %s", name, _prep_err)
        return {} if return_dict else None

    out: dict = {}
    n_rows = int(len(df_in))
    out["rows"] = n_rows

    # عدد السياقات الفريدة
    try:
        out["contexts_unique"] = int(ctx_df.drop_duplicates().shape[0])
    except (TypeError, ValueError, KeyError, AttributeError):
        out["contexts_unique"] = 0

    # فريد/نسبة unknown لكل عمود سياقي
    per_col_uniques = {}
    per_col_unknown_rate = {}
    for c in ctx_cols:
        try:
            ser_c = ctx_df[c]
            per_col_uniques[c] = int(ser_c.nunique(dropna=True))
            unk_mask = ser_c.isna() | (ser_c == "unknown")
            per_col_unknown_rate[c] = float(unk_mask.mean())
        except (TypeError, ValueError, KeyError, AttributeError):
            per_col_uniques[c] = 0
            per_col_unknown_rate[c] = 0.0
    out["per_col_uniques"] = per_col_uniques
    out["per_col_unknown_rate"] = per_col_unknown_rate

    # Top-N سياقات
    try:
        ctx_key = ctx_df.apply(lambda r: "|".join(r.values.tolist()), axis=1)
        vc = ctx_key.value_counts()
        denom = float(n_rows) if n_rows else 1.0
        out["top_contexts"] = [
            {"context": key, "count": int(cnt), "share": float(cnt) / denom}
            for key, cnt in vc.head(int(topn)).items()
        ]
    except (TypeError, ValueError, KeyError, AttributeError):
        out["top_contexts"] = []

    # context_feature_id إن وُجد
    if "context_feature_id" in df_in.columns:
        try:
            cfi = df_in["context_feature_id"].astype("object").map(_norm_str)
            vc_cfi = cfi.value_counts()
            out["context_feature_id_unique"] = int(cfi.nunique(dropna=True))
            out["top_context_feature_id"] = [
                {"context_feature_id": k, "count": int(v), "share": float(v) / n_rows}
                for k, v in vc_cfi.head(int(topn)).items()
            ]
        except (TypeError, ValueError, KeyError, AttributeError):
            out["context_feature_id_unique"] = 0
            out["top_context_feature_id"] = []

    # توزيع الأسباب
    if "reason" in df_in.columns:
        try:
            rser = df_in["reason"].astype("object").map(_norm_str)
            rdist = rser.value_counts(normalize=True, dropna=False).to_dict()
            out["reason_dist"] = {str(k): float(v) for k, v in rdist.items()}
            out["reason_share_exact"] = float(out["reason_dist"].get("recommended", 0.0) +
                                              out["reason_dist"].get("context_key_match", 0.0))
            out["reason_share_knn"] = float(out["reason_dist"].get("knn_recommendation", 0.0))
        except (TypeError, ValueError, KeyError, AttributeError):
            out["reason_dist"] = {}
            out["reason_share_exact"] = 0.0
            out["reason_share_knn"] = 0.0

    # Top-N feature_id
    if "feature_id" in df_in.columns:
        try:
            fser = df_in["feature_id"].astype("object").map(_norm_str)
            vcf = fser.value_counts()
            out["top_features"] = [
                {"feature_id": k, "count": int(v), "share": float(v) / n_rows}
                for k, v in vcf.head(int(topn)).items()
            ]
        except (TypeError, ValueError, KeyError, AttributeError):
            out["top_features"] = []

    # ملخص للأعمدة الثانوية (اختياري)
    if sec_cols:
        sec_summary = {}
        for sc in [c for c in sec_cols if c in df_in.columns]:
            try:
                _ser = df_in[sc].astype("object").map(_norm_str)
                sec_summary[sc] = {
                    "uniques": int(_ser.nunique(dropna=True)),
                    "unknown_rate": float((_ser.isna() | (_ser == "unknown")).mean()),
                    "top": [
                        {"value": k, "count": int(v), "share": float(v) / n_rows}
                        for k, v in _ser.value_counts().head(int(topn)).items()
                    ],
                }
            except (TypeError, ValueError, KeyError, AttributeError):
                continue
        if sec_summary:
            out["secondary_summary"] = sec_summary

    # Logging منظّم
    logger_obj.info("[SPLIT] %s — rows=%d | unique_contexts=%d", name, out.get("rows", 0), out.get("contexts_unique", 0))
    logger_obj.info("[SPLIT] %s — per-col uniques=%s", name, out.get("per_col_uniques", {}))
    logger_obj.info("[SPLIT] %s — per-col unknown_rate=%s", name, out.get("per_col_unknown_rate", {}))
    if out.get("top_contexts"):
        logger_obj.info("[SPLIT] %s — top-%d contexts=%s", name, topn, out["top_contexts"])
    if out.get("reason_dist"):
        logger_obj.info(
            "[SPLIT] %s — reason_dist=%s | exact=%.3f | knn=%.3f",
            name, out["reason_dist"], out.get("reason_share_exact", 0.0), out.get("reason_share_knn", 0.0)
        )
    if out.get("top_features"):
        logger_obj.info("[SPLIT] %s — top-%d feature_id=%s", name, topn, out["top_features"])
    if "context_feature_id_unique" in out:
        logger_obj.info("[SPLIT] %s — context_feature_id_unique=%s", name, out["context_feature_id_unique"])
    if out.get("secondary_summary"):
        logger_obj.info("[SPLIT] %s — secondary columns summary=%s", name, out["secondary_summary"])

    return out if return_dict else None

# ----------- [CBF][NARRATIVE + CALIBRATION] -----------
# Optional isotonic calibration if enabled and labels exist
try:
    _use_iso = str((config.get("scoring") or {}).get("post_calibration", "isotonic")).lower() == "isotonic"
except (AttributeError, KeyError, TypeError, ValueError):
    _use_iso = False

if _use_iso and isinstance(recommendations, pd.DataFrame) and ("true_response" in recommendations.columns):
    try:
        _min_samples_iso = int((config.get("scoring") or {}).get("isotonic_min_samples", 20))
    except (AttributeError, KeyError, TypeError, ValueError):
        _min_samples_iso = 20
    try:
        _iso_model = fit_and_save_isotonic(
            df_scores_labels=recommendations,
            score_col="score_cbf",
            label_col="true_response",
            min_samples=_min_samples_iso,
        )
        if _iso_model is not None:
            # apply on DataFrame to replace column in-place
            recommendations["score_cbf"] = apply_isotonic_if_available(
                recommendations["score_cbf"], _iso_model, clip=True
            )
    except Exception as _iso_err:
        logger.warning("[CBF][ISO] Isotonic calibration skipped: %s", _iso_err)

# Populate narratives (algorithmic + clinical) and advice strictly from helpers
try:
    if isinstance(recommendations, pd.DataFrame) and not recommendations.empty:
        recommendations = apply_cbf_narratives(recommendations, logger_obj=logger)
except Exception as _narr_err:
    logger.warning("[CBF][NARRATIVE] apply_cbf_narratives failed non-fatally: %s", _narr_err)

# Guard: prevent identical clinical and algorithmic explanations
if isinstance(recommendations, pd.DataFrame) and ("explanation" in recommendations.columns) and ("explanation_clinical" in recommendations.columns):
    _eq_mask = recommendations["explanation_clinical"].astype(str) == recommendations["explanation"].astype(str)
    if _eq_mask.any():
        recommendations.loc[_eq_mask, "explanation_clinical"] = ""

# Final score hygiene for export/eval: median fill then clip to [0,1]
if isinstance(recommendations, pd.DataFrame) and ("score_cbf" in recommendations.columns):
    try:
        _sc = pd.to_numeric(recommendations["score_cbf"], errors="coerce")
        if _sc.isna().any():
            _med = float(_sc.median()) if len(_sc.dropna()) > 0 else 0.5
            recommendations["score_cbf"] = _sc.fillna(_med)
        recommendations["score_cbf"] = pd.to_numeric(recommendations["score_cbf"], errors="coerce").clip(0.0, 1.0)
    except Exception as _sfix:
        logger.warning("[CBF][SCORE] Post-processing failed (median/clip): %s", _sfix)

# Remove manual_review rows from final output
if isinstance(recommendations, pd.DataFrame) and ("feature_id" in recommendations.columns):
    try:
        recommendations = recommendations.loc[recommendations["feature_id"].astype(str) != "manual_review"].copy()
    except Exception as _rm_err:
        logger.warning("[CBF][FILTER] Failed to drop manual_review rows: %s", _rm_err)

# ----------- [CBF][ACCEPTANCE] Quick narrative acceptance checks -----------
def _acceptance_checks(df_in: pd.DataFrame, log) -> bool:
    if not isinstance(df_in, pd.DataFrame) or df_in.empty:
        log.warning("[ACCEPT] Input is empty or invalid DataFrame; skipping acceptance checks.")
        return True

    ok = True

    # 1) reason ↔ source consistency: forbid 'fallback' source under knn/context reasons
    try:
        r = df_in["reason"].astype(str).str.lower()
        s_src = df_in["source"].astype(str).str.lower()
        bad1 = r.eq("knn_recommendation") & s_src.str.contains("fallback", na=False)
        bad2 = r.eq("context_key_match") & s_src.str.contains("fallback", na=False)
        if (bad1 | bad2).any():
            ok = False
            log.error("[ACCEPT] Inconsistent source under knn/context (fallback found). Count=%d", int((bad1 | bad2).sum()))
    except (KeyError, TypeError, ValueError, AttributeError) as _acc_e1:
        log.warning("[ACCEPT] reason/source check skipped: %s", _acc_e1)

    # 2) explanation_clinical ↔ explanation non-empty
    try:
        if "explanation_clinical" in df_in.columns and "explanation" in df_in.columns:
            mis = (df_in["explanation"].fillna("").astype(str).str.strip() == "") & \
                  (df_in["explanation_clinical"].fillna("").astype(str).str.strip() == "")
            if mis.any():
                ok = False
                log.error("[ACCEPT] Both explanation and explanation_clinical empty for %d rows.", int(mis.sum()))
    except (KeyError, TypeError, ValueError, AttributeError) as _acc_e2:
        log.warning("[ACCEPT] explanation/explanation_clinical check skipped: %s", _acc_e2)

    return ok

# Enforce acceptance before any CSV exports
assert _acceptance_checks(recommendations, logger), "Narrative acceptance checks failed."
# ----------- [/CBF][ACCEPTANCE] -----------

# 5) cap FULL export length unless debug flag explicitly allows
_export_full_grid = False
_full_cap = 1_000_000
try:
    # Prefer runtime config over global loader to avoid import‑time issues
    _dbg = (config.get("debug", {}) if isinstance(config, dict) else {}) or {}
    _export_full_grid = bool(_dbg.get("export_full_context_combinations", False))
    _full_cap = int(_dbg.get("max_context_combos", _full_cap))
except (AttributeError, KeyError, TypeError, ValueError) as _cfg_err:
    logger.warning("[CBF][CONFIG] Debug caps not found in config; using defaults. %s", _cfg_err)

# Guard recommendations existence and type
if not isinstance(recommendations, pd.DataFrame):
    recommendations_to_write = pd.DataFrame()
else:
    recommendations_to_write = (
        recommendations
        if (_export_full_grid or len(recommendations) <= _full_cap)
        else recommendations.head(_full_cap).copy()
    )

if 'recommendation_rows' in locals():
    del recommendation_rows
    gc.collect()

# ----------- Export FULL recommendations (all combinations, pre-deduplication) -----------
if "score_cbf" not in recommendations.columns:
    logger.warning("[PATCH] score_cbf column was missing before export, filling with None.")
    recommendations["score_cbf"] = None
_full_export_path = "outputs/CBF/df_cbf_recommendations_full.csv"
recommendations_to_write = locals().get("recommendations_to_write", recommendations.copy())
# Ensure FULL contains secondary context columns and clinical narrative column
for col in list(SECONDARY_CONTEXT_COLUMNS) + ["explanation_clinical"]:
    if col not in recommendations_to_write.columns:
        recommendations_to_write[col] = pd.NA

# Drop helper similarity column from FULL export
if "sim_cbf_raw" in recommendations_to_write.columns:
    recommendations_to_write = recommendations_to_write.drop(columns=["sim_cbf_raw"])

# Ensure 'advice' column exists prior to enrichment
if "advice" not in recommendations_to_write.columns:
    recommendations_to_write["advice"] = pd.NA

# [FULL] حقن explanation/source وتقوية advice قبل الحفظ
recommendations_to_write = _fill_algo_explain_and_source(recommendations_to_write)
recommendations_to_write = _fill_advice_fallbacks(recommendations_to_write)

# Helpers to detect blanks and to synthesize safe clinical text
def _is_blank_str(x):
    import math

    # Explicit None
    if x is None:
        return True

    # NaN-like floats
    try:
        if isinstance(x, float) and math.isnan(x):
            return True
    except (TypeError, ValueError):
        # If x cannot be treated as a float for NaN check, ignore and continue
        pass

    # Safe string coercion (str(...) is reliable for built-ins)
    xs = str(x).strip()
    return xs == "" or xs.lower() in {"nan", "none", "null", "unknown"}

def _make_explanation_clinical_full(_row: pd.Series) -> str:
    try:
        bp = str(_row.get("bp_category", "")).strip().lower()
        chol = str(_row.get("chol_category", "")).strip().lower()
        risk = str(_row.get("risk_level", "")).strip().lower()
        feat = str(_row.get("feature_id", "")).strip()

        # High‑level rules (brief and safe)
        if bp == "hypertension_stage_2" and chol in {"high", "borderline_high"}:
            base = "حالة خطورة مرتفعة: ضغط شديد" + (" وكوليسترول مرتفع" if chol == "high" else " وكوليسترول حدودي")
        elif bp == "hypertension_stage_1" and chol == "high":
            base = "ضغط مرتفع (درجة أولى) مع كوليسترول مرتفع"
        elif risk == "high":
            base = "مستوى خطورة مرتفع حسب السياق"
        elif risk == "medium":
            base = "مستوى خطورة متوسط حسب السياق"
        else:
            base = "مستوى خطورة منخفض/غير مرتفع"

        if feat:
            return f"{base}. التوصية مبنية على السياق السريري الحالي وبالاقتران مع '{feat}'."
        return f"{base}. التوصية مبنية على التشابه السياقي وقواعد التوجيه."
    except (TypeError, ValueError, AttributeError):
        return "التوصية مبنية على السياق السريري ومؤشرات المخاطر."

def _make_advice_full(_row: pd.Series) -> str:
    try:
        feat = str(_row.get("feature_id", "")).strip().lower()
        risk = str(_row.get("risk_level", "")).strip().lower()

        lifestyle_feats = {"increase_exercise", "diet_control", "lifestyle_monitoring"}
        pharm_feats = {"amlodipine", "ace_inhibitor", "amlodipine_and_thiazide"}

        if feat in lifestyle_feats:
            if feat == "increase_exercise":
                return "شجّع على نشاط بدني منتظم (150 دقيقة/أسبوع) والمتابعة خلال 4–6 أسابيع."
            if feat == "diet_control":
                return "اتباع نمط غذائي منخفض الصوديوم وغني بالخضار مع مراجعة القياسات دوريًا."
            return "إجراءات نمط الحياة أولًا والمتابعة المنتظمة للضغط والدهون."
        if feat in pharm_feats:
            return "ناقش بدء/تعديل العلاج الدوائي المناسب مع الطبيب المعالج وفق الإرشادات، مع مراقبة الضغط والأعراض."
        if "knn" in str(_row.get("reason", "")).lower():
            return "اقتراح مبني على تشابه سياقي؛ يُفضّل مراجعة الحالة سريريًا قبل الاعتماد النهائي."
        # Generic fallback by risk
        if risk == "high":
            return "خطّة مُعزّزة: تقييم دوائي محتمل إضافةً لنمط الحياة، مع متابعة لصيقة."
        if risk == "medium":
            return "خطّة متوازنة: تحسين نمط الحياة أولًا وإعادة التقييم قريبًا."
        return "استمر بنمط الحياة الصحي والمتابعة الروتينية."
    except (TypeError, ValueError, AttributeError):
        return "اتّبع الإرشادات السريرية المناسبة للحالة مع متابعة القياسات."

# Fill missing/blank clinical explanation
if "explanation_clinical" in recommendations_to_write.columns:
    mask_exp = recommendations_to_write["explanation_clinical"].apply(_is_blank_str)
    if mask_exp.any():
        recommendations_to_write.loc[mask_exp, "explanation_clinical"] = recommendations_to_write.loc[mask_exp].apply(_make_explanation_clinical_full, axis=1)

# Fill missing/blank advice strictly from the 4-text map (no derivation from explanation)
if "advice" in recommendations_to_write.columns:
    mask_adv = recommendations_to_write["advice"].apply(_is_blank_str)
    if mask_adv.any():
        _feat_series = recommendations_to_write.loc[mask_adv, "feature_id"].astype(str).str.strip().str.lower()
        recommendations_to_write.loc[mask_adv, "advice"] = _feat_series.map(_ADVICE_MAP).fillna("")

# --- [/PATCH][FULL] ---
# --- Sanitize or drop known optional columns that appear empty in FULL export ---
_maybe_optional_cols = [
    "chol_bins", "restecg_cat", "exang_cat", "oldpeak_cat", "ca_cat", "thal_cat"
]
try:
    _cfg_out_cols = set((config.get("output_columns", {}) or {}).get("cbf", []) or [])
except (AttributeError, KeyError, TypeError, ValueError):
    _cfg_out_cols = set()
for _c in _maybe_optional_cols:
    if _c in recommendations_to_write.columns:
        _all_na = recommendations_to_write[_c].isna().all()
        # If the column is not part of the configured CBF output OR it is entirely NA, drop it
        if (_c not in _cfg_out_cols) or _all_na:
            recommendations_to_write.drop(columns=[_c], inplace=True, errors="ignore")
        else:
            # Keep it, but ensure it is not empty
            recommendations_to_write[_c] = recommendations_to_write[_c].fillna("unknown")
try:
    # Diagnostics before FULL export
    try:
        if "score_cbf" in recommendations_to_write.columns:
            _s_full = pd.to_numeric(recommendations_to_write["score_cbf"], errors="coerce")
            _q_full = _s_full.quantile([0, .25, .5, .75, .9, 1]).round(4).to_dict()
            logger.info("[CBF][FULL][pre-save] score_cbf quantiles %s", {str(k): float(v) for k, v in _q_full.items() if pd.notna(v)})
        if "reason" in recommendations_to_write.columns:
            _r_full = recommendations_to_write["reason"].value_counts(dropna=False).head(5).to_dict()
            logger.info("[CBF][FULL][pre-save] reasons top-5 %s", {str(k): int(v) for k, v in _r_full.items()})
    except (TypeError, ValueError, KeyError, AttributeError) as _pre_full_diag_ex:
        logger.debug("[CBF][FULL] pre-save diagnostics skipped: %s", _pre_full_diag_ex)
    if len(recommendations_to_write) > 100_000:
        _full_export_path = _full_export_path + ".gz"
        recommendations_to_write.to_csv(_full_export_path, index=False, encoding="utf-8-sig", compression="gzip")
    else:
        recommendations_to_write.to_csv(_full_export_path, index=False, encoding="utf-8-sig")
    logger.info("✅ Exported FULL recommendations (pre-deduplication, all rows) to %s", _full_export_path)
    # Mark FULL export as enriched and finalized to avoid accidental overwrite later
    _FULL_ALREADY_EXPORTED = True

    # ========================= [UNIFIED LOCO OVERRIDE] =========================
    # Rebuild LOCO recommendations using the unified CBF recommender path
    # (This intentionally overwrites any earlier baseline-KNN LOCO export.)
    try:
        # --- Sanity & helpers ---
        if not isinstance(df_test_nopriv, pd.DataFrame) or df_test_nopriv.empty:
            logger.warning("[CBF][LOCO] df_test_nopriv is empty or invalid; skipping unified LOCO export.")
            raise ValueError("df_test_nopriv missing or empty")

        _missing_core = [c for c in ["patient_id", *CONTEXT_COLUMNS] if c not in df_test_nopriv.columns]
        if _missing_core:
            logger.warning("[CBF][LOCO] Missing core columns in df_test_nopriv: %s", _missing_core)
            raise KeyError(f"Missing core columns for LOCO: {_missing_core}")

        if '_progress_bar' not in globals():
            def _progress_bar(curr: int, total_count: int, prefix: str = "") -> None:
                try:
                    width = 24
                    curr_i = int(curr); total_i = max(int(total_count), 1)
                    filled = int(width * curr_i / total_i)
                    bar = "█"*filled + "░"*(width-filled)
                    print(f"{prefix} [{bar}] {curr_i}/{total_i}", end="\r", flush=True)
                    if curr_i >= total_i:
                        print("", flush=True)
                except (TypeError, ValueError, OverflowError):
                    pass

        # Safe local progress bar alias (guaranteed callable)
        _progress_bar_local = globals().get("_progress_bar", None)
        if not callable(_progress_bar_local):
            def _progress_bar_local(curr: int, total_count: int, prefix: str = "") -> None:
                try:
                    width = 24
                    curr_i = int(curr); total_i = max(int(total_count), 1)
                    filled = int(width * curr_i / total_i)
                    bar = "█"*filled + "░"*(width-filled)
                    print(f"{prefix} [{bar}] {curr_i}/{total_i}", end="\r", flush=True)
                    if curr_i >= total_i:
                        print("", flush=True)
                except (TypeError, ValueError, OverflowError):
                    pass

        # derive k for LOCO from config (evaluation.k_at or recommendation.top_n_eval), default=5
        try:
            k_lo = int((config.get("evaluation", {}) or {}).get("k_at",
                       (config.get("recommendation", {}) or {}).get("top_n_eval", 5)))
        except (TypeError, ValueError, AttributeError):
            k_lo = 5

        rows_loco_unified = []
        _total_loco = len(df_test_nopriv)
        for _i, (_, _row) in enumerate(df_test_nopriv.iterrows(), 1):
            # Build minimal context series for the unified recommender
            _ctx_series = pd.Series({c: _row.get(c, "unknown") for c in CONTEXT_COLUMNS})
            try:
                _direct = recommender.recommend(_ctx_series, top_n=k_lo, allow_exact=False)
            except (AssertionError, KeyError, ValueError, TypeError) as _e_loco:
                _direct = []
                logger.debug("[CBF][LOCO] unified recommend() failed non‑fatally: %s", _e_loco)

            _payload = _direct[0] if isinstance(_direct, list) and _direct and isinstance(_direct[0], dict) else {}
            if not isinstance(_payload, dict):
                _payload = {}

            try:
                logger.debug(
                    "[CBF][LOCO] unified payload → feature_id=%s | reason=%s | sim=%.4f",
                    _payload.get("feature_id"),
                    _payload.get("reason"),
                    float(_payload.get("sim_cbf_raw", _payload.get("similarity", 0.0)) or 0.0),
                )
            except (TypeError, ValueError):
                pass

            rows_loco_unified.append({
                "patient_id": _row.get("patient_id"),
                **{c: _row.get(c, pd.NA) for c in CONTEXT_COLUMNS},
                # carry unified payload as-is; scoring will be validated/calculated below
                **_payload,
            })
            if _total_loco:
                _progress_bar_local(_i, _total_loco, prefix="LOCO contexts")

        # Build DataFrame and compute unified CBF scores (reason + sim_cbf_raw + optional isotonic)
        df_loco_unified = pd.DataFrame(rows_loco_unified)
        try:
            from recommender.cbf import ensure_cbf_scores  # preferred import path
        except ImportError:
            try:
                from recommender.helperscbf import ensure_cbf_scores  # package-alt
            except ImportError:
                try:
                    from recommender.helperscbf import ensure_cbf_scores  # root-level fallback (module in repo root)
                except ImportError:
                    from recommender.cbf import ensure_cbf_scores  # last-resort root-level module
        df_loco_unified = ensure_cbf_scores(df_loco_unified, config, reason_col="reason", sim_col="sim_cbf_raw")

        # [PATCH][LOCO] Normalize similarity source for narratives (so build_algorithmic_explanation picks it up)
        if "similarity" not in df_loco_unified.columns:
            if "score_cbf_raw" in df_loco_unified.columns:
                df_loco_unified["similarity"] = df_loco_unified["score_cbf_raw"]
            elif "sim_cbf_raw" in df_loco_unified.columns:
                df_loco_unified["similarity"] = df_loco_unified["sim_cbf_raw"]

        # --- Per-patient score postprocessing (rank/min-max) and diagnostics ---
        def postprocess_scores_cbf(
                df_in: pd.DataFrame,
                score_col: str = "score_cbf",
                patient_col_name: str = "patient_id",
        ) -> pd.DataFrame:
            if not isinstance(df_in, pd.DataFrame) or df_in.empty or (score_col not in df_in.columns):
                return df_in
            df_out = df_in.copy()

            # ensure numeric
            df_out.loc[:, score_col] = pd.to_numeric(df_out[score_col], errors="coerce")

            # per-patient min-max normalization
            if patient_col_name in df_out.columns:
                def _minmax(x: pd.Series) -> pd.Series:
                    x = pd.to_numeric(x, errors="coerce")
                    try:
                        x_min = float(x.min())
                        x_max = float(x.max())
                    except (TypeError, ValueError):
                        return x.fillna(0.0)
                    if not (x_max > x_min):
                        return x.fillna(0.0)
                    return (x - x_min) / (x_max - x_min)

                try:
                    df_out.loc[:, score_col] = df_out.groupby(patient_col_name, group_keys=False)[score_col].apply(_minmax)
                except (KeyError, TypeError, ValueError, AttributeError):
                    # fallback to global min-max (avoid shadowing outer names)
                    _scores_glob = pd.to_numeric(df_out[score_col], errors="coerce")
                    _smin = float(_scores_glob.min())
                    _smax = float(_scores_glob.max())
                    _rng = _smax - _smin
                    if _rng > 0.0:
                        df_out.loc[:, score_col] = (_scores_glob - _smin) / _rng
                    else:
                        df_out.loc[:, score_col] = _scores_glob.fillna(0.0)

            # stable sorting
            try:
                if patient_col_name in df_out.columns:
                    df_out = df_out.sort_values([patient_col_name, score_col], ascending=[True, False])
                else:
                    df_out = df_out.sort_values(score_col, ascending=False)
            except (KeyError, TypeError, ValueError, AttributeError):
                pass

            return df_out


        # Apply postprocessing and log light diagnostics
        df_loco_unified = postprocess_scores_cbf(df_loco_unified, score_col="score_cbf", patient_col_name="patient_id")

        try:
            _s = pd.to_numeric(df_loco_unified["score_cbf"], errors="coerce")
            _qs = _s.quantile([0, 0.25, 0.5, 0.75, 0.9, 1]).round(4).to_dict()
            logger.info("[CBF][LOCO] score_cbf quantiles %s", {str(k): float(v) for k, v in _qs.items() if pd.notna(v)})
            if "reason" in df_loco_unified.columns:
                _top_reasons = df_loco_unified["reason"].value_counts(dropna=False).head(5).to_dict()
                logger.info("[CBF][LOCO] reasons top-5 %s", {str(k): int(v) for k, v in _top_reasons.items()})
        except (KeyError, TypeError, ValueError, AttributeError) as _ex:
            logger.warning("[CBF][LOCO] diagnostics failed: %s", _ex)


        # Keep a compact LOCO artifact; drop helper similarity column
        if "sim_cbf_raw" in df_loco_unified.columns:
            df_loco_unified = df_loco_unified.drop(columns=["sim_cbf_raw"])

        # Overwrite LOCO export with unified results
        _loco_path = "outputs/CBF/cbf_recs_loco.csv"
        os.makedirs(os.path.dirname(_loco_path), exist_ok=True)
        # Assert required columns exist before LOCO export
        _req_cols_loco = ["patient_id"] + list(CONTEXT_COLUMNS)
        _missing_loco = [c for c in _req_cols_loco if c not in df_loco_unified.columns]
        assert not _missing_loco, f"[CBF][LOCO] Missing core columns before export: {_missing_loco}"

        # Extra diagnostics just before LOCO save
        try:
            _s_loco = pd.to_numeric(df_loco_unified.get("score_cbf"), errors="coerce")
            _q_loco = _s_loco.quantile([0, .25, .5, .75, .9, 1]).round(4).to_dict()
            logger.info("[CBF][LOCO][pre-save] score_cbf quantiles %s", {str(k): float(v) for k, v in _q_loco.items() if pd.notna(v)})
            if "reason" in df_loco_unified.columns:
                _r_loco = df_loco_unified["reason"].value_counts(dropna=False).head(5).to_dict()
                logger.info("[CBF][LOCO][pre-save] reasons top-5 %s", {str(k): int(v) for k, v in _r_loco.items()})
        except (TypeError, ValueError, KeyError, AttributeError) as _pre_loco_diag_ex:
            logger.debug("[CBF][LOCO] pre-save diagnostics skipped: %s", _pre_loco_diag_ex)

        # [PRE-SAVE] If an earlier baseline (KNN-only) artifact exists, move it aside to avoid confusion
        try:
            if os.path.exists(_loco_path):
                _maybe_old = pd.read_csv(_loco_path)
                _baseline_like = False
                if isinstance(_maybe_old, pd.DataFrame) and not _maybe_old.empty:
                    try:
                        if "reason" in _maybe_old.columns and _maybe_old["reason"].nunique(dropna=False) == 1:
                            _baseline_like = True
                        if "score_cbf" in _maybe_old.columns:
                            _s_old = pd.to_numeric(_maybe_old["score_cbf"], errors="coerce")
                            if _s_old.nunique(dropna=True) == 1:
                                _baseline_like = True
                    except (KeyError, TypeError, ValueError, AttributeError):
                        pass
                if _baseline_like:
                    _baseline_path = os.path.splitext(_loco_path)[0] + "_baseline.csv"
                    try:
                        os.replace(_loco_path, _baseline_path)
                        logger.info("ℹ️ Moved baseline LOCO artifact to %s (pre-unified).", _baseline_path)
                    except OSError as _mv_err:
                        logger.warning("[CBF][LOCO] Could not move existing baseline LOCO file: %s", _mv_err)
        except (OSError, ValueError) as _pre_mv_err:
            logger.warning("[CBF][LOCO] Pre-save baseline check failed: %s", _pre_mv_err)
        df_loco_unified.to_csv(_loco_path, index=False, encoding="utf-8-sig")
        logger.info("✅ [UNIFIED LOCO] Overwrote %s with unified recommender results (k=%d).", _loco_path, k_lo)
        logger.info("[CBF][LOCO] Unified export confirmed at %s", _loco_path)

    except (KeyError, ValueError, TypeError, AssertionError, OSError) as _unified_loco_err:
        logger.warning("[CBF][LOCO] Unified LOCO override failed non‑fatally: %s", _unified_loco_err)
    # ======================= [/UNIFIED LOCO OVERRIDE] ==========================

except (OSError, ValueError, TypeError) as exp_err:
    logger.warning(
        "[CBF] Failed to write compressed FULL recommendations, retrying uncompressed. Error: %s",
        exp_err,
    )
    _full_export_path = "outputs/CBF/df_cbf_recommendations_full.csv"
    # Ensure the directory exists before fallback write
    try:
        os.makedirs(os.path.dirname(_full_export_path), exist_ok=True)
    except OSError as _mk_err:
        logger.warning("[CBF] Could not ensure FULL dir exists: %s", _mk_err)
    # Retry uncompressed write
    recommendations_to_write.to_csv(_full_export_path, index=False, encoding="utf-8-sig")
    # Mark FULL export as completed to avoid later overwrites by downstream saves
    _FULL_ALREADY_EXPORTED = True
    # Also reflect in locals guard variables used later in the pipeline
    try:
        locals()["_FULL_ALREADY_EXPORTED"] = True
        locals()["_full_export_path"] = _full_export_path
    except TypeError:
        # Do not escalate if locals() cannot be assigned; logging is sufficient
        pass


assert isinstance(recommendations, pd.DataFrame), "recommendations is not a DataFrame"
# --- [PATCH][MAIN] Coalesce/ensure enriched clinical fields on `recommendations` ---
# حافظ على الأعمدة السريرية حتى لو حصل حفظ لاحق من recommendations.

if "advice" not in recommendations.columns:
    recommendations["advice"] = pd.NA
# Unified minimal advice mapping (4 canonical texts) — keyed by feature_id
_ADVICE_MAP = {
    "lifestyle_monitoring": "إجراءات نمط الحياة والمتابعة المنتظمة للضغط.",
    "diet_control": "تقليل الصوديوم، حمية DASH، متابعة قياسات الضغط والدهون دورياً.",
    "ace_inhibitor": "مناقشة بدء/تعديل العلاج الدوائي الملائم، مع مراقبة الضغط والأعراض.",
    "exercise_program": "نشاط بدني منتظم (≈150 دقيقة/أسبوع) ثم إعادة تقييم خلال 4–6 أسابيع.",
}
if "explanation_clinical" not in recommendations.columns:
    recommendations["explanation_clinical"] = pd.NA

def _is_blank_str(x):
    import math
    if x is None:
        return True
    try:
        if isinstance(x, float) and math.isnan(x):
            return True
    except (TypeError, ValueError):
        pass
    xs = str(x).strip()
    return xs == "" or xs.lower() in {"nan", "none", "null", "unknown"}

# مولدات آمنة (نفس منطق FULL، مكررة هنا تحسبًا لاختصار مسار التنفيذ)
if "_make_explanation_clinical_full" not in locals():
    def _make_explanation_clinical_full(_row: pd.Series) -> str:
        try:
            bp   = str(_row.get("bp_category", "")).strip().lower()
            chol = str(_row.get("chol_category", "")).strip().lower()
            risk = str(_row.get("risk_level", "")).strip().lower()
            feat = str(_row.get("feature_id", "")).strip()
            if bp == "hypertension_stage_2" and chol in {"high", "borderline_high"}:
                base = "حالة خطورة مرتفعة: ضغط شديد" + (" وكوليسترول مرتفع" if chol == "high" else " وكوليسترول حدودي")
            elif bp == "hypertension_stage_1" and chol == "high":
                base = "ضغط مرتفع (درجة أولى) مع كوليسترول مرتفع"
            elif risk == "high":
                base = "مستوى خطورة مرتفع حسب السياق"
            elif risk == "medium":
                base = "مستوى خطورة متوسط حسب السياق"
            else:
                base = "مستوى خطورة منخفض/غير مرتفع"
            return f"{base}. التوصية مبنية على السياق السريري الحالي" + (f" وبالاقتران مع '{feat}'." if feat else ".")
        except (TypeError, ValueError, AttributeError):
            return "التوصية مبنية على السياق السريري ومؤشرات المخاطر."

if "_make_advice_full" not in locals():
    def _make_advice_full(_row: pd.Series) -> str:
        try:
            feat = str(_row.get("feature_id", "")).strip().lower()
            risk = str(_row.get("risk_level", "")).strip().lower()
            lifestyle_feats = {"increase_exercise", "diet_control", "lifestyle_monitoring"}
            pharm_feats     = {"amlodipine", "ace_inhibitor", "amlodipine_and_thiazide"}
            if feat in lifestyle_feats:
                if feat == "increase_exercise":
                    return "شجّع على نشاط بدني منتظم (150 دقيقة/أسبوع) والمتابعة خلال 4–6 أسابيع."
                if feat == "diet_control":
                    return "اتباع نمط غذائي منخفض الصوديوم وغني بالخضار مع مراجعة القياسات دوريًا."
                return "إجراءات نمط الحياة أولًا والمتابعة المنتظمة للضغط والدهون."
            if feat in pharm_feats:
                return "ناقش بدء/تعديل العلاج الدوائي المناسب مع الطبيب المعالج وفق الإرشادات، مع مراقبة الضغط والأعراض."
            if "knn" in str(_row.get("reason", "")).lower():
                return "اقتراح مبني على تشابه سياقي؛ يُفضّل مراجعة الحالة سريريًا قبل الاعتماد النهائي."
            if risk == "high":
                return "خطّة مُعزّزة: تقييم دوائي محتمل إضافةً لنمط الحياة، مع متابعة لصيقة."
            if risk == "medium":
                return "خطّة متوازنة: تحسين نمط الحياة أولًا وإعادة التقييم قريبًا."
            return "استمر بنمط الحياة الصحي والمتابعة الروتينية."
        except (TypeError, ValueError, AttributeError):
            return "اتّبع الإرشادات السريرية المناسبة للحالة مع متابعة القياسات."

# املأ الفارغ من recommendation نفسها (لا تعتمد على نسخة FULL فقط)
try:
    _mask_exp = recommendations["explanation_clinical"].apply(_is_blank_str)
    if _mask_exp.any():
        recommendations.loc[_mask_exp, "explanation_clinical"] = recommendations.loc[_mask_exp].apply(_make_explanation_clinical_full, axis=1)
except (KeyError, TypeError, ValueError, AttributeError):
    pass
# Local safe accessor for canonicalize_feature_id (avoid unresolved reference before later imports)
try:
    from utils.constants import canonicalize_feature_id as _canonicalize_feature_id  # type: ignore
except ImportError:
    _canonicalize_feature_id = lambda v: v  # no-op fallback
try:
    _mask_adv = recommendations["advice"].apply(_is_blank_str)
    if _mask_adv.any():
        # Canonicalize feature_id, then normalize to lowercase for consistent ADVICE_MAP lookup
        _feat_series_main = recommendations.loc[_mask_adv, "feature_id"].map(_canonicalize_feature_id).fillna(recommendations.loc[_mask_adv, "feature_id"])
        _feat_series_main = _feat_series_main.astype(str).str.strip().str.lower()
        recommendations.loc[_mask_adv, "advice"] = _feat_series_main.map(_ADVICE_MAP).fillna("")
except (KeyError, TypeError, ValueError, AttributeError):
    pass

# --- [/PATCH][MAIN] ---
logger.info(f"✅ Recommendations generated. Shape: {recommendations.shape}")

# [SANITIZE][FULL] unify feature_id in FULL recommendations
from utils.context_utils import sanitize_feature_id
from utils.constants import canonicalize_feature_id
if "feature_id" in recommendations.columns:
    try:
        recommendations.loc[:, "feature_id"] = recommendations["feature_id"].apply(sanitize_feature_id)
    except (TypeError, ValueError, AttributeError, KeyError) as _san_ex:
        logger.warning("[CBF][FULL] sanitize_feature_id on FULL skipped: %s", _san_ex)

# ===== [CBF][MAIN] Ensure unified scoring (reason + similarity → score_cbf) =====
try:
    try:
        # Prefer pipeline helpers; fall back to recommender helpers if needed
        from recommender.cbf import ensure_cbf_scores, postprocess_scores_cbf  # type: ignore
    except ImportError:
        from recommender.helperscbf import ensure_cbf_scores, postprocess_scores_cbf  # type: ignore
except Exception as _imp_main_sc:
    ensure_cbf_scores = None  # type: ignore
    postprocess_scores_cbf = None  # type: ignore
    logger.warning("[CBF][MAIN] scoring helpers import failed; continuing with raw recommendations: %s", _imp_main_sc)

if callable(locals().get("ensure_cbf_scores", None)):
    try:
        recommendations = ensure_cbf_scores(
            recommendations, config,
            reason_col="reason", sim_col="sim_cbf_raw",
            logger_obj=logger, log_id="CBF[MAIN]"
        )
        if callable(locals().get("postprocess_scores_cbf", None)):
            recommendations = postprocess_scores_cbf(
                recommendations, score_col="score_cbf", patient_col="patient_id"
            )
        # [PATCH] Normalize similarity source for narratives (so build_algorithmic_explanation picks it up)
        if "similarity" not in recommendations.columns:
            if "score_cbf_raw" in recommendations.columns:
                recommendations["similarity"] = recommendations["score_cbf_raw"]
            elif "sim_cbf_raw" in recommendations.columns:
                recommendations["similarity"] = recommendations["sim_cbf_raw"]
        # Light diagnostics
        try:
            _s_main = pd.to_numeric(recommendations.get("score_cbf"), errors="coerce")
            _q_main = _s_main.quantile([0, .25, .5, .75, .9, 1]).round(4).to_dict()
            logger.info("[CBF][MAIN] score_cbf quantiles %s", {str(k): float(v) for k, v in _q_main.items() if pd.notna(v)})
            if "reason" in recommendations.columns:
                _r_main = recommendations["reason"].value_counts(dropna=False).head(5).to_dict()
                logger.info("[CBF][MAIN] reasons top-5 %s", {str(k): int(v) for k, v in _r_main.items()})
        except (TypeError, ValueError, KeyError, AttributeError) as _diag_ex:
            logger.debug("[CBF][MAIN] diagnostics skipped: %s", _diag_ex)
    except (TypeError, ValueError, KeyError, AttributeError) as _score_ex:
        logger.warning("[CBF][MAIN] ensure_cbf_scores failed; proceeding with raw recommendations: %s", _score_ex)

# Save the MAIN recommendations (post-scoring) to standard artifacts
try:
    os.makedirs("outputs/CBF", exist_ok=True)
    # Assert core columns exist before saving MAIN artifacts
    _req_cols_main = ["patient_id"] + list(CONTEXT_COLUMNS)
    _missing_main = [c for c in _req_cols_main if c not in recommendations.columns]
    assert not _missing_main, f"[CBF][MAIN] Missing core columns before export: {_missing_main}"

    # Ensure unified scoring ran just before saving (idempotent, guarded)
    if callable(locals().get("ensure_cbf_scores", None)):
        try:
            recommendations = ensure_cbf_scores(
                recommendations, config,
                reason_col="reason", sim_col="sim_cbf_raw",
                logger_obj=logger, log_id="CBF[MAIN][pre-save]"
            )
        except (TypeError, ValueError, KeyError, AttributeError) as _ens_ex:
            logger.warning("[CBF][MAIN] ensure_cbf_scores pre-save skipped: %s", _ens_ex)
    if callable(locals().get("postprocess_scores_cbf", None)):
        try:
            recommendations = postprocess_scores_cbf(
                recommendations, score_col="score_cbf", patient_col="patient_id"
            )
        except (TypeError, ValueError, KeyError, AttributeError) as _pp_ex:
            logger.warning("[CBF][MAIN] postprocess_scores_cbf pre-save skipped: %s", _pp_ex)

    # Final safety: clip scores to [0,1] and avoid zero-y fills
    if "score_cbf" in recommendations.columns:
        recommendations.loc[:, "score_cbf"] = pd.to_numeric(
            recommendations["score_cbf"], errors="coerce"
        ).clip(0.0, 1.0)
        # إذا بقيت NaN، نملؤها بالوسيط لتجنب إدخال أصفار تشوّه الترتيب
        if recommendations["score_cbf"].isna().any():
            _median_score = recommendations["score_cbf"].median()
            if pd.notna(_median_score):
                recommendations.loc[:, "score_cbf"] = recommendations["score_cbf"].fillna(float(_median_score))

    # Diagnostics just before saving MAIN artifacts
    try:
        _s_main2 = pd.to_numeric(recommendations.get("score_cbf"), errors="coerce")
        _q_main2 = _s_main2.quantile([0, .25, .5, .75, .9, 1]).round(4).to_dict()
        logger.info("[CBF][MAIN][pre-save] score_cbf quantiles %s", {str(k): float(v) for k, v in _q_main2.items() if pd.notna(v)})
        if "reason" in recommendations.columns:
            _r_main2 = recommendations["reason"].value_counts(dropna=False).head(5).to_dict()
            logger.info("[CBF][MAIN][pre-save] reasons top-5 %s", {str(k): int(v) for k, v in _r_main2.items()})
    except (TypeError, ValueError, KeyError, AttributeError) as _pre_main_diag_ex:
        logger.debug("[CBF][MAIN] pre-save diagnostics skipped: %s", _pre_main_diag_ex)

    _main_path = "outputs/CBF/df_cbf_recommendations.csv"
    # Ensure audit columns once (idempotent), then reuse the same frame for all saves
    recommendations = _ensure_similarity_audit_cols(recommendations, config)
    # Save MAIN
    recommendations.to_csv(_main_path, index=False, encoding="utf-8-sig")

    # Avoid overwriting enriched FULL export written earlier in the pipeline.
    # If FULL was already exported (and enriched with advice/explanation_clinical),
    # skip writing to df_cbf_recommendations_full.csv here.
    if not locals().get("_FULL_ALREADY_EXPORTED", False):
        _full_main_path = "outputs/CBF/df_cbf_recommendations_full.csv"
        recommendations.to_csv(_full_main_path, index=False, encoding="utf-8-sig")
        logger.info("💾 [CBF][MAIN] Saved post-scoring recommendations to %s and %s", _main_path, _full_main_path)
    else:
        _full_main_path = locals().get("_full_export_path", "outputs/CBF/df_cbf_recommendations_full.csv")
        logger.info("💾 [CBF][MAIN] Saved post-scoring recommendations to %s (skipped secondary FULL overwrite; kept enriched FULL at %s)", _main_path, _full_main_path)
except (OSError, ValueError, TypeError) as _save_main_ex:
    logger.warning("[CBF][MAIN] Failed to save MAIN recommendations CSVs: %s", _save_main_ex)
# ===== [/CBF][MAIN] unified scoring & save =====


# ----------- After export: Ensure true_response exists and warn if missing -----------
s_tr_full, _tr_cols_full = _canonicalize_true_response(recommendations)
if (s_tr_full is None) or pd.to_numeric(s_tr_full, errors="coerce").isna().all():
    logger.warning("⚠️ Column 'true_response' is missing or all values are NaN after merging in FULL recommendations. Downstream steps will be skipped.")
    proceed_pipeline = False
else:
    if "true_response" not in recommendations.columns:
        recommendations.loc[:, "true_response"] = pd.to_numeric(s_tr_full, errors="coerce")
    else:
        recommendations.loc[:, "true_response"] = pd.to_numeric(recommendations["true_response"], errors="coerce")

# ---------- تصدير الحالات غير المغطاة لأي من feature_id_binned أو context_feature_id ----------
if export_heavy:
    export_uncovered_context_keys(df_encoded, output_dir="outputs/CBF")
else:
    logger.debug("[DEBUG] Heavy artifact export disabled: uncovered/coverage artifacts")

# ---------- فلتر سريري لاستبعاد التوصيات غير المنطقية ----------
def clinical_filter(rec_row):
    if rec_row.get('bp_category') == "hypertension_stage_2" and rec_row.get('chol_category') == "high" and rec_row.get('feature_id') == "diet_control":
        return False
    return True
if all(col in recommendations.columns for col in ["bp_category", "chol_category", "feature_id"]):
    recommendations = recommendations[recommendations.apply(clinical_filter, axis=1)]
    # [PATCH] Ensure score_cbf is preserved after clinical filter
    if "score_cbf" not in recommendations.columns:
        logger.warning("[PATCH] score_cbf column was missing after operation, filling with None.")
        recommendations["score_cbf"] = None

s_tr_dedup, _tr_cols_dedup = _canonicalize_true_response(recommendations)
if (s_tr_dedup is None) or pd.to_numeric(s_tr_dedup, errors="coerce").isna().all():
    logger.warning("⚠️ Column 'true_response' is missing or all values are NaN after merging in deduplicated recommendations. Downstream steps will be skipped.")
    proceed_pipeline = False
else:
    if "true_response" not in recommendations.columns:
        recommendations.loc[:, "true_response"] = pd.to_numeric(s_tr_dedup, errors="coerce")
    else:
        recommendations.loc[:, "true_response"] = pd.to_numeric(recommendations["true_response"], errors="coerce")

    # ---------- تجهيز وتوحيد الأعمدة النهائية لملف التوصيات ----------
    # استخدم ترتيب الأعمدة القادم من config لضمان الاتساق عبر الطبقات
    if "source" not in recommendations.columns:
        recommendations["source"] = None
    if "explanation_clinical" not in recommendations.columns:
        recommendations["explanation_clinical"] = None

    # اجمع الأعمدة النهائية من config، وأضمن تضمين true_response إذا كانت موجودة في الداتا
    final_columns = [c for c in cbf_output_columns if c in recommendations.columns]
    if ("true_response" in recommendations.columns) and ("true_response" not in final_columns):
        final_columns.append("true_response")

    # أنشئ النسخة النهائية
    recommendations_final = recommendations.loc[:, final_columns].copy()
    # --- Console-only sample (print just once) ---
    try:
        if isinstance(recommendations_final, pd.DataFrame) and not recommendations_final.empty:
            print("Recommendation sample:")
            # يعرض 5 صفوف فقط — Pandas repr الافتراضي
            print(recommendations_final.head(5))
    except (ValueError, TypeError, AttributeError) as _e_sample:
        logger.warning("[CBF][PRINT] Failed to print recommendation sample: %s", _e_sample)

    # تأكد من صحة feature_id
    if "feature_id" in recommendations_final.columns:
        recommendations_final.loc[:, "feature_id"] = recommendations_final["feature_id"].apply(sanitize_feature_id)
        unknown_ids_final = set(recommendations_final["feature_id"].unique()) - ALLOWED_FEATURE_IDS
        if unknown_ids_final:
            logger.warning(f"[CBF] [FINAL] تحذير: توجد قيم غير معروفة في feature_id النهائي: {unknown_ids_final}")

    # تأكد من وجود score_cbf
    if "score_cbf" not in recommendations_final.columns:
        logger.warning("[PATCH] score_cbf column was missing after operation, filling with None.")
        recommendations_final["score_cbf"] = None

    # Ensure minimal dtypes to reduce memory/IO
    _downcast_context_cats(recommendations_final, ["bp_category","chol_category","age_group","risk_level","fbs_cat","cp_cat","feature_id"])

    # تطبيع الأعمدة الحرجة لمنع أي اختلاف بالكتابة بين القيم
    for col in ["feature_id", "bp_category", "chol_category", "age_group", "risk_level", "fbs_cat", "cp_cat"]:
        if col in recommendations_final.columns:
            recommendations_final.loc[:, col] = recommendations_final[col].astype(str).apply(normalize_context_value)

    # توحيد/إنشاء true_response إن أمكن
    s_tr_fin_pre, _ = _canonicalize_true_response(recommendations_final)
    if s_tr_fin_pre is not None:
        recommendations_final.loc[:, "true_response"] = pd.to_numeric(s_tr_fin_pre, errors="coerce")
    elif "target" in recommendations.columns:
        # كحل احتياطي: اجلب من target إن كان موجوداً في الداتا الأصلية
        try:
            recommendations_final.loc[:, "true_response"] = pd.to_numeric(recommendations["target"], errors="coerce")
            logger.warning("✅ [FINAL PATCH] true_response filled from 'target' because it was missing from final columns.")
        except (KeyError, ValueError, TypeError) as _e:
            logger.warning(f"[FINAL PATCH] Unable to fill true_response from target: {_e}")

    assert isinstance(recommendations_final, pd.DataFrame), "recommendations_final must be a DataFrame before saving"

    # إذا ظل عمود true_response غير موجود أو كلّه NaN، لا نفشل بالـ assert — نسجّل تحذيرًا ونعطّل خطوات التقييم لاحقًا
    if "true_response" not in recommendations_final.columns or recommendations_final["true_response"].isnull().all():
        logger.warning("⚠️ 'true_response' غير موجود أو كلّه NaN في المخرجات النهائية. سيتم تخطي التقييم لاحقًا.")
        proceed_pipeline = False

    # ---------- Normalize context columns in final recommendations ----------
    for col in ["bp_category", "chol_category", "age_group", "risk_level", "fbs_cat", "cp_cat", "feature_id"]:
        if col in recommendations_final.columns:
            recommendations_final.loc[:, col] = recommendations_final[col].apply(normalize_context_value)
    if "true_response" in recommendations_final.columns:
        recommendations_final.loc[:, "true_response"] = pd.to_numeric(recommendations_final["true_response"], errors="coerce")

# ----------- إزالة التكرارات وضمان uniqueness -----------
# حذف التكرار فقط إذا كان هناك صف مطابق 100% في الأعمدة السياقية الأساسية + feature_id
_final_df = locals().get("recommendations_final", None)
if isinstance(_final_df, pd.DataFrame):
    dedup_cols_final = ["patient_id"] + list(CONTEXT_COLUMNS) + ["feature_id"]
    dedup_cols_final = [col for col in dedup_cols_final if col in _final_df.columns]
    before_final_dedup = _final_df.shape[0]
    _final_df = _final_df.drop_duplicates(subset=dedup_cols_final)
    after_final_dedup = _final_df.shape[0]
    logger.info(f"[CBF] (final) حذف التكرار على الأعمدة {dedup_cols_final}. عدد الصفوف قبل: {before_final_dedup} | بعد: {after_final_dedup} | الفرق: {before_final_dedup - after_final_dedup}")
    logger.info(f"[CBF] (final) تحقق uniqueness بعد الحذف: {_final_df.duplicated(subset=dedup_cols_final).sum()} صف مكرر متبقٍ (يجب أن يكون 0)")

    # [PATCH] Ensure score_cbf is preserved after deduplication
    if "score_cbf" not in _final_df.columns:
        logger.warning("[PATCH] score_cbf column was missing after operation, filling with None.")
        _final_df["score_cbf"] = None

    # write back
    recommendations_final = _final_df
else:
    logger.warning("[CBF] recommendations_final is undefined at dedup stage; skipping deduplication.")


# ---------- Log unique context values after normalization ----------
_final_df = locals().get("recommendations_final", None)
if isinstance(_final_df, pd.DataFrame):
    cols_to_check = ["bp_category", "chol_category", "age_group", "risk_level", "fbs_cat", "cp_cat"]
    for col in cols_to_check:
        if col in _final_df.columns:
            _series = _final_df[col]
            # Ensure we have a pandas Series; بعض اللنترز يشتكي من الأنواع
            if not isinstance(_series, pd.Series):
                _series = pd.Series(_series)
            try:
                uniques = _series.unique()
            except AttributeError:
                # Fallback: numpy unique إذا تعذّر .unique()
                uniques = pd.unique(pd.Series(_series).to_numpy())
            logger.info(f"[CHECK] Unique values in {col}: {uniques}")
            # تحذير لو وُجدت فراغات/unknown
            _empties = {"", "nan", "none", "unknown"}
            has_problem = _series.isna().any() or any(str(v).strip().lower() in _empties for v in uniques)
            if has_problem:
                logger.warning(f"[WARNING] Empty/NaN/unknown values in {col}: {uniques}")
else:
    logger.warning("[CBF] recommendations_final is undefined; skipping unique-context values logging.")

# ----------- Log بعد حذف التكرار -----------
if 'recommendations_final' in locals():
    logger.info(f"✅ Duplicates dropped. Final recommendations shape: {recommendations_final.shape}")

    # استيراد مباشر للدالة الفعلية بدون أسماء مختصرة/مخترعة
    evaluate_cbf_full = None  # type: ignore[assignment]
    try:
        from utils.evaluation import evaluate_cbf_full  # المسار المفضل
    except ImportError:
        try:
            from pipeline.evaluation import evaluate_cbf_full  # مسار بديل
        except ImportError:
            try:
                from evaluation import evaluate_cbf_full  # مسار قديم محتمل
            except ImportError:
                evaluate_cbf_full = None

    if callable(evaluate_cbf_full):
        # Derive k from config (prefer recommendation.top_n_eval, else evaluation.k_at, default=5)
        try:
            k_eval = int((config.get("recommendation", {}) or {}).get("top_n_eval",
                          (config.get("evaluation", {}) or {}).get("k_at", 5)))
        except (TypeError, ValueError, AttributeError):
            k_eval = 5
        try:
            evaluate_cbf_full(recommendations_final, k=k_eval, score_col="score_cbf")
        except TypeError:
            # If the signature does not support named args, fall back to positional
            try:
                evaluate_cbf_full(recommendations_final, k_eval)
            except Exception as eval_err2:
                logger.warning("[CBF][EVAL] Evaluation failed: %s", eval_err2)
    else:
        logger.warning("[CBF][EVAL] evaluate_cbf_full not available; skipping immediate full-eval call.")
else:
    logger.warning("[CBF] recommendations_final is undefined at post-dedup summary stage; skipping shape log.")

#
# ----------- تحقق من وجود جميع الأعمدة السياقية المطلوبة -----------
# الأعمدة الجوهرية تأتي حصراً من utils.constants.CONTEXT_COLUMNS (bp_category, chol_category, risk_level)
try:
    from utils.constants import CONTEXT_COLUMNS as _CORE_CTX_COLS
except ImportError:
    _CORE_CTX_COLS = ["bp_category", "chol_category", "risk_level"]  # fallback aligned with our minimal API

# ابدأ بالقائمة الجوهرية فقط؛ أضف age_group اختيارياً إن وُجد في الإطار النهائي
required_context_cols: list[str] = list(_CORE_CTX_COLS)

if 'recommendations_final' in locals() and isinstance(recommendations_final, pd.DataFrame):
    if "age_group" in recommendations_final.columns:
        required_context_cols.append("age_group")
    _missing_cols = [c for c in required_context_cols if c not in recommendations_final.columns]
    if _missing_cols:
        logger.error(f"❌ Missing contextual columns in output: {_missing_cols}")
        raise ValueError(f"Missing contextual columns in output: {_missing_cols}")
else:
    logger.warning("[CBF] recommendations_final is undefined or invalid; skipping required contextual columns check.")

#
# Diagnostics on final output
try:
    if "score_cbf" in recommendations_final.columns and recommendations_final["score_cbf"].notna().any():
        _qs_final = recommendations_final["score_cbf"].quantile([0, 0.25, 0.5, 0.75, 1]).to_dict()
        logger.info(
            "[CBF][FINAL] score_cbf quantiles: %s",
            {str(k): float(v) for k, v in _qs_final.items()}
        )
    if "reason" in recommendations_final.columns:
        _dist_final = (
            recommendations_final["reason"].astype(str)
            .value_counts(normalize=True, dropna=False)
            .sort_values(ascending=False)
        )
        logger.info(
            "[CBF][FINAL] reason distribution: %s",
            {k: round(float(v), 4) for k, v in _dist_final.to_dict().items()}
        )
except (TypeError, ValueError) as _dbg_err:
    logger.warning("[CBF][FINAL] Diagnostics failed: %s", _dbg_err)

# ---------- 10. Save Results -------------
# --- Acceptance gate: reason distribution & score diagnostics ---
try:
    _rec_final = locals().get("recommendations_final", None)
    if isinstance(_rec_final, pd.DataFrame) and not _rec_final.empty:
        # reason distribution (محروس)
        if "reason" in _rec_final.columns:
            _ser_reason = pd.Series(_rec_final["reason"])
            _reason_dist = (
                _ser_reason.astype(str)
                .value_counts(normalize=True, dropna=False)
                .to_dict()
            )
            _share_exact = float(_reason_dist.get("recommended", 0.0)
                                 + _reason_dist.get("context_key_match", 0.0))
            _share_knn = float(_reason_dist.get("knn_recommendation", 0.0))
            logger.info("[CBF][GATE] reason shares: exact=%.3f, knn=%.3f", _share_exact, _share_knn)
            if _share_knn < 0.30:
                logger.warning(
                    "[CBF][GATE] knn_recommendation share %.2f < 0.30. Consider lowering min_similarity by 0.05 and increasing k by +2, and enabling an extra backoff stage.",
                    _share_knn
                )
        # score_cbf quantiles (محروس)
        if "score_cbf" in _rec_final.columns:
            _ser_score = _rec_final["score_cbf"]
            if not isinstance(_ser_score, pd.Series):
                _ser_score = pd.Series(_ser_score)
            _sc = pd.to_numeric(_ser_score, errors="coerce")
            if _sc.notna().any():
                _qs = _sc.quantile([0, 0.5, 0.75, 0.9, 1.0]).to_dict()
                logger.info("[CBF][FINAL] score_cbf quantiles (min/med/q75/q90/max): %s",
                            {str(k): float(v) for k, v in _qs.items()})
except (KeyError, TypeError, AttributeError, ValueError) as _gate_err:
    logger.warning("[CBF][GATE] Diagnostics failed non-fatally: %s", _gate_err)

if 'recommendations_final' in locals():
    logger.info(f"💾 Saving recommendations to: {output_path}")
    # [SANITIZE][FINAL] canonicalize feature_id before export
    if "feature_id" in recommendations_final.columns:
        try:
            recommendations_final.loc[:, "feature_id"] = recommendations_final["feature_id"].map(canonicalize_feature_id).fillna(recommendations_final["feature_id"])
        except (TypeError, ValueError, AttributeError, KeyError) as _can_ex:
            logger.warning("[CBF][FINAL] canonicalize_feature_id skipped: %s", _can_ex)
    # Drop helper similarity column from FINAL export
    if "sim_cbf_raw" in recommendations_final.columns:
        recommendations_final = recommendations_final.drop(columns=["sim_cbf_raw"])
    # [PATCH] Ensure score_cbf is present before export
    if "score_cbf" not in recommendations_final.columns:
        logger.warning("[PATCH] score_cbf column was missing before export, filling with None.")
        recommendations_final["score_cbf"] = None

    # --- [PATCH][FINAL ENRICH] Fill blank clinical texts and normalize scores before export ---
    try:
        # Fill missing/blank clinical explanation based on final context if available
        if "explanation_clinical" in recommendations_final.columns:
            _mask_exp_final = recommendations_final["explanation_clinical"].apply(_is_blank_str)
            if _mask_exp_final.any():
                recommendations_final.loc[_mask_exp_final, "explanation_clinical"] = (
                    recommendations_final.loc[_mask_exp_final].apply(_make_explanation_clinical_full, axis=1)
                )
        # Fill missing/blank advice strictly from the 4-text map (no derivation from explanation)
        if "advice" in recommendations_final.columns:
            _mask_adv_final = recommendations_final["advice"].apply(_is_blank_str)
            if _mask_adv_final.any():
                # Canonicalize feature_id first to ensure stable mapping keys
                _feat_series_final = recommendations_final.loc[_mask_adv_final, "feature_id"].map(_canonicalize_feature_id).fillna(recommendations_final.loc[_mask_adv_final, "feature_id"])
                _feat_series_final = _feat_series_final.astype(str).str.strip().str.lower()
                recommendations_final.loc[_mask_adv_final, "advice"] = (
                    _feat_series_final.map(_ADVICE_MAP).fillna("")
                )
    except (KeyError, TypeError, ValueError, AttributeError) as _enrich_final_ex:
        logger.debug("[CBF][FINAL ENRICH] Skipped clinical enrich (non-fatal): %s", _enrich_final_ex)

    # Normalize/clip score_cbf to [0,1] and fill remaining NaNs with median (final layer)
    try:
        if "score_cbf" in recommendations_final.columns:
            _sc_final = pd.to_numeric(recommendations_final["score_cbf"], errors="coerce")
            _sc_final = _sc_final.clip(0.0, 1.0)
            if _sc_final.isna().any():
                _med_final = _sc_final.median()
                if pd.notna(_med_final):
                    _sc_final = _sc_final.fillna(float(_med_final))
            recommendations_final.loc[:, "score_cbf"] = _sc_final
    except (TypeError, ValueError, KeyError, AttributeError) as _sc_norm_final_ex:
        logger.debug("[CBF][FINAL ENRICH] Score normalization skipped (non-fatal): %s", _sc_norm_final_ex)

    # [SANITIZE][FINAL] extra safety sanitize on feature_id (idempotent)
    try:
        from utils.context_utils import sanitize_feature_id as _sanitize_fid_final
    except ImportError:
        _sanitize_fid_final = None
    if callable(_sanitize_fid_final) and "feature_id" in recommendations_final.columns:
        try:
            recommendations_final.loc[:, "feature_id"] = recommendations_final["feature_id"].apply(_sanitize_fid_final)
        except (TypeError, ValueError, AttributeError, KeyError) as _san_fid_ex:
            logger.debug("[CBF][FINAL] sanitize_feature_id skipped (non-fatal): %s", _san_fid_ex)
    # [CRITICAL PATCH] true_response safety and export check
    # --- Canonicalized true_response guard before export ---
    s_tr_fin, _ = _canonicalize_true_response(recommendations_final)
    _all_nan_true_response = (s_tr_fin is None) or bool(pd.to_numeric(s_tr_fin, errors="coerce").isna().all())
    if _all_nan_true_response:
        if "target" in recommendations_final.columns and not recommendations_final["target"].isnull().all():
            recommendations_final = recommendations_final.drop(columns=[c for c in recommendations_final.columns if (c == "true_response") or c.startswith("true_response")], errors="ignore")
            recommendations_final.loc[:, "true_response"] = pd.to_numeric(recommendations_final["target"], errors="coerce")
            logger.warning("✅ [FINAL PATCH] true_response filled automatically from target before export.")
        else:
            logger.error("❌ Neither true_response nor target available or filled before final export! Skipping downstream steps.")
            proceed_pipeline = False
    s_tr_fin2, _ = _canonicalize_true_response(recommendations_final)
    assert s_tr_fin2 is not None and not pd.to_numeric(s_tr_fin2, errors="coerce").isna().all(), \
        "كل القيم في true_response فارغة أو مفقودة في ملف التوصيات النهائي! توقف التصدير."
    # --- Export-time score normalization and default fills (config-driven; no row deletions)
    rec_cfg = config.get("recommendation", {})
    if "score_cbf" in recommendations_final.columns and rec_cfg.get("clip_scores", True):
        recommendations_final.loc[:, "score_cbf"] = recommendations_final["score_cbf"].clip(0.0, 1.0).round(6)
    fill_defaults = rec_cfg.get("fill_defaults", {"true_response": 0, "reason": "", "explanation": "", "source": ""})
    for _c, _v in fill_defaults.items():
        if _c in recommendations_final.columns:
            recommendations_final[_c] = recommendations_final[_c].fillna(_v)

    # --- Sanitize or drop optional columns in FINAL export as well ---
    _maybe_optional_cols = [
        "chol_bins", "restecg_cat", "exang_cat", "oldpeak_cat", "ca_cat", "thal_cat"
    ]
    try:
        _cfg_out_cols = set((config.get("output_columns", {}) or {}).get("cbf", []) or [])
    except (AttributeError, KeyError, TypeError, ValueError):
        _cfg_out_cols = set()
    for _c in _maybe_optional_cols:
        if _c in recommendations_final.columns:
            _all_na = recommendations_final[_c].isna().all()
            if (_c not in _cfg_out_cols) or _all_na:
                recommendations_final.drop(columns=[_c], inplace=True, errors="ignore")
            else:
                recommendations_final[_c] = recommendations_final[_c].fillna("unknown")

    try:
        # [FINAL] حقن explanation/source وتقوية advice قبل الحفظ
        recommendations_final = _fill_algo_explain_and_source(recommendations_final)
        recommendations_final = _fill_advice_fallbacks(recommendations_final)
        _final_path = output_path
        if len(recommendations_final) > 100_000 and not output_path.endswith('.gz'):
            _final_path = output_path + ".gz"
            recommendations_final.to_csv(_final_path, index=False, encoding="utf-8-sig", compression="gzip")
        else:
            recommendations_final = _ensure_similarity_audit_cols(recommendations_final, config)
            recommendations_final.to_csv(_final_path, index=False, encoding="utf-8-sig")
        logger.info("💾 Saved recommendations to: %s", _final_path)
    except (OSError, ValueError) as save_err:
        logger.warning("[CBF] Failed to write compressed final recommendations, retrying uncompressed. Error: %s", save_err)
        recommendations_final = _ensure_similarity_audit_cols(recommendations_final, config)
        recommendations_final.to_csv(output_path, index=False, encoding="utf-8-sig")
else:
    logger.error("[CBF] recommendations_final is undefined; skipping final export.")

# --------- After saving unique recommendations, check true_response -----------
if 'recommendations_final' in locals():
    s_tr_check, _ = _canonicalize_true_response(recommendations_final)
    if (s_tr_check is None) or pd.to_numeric(s_tr_check, errors="coerce").isna().all():
        logger.warning("⚠️ Column 'true_response' is missing or all values are NaN in unique recommendations. Downstream steps will be skipped.")
        proceed_pipeline = False
    else:
        recommendations_final.loc[:, "true_response"] = pd.to_numeric(s_tr_check, errors="coerce")
else:
    proceed_pipeline = False

if proceed_pipeline and 'recommendations_final' in locals():
    # ----------- تقييم CBF الكامل (جميع التركيبات) وتصدير النتائج -----------
    from utils.evaluation import evaluate_cbf_full, evaluate_cbf_unique

    # Always reload after true_response merge/saving
    df_full = recommendations.copy()
    for col in ["feature_id", "bp_category", "chol_category", "age_group", "risk_level", "fbs_cat", "cp_cat"]:
        if col in df_full.columns:
            df_full.loc[:, col] = df_full[col].astype(str).apply(normalize_context_value)
    s_tr_eval, _cols_eval = _canonicalize_true_response(df_full)
    if (s_tr_eval is None) or bool(pd.to_numeric(s_tr_eval, errors="coerce").isna().all()):
        logger.warning(
            "⚠️ Column 'true_response' is missing or all values are NaN in recommendations (test set). Skipping evaluation.")
    else:
        df_full.loc[:, "true_response"] = pd.to_numeric(s_tr_eval, errors="coerce")

        # --- [CBF][CALIB] Train isotonic calibrator if enabled (post_calibration=isotonic) ---
        # Safely pull calibration mode without broad exceptions
        _scoring = (config.get("scoring", {}) or {}) if isinstance(config, dict) else {}
        _cbf_mix = (_scoring.get("cbf_mix", {}) or {})
        _post_calib = str(_cbf_mix.get("post_calibration", "")).strip().lower()
        if _post_calib == "isotonic":
            try:
                from pipeline.helperscbf import fit_and_save_isotonic  # type: ignore
            except ImportError as _imp_err:
                fit_and_save_isotonic = None  # type: ignore
                logger.warning("[CBF][CALIB] fit_and_save_isotonic import failed: %s", _imp_err)
            if callable(fit_and_save_isotonic):
                # Build calibration frame (scores + labels), drop NaNs, and require a minimum sample size
                try:
                    _df_cal = df_full.copy()
                    _df_cal = _df_cal[(_df_cal["score_cbf"].notna()) & (_df_cal["true_response"].notna())]
                    if len(_df_cal) >= 20:
                        fit_and_save_isotonic(
                            _df_cal,
                            score_col="score_cbf",
                            label_col="true_response",
                            min_samples=20
                        )
                        logger.info("[CBF][CALIB] Isotonic model trained on %d rows.", len(_df_cal))
                    else:
                        logger.warning("[CBF][CALIB] Not enough rows for isotonic calibration (n=%d). Skipping.", len(_df_cal))
                except (RuntimeError, ValueError, TypeError, KeyError, AttributeError, OSError) as _cal_err:
                    logger.warning("[CBF][CALIB] Isotonic calibration failed non-fatally: %s", _cal_err)
        metrics_full = evaluate_cbf_full(df_full, k=5, score_col="score_cbf")
        pd.DataFrame([metrics_full]).to_csv("outputs/CBF/cbf_eval_full.csv", index=False, encoding="utf-8-sig")
        logger.info("Full CBF evaluation: %s", metrics_full)

    # ----------- تقييم CBF الفريد (سياقات فريدة فقط) وتصدير النتائج -----------
    df_unique = recommendations_final.copy()
    for col in ["feature_id", "bp_category", "chol_category", "age_group", "risk_level", "fbs_cat", "cp_cat"]:
        if col in df_unique.columns:
            df_unique[col] = df_unique[col].astype(str).apply(normalize_context_value)
    if "true_response" in df_unique.columns:
        df_unique["true_response"] = pd.to_numeric(df_unique["true_response"], errors="coerce")
    if "true_response" not in df_unique.columns or df_unique["true_response"].isnull().all():
        logger.warning("⚠️ Column 'true_response' is missing or all values are NaN in recommendations_final (test set). Skipping evaluation.")
    else:
        metrics_unique = evaluate_cbf_unique(df_unique, k=5, score_col="score_cbf")  # [CBF] Ensure evaluation uses score_cbf for ranking
        pd.DataFrame([metrics_unique]).to_csv("outputs/CBF/cbf_eval_unique.csv", index=False, encoding="utf-8-sig")
        logger.info("Unique context CBF evaluation: %s", metrics_unique)
    logger.info("✅ CBF evaluation (full & unique) completed and results exported to cbf_eval_full.csv and cbf_eval_unique.csv.")

    # === Structured run-summary helpers (single, neat console block) ===
    def _safe_quantiles(series_like) -> dict:
        try:
            _q_series = pd.to_numeric(series_like, errors="coerce")
            if not hasattr(_q_series, "dropna"):
                _q_series = pd.Series(_q_series)
            _q_non_null = _q_series.dropna()
            if _q_non_null.empty:
                return {}
            qs = _q_non_null.quantile([0.0, 0.25, 0.5, 0.75, 0.9, 1.0]).to_dict()
            return {str(k): float(v) for k, v in qs.items()}
        except (TypeError, ValueError, AttributeError):
            return {}

    def _share_reasons(df_in) -> dict:
        if df_in is None or not hasattr(df_in, "empty") or df_in.empty or "reason" not in df_in.columns:
            return {}
        try:
            vc = df_in["reason"].astype(str).value_counts(normalize=True, dropna=False)
            return {k: round(float(v), 4) for k, v in vc.to_dict().items()}
        except (TypeError, ValueError, AttributeError, KeyError) as _sr_err:
            return {}

    def render_cbf_run_summary(
            recommendations_final_in=None,
            metrics_full_in: dict | None = None,
            metrics_unique_in: dict | None = None,
            k_eval_in: int | None = None,
            output_paths_in: dict | None = None,
            df_shapes_in: dict | None = None,
        ) -> str:
        import datetime

        lines: list[str] = []
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines.append("====== ملخص تشغيل CBF ======")
        lines.append(f"الوقت: {now}")

        # Shapes
        if isinstance(df_shapes_in, dict):
            tr = df_shapes_in.get("train")
            va = df_shapes_in.get("val")
            te = df_shapes_in.get("test")
            lines.append(f"أحجام البيانات — train={tr} | val={va} | test={te}")

        # Reasons & score quantiles
        rec_final = recommendations_final_in
        try:
            reason_dist = _share_reasons(rec_final) if rec_final is not None else {}
            score_series = None
            if isinstance(rec_final, pd.DataFrame) and "score_cbf" in rec_final.columns:
                score_series = rec_final["score_cbf"]
            score_q = _safe_quantiles(score_series) if score_series is not None else {}
        except (TypeError, ValueError, AttributeError, KeyError):
            reason_dist, score_q = {}, {}

        if reason_dist:
            lines.append(f"توزيع الأسباب (FINAL): {reason_dist}")
        if score_q:
            _quantile_label_map_local = {"0.0": "min", "0.25": "p25", "0.5": "p50", "0.75": "p75", "0.9": "p90", "1.0": "max"}
            score_fmt = {
                (_quantile_label_map_local.get(k, k) if isinstance(k, str) else _quantile_label_map_local.get(str(k), k)): round(v, 6)
                for k, v in score_q.items()
            }
            lines.append(f"score_cbf — {score_fmt}")

        # Metrics
        if isinstance(k_eval_in, int) and k_eval_in > 0:
            if isinstance(metrics_full_in, dict) and metrics_full_in:
                lines.append(
                    f"تقييم FULL@{k_eval_in}: "
                    f"P={metrics_full_in.get('precision@k'):.4f} | "
                    f"R={metrics_full_in.get('recall@k'):.4f} | "
                    f"nDCG={metrics_full_in.get('ndcg@k'):.4f} | "
                    f"MAP={metrics_full_in.get('map@k'):.4f}"
                )
            if isinstance(metrics_unique_in, dict) and metrics_unique_in:
                lines.append(
                    f"تقييم UNIQUE@{k_eval_in}: "
                    f"P={metrics_unique_in.get('precision@k'):.4f} | "
                    f"R={metrics_unique_in.get('recall@k'):.4f} | "
                    f"nDCG={metrics_unique_in.get('ndcg@k'):.4f} | "
                    f"MAP={metrics_unique_in.get('map@k'):.4f}"
                )

        # Output files
        if isinstance(output_paths_in, dict) and output_paths_in:
            paths_line = " | ".join(f"{k}={v}" for k, v in output_paths_in.items() if v)
            if paths_line:
                lines.append(f"ملفات الناتج: {paths_line}")

        lines.append("================================")
        return "\n".join(lines)

    try:
        _paths = {
            "full_csv": locals().get("_full_export_path", None),
            "final_csv": locals().get("_final_path", output_path),
            "eval_full": "outputs/CBF/cbf_eval_full.csv",
            "eval_unique": "outputs/CBF/cbf_eval_unique.csv",
        }
        _shapes = {
            "train": df_train.shape if 'df_train' in locals() else None,
            "val": df_val.shape if 'df_val' in locals() else None,
            "test": df_test.shape if 'df_test' in locals() else None,
        }
        _summary_txt = render_cbf_run_summary(
            recommendations_final_in=locals().get("recommendations_final", None),
            metrics_full_in=locals().get("metrics_full", None),
            metrics_unique_in=locals().get("metrics_unique", None),
            k_eval_in=locals().get("k_eval", None),
            output_paths_in=_paths,
            df_shapes_in=_shapes,
        )
        logger.info("\n%s", _summary_txt)
    except (ValueError, TypeError, KeyError, AttributeError) as _sum_err:
        logger.warning("[CBF][SUMMARY] Unable to render run summary: %s", _sum_err)

    # --- Robust import for per-patient Top-K capping ---
    try:
        from pipeline.helperscbf import cap_topk_per_patient  # preferred public name
    except ImportError:  # fallback to underscore variant, if that's what's defined
        try:
            from pipeline.helperscbf import _cap_topk_per_patient as cap_topk_per_patient  # type: ignore
        except ImportError:
            cap_topk_per_patient = None  # type: ignore

    # Prefer CBF-specific evaluators; no CF/utils fallback to avoid cross-system coupling
    try:
        from pipeline.helperscbf import (  # type: ignore
            evaluate_recommendations_loco,
            evaluate_recommendations_loco_family,
        )
    except ImportError:
        evaluate_recommendations_loco = None           # type: ignore
        evaluate_recommendations_loco_family = None    # type: ignore

    # === [CBF][EVAL][pre] — LOCO metrics before any extra eval caps (per-patient, optional per-row replication) ===
    try:
        from utils.evaluation import ranking_at_k, summarize_loco  # local project module
    except ImportError:
        ranking_at_k = None  # type: ignore
        summarize_loco = None  # type: ignore

    try:
        # Resolve K and required column names from config (falling back safely)
        _eval_cfg = (config.get("evaluation", {}) or {}) if isinstance(config, dict) else {}
        _rec_cfg = (config.get("recommendation", {}) or {}) if isinstance(config, dict) else {}
        _k_at = int(_rec_cfg.get("top_n_eval", _eval_cfg.get("k_at", 5)))
    except (TypeError, ValueError, AttributeError):
        _k_at = 5

    _score_col = "score_cbf"
    _truth_col = "true_response"
    _group_key = ("patient_id",)


    def _safe_numeric_series(s):
        import pandas as _pd
        if s is None:
            return _pd.Series(dtype="float64")
        try:
            # Fast path for Series/array-like
            return _pd.to_numeric(s, errors="coerce")
        except (TypeError, ValueError, AttributeError):
        # Fallback: wrap scalars or odd types into a Series, then coerce
            return _pd.to_numeric(_pd.Series(s), errors="coerce")
        except (TypeError, ValueError, AttributeError):
            return _pd.Series(dtype="float64")

    def _has_non_na(values):
        import pandas as _pd
        try:
            s = _pd.Series(values)
            return s.notna().any()
        except (TypeError, ValueError, AttributeError):
            return False

    # We prefer the **final** CBF frame as the evaluation base because it already has merged truth and sanitation.
    _eval_base = locals().get("recommendations_final", None)
    if not isinstance(_eval_base, pd.DataFrame) or _eval_base.empty:
        _eval_base = locals().get("recommendations", None)

    if isinstance(_eval_base, pd.DataFrame) and (_score_col in _eval_base.columns):
        # Ensure required columns are well-typed
        try:
            if _truth_col in _eval_base.columns:
                _eval_base.loc[:, _truth_col] = _safe_numeric_series(_eval_base[_truth_col]).fillna(0).astype(int)
            _eval_base.loc[:, _score_col] = _safe_numeric_series(_eval_base[_score_col]).fillna(0.0).clip(0.0, 1.0)
        except (TypeError, ValueError, KeyError, AttributeError) as _eval_cast_ex:
            logger.warning("[CBF][EVAL][pre] Coercion failed (continuing): %s", _eval_cast_ex)

        # Only run if true_response exists with at least one non-NaN value
        _truth_exists = (_truth_col in _eval_base.columns)
        _truth_series = _eval_base[_truth_col] if _truth_exists else None
        _can_eval = bool(_truth_exists and _has_non_na(_truth_series))
        if _can_eval and callable(ranking_at_k) and callable(summarize_loco):
            try:
                _rows_accum = []
                _loco_df = None
                for _kind, _payload in ranking_at_k(
                    _eval_base, k=_k_at, score_col=_score_col, truth_col=_truth_col,
                    group_key=_group_key, replicate_per_row=True
                ):
                    if _kind == "loco":
                        _loco_df = _payload
                    elif _kind == "rows":
                        _rows_accum.append(_payload)

                os.makedirs("outputs/CBF", exist_ok=True)
                if isinstance(_loco_df, pd.DataFrame) and not _loco_df.empty:
                    _loco_path = "outputs/CBF/cbf_recs_loco.csv"
                    _loco_df.to_csv(_loco_path, index=False, encoding="utf-8-sig")
                    # Summary (mean/median etc.)
                    try:
                        summarize_loco(_loco_df).to_csv("outputs/CBF/cbf_eval_loco.csv", index=False, encoding="utf-8-sig")
                    except (TypeError, ValueError, KeyError, AttributeError) as _sum_ex:
                        logger.warning("[CBF][EVAL][pre] summarize_loco failed: %s", _sum_ex)
                    logger.info("[CBF][EVAL][pre] LOCO per-patient saved: %s (rows=%d)", _loco_path, len(_loco_df))
                else:
                    logger.warning("[CBF][EVAL][pre] LOCO per-patient frame is empty; files not written.")

                if _rows_accum:
                    try:
                        pd.concat(_rows_accum, ignore_index=True).to_csv(
                            "outputs/CBF/cbf_recs_loco_rows.csv", index=False, encoding="utf-8-sig"
                        )
                        logger.info("[CBF][EVAL][pre] LOCO per-row replication saved to outputs/CBF/cbf_recs_loco_rows.csv")
                    except (OSError, ValueError, TypeError) as _rows_ex:
                        logger.warning("[CBF][EVAL][pre] Saving per-row replication failed (non-fatal): %s", _rows_ex)
            except (KeyError, ValueError, TypeError, AttributeError) as _pre_eval_ex:
                logger.warning("[CBF][EVAL][pre] Pre-filter LOCO evaluation failed non-fatally: %s", _pre_eval_ex)
        else:
            logger.info("[CBF][EVAL][pre] Skipped: '%s' missing or empty, or evaluators unavailable.", _truth_col)
    else:
        logger.info("[CBF][EVAL][pre] Skipped: evaluation base missing or '%s' not in columns.", _score_col)

    # Ensure output dir exists
    os.makedirs("outputs/CBF", exist_ok=True)

    # --- Build standard evaluation candidates (cap by evaluation.eval_cap) ---
    try:
        k_eval = int(config.get("recommendation", {}).get("top_n_eval", 5))
    except (KeyError, ValueError, TypeError, AttributeError):
        k_eval = 5
    try:
        eval_cap = int(config.get("evaluation", {}).get("eval_cap", 10))
    except (KeyError, ValueError, TypeError, AttributeError):
        eval_cap = 10

    patient_col = "patient_id"
    feature_col = "feature_id"

    # --- Normalize eval frames before LOCO/LOCO-Family ---
    def _ensure_eval_ready(eval_df, *, patient_col_name: str = "patient_id", logger_obj=None, log_id_str: str = "CBF"):
        # Lazy import without re-importing pandas here to avoid shadowing warnings
        try:
            from utils.context_utils import ensure_feature_id_binned_and_context as _ensure_fam_ctx  # preferred path
        except ImportError:
            _ensure_fam_ctx = None  # type: ignore

        if not isinstance(eval_df, pd.DataFrame) or eval_df.empty:
            return eval_df

        # 1) Restore 'patient_id' from index if necessary
        if patient_col_name not in eval_df.columns:
            idx_names = [n for n in list(getattr(eval_df.index, "names", []) or []) if n]
            if patient_col_name in idx_names:
                eval_df = eval_df.reset_index()
                (logger_obj or logger).info(f"[{log_id_str}] Eval frame: restored '{patient_col_name}' from index.")
            else:
                (logger_obj or logger).warning(f"[{log_id_str}] Eval frame missing '{patient_col_name}' in columns & index; LOCO may fail.")

        # 2) Ensure contextual family columns exist (safe no-op if source bins are missing)
        if callable(_ensure_fam_ctx):
            try:
                eval_df = _ensure_fam_ctx(eval_df, log=(logger_obj or logger), log_id=f"{log_id_str}[eval_prep]")
            except (TypeError, ValueError, KeyError) as ex:
                (logger_obj or logger).warning(f"[{log_id_str}] ensure_feature_id_binned_and_context skipped during eval prep: {ex}")

        return eval_df


    # --- Apply narratives (MAIN) then fill explanation/source and advice fallbacks ---
    try:
        if isinstance(recommendations, pd.DataFrame) and not recommendations.empty:
            recommendations = apply_cbf_narratives(recommendations, logger_obj=logger)
    except Exception as _narr_err:
        logger.warning("[CBF][NARRATIVE] apply_cbf_narratives failed non-fatally: %s", _narr_err)

    # حقن explanation/source ثم تقوية advice بعد السرد
    recommendations = _fill_algo_explain_and_source(recommendations)
    recommendations = _fill_advice_fallbacks(recommendations)

    # Use the final recommendations for UI as the base, then expand/cap for eval
    # --- Ensure a stable log_id is available for this evaluation block (always define) ---
    import uuid as _uuid_mod
    _log_prev = locals().get('log_id', None)
    if isinstance(_log_prev, str) and _log_prev:
        log_id = _log_prev
    else:
        log_id = str(_uuid_mod.uuid4())
        logger.info("[CBF][INIT] Generated log_id=%s", log_id)
    if 'recommendations_final' in locals() and isinstance(recommendations_final, pd.DataFrame) and not recommendations_final.empty:
        # Local fallback if helper is unavailable
        if cap_topk_per_patient is None:
            def cap_topk_per_patient(df_in, k=10,
                                     patient_col_name="patient_id",
                                     feature_col_name="feature_id",
                                     score_col_name="score_cbf"):
                """
                Local CBF-centric fallback: keep top-k rows per patient based on score.
                Uses feature_col_name as a stable tie-breaker to avoid nondeterministic ordering.
                """
                import pandas as _pd
                if not isinstance(df_in, _pd.DataFrame) or df_in.empty:
                    return df_in
                d = df_in.copy()
                # Normalize score column
                d[score_col_name] = _pd.to_numeric(d.get(score_col_name, 0.0), errors="coerce").fillna(0.0)
                # Ensure tie-breaker column exists (cast to string to avoid mixed types)
                if feature_col_name in d.columns:
                    d[feature_col_name] = d[feature_col_name].astype(str)
                    sort_cols = [patient_col_name, score_col_name, feature_col_name]
                    sort_asc = [True, False, True]
                else:
                    sort_cols = [patient_col_name, score_col_name]
                    sort_asc = [True, False]
                # Sort then keep top-k per patient
                d = d.sort_values(sort_cols, ascending=sort_asc)
                return d.groupby(patient_col_name, as_index=False, group_keys=False).head(int(max(1, k)))
        df_eval_candidates = cap_topk_per_patient(
            recommendations_final.copy(),
            eval_cap,
            patient_col,
            feature_col,
            "score_cbf",
        )
        df_eval_candidates = _ensure_eval_ready(
            df_eval_candidates,
            patient_col_name=patient_col,
            logger_obj=logger,
            log_id_str=log_id
        )
        # Save standard eval candidates (for parity with CF naming)
        std_path = "outputs/CBF/df_cbf_recommendations_eval.csv"
        try:
            df_eval_candidates.to_csv(std_path, index=False, encoding="utf-8-sig")
            logger.info("[CBF][EVAL] Saved standard evaluation candidates to %s (rows=%d)", std_path, len(df_eval_candidates))
        except (OSError, ValueError) as _e:
            logger.warning("[CBF][EVAL] Failed to save %s: %s", std_path, _e)

        # --- [PATCH][INIT] Ensure log_id and df_ctx exist for downstream LOCO/LOCO-Family ---
        # Statically declare df_ctx for linters and ensure it's defined
        from typing import Optional
        df_ctx: Optional[pd.DataFrame]
        if ('df_ctx' in locals()) and isinstance(locals().get('df_ctx'), pd.DataFrame):
            # keep existing df_ctx
            pass
        else:
            df_ctx = None
            # Try common locations to load external contextual truth
            for _p in ("outputs/tmp/df_contextualized.csv", "outputs/CF/df_contextualized.csv"):
                try:
                    if os.path.exists(_p):
                        df_ctx = pd.read_csv(_p)
                        logger.info("[CBF][INIT] Loaded df_ctx from %s (rows=%d)", _p, len(df_ctx))
                        break
                except (OSError, ValueError, pd.errors.ParserError) as _e_dfctx:
                    logger.warning("[CBF][INIT] Failed to load df_ctx from %s: %s", _p, _e_dfctx)
            if df_ctx is None:
                logger.warning("[CBF][INIT] df_ctx not available; LOCO/LOCO-Family may be skipped.")

        _df_ctx: Optional[pd.DataFrame] = locals().get('df_ctx', None)
        if not isinstance(_df_ctx, pd.DataFrame):
            _df_ctx = None

        # --- LOCO (Leave-One-Context-Out) using external truth (df_ctx) if available ---
        df_cbf_loco = pd.DataFrame()
        try:
            if (evaluate_recommendations_loco is not None) and isinstance(_df_ctx, pd.DataFrame):
                df_cbf_loco = evaluate_recommendations_loco(
                    df_eval_candidates, _df_ctx,
                    patient_col=patient_col, feature_col=feature_col, true_col="true_response",
                    k=k_eval, eval_logger=logger, log_id=log_id, score_col="score_cbf"
                )
                loco_path = "outputs/CBF/df_cbf_recommendations_eval_loco.csv"
                if isinstance(df_cbf_loco, pd.DataFrame) and not df_cbf_loco.empty:
                    df_cbf_loco.to_csv(loco_path, index=False, encoding="utf-8-sig")
                    logger.info("[CBF][EVAL] LOCO saved to %s (rows=%d)", loco_path, len(df_cbf_loco))
                else:
                    logger.warning("[CBF][EVAL] LOCO returned empty DataFrame; CSV not written.")
            else:
                logger.warning("[CBF][EVAL] LOCO skipped: evaluator or df_ctx unavailable.")
        except (KeyError, ValueError, TypeError, AttributeError) as _ex:
            logger.warning("[CBF][EVAL] LOCO evaluation raised a non-fatal exception: %s", _ex)

        # --- LOCO-Family (Leave-One-Family-Out) ---
        df_cbf_lf = pd.DataFrame()
        try:
            lf_cfg = (config.get("evaluation", {}) or {}).get("loco_family", {}) or {}
            family_col = lf_cfg.get("family_col", "feature_id_binned")
            exclude_seen_families = bool(lf_cfg.get("exclude_seen_families", True))
            exclude_synonym_families = bool(lf_cfg.get("exclude_synonym_families", True))
            syn_map = lf_cfg.get("synonym_families", {}) or {}

            # Early guard (diagnostics)
            if not isinstance(_df_ctx, pd.DataFrame):
                logger.warning("[CBF][EVAL] LOCO-Family skipped: df_ctx unavailable or not a DataFrame.")
            elif family_col not in _df_ctx.columns:
                logger.warning("[CBF][LF GUARD] df_ctx missing '%s' — LOCO-Family may be empty.", family_col)
            else:
                from pandas import DataFrame
                df_ctx_local: pd.DataFrame = _df_ctx  # type: ignore[assignment]
                if isinstance(df_ctx_local, pd.DataFrame):
                    _ctx: DataFrame = df_ctx_local.loc[:, [patient_col, feature_col, family_col, "true_response"]].copy()
                else:
                    _ctx: DataFrame = pd.DataFrame(columns=[patient_col, feature_col, family_col, "true_response"])
                _ctx["true_response"] = pd.to_numeric(_ctx["true_response"], errors="coerce").fillna(0).astype(int)
                _pos = _ctx[_ctx["true_response"] == 1].dropna(subset=[patient_col, family_col])
                _fam_counts = (
                    _pos.drop_duplicates([patient_col, family_col])
                        .groupby(patient_col, as_index=False)[family_col]
                        .count()
                )
                _n_patients_posfam = int((_fam_counts[family_col] > 0).sum()) if not _fam_counts.empty else 0
                logger.info(
                    "[CBF][LF GUARD] patients_with_pos_families=%d, min=%s, max=%s, avg=%.2f",
                    _n_patients_posfam,
                    int(_fam_counts[family_col].min()) if not _fam_counts.empty else 0,
                    int(_fam_counts[family_col].max()) if not _fam_counts.empty else 0,
                    float(_fam_counts[family_col].mean()) if not _fam_counts.empty else 0.0  # noqa
                )

            if (evaluate_recommendations_loco_family is not None) and isinstance(_df_ctx, pd.DataFrame):
                df_cbf_lf = evaluate_recommendations_loco_family(
                    df_eval_candidates, _df_ctx,
                    patient_col=patient_col, feature_col=feature_col, true_col="true_response",
                    family_col=family_col, k=k_eval, eval_logger=logger, log_id=log_id,
                    exclude_seen_families=exclude_seen_families,
                    exclude_synonym_families=exclude_synonym_families,
                    synonym_families=syn_map,
                    use_eval_score_calibration=True,
                    score_col="score_cbf"
                )
                lf_path = "outputs/CBF/df_cbf_recommendations_eval_loco_family.csv"
                if isinstance(df_cbf_lf, pd.DataFrame) and not df_cbf_lf.empty:
                    df_cbf_lf.to_csv(lf_path, index=False, encoding="utf-8-sig")
                    logger.info("[CBF][EVAL] LOCO-Family saved to %s (rows=%d)", lf_path, len(df_cbf_lf))
                else:
                    logger.warning("[CBF][EVAL] LOCO-Family returned empty DataFrame; CSV not written.")
            else:
                logger.warning("[CBF][EVAL] LOCO-Family skipped: evaluator or df_ctx unavailable.")
        except (KeyError, ValueError, TypeError, AttributeError) as _cbf_eval_ex:
            logger.warning("[CBF][EVAL] CF-style evaluation block failed non-fatally: %s", _cbf_eval_ex)

    # ---- Lightweight post-export summaries (row counts only) ----
    try:
        _summary_targets = [
            ("outputs/CBF/df_cbf_recommendations_eval.csv", "STANDARD EVAL"),
            ("outputs/CBF/df_cbf_recommendations_eval_loco.csv", "LOCO EVAL"),
            ("outputs/CBF/df_cbf_recommendations_eval_loco_family.csv", "LOCO-FAMILY EVAL"),
        ]
        for _path, _label in _summary_targets:
            if os.path.exists(_path):
                try:
                    _df_tmp = pd.read_csv(_path)
                    logger.info("📄 %s loaded: path=%s | rows=%d | cols=%d", _label, _path, len(_df_tmp), _df_tmp.shape[1])
                except (OSError, ValueError, TypeError, pd.errors.ParserError) as _e:
                    logger.warning("[CBF][PRINT] Could not load %s (%s): %s", _label, _path, _e)
            else:
                logger.info("ℹ️ %s missing (path=%s)", _label, _path)
    except (OSError, ValueError, TypeError, AttributeError, pd.errors.ParserError) as _pp_err:
        logger.debug("[CBF][PRINT] summary print skipped: %s", _pp_err)
    # ----------- طباعة أحجام مجموعات train/val/test -----------
    _log_split_summary(df_train, df_val, df_test, logger)
    _log_context_coverage(df_train, "train", logger)
    _log_context_coverage(df_val, "val", logger)
    _log_context_coverage(df_test, "test", logger)

# -----------------------------------------------------------------------------
# تصدير التركيبات السياقية الفعلية في البيانات (heavy artifact) — موقوف افتراضيًا
if export_heavy:
    try:
        _ctx_combos = df[CONTEXT_COLUMNS + ["context_key"]].drop_duplicates()
        try:
            _maybe_export_heavy_csv(  # use helper if available
                _ctx_combos,
                "outputs/CBF/context_combinations_in_data.csv",
                "context_combinations_in_data"
            )
        except NameError:
            # Fallback to direct export if helper is not defined
            _ctx_combos.to_csv("outputs/CBF/context_combinations_in_data.csv", index=False, encoding="utf-8-sig")
        logger.debug("[DEBUG] Heavy artifact exported: context_combinations_in_data.csv")
    except (KeyError, TypeError, ValueError) as _ctx_err:
        logger.warning("[DEBUG] Failed to build/export context_combinations_in_data.csv: %s", _ctx_err)
else:
    logger.debug("[DEBUG] Heavy artifact export disabled: context_combinations_in_data.csv")


# --- Ensure __core_key__ exists on all splits for strict evaluation ---
try:
    from utils.context_utils import make_core_context_key
    from utils.context_utils import ensure_feature_id_binned_and_context, assert_no_many_to_many
except ImportError:
    from utils.context_utils import make_core_context_key  # type: ignore
    ensure_feature_id_binned_and_context = None  # type: ignore
    assert_no_many_to_many = None  # type: ignore
for _df_name in ("df_train", "df_val", "df_test"):
    _df_obj = locals().get(_df_name, None)
    if isinstance(_df_obj, pd.DataFrame) and "__core_key__" not in _df_obj.columns:
        try:
            _df_obj["__core_key__"] = _df_obj.apply(make_core_context_key, axis=1)
            locals()[_df_name] = _df_obj
            logger.info("[EVAL][STRICT] Built __core_key__ on %s (rows=%d)", _df_name, len(_df_obj))
        except (TypeError, ValueError, AttributeError) as _mk_err:
            logger.warning("[EVAL][STRICT] Failed to build __core_key__ on %s: %s", _df_name, _mk_err)

# ---------- 10a. STRICT EVALUATION (LOCO / GroupKFold) ----------
# Runs before the generic evaluation; controlled by config["evaluation"]["mode"]
try:
    EVAL_CFG = config.get("evaluation", {}) or {}
    EVAL_MODE = str(EVAL_CFG.get("mode", "")).strip().lower()
    K_AT = int(EVAL_CFG.get("k_at", 5))
    STRICT_ENABLED = EVAL_MODE in {"leave_one_context_out", "group_kfold"}
except (AttributeError, KeyError, TypeError, ValueError) as _e:
    logger.warning("[EVAL][STRICT] Invalid evaluation config; skipping strict evaluation: %s", _e)
    EVAL_MODE = ""
    K_AT = 5
    STRICT_ENABLED = False

def _strict_score_map_and_threshold(cfg: dict) -> tuple[dict, float]:
    try:
        try:
            from utils.constants import get_cbf_scoring_policy  # preferred absolute import
        except ImportError:
            from utils.constants import get_cbf_scoring_policy  # project-root fallback

        policy_result = get_cbf_scoring_policy(cfg)
        # Accept 2- or 3-tuple returns; ignore extra values beyond the first two
        if isinstance(policy_result, tuple):
            if len(policy_result) >= 2:
                smap = policy_result[0]
                thr = policy_result[1]
            else:
                # Unexpected shape; fallback
                smap, thr = {}, 0.5
        else:
            # If a mapping alone is returned, use default threshold
            smap, thr = policy_result, 0.5

        # Ensure numeric threshold
        try:
            thr = float(thr)
        except (TypeError, ValueError):
            thr = 0.5

        # Basic sanity for score map
        if not isinstance(smap, dict) or not smap:
            smap = {
                "recommended": 1.0,
                "context_key_match": 0.88,
                "knn_recommendation": 0.90,
                "similarity_fallback_high": 0.82,
                "similarity_fallback_medium": 0.65,
                "similarity_fallback_low": 0.50,
                "knn_fallback": 0.70,
                "manual_review": 0.0,
            }

        return smap, thr

    except (ImportError, AttributeError, TypeError, ValueError) as _pol_err:
        logger.warning("[EVAL][STRICT] get_cbf_scoring_policy failed; using defaults: %s", _pol_err)
        return (
            {
                "recommended": 1.0,
                "context_key_match": 0.88,
                "knn_recommendation": 0.90,
                "similarity_fallback_high": 0.82,
                "similarity_fallback_medium": 0.65,
                "similarity_fallback_low": 0.50,
                "knn_fallback": 0.70,
                "manual_review": 0.0,
            },
            0.5,
        )

def _strict_eval_loop_loco(df_tr: pd.DataFrame, df_te: pd.DataFrame) -> tuple[dict, pd.DataFrame]:
    from utils.evaluation import precision_at_k, average_precision_at_k, ndcg_at_k

    def _compute_metrics_at_k(eval_df_local: pd.DataFrame, k: int, score_col: str = "score_cbf") -> dict:
        if eval_df_local is None or eval_df_local.empty:
            return {"precision@k": 0.0, "recall@k": 0.0, "ndcg@k": 0.0, "map@k": 0.0}
        req = {"patient_id", "feature_id", "true_response", score_col}
        if not req.issubset(set(eval_df_local.columns)):
            return {"precision@k": 0.0, "recall@k": 0.0, "ndcg@k": 0.0, "map@k": 0.0}
        k = int(max(1, k))
        precs, recs, ndcgs, maps = [], [], [], []
        # Group by patient + CONTEXT and compute metrics per group
        group_cols_local = ["patient_id"] + list(CONTEXT_COLUMNS)
        group_cols_local = [c for c in group_cols_local if c in eval_df_local.columns]
        for _, g_local in eval_df_local.groupby(group_cols_local, as_index=False):
            g_local = g_local.copy()
            g_local[score_col] = pd.to_numeric(g_local[score_col], errors="coerce").fillna(0.0)
            g_local = g_local.sort_values(score_col, ascending=False)
            y_true = set(g_local.loc[pd.to_numeric(g_local["true_response"], errors="coerce") == 1, "feature_id"])
            ranked = list(zip(g_local["feature_id"].tolist(), g_local[score_col].tolist()))
            if len(ranked) == 0:
                continue
            p = precision_at_k(y_true, [it for it, _ in ranked], k=k)
            # recall@k = hits / max(1, len(y_true))
            topk_items = [it for it, _ in ranked[:k]]
            hits = len(y_true.intersection(topk_items)) if y_true else 0
            r = float(hits) / float(max(1, len(y_true))) if y_true else 0.0
            a = average_precision_at_k(y_true, ranked, k=k)
            n = ndcg_at_k(y_true, ranked, k=k)
            precs.append(p); recs.append(r); maps.append(a); ndcgs.append(n)
        def _avg_list_local(xs):
            return float(sum(xs) / len(xs)) if xs else 0.0
        return {
            "precision@k": _avg_list_local(precs),
            "recall@k": _avg_list_local(recs),
            "ndcg@k": _avg_list_local(ndcgs),
            "map@k": _avg_list_local(maps)
        }
    smap, thr = _strict_score_map_and_threshold(config)
    groups = (df_te["__core_key__"].dropna().unique().tolist()
              if "__core_key__" in df_te.columns else [])
    if not groups:
        logger.warning("[EVAL][LOCO] No __core_key__ in test split; skipping LOCO.")
        return {}, pd.DataFrame()

    all_metrics: list[dict] = []
    fold_records: list[pd.DataFrame] = []

    for key in groups:
        # train without this context key, test only this key
        try:
            train_mask = (df_tr["__core_key__"] != key) if "__core_key__" in df_tr.columns else pd.Series(True, index=df_tr.index)
            train_fold = df_tr.loc[train_mask].copy()
            test_fold  = df_te.loc[df_te["__core_key__"] == key].copy()
            if test_fold.empty or train_fold.empty:
                continue

            # Fit a fresh model on the fold's training data (no leakage)
            rec_fold = CBFRecommender(config)
            rec_fold.fit(hide_sensitive_columns(train_fold, config))

            # Generate top-K for each row in this context
            rows = []
            for _, row_ in test_fold.iterrows():
                ctx_series = pd.Series({c: row_.get(c, "unknown") for c in CONTEXT_COLUMNS})
                try:
                    out = rec_fold.recommend(ctx_series, top_n=K_AT, allow_exact=False)
                except TypeError:
                    # Backward compatibility if allow_exact is not supported
                    out = rec_fold.recommend(ctx_series, top_n=K_AT)
                for o in (out or []):
                    rows.append({
                        "patient_id": row_.get("patient_id"),
                        **{c: row_.get(c) for c in CONTEXT_COLUMNS},
                        "feature_id": o.get("feature_id"),
                        "reason": o.get("reason"),
                        "explanation": o.get("explanation", ""),
                        "source": o.get("source", "cbf"),
                        "true_response": row_.get("true_response", None),
                    })
            if not rows:
                continue

            _fold_df_local = pd.DataFrame(rows)
            # Central scoring (reason → score)
            _fold_df_local["score_cbf"] = _fold_df_local["reason"].map(smap).fillna(0.0)
            _fold_df_local = _fold_df_local.loc[_fold_df_local["score_cbf"] >= thr].copy()

            # Evaluate this fold using strict grouping (patient_id + CONTEXT)
            m = _compute_metrics_at_k(
                eval_df_local=_fold_df_local,
                k=K_AT,
                score_col="score_cbf",
            )
            all_metrics.append(m)
            fold_records.append(_fold_df_local)
        except (KeyError, ValueError, TypeError, AttributeError, RuntimeError) as _fold_err:
            logger.warning("[EVAL][LOCO] Fold for key=%s failed: %s", key, _fold_err)

    # Aggregate metrics
    def _avg_metric_value(metric_name: str) -> float:
        vals = [float(d.get(metric_name, 0.0)) for d in all_metrics if isinstance(d, dict)]
        return sum(vals) / len(vals) if vals else 0.0

    _summary = {
        "mode": "leave_one_context_out",
        "k": K_AT,
        "precision@k": _avg_metric_value("precision@k"),
        "recall@k": _avg_metric_value("recall@k"),
        "ndcg@k": _avg_metric_value("ndcg@k"),
        "map@k": _avg_metric_value("map@k"),
        "group_cols": ["patient_id"] + list(CONTEXT_COLUMNS)
    }
    _folds_df = pd.concat(fold_records, ignore_index=True) if fold_records else pd.DataFrame()
    return _summary, _folds_df

def _strict_eval_loop_groupkfold(df_all: pd.DataFrame) -> tuple[dict, pd.DataFrame]:
    # --- Safety: create __core_key__ if missing on df_all ---
    if "__core_key__" not in df_all.columns:
        try:
            from utils.context_utils import make_core_context_key as _mk_key
            from utils.context_utils import ensure_feature_id_binned_and_context, assert_no_many_to_many
        except ImportError:
            from context_utils import make_core_context_key as _mk_key  # type: ignore
        try:
            df_all = df_all.copy()
            df_all["__core_key__"] = df_all.apply(_mk_key, axis=1)
        except (TypeError, ValueError, AttributeError, KeyError) as err_mk:
            logger.warning("[EVAL][GKF] Failed to build __core_key__ on df_all: %s", err_mk)
            return {}, pd.DataFrame()

    if GroupKFold is None:
        logger.warning("[EVAL][GKF] sklearn is not available; skipping GroupKFold strict evaluation.")
        return {}, pd.DataFrame()

    from utils.evaluation import precision_at_k, average_precision_at_k, ndcg_at_k

    def _compute_metrics_at_k(eval_df_local: pd.DataFrame, k: int, score_col: str = "score_cbf") -> dict:
        if eval_df_local is None or eval_df_local.empty:
            return {"precision@k": 0.0, "recall@k": 0.0, "ndcg@k": 0.0, "map@k": 0.0}
        req = {"patient_id", "feature_id", "true_response", score_col}
        if not req.issubset(set(eval_df_local.columns)):
            return {"precision@k": 0.0, "recall@k": 0.0, "ndcg@k": 0.0, "map@k": 0.0}
        k = int(max(1, k))
        precs, recs, ndcgs, maps = [], [], [], []
        # Group by patient + CONTEXT and compute metrics per group
        group_cols_local = ["patient_id"] + list(CONTEXT_COLUMNS)
        group_cols_local = [c for c in group_cols_local if c in eval_df_local.columns]
        for _, g_local in eval_df_local.groupby(group_cols_local, as_index=False):
            g_local = g_local.copy()
            g_local[score_col] = pd.to_numeric(g_local[score_col], errors="coerce").fillna(0.0)
            g_local = g_local.sort_values(score_col, ascending=False)
            y_true = set(g_local.loc[pd.to_numeric(g_local["true_response"], errors="coerce") == 1, "feature_id"])
            ranked = list(zip(g_local["feature_id"].tolist(), g_local[score_col].tolist()))
            if len(ranked) == 0:
                continue
            p = precision_at_k(y_true, [it for it, _ in ranked], k=k)
            # recall@k = hits / max(1, len(y_true))
            topk_items = [it for it, _ in ranked[:k]]
            hits = len(y_true.intersection(topk_items)) if y_true else 0
            r = float(hits) / float(max(1, len(y_true))) if y_true else 0.0
            a = average_precision_at_k(y_true, ranked, k=k)
            n = ndcg_at_k(y_true, ranked, k=k)
            precs.append(p); recs.append(r); maps.append(a); ndcgs.append(n)
        def _avg_list_local(xs):
            return float(sum(xs) / len(xs)) if xs else 0.0
        return {
            "precision@k": _avg_list_local(precs),
            "recall@k": _avg_list_local(recs),
            "ndcg@k": _avg_list_local(ndcgs),
            "map@k": _avg_list_local(maps)
        }
    smap, thr = _strict_score_map_and_threshold(config)

    if "__core_key__" not in df_all.columns:
        logger.warning("[EVAL][GKF] __core_key__ is missing; skipping.")
        return {}, pd.DataFrame()

    groups_all = df_all["__core_key__"].astype(str).values
    x_idx = df_all.index.values
    n_splits = int(EVAL_CFG.get("folds", 5))
    gkf = GroupKFold(n_splits=n_splits)

    all_metrics: list[dict] = []
    fold_records: list[pd.DataFrame] = []

    for fold, (tr_idx, te_idx) in enumerate(gkf.split(x_idx, groups=groups_all), start=1):
        try:
            train_fold = df_all.iloc[tr_idx].copy()
            test_fold  = df_all.iloc[te_idx].copy()
            if train_fold.empty or test_fold.empty:
                continue

            rec_fold = CBFRecommender(config)
            rec_fold.fit(hide_sensitive_columns(train_fold, config))

            rows = []
            for _, row_ in test_fold.iterrows():
                ctx_series = pd.Series({c: row_.get(c, "unknown") for c in CONTEXT_COLUMNS})
                try:
                    out = rec_fold.recommend(ctx_series, top_n=K_AT, allow_exact=False)
                except TypeError:
                    out = rec_fold.recommend(ctx_series, top_n=K_AT)
                for o in (out or []):
                    rows.append({
                        "patient_id": row_.get("patient_id"),
                        **{c: row_.get(c) for c in CONTEXT_COLUMNS},
                        "feature_id": o.get("feature_id"),
                        "reason": o.get("reason"),
                        "explanation": o.get("explanation", ""),
                        "source": o.get("source", "cbf"),
                        "true_response": row_.get("true_response", None),
                    })
            if not rows:
                continue

            _fold_df_local = pd.DataFrame(rows)
            _fold_df_local["score_cbf"] = _fold_df_local["reason"].map(smap).fillna(0.0)
            _fold_df_local = _fold_df_local.loc[_fold_df_local["score_cbf"] >= thr].copy()

            m = _compute_metrics_at_k(
                eval_df_local=_fold_df_local,
                k=K_AT,
                score_col="score_cbf",
            )
            all_metrics.append(m)
            fold_records.append(_fold_df_local)
        except (KeyError, ValueError, TypeError, AttributeError, RuntimeError) as _gkf_err:
            logger.warning("[EVAL][GKF] Fold %d failed: %s", fold, _gkf_err)

    def _avg_metric_value(metric_name: str) -> float:
        vals = [float(d.get(metric_name, 0.0)) for d in all_metrics if isinstance(d, dict)]
        return sum(vals) / len(vals) if vals else 0.0

    _summary = {
        "mode": "group_kfold",
        "folds": n_splits,
        "k": K_AT,
        "precision@k": _avg_metric_value("precision@k"),
        "recall@k": _avg_metric_value("recall@k"),
        "ndcg@k": _avg_metric_value("ndcg@k"),
        "map@k": _avg_metric_value("map@k"),
        "group_cols": ["patient_id"] + list(CONTEXT_COLUMNS)
    }
    _folds_df = pd.concat(fold_records, ignore_index=True) if fold_records else pd.DataFrame()
    return _summary, _folds_df

try:
    from sklearn.model_selection import GroupKFold  # type: ignore
except ImportError:  # sklearn optional in some environments
    GroupKFold = None  # type: ignore

# --- Safe import of make_core_context_key ---
try:
    from utils.context_utils import make_core_context_key, assert_no_many_to_many  # preferred absolute import
except ImportError:
    # Backward compatibility if run with project root as cwd
    from utils.context_utils import make_core_context_key  # type: ignore

if STRICT_ENABLED:
    logger.info("[EVAL][STRICT] Running strict evaluation mode: %s", EVAL_MODE)
    if EVAL_MODE == "leave_one_context_out":
        summary, folds_df = _strict_eval_loop_loco(df_train, df_test)
        out_summary = "outputs/CBF/cbf_eval_loco.csv"
        out_recs    = "outputs/CBF/cbf_recs_loco.csv"
    elif EVAL_MODE == "group_kfold":
        # Use train set for CV; you can switch to concat(train,test) if desired
        df_train_cv = df_train.copy()
        summary, folds_df = _strict_eval_loop_groupkfold(df_train_cv)
        out_summary = "outputs/CBF/cbf_eval_groupkfold.csv"
        out_recs    = "outputs/CBF/cbf_recs_groupkfold.csv"
    else:
        summary, folds_df = {}, pd.DataFrame()
        out_summary = ""
        out_recs = ""

    import uuid as _uuid_mod
    _log_id = locals().get('log_id', None)
    if not isinstance(_log_id, str) or not _log_id:
        _log_id = str(_uuid_mod.uuid4())
        logger.info("[CBF][INIT] Generated fallback log_id=%s", _log_id)
    try:
        # [SAFETY INIT] Ensure _log_id and _df_ctx exist and have correct types
        _df_ctx = locals().get('df_ctx', None)
        if not isinstance(_df_ctx, pd.DataFrame):
            _df_ctx = None

        # Pull LOCO-Family config (already defined above for LOCO-Family call)
        lf_cfg = config.get("evaluation", {}).get("loco_family", {}) or {}
        family_col = lf_cfg.get("family_col", "feature_id_binned")

        # --- Safe local aliases to satisfy linters and runtime ---
        patient_col_local = locals().get("patient_col", "patient_id")
        feature_col_local = locals().get("feature_col", "feature_id")
        _df_ctx_local = locals().get("_df_ctx", None)

        if isinstance(_df_ctx_local, pd.DataFrame) and all(
            c in _df_ctx_local.columns for c in [patient_col_local, feature_col_local, "true_response"]
        ):
            if family_col in _df_ctx_local.columns:
                # Safe slice with explicit DataFrame type; never call .copy() on None
                _ctx = _df_ctx_local.loc[:, [patient_col_local, feature_col_local, family_col, "true_response"]].copy()
                _ctx["true_response"] = pd.to_numeric(_ctx["true_response"], errors="coerce").fillna(0).astype(int)
                _pos = _ctx[_ctx["true_response"] == 1].dropna(subset=[patient_col_local, family_col])
                # Count unique positive families per patient
                _fam_counts = (
                    _pos.drop_duplicates([patient_col_local, family_col])
                        .groupby(patient_col_local, as_index=False)[family_col]
                        .count()
                )
                _n_patients_posfam = int((_fam_counts[family_col] > 0).sum()) if not _fam_counts.empty else 0
                _min_f = int(_fam_counts[family_col].min()) if not _fam_counts.empty else 0
                _max_f = int(_fam_counts[family_col].max()) if not _fam_counts.empty else 0
                _avg_f = float(_fam_counts[family_col].mean()) if not _fam_counts.empty else 0.0

                logger.info(
                    f"[{_log_id}] [CBF] LOCO-Family guard — positive families per patient: "
                    f"patients_with_pos_families={_n_patients_posfam}, "
                    f"min={_min_f}, max={_max_f}, avg={_avg_f:.2f}"
                )
                if _n_patients_posfam == 0:
                    logger.warning(f"[{_log_id}] [CBF] LOCO-Family: no patients with positive families in _df_ctx; result may be empty.")
            else:
                logger.warning(f"[{_log_id}] [CBF] LOCO-Family guard: _df_ctx missing '{family_col}' — evaluation may be empty.")
        else:
            logger.warning(f"[{_log_id}] [CBF] LOCO-Family guard: _df_ctx unavailable or missing required columns ({patient_col_local}, {feature_col_local}, true_response).")
    except (KeyError, ValueError, TypeError, AttributeError) as _ex:
        logger.warning(f"[{_log_id}] [CBF] LOCO-Family guard failed: {_ex}")

    if summary:
        try:
            pd.DataFrame([summary]).to_csv(out_summary, index=False, encoding="utf-8-sig")
            logger.info("✅ Strict evaluation summary saved to %s", out_summary)
        except (OSError, ValueError, TypeError) as _sv1:
            logger.warning("[EVAL][STRICT] Failed to save summary: %s", _sv1)
    if not folds_df.empty:
        try:
            folds_df.to_csv(out_recs, index=False, encoding="utf-8-sig")
            logger.info("✅ Strict evaluation recommendations saved to %s", out_recs)
        except (OSError, ValueError, TypeError) as _sv2:
            logger.warning("[EVAL][STRICT] Failed to save fold recommendations: %s", _sv2)
# ---------- End STRICT EVALUATION ----------

# ---------- 10b. Evaluation (automatic) ----------
from utils.evaluation import evaluate_cbf_full, evaluate_cbf_unique

eval_results = None  # default to avoid NameError if recommendations_final is not created

# --- Safe save of evaluation summary (handles dict, list-of-dicts, DataFrame-like, None, and scalars) ---
def _save_eval_results(eval_results_in, eval_path_in, log):
    try:
        if eval_results_in is None:
            with open(eval_path_in, "w", encoding="utf-8-sig") as f:
                f.write("No evaluation results (None).")
            log.info(f"✅ Evaluation summary saved (None placeholder) to: {eval_path_in}")
            return
        to_csv_attr = getattr(eval_results_in, "to_csv", None)
        if callable(to_csv_attr):
            eval_results_in.to_csv(eval_path_in, index=False, encoding="utf-8-sig")
            log.info(f"✅ Evaluation summary (to_csv object) saved to: {eval_path_in}")
            return
        if isinstance(eval_results_in, dict):
            pd.DataFrame([eval_results_in]).to_csv(eval_path_in, index=False, encoding="utf-8-sig")
            log.info(f"✅ Evaluation summary (dict) saved to: {eval_path_in}")
            return
        if isinstance(eval_results_in, (list, tuple)):
            if len(eval_results_in) == 0:
                with open(eval_path_in, "w", encoding="utf-8-sig") as f:
                    f.write("[]")
                log.info(f"✅ Evaluation summary (empty list) saved to: {eval_path_in}")
                return
            first = eval_results_in[0]
            if isinstance(first, dict):
                pd.DataFrame(list(eval_results_in)).to_csv(eval_path_in, index=False, encoding="utf-8-sig")
                log.info(f"✅ Evaluation summary (list of dicts) saved to: {eval_path_in}")
                return
            pd.DataFrame({"value": list(eval_results_in)}).to_csv(eval_path_in, index=False, encoding="utf-8-sig")
            log.info(f"✅ Evaluation summary (list of scalars) saved to: {eval_path_in}")
            return
        with open(eval_path_in, "w", encoding="utf-8-sig") as f:
            f.write(str(eval_results_in))
        log.info(f"✅ Evaluation summary (stringified) saved to: {eval_path_in}")
    except (OSError, ValueError, TypeError) as save_exc:
        log.error(f"❌ Failed to save evaluation summary: {save_exc}")

eval_path = config.get("hybrid_paths", {}).get("cbf_recommendations_eval", "outputs/CBF/cbf_eval_summary.csv")

# Determine k for evaluation (prefer recommendation.top_n_eval, else evaluation.k_at, default=5)
try:
    k_eval = int((config.get("recommendation", {}) or {}).get("top_n_eval",
                  (config.get("evaluation", {}) or {}).get("k_at", 5)))
except (TypeError, ValueError, AttributeError):
    k_eval = 5

if 'recommendations_final' in locals() and isinstance(recommendations_final, pd.DataFrame) and not recommendations_final.empty:
    try:
        # Ensure numeric/clean scores for ranking
        sc_series = recommendations_final.get("score_cbf", None)
        # Ensure we operate on a pandas Series; handle scalar/None gracefully
        if not isinstance(sc_series, pd.Series):
            sc_series = pd.Series(sc_series, index=recommendations_final.index)
        sc_series = pd.to_numeric(sc_series, errors="coerce")
        recommendations_final.loc[:, "score_cbf"] = sc_series.clip(0.0, 1.0)
    except Exception as _eclip:
        logger.warning("[CBF][EVAL] score_cbf coercion/clip failed (continuing): %s", _eclip)

    # Compute FULL and UNIQUE metrics using the new evaluators
    try:
        metrics_full = evaluate_cbf_full(recommendations_final, k=k_eval, score_col="score_cbf")
    except Exception as _efull:
        logger.warning("[CBF][EVAL] evaluate_cbf_full failed: %s", _efull)
        metrics_full = {}

    try:
        metrics_unique = evaluate_cbf_unique(recommendations_final, k=k_eval, score_col="score_cbf")
    except Exception as _euniq:
        logger.warning("[CBF][EVAL] evaluate_cbf_unique failed: %s", _euniq)
        metrics_unique = {}

    # Persist individual summaries too (backward-compatible paths)
    try:
        if metrics_full:
            pd.DataFrame([metrics_full]).to_csv("outputs/CBF/cbf_eval_full.csv", index=False, encoding="utf-8-sig")
        if metrics_unique:
            pd.DataFrame([metrics_unique]).to_csv("outputs/CBF/cbf_eval_unique.csv", index=False, encoding="utf-8-sig")
    except (OSError, ValueError) as _esv:
        logger.warning("[CBF][EVAL] Failed to save per-scope summaries: %s", _esv)

    try:
        combined = pd.DataFrame([
            {"scope": "full", **metrics_full} if metrics_full else {"scope": "full"},
            {"scope": "unique", **metrics_unique} if metrics_unique else {"scope": "unique"},
        ])
        _save_eval_results(combined, eval_path, logger)
    except Exception as _ecomb:
        logger.warning("[CBF][EVAL] Combined summary save skipped: %s", _ecomb)

    # Console prints
    try:
        if metrics_full:
            print(f"FULL@{k_eval}: P={metrics_full.get('precision@k', float('nan')):.4f} | "
                  f"R={metrics_full.get('recall@k', float('nan')):.4f} | "
                  f"nDCG={metrics_full.get('ndcg@k', float('nan')):.4f} | "
                  f"MAP={metrics_full.get('map@k', float('nan')):.4f}")
        if metrics_unique:
            print(f"UNIQUE@{k_eval}: P={metrics_unique.get('precision@k', float('nan')):.4f} | "
                  f"R={metrics_unique.get('recall@k', float('nan')):.4f} | "
                  f"nDCG={metrics_unique.get('ndcg@k', float('nan')):.4f} | "
                  f"MAP={metrics_unique.get('map@k', float('nan')):.4f}")
    except Exception as _eprint:
        logger.warning("[CBF][EVAL] Console print failed: %s", _eprint)
else:
    logger.warning("[CBF] recommendations_final is undefined or empty; skipping automatic evaluation.")
    _save_eval_results(None, eval_path, logger)
    logger.info("✅ Saved successfully.")

# ---------- 11. تصدير ملف أخطاء التوصية مع شرح سريري ----------
def clinical_explanation(context_row):
    bp = str(context_row.get('bp_category', '')).strip().lower()
    chol = str(context_row.get('chol_category', '')).strip().lower()
    # توقّعنا قيماً مطبّعة مثل hypertension_stage_2, borderline_high, high
    if bp == "hypertension_stage_2" and chol == "high":
        return "❗️مريض في مرحلة خطرة جدًا (ضغط مرتفع جدًا وكوليسترول مرتفع): يجب مراجعة العلاج الدوائي فورًا ولا يُكتفى بالنصائح الحياتية."
    elif bp == "hypertension_stage_2" and chol == "borderline_high":
        return "⚠️ حالة ضغط شديد مع كوليسترول حدودي: راجع العوامل الإضافية وحدد إذا كان العلاج الدوائي ضروريًا."
    elif bp == "hypertension_stage_1" and chol == "high":
        return "🔹ضغط مرتفع من الدرجة الأولى مع كوليسترول مرتفع: راقب المريض بدقة وقيّم ضرورة البدء بالعلاج الدوائي بناءً على المخاطر."
    else:
        return "مستوى الخطورة متوسط أو منخفض. اتبع الإرشادات السريرية العامة والتقييم الشامل."

if all(col in recommendations.columns for col in ["bp_category", "chol_category", "true_response"]):
    accepted_success_reasons = ["recommended", "context_key_match"]
    # فلترة الصفوف: feature_id ليس فارغ أو manual_review
    is_valid = (
        recommendations["feature_id"].notnull() &
        (recommendations["feature_id"].str.lower() != "manual_review")
    )
    errors = recommendations[
        is_valid &
        (
            (recommendations["true_response"] == 0) |
            (~recommendations["reason"].isin(accepted_success_reasons))
        )
    ].copy()
    errors["clinical_explanation"] = errors.apply(clinical_explanation, axis=1)
    errors.to_csv("outputs/CBF/cbf_errors_explained.csv", index=False, encoding="utf-8-sig")
    logger.info("✅ Exported clinical explanation for errors to outputs/CBF/cbf_errors_explained.csv")

# ---------- 12. تقييم مختصر: Precision@k ----------
def precision_at_k(recommendations_df, k=1, score_col="score_cbf"):
    # تحسب نسبة الحالات التي تم فيها التوصية الصحيحة ضمن أعلى k توصيات لكل مريض بعد ترتيبها بالدرجات
    required = {"patient_id", "true_response", score_col}
    if not required.issubset(recommendations_df.columns):
        return float('nan')
    df_sorted = recommendations_df.sort_values(["patient_id", score_col], ascending=[True, False])
    topk = df_sorted.groupby("patient_id").head(k)
    y = pd.to_numeric(topk["true_response"], errors="coerce")
    result = (y == 1)
    return float(result.mean()) if hasattr(result, "mean") else float(result)

if "patient_id" in recommendations.columns and "true_response" in recommendations.columns:
    print(f"Precision@1: {precision_at_k(recommendations, 1, 'score_cbf'):.2%}")
    print(f"Precision@3: {precision_at_k(recommendations, 3, 'score_cbf'):.2%}")

# ---------- 12. Print Summary -------------

# ----------- تقرير تغطية قاموس التوصية الفعلي (CBF) -----------
# --- [COVERAGE][RECOMPUTE] Robust coverage check & export for uncovered contexts ---
try:
    # Lazy imports here to avoid top-level coupling and linter noise
    from utils.constants import MEDICAL_RECOMMENDATION_PLAN as _PLAN  # clinical context dictionary
    from utils.context_utils import make_context_key as _mk_ctx_key, normalize_context_value as _norm_ctx_val
except (ImportError, AttributeError) as _imp_cov_ex:
    _PLAN = {}
    def _mk_ctx_key(row_obj, context_columns):  # minimal fallback (renamed param to avoid shadowing)
        try:
            return "|".join([f"{c}={str(row_obj.get(c, ''))}" for c in context_columns])
        except (KeyError, TypeError, AttributeError, ValueError):
            return ""
    def _norm_ctx_val(x):
        return str(x).strip().lower() if x is not None else "unknown"

# Choose a source frame for coverage: prefer the raw data df; fallback to recommendations_final
_src_df = None
if "df" in locals() and isinstance(locals()["df"], pd.DataFrame) and not locals()["df"].empty:
    _src_df = locals()["df"].copy()
elif "recommendations_final" in locals() and isinstance(locals()["recommendations_final"], pd.DataFrame):
    _src_df = locals()["recommendations_final"].copy()

covered = 0
n_data = 0
not_covered = 0
coverage_ratio = 0.0

if isinstance(_src_df, pd.DataFrame) and not _src_df.empty:
    _ctx_cols = [c for c in list(CONTEXT_COLUMNS) if c in _src_df.columns]
    # Normalize context columns robustly (convert to string before apply)
    for _c in _ctx_cols:
        try:
            # Guard against None and missing columns; ensure we operate on a Series
            col = _src_df[_c] if (_src_df is not None and _c in _src_df.columns) else None
            if isinstance(col, pd.Series):
                _src_df.loc[:, _c] = col.astype("string").fillna("").map(_norm_ctx_val)
            else:
                # If the column is missing or not a Series, skip safely
                continue
        except Exception as _norm_ex:
            logger.warning("[COVERAGE] Normalization skipped for column %s: %s", _c, _norm_ex)
    # Build canonical context_key for each unique context row with try/except
    try:
        _uniq_ctx = _src_df[_ctx_cols].drop_duplicates().reset_index(drop=True)
        _uniq_ctx.loc[:, "context_key"] = _uniq_ctx.apply(lambda r: _mk_ctx_key(r, context_columns=_ctx_cols), axis=1)
    except Exception as _ctx_ex:
        logger.warning("[COVERAGE] Failed to build context_key on unique contexts: %s", _ctx_ex)
        _uniq_ctx = pd.DataFrame(columns=_ctx_cols + ["context_key"])
    _plan_keys = set(_PLAN.keys()) if isinstance(_PLAN, dict) else set()
    _uniq_ctx["_is_covered"] = _uniq_ctx["context_key"].isin(_plan_keys)
    n_data = int(len(_uniq_ctx))
    covered = int(_uniq_ctx["_is_covered"].sum())
    not_covered = int((~_uniq_ctx["_is_covered"]).sum())
    coverage_ratio = (covered / n_data) if n_data > 0 else 0.0
    # Export uncovered contexts with frequency and a suggested tidy form
    try:
        _src_tmp = _src_df.copy()
        try:
            _src_tmp.loc[:, "context_key"] = _src_tmp.apply(lambda r: _mk_ctx_key(r, context_columns=_ctx_cols), axis=1)
        except Exception as _tmp_ctx_ex:
            logger.warning("[COVERAGE] Failed to build context_key on src_tmp: %s", _tmp_ctx_ex)
            _src_tmp = pd.DataFrame(columns=list(_src_df.columns) + ["context_key"])
        _freq = (
            _src_tmp["context_key"]
            .value_counts(dropna=False)
            .rename_axis("context_key")
            .reset_index(name="count_in_data")
        ) if "context_key" in _src_tmp.columns else pd.DataFrame(columns=["context_key", "count_in_data"])
        _uncovered = (
            _uniq_ctx.loc[~_uniq_ctx["_is_covered"], _ctx_cols + ["context_key"]]
            .merge(_freq, on="context_key", how="left")
            .sort_values("count_in_data", ascending=False)
            if not _uniq_ctx.empty and not _freq.empty else pd.DataFrame(columns=_ctx_cols + ["context_key", "count_in_data"])
        )
        os.makedirs("outputs/CBF", exist_ok=True)
        _uncovered_path = "outputs/CBF/context_combinations_not_covered.csv"
        _uncovered.to_csv(_uncovered_path, index=False, encoding="utf-8-sig")
        logger.info("[COVERAGE] Exported uncovered contexts to %s (rows=%d)", _uncovered_path, len(_uncovered))
    except Exception as _cov_save_ex:
        logger.warning("[COVERAGE] Failed to export uncovered contexts CSV: %s", _cov_save_ex)

# Final user-facing coverage prints
print(f"🔵 تغطية قاموس التوصية الفعلي (CBF): {covered}/{n_data} ({coverage_ratio:.2%})")
if not_covered > 0:
    print(f"🟠 عدد التركيبات السياقية غير المغطاة في القاموس: {not_covered} (انظر context_combinations_not_covered.csv)")
else:
    print("✅ لا توجد تراكيب سياقية غير مغطاة حاليًا.")

if __name__ == "__main__":
    print("✅ CBF Pipeline completed.")
    print("Recommendation sample:")
    try:
        print(recommendations_final.head())
    except NameError:
        print("recommendations_final is undefined (skipped earlier due to pipeline guard).")
    try:
        print("Evaluation summary:")
        print(eval_results)
    except (NameError, ValueError, TypeError, OSError) as err:
        print("No evaluation results available.")
        print("Error:", err)
        logger.error(f"Error during evaluation summary print: {err}")
        logger.info("🚀 [CBF Pipeline] Done.")
# ---------- طباعة الأعمدة في كل من مجموعات التقسيم (للتدقيق السريع) ----------
print("df_train columns:", df_train.columns.tolist())
print("df_val columns:", df_val.columns.tolist())
print("df_test columns:", df_test.columns.tolist())
print("df_train_nopriv columns:", df_train_nopriv.columns.tolist())
print("df_val_nopriv columns:", df_val_nopriv.columns.tolist())
print("df_test_nopriv columns:", df_test_nopriv.columns.tolist())