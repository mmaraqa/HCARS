# 🧠 مشروع التوصية السياقية لمرضى ارتفاع ضغط الدم

نظام توصية ذكي يستخدم بيانات طبية حقيقية لتحليل عوامل الخطر المرتبطة بمرضى ارتفاع ضغط الدم، السكري، والسكتة الدماغية، مع تقديم توصيات طبية مخصصة بناءً على التحليل السياقي.

---

## 📂 هيكل المشروع

```
hypertension_recommender/
├── data/                    # ملفات البيانات الأصلية
│   ├── diabetes_data.csv
│   ├── hypertension_data.csv
│   └── stroke_data.csv
├── preprocessing/           # تنظيف البيانات، الترميز، الإكمال
│   ├── data_cleaning.py
│   ├── encoding.py
│   ├── imputation.py
│   └── integration.py
├── context/                 # هندسة المتغيرات السياقية
│   └── feature_engineering.py
├── recommender/             # نماذج التوصية الذكية
│   ├── cbf.py               # خوارزمية المحتوى
│   ├── cf.py                # خوارزمية التفاعل التعاوني
│   └── hybrid.py            # نظام هجين متعدد الطبقات مع Meta-Learner
├── evaluation/              # تقييم الأداء والتحليل السريري
│   ├── metrics.py           # دوال التقييم الإحصائي والسريري
│   └── visualization.py     # رسوم بيانية للتحليل والتقييم
├── notebooks/               # التحليل الاستكشافي والتوثيق
│   └── 01_eda.ipynb
├── utils/
│   └── loader.py            # تحميل البيانات
└── README.md
```

---

## ⚙️ خطوات التنفيذ

### 1. التحميل والمعاينة الأولية
- باستخدام `loader.py` قم بتحميل ملفات البيانات الثلاثة.

### 2. تنظيف البيانات
- `data_cleaning.py`: توحيد الأسماء، إزالة القيم غير المنطقية، استبعاد القيم المفقودة الحرجة.

### 3. الترميز Encoding
- `encoding.py`: تحويل القيم النصية إلى عددية باستخدام `LabelEncoder`.

### 4. تعويض القيم المفقودة (Imputation)
- `imputation.py`: استخدام المتوسط أو الوسيط أو الأكثر تكرارًا حسب نوع المتغير.

### 5. هندسة المتغيرات (Feature Engineering)
- `feature_engineering.py`: إنشاء أعمدة جديدة مثل `age_group`, `bmi_class`, `risk_score`.

### 6. دمج البيانات (اختياري)
- `integration.py`: دمج البيانات حسب النموذج المستهدف (مشترك أو منفصل).

### 7. التحليل الاستكشافي EDA
- `01_eda.ipynb`: تحليل التوزيعات، الفئات النادرة، القيم المتطرفة، أهمية السمات.

### 8. توصيات ذكية (CBF / CF / Hybrid)
- `cbf.py`: توصية محتوى حسب السياق الطبي.
- `cf.py`: توصية تعاونية باستخدام خوارزميات SVD و KNN.
- `hybrid.py`: دمج ذكي عبر Meta-Learner و SHAP و Knowledge Base.

### 9. تقييم الأداء (Evaluation)
- `metrics.py`: حساب Precision@K, Clinical Impact, Bias, Consistency.
- `visualization.py`: عرض النتائج باستخدام Heatmaps, Barplots, SHAP explanations.

---

## ✅ أهداف المشروع

- تصميم نظام توصية ذكي سياقي للأمراض المزمنة.
- بناء نظام توصية طبي ذكي قابل للتفسير.
- دعم اتخاذ القرار السريري بناءً على تحليل عميق للبيانات.
- استخدام Meta-Learning و SHAP وقياسات تأثير سريري قابلة للنشر الأكاديمي.

---

## 🧪 التحليل الطبي

- الحفاظ على القيم المتطرفة ذات المعنى الطبي (مثل BMI العالي).
- التعامل مع الفئات النادرة فقط عند عدم وجود دلالة طبية.
- استخدام `clip()` لتقييد القيم غير المنطقية مثل `bmi > 70`.

---

## 📊 مخرجات EDA

- رسوم بيانية للتوزيع.
- تحليل الفئات النادرة والقيم المتطرفة.
- رسوم توضيحية لتوزيع الميزات، خريطة الارتباط، وتحليل التحيز.
- تفسير SHAP لكل توصية طبية.

---

## ✍️ ملاحظات للأطروحة

- المشروع مناسب للفصل الرابع (Results).
- الجزء العملي يغطي الفصول: 3 (المنهجية)، 4 (النتائج)، 5 (التحليل).
- يمكن إضافة الجداول والرسوم مباشرة من `01_eda.ipynb`.
- الأنظمة قابلة للنشر كأداة سريرية تفاعلية بعد الربط مع قواعد بيانات مرضى حقيقية.

---

## 📚 المتطلبات

```bash
pandas
numpy
scikit-learn
seaborn
matplotlib
shap
scipy
surprise
xgboost
``` 

---

## 👨‍⚕️ الإشراف الأكاديمي

- إعداد: Mohammed Maraqa
- البرنامج: ماجستير علوم البيانات والذكاء الاصطناعي – جامعة عربية أمريكية

# 🧠 مشروع التوصية السياقية لمرضى ارتفاع ضغط الدم (HCARS)

نظام توصية طبي ذكي يعتمد على تعلم الآلة والسياق السريري لتقديم توصيات مخصصة لمرضى ارتفاع ضغط الدم، السكري، والسكتة الدماغية. يستخدم النظام معايير تقييم سريرية، اشتقاق السمات، والدمج بين عدة خوارزميات توصية (CBF, CF, Hybrid) ضمن بيئة معيارية صارمة ومتوافقة مع معايير ISO/IEC 25010 و 13485.

---

## 📁 هيكل المشروع

```
hypertension_recommender/
├── data/                          # بيانات CSV الأصلية
│   ├── hypertension_data.csv
│   ├── diabetes_data.csv
│   └── stroke_data.csv
├── schemas/                       # مخططات التحقق YAML لمراحل المعالجة
│   ├── raw.yaml
│   ├── clean_hypertension_data.yaml
│   ├── post-cleaning.yaml
│   ├── post-imputation.yaml
│   ├── post-encoding.yaml
│   ├── post-feature-engineering.yaml
│   └── hypertension.yaml          # المخطط النهائي
├── preprocessing/
│   ├── data_cleaning.py          # تنظيف البيانات
│   ├── imputation.py             # إكمال القيم المفقودة
│   ├── encoding.py               # الترميز
│   ├── integration.py            # دمج الملفات
│   └── restoration.py            # استعادة الأعمدة المحمية
├── context/
│   └── feature_engineering.py    # اشتقاق سمات مثل age_group, chol_flag
├── recommender/
│   ├── cbf.py                    # توصية معتمدة على السمات (Cosine Similarity)
│   ├── cf.py                     # توصية تعاونية (KNN, SVD)
│   └── hybrid.py                 # توصية هجينة باستخدام Meta-Learning و LogisticRegression
├── pipeline/
│   ├── cbf_pipeline.py
│   ├── cf_pipeline.py
│   ├── hybrid_pipeline.py
│   ├── run_pipeline.py
│   └── config.yaml               # الإعدادات الديناميكية لكل مرحلة
├── evaluation/
│   ├── metrics.py                # Precision, Recall, Clinical Impact
│   └── visualization.py         # Heatmaps, SHAP, توزيع النتائج
├── utils/
│   ├── loader.py
│   ├── validation.py             # التحقق من المخططات
│   ├── config_loader.py          # تحميل ديناميكي مع تتبع hash
│   ├── hcars_utils.py            # عمليات دعم سياقية / CBF
│   ├── constants.py
│   └── logging_config.json
├── notebooks/
│   └── 01_eda.ipynb              # تحليل استكشافي شامل EDA
└── README.md
```

---

## ⚙️ مراحل التنفيذ

### ✅ التحميل والتحقق
- `loader.py`: تحميل البيانات الأصلية
- التحقق من البنية باستخدام `validation.py` مقابل YAML

### 🧼 التنظيف
- `data_cleaning.py`: استبعاد الأعمار غير المنطقية، إزالة المتغيرات غير المفيدة

### 🔢 الترميز
- `encoding.py`: تحويل النصوص إلى أرقام، حفظ نسخة احتياطية من target (`target_copy`)

### 🔧 الإكمال
- `imputation.py`: إكمال القيم العددية والنوعية بحسب المنهجية (mean, mode...)

### 🧬 اشتقاق السمات
- `feature_engineering.py`: توليد  risk_score، chol_flag، age_group

### 🔁 استعادة الأعمدة
- `restoration.py`: إعادة `target_copy` إذا تم حذفها أثناء المعالجة

### 🔄 الدمج (اختياري)
- `integration.py`: يمكن ضم ملفات متعددة لإجراء توصية موحدة

### 🔍 التحليل الاستكشافي
- `01_eda.ipynb`: توزيع BMI, glucose، الارتباط، الفئات النادرة، SHAP

### 🤖 نماذج التوصية
- `cbf.py`: توصية سياقية (Cosine)
- `cf.py`: توصية تعاونية (SVD, KNN)
- `hybrid.py`: توصية هجينة بدمج النموذجين وتقييمه سريريًا

### 📊 التقييم والتحليل
- `metrics.py`: تقييم علمي وسريري
- `visualization.py`: عرض نتائج KNN, Cosine, SHAP

---

## 🧠 السمات المولدة (Derived Features)

| الاسم | الوصف |
|------|--------|
| age_group | تصنيف عمري للسكان |
| chol_flag | علم ارتفاع الكولسترول |
| risk_score | مؤشر خطورة حسابي بناءً على معايير متعددة |
| target_copy | نسخة محمية من الهدف للتتبع والتحليل |

---

## 📑 آلية التحقق المتعددة

- **قبل/بعد كل مرحلة** (cleaning, encoding...) يتم تطبيق `validate_schema()` لمطابقة البيانات مع مخطط `.yaml`.
- ملفات YAML تمت مراجعتها لتشمل جميع السمات الجديدة والمحمية.

---

## 🔒 نظام تتبع الإعدادات

- يستخدم `config_loader.py` تقنية `hashlib` لتتبع تغيرات ملف `config.yaml` بشكل ذكي وتحديث الإعدادات فقط عند الحاجة.

---

## 🔎 المخرجات النهائية

- توصيات مرتبة بـ `patient_id`, `feature_id`, `score`
- دعم تحليل التأثير باستخدام SHAP
- دعم استعادة التوصية fallback في حالة نقص بيانات CBF

---

## 📚 متطلبات البيئة

```bash
pandas
numpy
scikit-learn
seaborn
matplotlib
xgboost
surprise
shap
pyyaml
```

---

## 🎓 الإشراف الأكاديمي

- الباحث: Mohammed Maraqa
- التخصص: ماجستير علوم البيانات والذكاء الاصطناعي – الجامعة العربية الأمريكية
