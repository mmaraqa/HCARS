

import os
from utils.yaml_utils import load_yaml_file

def load_schema(name: str) -> dict:
    """
    Loads a YAML schema file from the schemas directory.
    Example: load_schema("post-cleaning.yaml")
    """
    base_path = os.path.dirname(__file__)
    full_path = os.path.join(base_path, name)
    return load_yaml_file(full_path)