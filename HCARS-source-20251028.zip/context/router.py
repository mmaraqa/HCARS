"""
🧠 Context-Aware Feature Engineering Dispatcher
----------------------------------------------
This module routes medical datasets to the appropriate clinical feature engineering logic
based on the disease context (e.g., hypertension).

✅ Core Responsibilities:
    - Directs DataFrames to the correct feature engineering pipeline.
    - Applies standardized transformations including derived features, clinical scores, and restoration logic.
    - Centralizes modular logic for medical datasets to ensure maintainability and scalability.

📐 Standards and Best Practices:
    - Medical logic based on global hypertension stratification practices.
    - Software design conforms to ISO/IEC 25010 (quality attributes: modularity, maintainability, testability).
    - Data quality and auditability align with ISO 13485 (medical software) and ISO 27001 (security and traceability).
    - Validates compatibility with HL7/FHIR structured health records.

🔒 Note:
    This module is **internal** and not intended for direct use.
    Use `feature_engineering.py` as the external API interface to maintain system consistency.
"""

from context.core import generate_context_features
from context.fallback import get_context_dict
from utils.constants import CONTEXT_TO_RECOMMENDATION_MAP, assign_feature_id_by_binned
from context.feature_engineering import log_feature_statistics
from clinical_features import build_clinical_features
import uuid
import pandas as pd
from typing import Callable

config = None  # Will be passed explicitly later if needed

def engineer_hypertension_features(df, log_id=None):
    """
    Applies hypertension-specific feature engineering using centralized context feature generation.
    Automatically generates and verifies presence of new columns: 'bp_bin4', 'chol_bins', 'age_q3', 'feature_id_binned'.
    Uses clinical_features.build_clinical_features to generate clinical columns.
    Logs detailed information about the new columns (presence, distribution, unique values).
    Supports dynamic, context-driven feature_id generation via binned features with fallback to legacy mapping for backward compatibility.
    """
    from utils.logging_utils import get_feature_engineering_logger
    logger = get_feature_engineering_logger()

    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    df = generate_context_features(df, log_id=log_id)

    # Generate clinical features using build_clinical_features and verify new columns
    df = build_clinical_features(df)
    new_cols = {'bp_bin4', 'chol_bins', 'age_q3', 'feature_id_binned'}
    missing_cols = new_cols - set(df.columns)
    if missing_cols:
        logger.warning(f"[{log_id}] [Hypertension] Missing clinical feature columns after build_clinical_features: {missing_cols}")
    else:
        logger.info(f"[{log_id}] [Hypertension] All clinical feature columns generated successfully: {new_cols}")

    # Log distribution and unique counts for new columns
    for col in new_cols:
        if col in df.columns:
            unique_vals = df[col].nunique(dropna=True)
            sample_vals = df[col].dropna().unique()[:5]
            logger.info(f"[{log_id}] [Hypertension] Column '{col}': unique values count = {unique_vals}, sample values = {sample_vals.tolist()}")

    # Advanced: Generate feature_id using the new binned features approach if available
    if "feature_id_binned" in df.columns:
        df = assign_feature_id_by_binned(df)
        missing = df["feature_id"].isna().sum()
        if missing > 0:
            logger.warning(f"[{log_id}] [Router] {missing} feature_id entries could not be mapped from feature_id_binned. Defaulted to 'manual_review' where needed.")
        else:
            logger.info(f"[{log_id}] [Router] All feature_id values successfully generated from feature_id_binned.")
    elif "context_feature_id" in df.columns:
        # Fallback to legacy mapping for backward compatibility
        df["feature_id"] = df["context_feature_id"].map(CONTEXT_TO_RECOMMENDATION_MAP)
        missing = df["feature_id"].isna().sum()
        if missing > 0:
            logger.warning(f"[{log_id}] [Router] {missing} feature_id entries could not be mapped from context_feature_id (legacy).")
        else:
            logger.info(f"[{log_id}] [Router] All feature_id values successfully generated from context_feature_id.")
    else:
        logger.warning(f"[{log_id}] [Router] Neither 'feature_id_binned' nor 'context_feature_id' found — skipping feature_id generation.")

    context_dict = get_context_dict(df)
    logger.info(f"[{log_id}] [Router] Retrieved context_dict: {context_dict}")

    core_features = ["age", "bp_category", "chol_category", "risk_level"]
    all_features = core_features + list(new_cols)
    log_feature_statistics(df, all_features, logger=logger, stage=f"After hypertension pipeline [{log_id}]")

    logger.info(f"[{log_id}] [Hypertension] Successfully generated all context and binning columns: {new_cols}")
    return df

# Dispatcher registry for disease-specific pipelines
def generic_engineer_features(df, log_id=None):
    """
    Generic feature engineering function that applies context features generation and clinical feature building.
    Ensures new columns 'bp_bin4', 'chol_bins', 'age_q3', 'feature_id_binned' are generated and logged.
    Supports dynamic feature_id generation via binned features if implemented in future extensions.
    """
    from utils.logging_utils import get_feature_engineering_logger
    logger = get_feature_engineering_logger()

    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    df = generate_context_features(df, log_id=log_id)

    # Generate clinical features using build_clinical_features and verify new columns
    new_cols = {'bp_bin4', 'chol_bins', 'age_q3', 'feature_id_binned'}
    df = build_clinical_features(df)
    missing_cols = new_cols - set(df.columns)
    if missing_cols:
        logger.warning(f"[{log_id}] [Generic] Missing clinical feature columns after build_clinical_features: {missing_cols}")
    else:
        logger.info(f"[{log_id}] [Generic] All clinical feature columns generated successfully: {new_cols}")

    # Log distribution and unique counts for new columns
    for col in new_cols:
        if col in df.columns:
            unique_vals = df[col].nunique(dropna=True)
            sample_vals = df[col].dropna().unique()[:5]
            logger.info(f"[{log_id}] [Generic] Column '{col}': unique values count = {unique_vals}, sample values = {sample_vals.tolist()}")

    return df

ENGINEERING_DISPATCH: dict[str, Callable[[pd.DataFrame], pd.DataFrame]] = {
    "hypertension": engineer_hypertension_features,
    # Extendable to other diseases (e.g., diabetes, stroke) with generic clinical features builder
    # For future diseases, use generic_engineer_features to apply standard clinical feature building
}

def feature_engineering_dispatcher(disease: str):
    """
    Returns the appropriate feature engineering function based on disease.
    Raises NotImplementedError if the disease is not registered.
    """
    from utils.logging_utils import get_feature_engineering_logger
    logger = get_feature_engineering_logger()

    if disease not in ENGINEERING_DISPATCH:
        raise NotImplementedError(f"Feature engineering for '{disease}' is not implemented.")
    logger.info(f"🔁 Dispatching feature engineering for disease: {disease}")
    return ENGINEERING_DISPATCH[disease]

def engineer_features(df, disease: str = "hypertension", risk_transformer=None, log_id=None):
    """
    Entry point for clinical feature engineering based on disease context.
    Routes DataFrame through the disease-specific feature engineering pipeline.
    Automatically ensures new columns 'bp_bin4', 'chol_bins', 'age_q3', and 'feature_id_binned' are generated.
    Logs key structural information before and after transformation including new columns' presence and distribution.
    Supports dynamic feature_id assignment via binned features methodology with fallback to legacy mapping.
    """
    from utils.logging_utils import get_feature_engineering_logger
    logger = get_feature_engineering_logger()

    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    logger.info(f"[{log_id}] 📦 Starting feature engineering for disease context: {disease}")
    logger.debug(f"[{log_id}] [Router] Incoming DataFrame shape: {df.shape}")
    logger.debug(f"[{log_id}] [Router] Columns before dispatch: {df.columns.tolist()}")

    engine = feature_engineering_dispatcher(disease)
    df = engine(df)

    core_features = ["age", "bp_category", "chol_category", "risk_level"]
    new_cols = ['bp_bin4', 'chol_bins', 'age_q3', 'feature_id_binned']
    all_features = core_features + new_cols
    log_feature_statistics(df, all_features, logger=logger, stage=f"After dispatch [{disease}]")

    if risk_transformer:
        df = risk_transformer.transform(df)

    logger.debug(f"[{log_id}] [Router] Columns after dispatch: {df.columns.tolist()}")
    logger.info(f"[{log_id}] ✅ Completed feature engineering for: {disease}")
    return df

def route_context(df: pd.DataFrame, risk_transformer=None, log_id=None) -> pd.DataFrame:
    """
    Public routing entry point for context-aware feature engineering.
    Currently defaults to 'hypertension' but extendable to multi-context in the future.
    Automatically generates and verifies presence of new columns 'bp_bin4', 'chol_bins', 'age_q3', 'feature_id_binned'.
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    return engineer_features(df, disease="hypertension", risk_transformer=risk_transformer, log_id=log_id)
