try:
    import pandas as pd
except ImportError:
    raise ImportError("pandas is required but not installed. Please install with `pip install pandas`.")
import sys
from pathlib import Path
import time
sys.path.append(str(Path(__file__).resolve().parents[1]))
from utils.logging_utils import get_logger
from context.core import generate_context_features
from context.feature_engineering import run_feature_engineering, log_feature_statistics

# Load cleaned data from previous step
DATA_PATH = Path("outputs/tmp/df_cleaned.csv")
assert DATA_PATH.exists(), f"Missing cleaned dataset: {DATA_PATH}"
df_cleaned = pd.read_csv(DATA_PATH)

print(f"✅ Loaded dataset with shape: {df_cleaned.shape}")

# Set up logging
logger = get_logger("debug_context_modules")

# --- Test context.__init__.py ---
try:
    import context
    logger.info("✅ context.__init__.py loaded successfully")
except Exception as e:
    logger.error("❌ Failed to load context.__init__.py: %s", e)

core_features = [
    "age", "bp_category", "chol_category", "risk_level", "age_group",
    "bp_bin4", "chol_bins", "age_q3", "feature_id_binned"
]
# ➕ Generate context features
start_time = time.time()
df = generate_context_features(df_cleaned)
logger.info("✅ core.generate_context_features invoked successfully — skipping redundant test")

# Apply context feature generation on cleaned data
df_contextualized = generate_context_features(df_cleaned)
log_feature_statistics(df_contextualized, core_features, logger, stage="[بعد generate_context_features]")
for feature in core_features:
    if feature in df_contextualized.columns:
        value_counts = df_contextualized[feature].value_counts(normalize=True)
        top_value = value_counts.iloc[0] if not value_counts.empty else 0
        nunique = df_contextualized[feature].nunique(dropna=False)
        logger.info(f"[generate_context_features] {feature}: unique={nunique}, value_counts=\n{df_contextualized[feature].value_counts()}")
        if nunique <= 1:
            logger.error(f"[CRITICAL] Feature '{feature}' is constant after stage [بعد generate_context_features]!")
        elif top_value > 0.95:
            logger.warning(f"[WARNING] Feature '{feature}' is highly dominant (>95%) after stage [بعد generate_context_features].")

df_contextualized = run_feature_engineering(df_contextualized)
log_feature_statistics(df_contextualized, core_features, logger, stage="[بعد run_feature_engineering]")
for feature in core_features:
    if feature in df_contextualized.columns:
        value_counts = df_contextualized[feature].value_counts(normalize=True)
        top_value = value_counts.iloc[0] if not value_counts.empty else 0
        nunique = df_contextualized[feature].nunique(dropna=False)
        logger.info(f"[run_feature_engineering] {feature}: unique={nunique}, value_counts=\n{df_contextualized[feature].value_counts()}")
        if nunique <= 1:
            logger.error(f"[CRITICAL] Feature '{feature}' is constant after stage [بعد run_feature_engineering]!")
        elif top_value > 0.95:
            logger.warning(f"[WARNING] Feature '{feature}' is highly dominant (>95%) after stage [بعد run_feature_engineering].")
# Log variance for age if present
if "age" in df_contextualized.columns:
    logger.info(f"Variance of 'age' = {df_contextualized['age'].var()}")

df_contextualized.to_csv("outputs/tmp/df_contextualized.csv", index=False)
logger.info("✅ df_contextualized saved to outputs/tmp/df_contextualized.csv")

elapsed = time.time() - start_time
print(df_contextualized[core_features].head())
print("🧠 Contextual features added:", df_contextualized.columns.tolist())
print(f"⏱️ generate_context_features took {elapsed:.2f} seconds")

# Run feature engineering to ensure contextual columns are present
from context.feature_engineering import run_feature_engineering

# --- Manual check: Compare columns before and after encoding ---
df_before_encoding = df_contextualized.copy()
df_encoded = run_feature_engineering(df_before_encoding)
original_columns = set(df_before_encoding.columns)
encoded_columns = set(df_encoded.columns)
added_columns = encoded_columns - original_columns
removed_columns = original_columns - encoded_columns
print("\n🧪 [Manual Column Comparison]")
print(f"➕ Added columns: {sorted(list(added_columns))}")
print(f"➖ Removed columns: {sorted(list(removed_columns))}")
print(f"📏 Column count before: {len(original_columns)}, after: {len(encoded_columns)}")

df_contextualized = df_encoded

missing_cols = df_contextualized[core_features].isna().sum()
for col, count in missing_cols.items():
    if count > 0:
        logger.warning(f"⚠️ Missing {count} entries in {col}")

# --- Print first values and null percentage of contextual columns ---
print("\n📌 Contextual Feature Check:")
for col in core_features:
    if col in df_contextualized.columns:
        null_count = df_contextualized[col].isna().sum()
        total = len(df_contextualized)
        percent_null = (null_count / total) * 100
        sample_values = df_contextualized[col].dropna().unique().tolist()[:5]
        print(f"🧬 {col}: {null_count} nulls ({percent_null:.2f}%), sample values: {sample_values}")
    else:
        print(f"❌ {col} column is missing from DataFrame!")

# --- Test schema_validator.py ---
start_time = time.time()
try:
    from context.schema_validator import validate_schema
    from utils.config_loader import load_schema
    schema_path = "schemas/minimal_test_schema.yaml"
    schema_definition = load_schema(schema_path)

    # Normalize schema into a list of columns using duck-typing to avoid
    # static analyzer "unreachable" warnings on exclusive isinstance branches.
    schema_cols = None

    # Try dict-like first (has .get)
    if hasattr(schema_definition, "get"):
        schema_cols = (
            schema_definition.get("columns")
            or schema_definition.get("expected_columns")
        )

    # If still None, attempt to coerce any iterable (except str/bytes) into a list
    if schema_cols is None:
        if isinstance(schema_definition, (str, bytes)):
            raise TypeError(f"Unsupported schema type from load_schema: {type(schema_definition)}")
        try:
            schema_cols = list(schema_definition)
        except TypeError as e:
            raise TypeError(f"Unsupported schema type from load_schema: {type(schema_definition)}") from e

    validate_schema(
        df_contextualized.copy(),
        schema=schema_cols
    )
    print("✅ schema_validator.validate_schema passed")
except Exception as schema_err:
    logger.error("❌ schema_validator failed: %s", schema_err)
elapsed_time = time.time() - start_time
print("⏱️ schema_validator executed in", elapsed_time)

# --- Test clinical_features.py ---
df_test = None
start_time = time.time()
try:
    from context.clinical_features import (
        derive_bp_category,
        derive_chol_category,
        build_clinical_features,
    )
    df_test = df_contextualized.copy()
    df_test = derive_bp_category(df_test)
    df_test = derive_chol_category(df_test)
    df_test = build_clinical_features(df_test)
    log_feature_statistics(df_test, core_features, logger, stage="[بعد build_clinical_features]")
    for feature in core_features:
        if feature in df_test.columns:
            value_counts = df_test[feature].value_counts(normalize=True)
            top_value = value_counts.iloc[0] if not value_counts.empty else 0
            nunique = df_test[feature].nunique(dropna=False)
            logger.info(f"[build_clinical_features] {feature}: unique={nunique}, value_counts=\n{df_test[feature].value_counts()}")
            if nunique <= 1:
                logger.error(f"[CRITICAL] Feature '{feature}' is constant after stage [بعد build_clinical_features]!")
            elif top_value > 0.95:
                logger.warning(f"[WARNING] Feature '{feature}' is highly dominant (>95%) after stage [بعد build_clinical_features].")
    print("✅ clinical_features functions passed")
except Exception as e:
    logger.error("❌ clinical_features failed: %s", e)
elapsed_time = time.time() - start_time
print("⏱️ clinical_features executed in", elapsed_time)

# --- Test context_validation.py ---
start_time = time.time()
try:
    from context.context_validation import validate_context_columns
    if df_test is not None:
        required_cols = core_features
        missing_cols = [col for col in required_cols if col not in df_test.columns]
        if missing_cols:
            logger.warning(f"🟡 Context validation skipped — missing: {missing_cols}")
        else:
            try:
                validate_context_columns(df_test)
            except Exception as e:
                logger.warning(f"⚠️ validate_context_columns raised an exception but was ignored: {e}")
        print("✅ context_validation.validate_context_columns completed (with conditional skip)")
except Exception as e:
    logger.error("❌ context_validation failed: %s", e)
elapsed_time = time.time() - start_time
print("⏱️ context_validation executed in", elapsed_time)

# --- Test fallback.py ---
df_restored = None
df_features = None
df_engineered = None
df_final = None
start_time = time.time()
try:
    from context.fallback import restore_derived_clinical_columns
    df_restored = restore_derived_clinical_columns(df_test.copy())
    print("✅ fallback.restore_derived_clinical_columns passed")
except Exception as e:
    logger.error("❌ fallback failed: %s", e)
elapsed_time = time.time() - start_time
print("⏱️ fallback executed in", elapsed_time)

# --- Test router.py ---
start_time = time.time()
try:
    from context.router import engineer_features
    df_engineered = engineer_features(df_contextualized.copy())
    log_feature_statistics(df_engineered, core_features, logger, stage="[بعد engineer_features]")
    for feature in core_features:
        if feature in df_engineered.columns:
            value_counts = df_engineered[feature].value_counts(normalize=True)
            top_value = value_counts.iloc[0] if not value_counts.empty else 0
            nunique = df_engineered[feature].nunique(dropna=False)
            logger.info(f"[engineer_features] {feature}: unique={nunique}, value_counts=\n{df_engineered[feature].value_counts()}")
            if nunique <= 1:
                logger.error(f"[CRITICAL] Feature '{feature}' is constant after stage [بعد engineer_features]!")
            elif top_value > 0.95:
                logger.warning(f"[WARNING] Feature '{feature}' is highly dominant (>95%) after stage [بعد engineer_features].")
    print("✅ router.engineer_features passed")
except Exception as e:
    logger.error("❌ router failed: %s", e)
elapsed_time = time.time() - start_time
print("⏱️ router executed in", elapsed_time)

# --- Test feature_engineering.py ---
start_time = time.time()
try:
    from context.feature_engineering import run_feature_engineering
    df_final = run_feature_engineering(df_contextualized.copy())
    log_feature_statistics(df_final, core_features, logger, stage="[قبل التصدير النهائي]")
    for feature in core_features:
        if feature in df_final.columns:
            value_counts = df_final[feature].value_counts(normalize=True)
            top_value = value_counts.iloc[0] if not value_counts.empty else 0
            nunique = df_final[feature].nunique(dropna=False)
            logger.info(f"[run_feature_engineering-final] {feature}: unique={nunique}, value_counts=\n{df_final[feature].value_counts()}")
            if nunique <= 1:
                logger.error(f"[CRITICAL] Feature '{feature}' is constant after stage [قبل التصدير النهائي]!")
            elif top_value > 0.95:
                logger.warning(f"[WARNING] Feature '{feature}' is highly dominant (>95%) after stage [قبل التصدير النهائي].")
    if "age" in df_final.columns:
        logger.info(f"Variance of 'age' = {df_final['age'].var()}")
    print("✅ feature_engineering.run_feature_engineering passed")
except Exception as e:
    logger.error("❌ feature_engineering failed: %s", e)
elapsed_time = time.time() - start_time
print("⏱️ feature_engineering executed in", elapsed_time)



# Ensure response initialization is applied *after* all context modules are tested
from context.response_initializer import (
    initialize_true_response,
    assign_patient_id,
    assign_context_feature_id
)
from utils.constants import assign_feature_id_by_binned

from context.core import harmonize_bp_columns

df_final = initialize_true_response(df_final)
df_final = assign_patient_id(df_final)
df_final = assign_context_feature_id(df_final, use_binned=True)
df_final = harmonize_bp_columns(df_final, prefer='trestbps')

# Use the updated, centralized assignment function for feature_id mapping
df_final = assign_feature_id_by_binned(df_final)

missing_feature_ids = df_final["feature_id"].isna().sum() if "feature_id" in df_final.columns else -1
if missing_feature_ids > 0:
    logger.warning(f"⚠️ {missing_feature_ids} feature_id entries could not be mapped by assign_feature_id_by_binned.")
else:
    logger.info("✅ All feature_id values successfully mapped by assign_feature_id_by_binned.")

# Ensure true_response is included in saved file
# --- Clean redundant contextual columns before saving ---
from context.core import harmonize_bp_columns

df_final = harmonize_bp_columns(df_final, prefer='trestbps')

# إزالة عمود diastolic_bp إذا لم يحمل قيمة سريرية حقيقية أو كان مكررًا
if (
    'diastolic_bp' in df_final.columns and
    (df_final['diastolic_bp'].isnull().all() or df_final['diastolic_bp'].equals(df_final['trestbps']))
):
    df_final = df_final.drop(columns=['diastolic_bp'])
    logger.info("🗑️ Removed redundant diastolic_bp column.")

df_final.to_csv("outputs/tmp/df_contextualized.csv", index=False)
logger.info("✅ df_contextualized with true_response saved to outputs/tmp/df_contextualized.csv")

# Log warning if true_response is missing in df_final
if 'true_response' in df_final.columns:
    missing_true_response = df_final['true_response'].isna().sum()
    if missing_true_response > 0:
        logger.warning(f"⚠️ Missing {missing_true_response} entries in true_response")
else:
    logger.warning("⚠️ 'true_response' column not found in final dataframe")

print("🧬 Final columns:", df_final.columns.tolist())
print("🔍 Missing columns:", [col for col in core_features if col not in df_final.columns])
print("🎯 All context modules executed.")
print("🔍 Contextual feature missing counts:")
print(missing_cols)

# --- Summary Report as JSON ---
import json

report = {
    "context.__init__.py": "✅ Loaded successfully",
    "clinical_features.py": "✅ Passed",
    "context_validation.py": "✅ Passed",
    "fallback.py": "✅ Passed",
    "core.py": "✅ Passed",
    "router.py": "✅ Passed",
    "feature_engineering.py": "✅ Passed",
    "schema_validator.py": "✅ Passed",
}

# تحديث الحقول بناءً على أي أخطاء في السجل
if 'df_restored' not in locals() or df_restored is None:
    report["fallback.py"] = "❌ Failed"
# Ensure df_features is set for the report to recognize core.py as passed
df_features = df_contextualized
if 'df_features' not in locals() or df_features is None:
    report["core.py"] = "❌ Failed"
if 'df_engineered' not in locals() or df_engineered is None:
    report["router.py"] = "❌ Failed"
if 'df_final' not in locals() or df_final is None:
    report["feature_engineering.py"] = "❌ Failed"
if 'df_test' not in locals() or df_test is None:
    report["clinical_features.py"] = "❌ Failed"
if 'validate_context_columns' not in locals() or validate_context_columns is None:
    report["context_validation.py"] = "❌ Failed"


# --- تحليل تباين وتنوع الخصائص المستخدمة في التوصية (features) ---
cbf_features = core_features
existing_features = [col for col in cbf_features if col in df_contextualized.columns]
missing_features = [col for col in cbf_features if col not in df_contextualized.columns]
if missing_features:
    print(f"⚠️ [تحذير] الأعمدة التالية غير موجودة في df_contextualized: {missing_features}")

print("\n🔬 عدد القيم الفريدة لكل feature:")
print(df_contextualized[existing_features].nunique())

print("\n🔬 التباين الإحصائي لكل feature رقمي:")
for col in existing_features:
    if pd.api.types.is_numeric_dtype(df_contextualized[col]):
        print(f"{col}: variance={df_contextualized[col].var():.4f}")

print("\n🔎 معاينة أول 10 صفوف من الخصائص المستخدمة:")
print(df_contextualized[existing_features].head(10))

# --- Add contextual column statistics to report ---
contextual_cols = core_features
contextual_report = {}

for col in contextual_cols:
    if col in df_contextualized.columns:
        null_count = int(df_contextualized[col].isnull().sum())
        total_count = len(df_contextualized)
        percent_null = round((null_count / total_count) * 100, 2)
        sample_values = df_contextualized[col].dropna().unique().tolist()[:5]
        contextual_report[col] = {
            "exists": True,
            "missing_values": null_count,
            "percent_missing": percent_null,
            "sample_values": sample_values,
            "unique_count": int(df_contextualized[col].nunique(dropna=False)),
            "dominant_ratio": float(df_contextualized[col].value_counts(normalize=True).max()) if not df_contextualized[col].value_counts(normalize=True).empty else None
        }
    else:
        contextual_report[col] = {
            "exists": False,
            "missing_values": "N/A",
            "percent_missing": "N/A",
            "sample_values": [],
            "status": "❌ Missing from DataFrame"
        }


# دالة لتحويل جميع قيم pandas. Interval إلى string
def convert_intervals(obj):
    if isinstance(obj, dict):
        return {k: convert_intervals(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_intervals(v) for v in obj]
    elif isinstance(obj, pd.Interval):
        return str(obj)
    else:
        return obj

contextual_report_clean = convert_intervals(contextual_report)
report["contextual_columns"] = json.dumps(contextual_report_clean, ensure_ascii=False)

# طباعة التقرير بصيغة JSON
summary_json = json.dumps(report, indent=2, ensure_ascii=False)
print("📊 Execution Summary:")
print(summary_json)

# حفظ التقرير في مَلف خارجي داخل مجلد context
from pathlib import Path
# إعادة تعيين المسار لحفظ المَلف داخل مجلد context
summary_path = Path(__file__).resolve().parent / "context_debug_summary.json"
# تأكد أن المجلد موجود
summary_path.parent.mkdir(parents=True, exist_ok=True)
print("📦 Saving context_debug_summary.json to:", summary_path)
# Only save report if all intermediate outputs are available
if all([df_final is not None, df_engineered is not None, df_restored is not None, df_test is not None]):
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print("✅ Report saved successfully at:", summary_path)
else:
    print("❌ Report not saved due to missing intermediate outputs.")