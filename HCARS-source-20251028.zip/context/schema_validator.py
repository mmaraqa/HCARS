"""
📋 Feature Schema Validator for Clinical Pipelines
---------------------------------------------------
This module provides validation utilities to ensure feature consistency across medical data pipelines.

✅ Responsibilities:
    - Verify that expected clinical features exist in the DataFrame.
    - Detect missing or extra columns based on defined YAML schemas.
    - Validate column types and integrity against schema definitions.
    - Support derived features including binning and feature combinations.

📐 Standards Alignment:
    - Follows ISO/IEC 25010 (Maintainability, Correctness, Testability).
    - Supports ISO/IEC 13485 principles for medical software validation.
    - Enhances data quality assurance as required by ISO/IEC 27001 (Security & Integrity).

🔒 Suitable for:
    - Clinical recommender systems
    - Regulatory-compliant healthcare analytics platforms
    - Traceable medical feature audits
"""

import pandas as pd
import yaml
import logging
import uuid
from utils.config_loader import load_global_config
from context.core import get_context_dict
from context.clinical_features import build_clinical_features
logger = logging.getLogger(__name__)

def log_column_uniqueness_and_variance(df, columns, log, min_unique=5):
    """
    يحلل ويُسجّل خصائص الأعمدة (عدد القيم الفريدة، نوع الداتا، عينة القيم، التباين) ويطلق تحذيرًا إذا كان العمود ضعيف التميز.
    """
    derived_columns = {"bp_bin4", "chol_bins", "age_q3", "feature_id_binned"}
    for col in columns:
        if col in df.columns:
            unique_count = df[col].nunique(dropna=True)
            sample_vals = df[col].dropna().unique()[:5]
            col_type = str(df[col].dtype)
            origin = "NEW" if col in derived_columns else "orig."
            log.info(f"[SchemaValidator] عمود '{col}' ({origin}): نوع البيانات={col_type}، عدد القيم الفريدة={unique_count}، عينة={sample_vals}")
            if unique_count < min_unique:
                log.warning(f"[SchemaValidator] العمود '{col}' يحمل {unique_count} قيمة فريدة فقط (<{min_unique})—راجع جدواه الإكلينيكي.")
            if unique_count <= 1:
                log.error(f"[SchemaValidator] العمود '{col}' ثابت أو مكرر بالكامل! راجع اشتقاقه.")
                raise ValueError(f"[SchemaValidator] العمود '{col}' ثابت أو مكرر بالكامل بعد Feature Engineering.")

__all__ = ["FeatureEngineeringValidator", "validate_schema"]

class FeatureEngineeringValidator:
    """
    ✅ FeatureEngineeringValidator:
    Ensures strict column compliance for clinical pipelines with schema-based validation.

    📌 Key Features:
        - Compares DataFrame columns with expected schema.
        - Detects extra/missing columns with precise diagnostics.
        - Validates column data types as per schema.

    🔐 Regulatory Compliance:
        - Aligns with ISO/IEC 25010 (Correctness & Testability)
        - Supports ISO/IEC 13485 for clinical software validation
        - Reinforces ISO/IEC 27001 integrity checks
    """


    @staticmethod
    def check_column_consistency(df: pd.DataFrame, expected: list, stage: str = "Unknown") -> dict:
        """
        Checks for missing and extra columns in the DataFrame compared to expected schema.
        """
        actual = set(df.columns)
        expected = set(expected)
        missing = expected - actual
        extra = actual - expected
        logger.debug(f"[{stage}] 🔍 Checking column consistency...")
        logger.debug(f"[{stage}] Actual columns: {sorted(actual)}")
        logger.debug(f"[{stage}] Expected columns: {sorted(expected)}")
        logger.debug(f"[{stage}] Missing columns: {sorted(missing)}")
        logger.debug(f"[{stage}] Extra columns: {sorted(extra)}")
        return {"missing": sorted(missing), "extra": sorted(extra)}

    @staticmethod
    def final_feature_validation(df: pd.DataFrame, schema_path: str = None, schema: list = None, log_id=None) -> None:
        if log_id is None:
            log_id = uuid.uuid4().hex[:8]
        # If schema is not provided, load from schema_path
        if schema is None:
            with open(schema_path, 'r') as f:
                schema = yaml.safe_load(f)

        # 🔍 Contextual Column Presence Check Before Validation
        contextual_columns = ["bp_category", "chol_category", "chol_flag", "risk_level", "age_group", "bp_bin4", "chol_bins", "age_q3", "feature_id_binned"]
        for col in contextual_columns:
            if col not in df.columns:
                logger.error(f"[{log_id}] ❌ Contextual column '{col}' missing before schema check.")

        try:
            context_dict = get_context_dict(df, log_id=log_id)
            logger.info(f"[{log_id}] 🧠 Retrieved context_dict from df: {context_dict}")
        except Exception as e:
            logger.warning(f"[{log_id}] ⚠️ Unable to extract context_dict from DataFrame: {e}")

        config = load_global_config()
        logger.debug(f"[{log_id}] 🧪 [Debug] Loaded GLOBAL_CONFIG for final schema validation")
        logger.debug(f"[{log_id}] 🧪 [Debug] Loaded config keys: {list(config.keys())}")
        logger.debug(f"[{log_id}] 🧪 [Debug] Retrieved 'schemas' config block: {config.get('schemas')}")

        if isinstance(schema, dict):
            # Prefer 'columns' from the provided schema dict; if missing/empty, fall back to config
            expected_columns = schema.get("columns")
            if not expected_columns:
                expected_columns = config.get("final_columns_after_encoding", [])
        elif isinstance(schema, list):
            expected_columns = schema
        else:
            raise ValueError("Invalid schema format: must be dict with 'columns' or a list of column names")

        # Sanity check to avoid silent failures and satisfy static analyzers
        if not isinstance(expected_columns, list):
            raise ValueError(
                f"Expected a list of column names for schema, got {type(expected_columns)}. "
                f"Hint: ensure 'columns' is defined in the schema file or 'final_columns_after_encoding' exists in config."
            )

        logger.info(f"[{log_id}] 📌 Columns before validation: {list(df.columns)}")
        logger.info(f"[{log_id}] 📌 Expected schema columns: {expected_columns}")

        # Compare current DataFrame columns with expected
        issues = FeatureEngineeringValidator.check_column_consistency(df, expected_columns, stage="Final Schema Load")
        if issues["missing"]:
            logger.warning(f"[{log_id}] [Final Schema Load] ⚠️ Missing columns before merge: {issues['missing']}")
        if issues["extra"]:
            logger.warning(f"[{log_id}] [Final Schema Load] ⚠️ Unexpected extra columns before merge: {issues['extra']}")

        missing_cols = [col for col in expected_columns if col not in df.columns]
        if missing_cols:
            logger.error(f"[{log_id}] ❌ Schema validation failed. Missing columns: {missing_cols}")
            raise ValueError(f"Schema mismatch: missing columns: {missing_cols}")

        column_types = schema.get("column_types", {}) if isinstance(schema, dict) else {}

        # 🧼 Pre-validation cleanup — ensure DataFrame is filtered to final expected columns only
        final_columns_after_encoding = [col for col in df.columns if col in expected_columns]
        # Ensure contextual columns are included if they exist
        for col in ["risk_score", "risk_level", "bp_category", "chol_category", "age_group", "bp_bin4", "chol_bins", "age_q3", "feature_id_binned"]:
            if col in df.columns and col not in final_columns_after_encoding:
                final_columns_after_encoding.append(col)
        df = df[final_columns_after_encoding]

        # Validator now assumes protected columns were merged back into the DataFrame after encoding.
        # Schema validation is performed post-merge to ensure all features are present.
        issues = FeatureEngineeringValidator.check_column_consistency(df, expected_columns, stage="Final Validation")

        # 🔍 Additional validation for protected clinical columns
        critical_protected = {"risk_level", "target_copy", "context_feature_id"}
        missing_protected = critical_protected.intersection(set(issues["missing"]))
        if missing_protected:
            logger.error(f"[{log_id}] [Final Validation] ❗ Critical protected columns missing post-encoding/merge: {missing_protected}. "
                         f"Ensure restore_protected_columns() was called after concat.")

        # Enhanced logging to clarify missing columns origin
        if issues["missing"]:
            logger.warning(f"[{log_id}] [Final Validation] ⚠️ Missing columns detected. Verify if due to encoding omission or merge failure.")

        for col in expected_columns:
            if col in df.columns:
                actual_type = str(df[col].dtype)
                expected_type = column_types.get(col)
                if expected_type and expected_type != actual_type:
                    logger.warning(f"[{log_id}] [Type Warning] Column '{col}' expected '{expected_type}', got '{actual_type}'")

        logger.info(f"[{log_id}] 🧬 Final columns validated: {list(df.columns)}")
        logger.info(f"[{log_id}] 🛡️ Schema validation complete. Assumes protected columns restored post-merge.")

        # --- تحليل فريد الأعمدة بعد مرحلة Feature Engineering ---
        clinical_features = [
            "age", "bp_category", "chol_category", "risk_level", "age_group",
            "bp_bin4", "chol_bins", "age_q3", "feature_id_binned"
        ]

        # If derived columns are missing, build them automatically
        missing_derived = [col for col in clinical_features if col not in df.columns]
        if missing_derived:
            logger.info(f"[{log_id}] 🔨 Missing derived clinical features detected: {missing_derived}. Running build_clinical_features()...")
            df = build_clinical_features(df)

        log_column_uniqueness_and_variance(df, clinical_features, logger, min_unique=5)


# Convenience function to resolve missing import
def validate_schema(df: pd.DataFrame, schema_path: str = None, schema: list = None, log_id=None) -> None:
    return FeatureEngineeringValidator.final_feature_validation(df, schema_path=schema_path, schema=schema, log_id=log_id)