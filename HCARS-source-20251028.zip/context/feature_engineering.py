import pandas as pd
import uuid

# استيراد دالة assign_feature_id_by_binned من utils.constants
from utils.constants import assign_feature_id_by_binned

# دالة لمراقبة وضبط تباين الخصائص الأساسية والجديدة
def log_feature_statistics(df, feature_names, logger, stage=""):
    """
    Logs statistics for selected features: unique values, variance, min, max, sample.
    Raises AssertionError if feature is constant.
    Handles both numeric and categorical columns safely.
    """
    for feature in feature_names:
        values = df[feature].dropna()
        unique_count = values.nunique()
        sample_vals = values.head(5).tolist()
        if pd.api.types.is_numeric_dtype(values):
            var = values.var()
            min_val = values.min() if not values.empty else None
            max_val = values.max() if not values.empty else None
            logger.info(
                f"[{stage}] Feature '{feature}': unique={unique_count}, var={var}, min={min_val}, max={max_val}, sample={sample_vals}"
            )
        else:
            logger.info(
                f"[{stage}] Feature '{feature}': unique={unique_count}, sample={sample_vals}"
            )
        assert unique_count > 1, f"[{stage}] Feature '{feature}' has only one unique value! Check feature engineering logic."

from context.clinical_features import (
    derive_chol_flag,
    build_clinical_features
)
# وحدة استعادة القيم المحمية بعد التكويد لضمان استرجاع البيانات الأصلية
from context.fallback import FallbackRestorer, generate_context_feature_id
from utils.column_audit import audit_columns

from utils.config_loader import load_global_config
from context.core import get_context_dict
config = load_global_config()

# يستخدم هذا الإسناد لتوليد معرف مميز لكل سجل استنادًا إلى العمر ومؤشر الصف


def run_feature_engineering(df: pd.DataFrame, risk_transformer=None, log_id=None) -> pd.DataFrame:
    """
    Runs the feature engineering pipeline on the given DataFrame.

    Note:
    All new derived columns such as 'bp_bin4', 'chol_bins', 'age_q3', and 'feature_id_binned'
    are automatically generated within the 'build_clinical_features' function.
    Therefore, there is no need for manual processing of these columns in this function.

    Parameters:
    - df: Input DataFrame.
    - risk_transformer: Optional transformer for risk calculation.
    - log_id: Optional identifier for logging.

    Returns:
    - DataFrame with engineered features.
    """
    from utils.logging_utils import get_feature_engineering_logger
    from context.core import generate_context_features
    from context import router  # added for routing
    logger = get_feature_engineering_logger()
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]

    # Core features and new derived features to monitor
    core_features = ["age", "bp_category", "chol_category", "risk_level"]
    new_derived_features = ["bp_bin4", "chol_bins", "age_q3", "feature_id_binned"]
    all_features_to_check = core_features + new_derived_features

    logger.info(f"[{log_id}] [run_feature_engineering] Starting feature derivation on DataFrame with shape: {df.shape}")

    if not config.get("apply_feature_engineering", True):
        logger.warning(f"[{log_id}] [run_feature_engineering] Skipping feature engineering as per configuration.")
        return df

    # Step 1: Generate context-based features
    logger.info(f"[{log_id}] [run_feature_engineering] Generating context-based features...")
    context_features = config.get("context_features", [])
    df = router.route_context(df, risk_transformer=risk_transformer, log_id=log_id)

    # مراقبة القيم المفقودة والتحذير بعد اشتقاق الخصائص السياقية الأولية
    for col in core_features:
        if col in df.columns:
            n_missing = df[col].isna().sum()
            if n_missing > 0:
                logger.warning(f"[{log_id}] [feature_engineering] Filling {n_missing} missing values in '{col}' with default ('Unknown').")
                df[col].fillna("Unknown", inplace=True)
            unique_vals = df[col].nunique()
            logger.info(f"[{log_id}] [feature_engineering] Checked core feature '{col}' after router: unique values = {unique_vals}")
            if unique_vals <= 1:
                logger.error(f"[{log_id}] [feature_engineering] Feature '{col}' appears constant after router—Review feature engineering logic!")
                raise AssertionError(f"[{log_id}] Feature '{col}' appears constant after router—Check feature engineering pipeline.")

    routed_cols = ["bp_category", "chol_category", "risk_level"]
    for col in routed_cols:
        if col not in df.columns:
            logger.warning(f"[{log_id}] [run_feature_engineering] Column '{col}' was expected from router but is missing.")

    # Step 2: Generate clinical features
    logger.info(f"[{log_id}] [run_feature_engineering] Generating clinical features...")
    df = generate_context_features(df, context_features=context_features, log_id=log_id)

    # مراقبة القيم المفقودة والتحذير بعد اشتقاق الخصائص السياقية من generate_context_features
    for col in core_features:
        if col in df.columns:
            n_missing = df[col].isna().sum()
            if n_missing > 0:
                logger.warning(f"[{log_id}] [feature_engineering] Filling {n_missing} missing values in '{col}' with default ('Unknown').")
                df[col].fillna("Unknown", inplace=True)
            unique_vals = df[col].nunique()
            logger.info(f"[{log_id}] [feature_engineering] Checked core feature '{col}' after generate_context_features: unique values = {unique_vals}")
            if unique_vals <= 1:
                logger.error(f"[{log_id}] [feature_engineering] Feature '{col}' appears constant after generate_context_features—Review feature engineering logic!")
                raise AssertionError(f"[{log_id}] Feature '{col}' appears constant after generate_context_features—Check feature engineering pipeline.")

    context_dict = get_context_dict(df, log_id=log_id)
    logger.info(f"[{log_id}] [run_feature_engineering] Context dictionary extracted: {context_dict}")
    df = build_clinical_features(df)
    logger.info(f"[{log_id}] [run_feature_engineering] build_clinical_features applied - new derived features 'bp_bin4', 'chol_bins', 'age_q3', 'feature_id_binned' should now be present.")

    # توليد feature_id من القيم الجديدة feature_id_binned
    if "feature_id_binned" in df.columns:
        df = assign_feature_id_by_binned(df)
        null_count = df["feature_id"].isnull().sum()
        if null_count > 0:
            logger.warning(f"[{log_id}] [run_feature_engineering] {null_count} feature_id values could not be generated from feature_id_binned. These are set to 'manual_review'.")
        else:
            logger.info(f"[{log_id}] [run_feature_engineering] All feature_id values generated successfully from feature_id_binned.")
    else:
        logger.error(f"[{log_id}] [run_feature_engineering] 'feature_id_binned' column not found. Feature ID assignment skipped.")

    # مراقبة القيم المفقودة والتحذير بعد build_clinical_features لجميع الأعمدة القديمة والجديدة
    for col in all_features_to_check:
        if col in df.columns:
            n_missing = df[col].isna().sum()
            if n_missing > 0:
                logger.warning(f"[{log_id}] [feature_engineering] Filling {n_missing} missing values in '{col}' with default ('Unknown').")
                df[col].fillna("Unknown", inplace=True)
            unique_vals = df[col].nunique()
            logger.info(f"[{log_id}] [feature_engineering] Checked feature '{col}' after build_clinical_features: unique values = {unique_vals}")
            if unique_vals <= 1:
                logger.error(f"[{log_id}] [feature_engineering] Feature '{col}' appears constant after build_clinical_features—Review feature engineering logic!")
                raise AssertionError(f"[{log_id}] Feature '{col}' appears constant after build_clinical_features—Check feature engineering pipeline.")

    # Ensure all critical contextual features are retained after feature engineering
    required_context_cols = ["bp_category", "chol_category", "risk_level", "age_group"] + new_derived_features
    for col in required_context_cols:
        if col not in df.columns or df[col].isnull().all():
            logger.error(f"[{log_id}] ❌ Required contextual column '{col}' is missing or empty after feature engineering.")
            # raise ValueError(f"Missing or empty required contextual feature: {col}")

    incomplete_cols = [col for col in required_context_cols if col not in df.columns or df[col].isnull().all()]
    if incomplete_cols:
        from context.fallback import restore_derived_clinical_columns
        logger.warning(f"[{log_id}] [run_feature_engineering] Missing or empty contextual columns detected: {incomplete_cols}")
        logger.info(f"[{log_id}] [run_feature_engineering] Reapplying restore_derived_clinical_columns for recovery.")
        df = restore_derived_clinical_columns(df, log_id=log_id)

    logger.debug(f"[{log_id}] [run_feature_engineering] Columns after feature engineering:")
    logger.debug(f"[{log_id}] {df.columns.tolist()}")

    audit_columns(df, stage="Feature Engineering")

    logger.info(f"[{log_id}] [run_feature_engineering] Completed. Final columns: {sorted(df.columns.tolist())}")
    logger.debug(f"[{log_id}] [run_feature_engineering] Columns after all steps: {df.columns.tolist()}")

    # تحقق من تباين الخصائص الأساسية والمشتقة المهمة
    log_feature_statistics(df, all_features_to_check, logger=logger, stage="نهاية feature_engineering")

    return df

# العناصر المعروضة مصممة لدعم استيراد مرن عند استخدام from feature_engineering import *
__all__ = [
    "derive_chol_flag",
    "FallbackRestorer",
    "generate_context_feature_id",
    "build_clinical_features",
    "run_feature_engineering",
    "log_feature_statistics"
]
