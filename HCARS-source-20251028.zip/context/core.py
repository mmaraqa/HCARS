"""
🧬 Core Feature Engineering Module
----------------------------------
Provides foundational clinical transformations for hypertension-related recommendation systems.

✅ Responsibilities:
    - Categorize patient age into discrete age groups.
    - Classify blood pressure based on AHA/ACC hypertension stages.
    - Categorize cholesterol levels using NIH thresholds.
    - Derive high-level features (e.g., age_group, bp_category, chol_category) used by SHAP and hybrid models.
    - Support additional extended context features (bp_bin4, chol_bins, age_q3, feature_id_binned) generated automatically via clinical_features.py.

📐 Standards Compliance:
    - AHA/ACC 2017 guidelines for BP staging.
    - NIH/WHO guidelines for cholesterol.
    - Modular design per ISO/IEC 25010 and traceable logic per ISO 13485 and ISO 27001.

🔒 Used as a foundational utility by context-based feature derivation modules.
"""
# 🔧 This module is invoked by clinical_features.py to generate context-based features such as age_group, bp_category, chol_category, and extended context features like bp_bin4, chol_bins, age_q3, feature_id_binned.
# 🧪 Ensures consistent feature derivation logic for hybrid recommendations and SHAP interpretability.

import pandas as pd

# ➕ Helper to safely coerce numbers coming from mixed types (e.g., strings)
def _coerce_float(x):
    try:
        if x is None or (isinstance(x, float) and pd.isna(x)):
            return pd.NA
        if isinstance(x, str):
            x = x.strip()
            if x == "":
                return pd.NA
            try:
                return float(x)
            except ValueError:
                # try to extract first number
                import re
                m = re.search(r"[-+]?\d*\.?\d+", x)
                return float(m.group(0)) if m else pd.NA
        return float(x)
    except (TypeError, ValueError, OverflowError):
        # Narrowly catch conversion-related errors only
        return pd.NA

# ➕ أضيفت هذه الدالة لتنظيف أعمدة ضغط الدم الزائدة وتوحيدها
def harmonize_bp_columns(df, prefer='trestbps'):
    """
    Harmonize blood pressure columns in your DataFrame.
    - If 'systolic_bp' and 'diastolic_bp' are just copies of 'trestbps', can drop the generated ones.
    - Set 'prefer' to 'systolic_bp' or 'trestbps' based on which you want to keep as main.

    Args:
        df (pd.DataFrame): Input DataFrame.
        prefer (str): Which column to keep as main systolic. Options: 'trestbps' or 'systolic_bp'.

    Returns:
        pd.DataFrame: Cleaned DataFrame with harmonized BP columns.
    """
    # If 'systolic_bp' is identical to 'trestbps', you don't need both
    if 'systolic_bp' in df.columns and 'trestbps' in df.columns:
        if df['systolic_bp'].equals(df['trestbps']):
            if prefer == 'trestbps':
                df = df.drop(columns=['systolic_bp'])
            else:
                df = df.drop(columns=['trestbps'])
    # Optionally drop 'diastolic_bp' if it's always missing or constant
    if 'diastolic_bp' in df.columns:
        if df['diastolic_bp'].isnull().all() or df['diastolic_bp'].nunique() <= 1:
            df = df.drop(columns=['diastolic_bp'])
    return df
import uuid
from utils.config_loader import load_global_config
CONFIG = load_global_config()

# ➕ Helper function to log feature statistics and detect constant features
def log_feature_statistics(df, features, log=None, stage=""):
    from utils.logging_utils import get_feature_engineering_logger
    log = log or get_feature_engineering_logger()
    for feature in features:
        if feature in df.columns:
            unique_vals = df[feature].nunique(dropna=True)
            sample_vals = df[feature].dropna().unique()[:5]
            log.info(f"{stage} Feature '{feature}': Unique values count = {unique_vals}, Sample values = {sample_vals}")
            if unique_vals <= 1:
                log.error(f"{stage} Feature '{feature}' is constant or nearly constant!")
                raise ValueError(f"{stage} Feature '{feature}' is constant or nearly constant!")

def categorize_age(age):
    age = _coerce_float(age)
    if pd.isna(age) or age < 0:
        return pd.NA
    bins = [0, 18, 30, 45, 60, 75, float('inf')]
    labels = ["<18", "18–30", "31–45", "46–60", "61–75", "75+"]
    return pd.cut([age], bins=bins, labels=labels, right=False)[0]

def generate_bp_category(systolic: float, diastolic: float) -> str:
    """Classify BP using ACC/AHA 2017 staging.
    - Works if only systolic is present (diastolic may be NaN).
    - Returns 'Unknown' when both are missing or invalid.
    """
    systolic = _coerce_float(systolic)
    diastolic = _coerce_float(diastolic)

    # Handle missing values entirely
    if (pd.isna(systolic)) and (pd.isna(diastolic)):
        return "Unknown"

    # Guard against impossible negatives
    if (not pd.isna(systolic) and systolic < 0) or (not pd.isna(diastolic) and diastolic < 0):
        return "Unknown"

    # Hypertensive Crisis
    if (not pd.isna(systolic) and systolic >= 180) or (not pd.isna(diastolic) and diastolic >= 120):
        return "Hypertensive Crisis"

    # Stage 2 Hypertension
    if (not pd.isna(systolic) and systolic >= 140) or (not pd.isna(diastolic) and diastolic >= 90):
        return "Hypertension Stage 2"

    # Stage 1 Hypertension
    if (not pd.isna(systolic) and 130 <= systolic < 140) or (not pd.isna(diastolic) and 80 <= diastolic < 90):
        return "Hypertension Stage 1"

    # Elevated (requires diastolic < 80 if diastolic is known)
    if (not pd.isna(systolic) and 120 <= systolic < 130) and (pd.isna(diastolic) or diastolic < 80):
        return "Elevated"

    # Normal (requires diastolic < 80 if diastolic is known)
    if (not pd.isna(systolic) and systolic < 120) and (pd.isna(diastolic) or diastolic < 80):
        return "Normal"

    return "Unknown"

def generate_chol_category(cholesterol: float) -> str:
    cholesterol = _coerce_float(cholesterol)
    if pd.isna(cholesterol) or cholesterol < 0:
        return "Unknown"
    if cholesterol < 200:
        return "Desirable"
    elif 200 <= cholesterol < 240:
        return "Borderline High"
    else:
        return "High"

def derive_bp_category(df: pd.DataFrame) -> pd.DataFrame:
    if "trestbps" in df.columns:
        s = df["trestbps"].apply(_coerce_float)

        cats = pd.cut(
            s,
            bins=[0, 120, 130, 140, 180, float("inf")],
            labels=["Normal", "Elevated", "Hypertension Stage 1", "Hypertension Stage 2", "Hypertensive Crisis"],
            include_lowest=True,
            right=False
        ).astype("object")

        invalid = s.isna() | (s < 0)
        cats[invalid] = "Unknown"

        bp_order = ["Normal", "Elevated", "Hypertension Stage 1", "Hypertension Stage 2", "Hypertensive Crisis", "Unknown"]
        df["bp_category"] = pd.Categorical(cats, categories=bp_order, ordered=True)
    return df

def derive_chol_category(df: pd.DataFrame) -> pd.DataFrame:
    if "chol" in df.columns:
        df["chol_category"] = pd.cut(
            df["chol"],
            bins=[0, 200, 239, float("inf")],
            labels=["Desirable", "Borderline High", "High"],
            include_lowest=True,  # ensure 0→Desirable, 200→Borderline High
            right=True            # 239 included in Borderline High, 240+ → High
        )
    return df

# ➕ Ensure consistent ordered categories for context columns
def enforce_context_category_orders(df: pd.DataFrame) -> pd.DataFrame:
    if "bp_category" in df.columns:
        bp_order = [
            "Normal",
            "Elevated",
            "Hypertension Stage 1",
            "Hypertension Stage 2",
            "Hypertensive Crisis",
            "Unknown",
        ]
        df["bp_category"] = pd.Categorical(df["bp_category"], categories=bp_order, ordered=True)
    if "chol_category" in df.columns:
        chol_order = ["Desirable", "Borderline High", "High", "Unknown"]
        df["chol_category"] = pd.Categorical(df["chol_category"], categories=chol_order, ordered=True)
    if "age_group" in df.columns:
        age_order = ["<18", "18–30", "31–45", "46–60", "61–75", "75+"]
        df["age_group"] = pd.Categorical(df["age_group"], categories=age_order, ordered=True)
    if "risk_level" in df.columns:
        risk_order = ["low", "medium", "high"]
        df["risk_level"] = pd.Categorical(df["risk_level"], categories=risk_order, ordered=True)
    return df

def generate_derived_features(df):
    from utils.logging_utils import get_feature_engineering_logger
    log = get_feature_engineering_logger()

    # Drop legacy/duplicated inputs only (keep BP columns)
    if 'age_category' in df.columns:
        df = df.drop(columns=['age_category'])
    if 'cholesterol' in df.columns:
        df = df.drop(columns=['cholesterol'])

    # Harmonize BP-related columns to avoid redundant copies or all-NA columns
    df = harmonize_bp_columns(df, prefer='trestbps')

    # ➕ Categorize age into clinical groups
    df['age_group'] = df['age'].apply(categorize_age)
    log.info("🧬 Created age_group column")
    log.debug(f"age_group distribution: {df['age_group'].value_counts(dropna=False).to_dict()}")

    # 🔍 Ensure systolic and diastolic BP columns exist
    if 'systolic_bp' not in df.columns:
        if 'trestbps' in df.columns:
            df['systolic_bp'] = df['trestbps']
        else:
            df['systolic_bp'] = pd.NA
    if 'diastolic_bp' not in df.columns:
        df['diastolic_bp'] = pd.NA
    log.info("🩺 Ensured presence of systolic_bp and diastolic_bp columns (diastolic left as NA if unavailable)")

    # ➕ Generate blood pressure category from systolic and diastolic values
    df['bp_category'] = df.apply(lambda row: generate_bp_category(row['systolic_bp'], row['diastolic_bp']), axis=1)
    log.info("🩺 Created bp_category column")
    log.debug(f"bp_category distribution: {df['bp_category'].value_counts(dropna=False).to_dict()}")

    # ➕ Derive cholesterol category
    df['chol_category'] = df['chol'].apply(generate_chol_category)
    log.info("🩸 Created chol_category column")
    log.debug(f"chol_category distribution: {df['chol_category'].value_counts(dropna=False).to_dict()}")

    # ➕ Enforce ordered categories for consistent downstream behavior
    df = enforce_context_category_orders(df)

    # ➕ Check for duplicate rows after feature generation
    assert len(df) == len(df.drop_duplicates()), "[core] Duplicate rows detected after feature generation!"

    log.info(f"📊 Final columns after feature generation: {list(df.columns)}")

    # ➕ Log feature statistics for key and extended context features
    key_features = ["age", "bp_category", "chol_category", "risk_level"]
    extended_features = ["bp_bin4", "chol_bins", "age_q3", "feature_id_binned"]
    all_features_to_log = key_features + [f for f in extended_features if f in df.columns]
    log_feature_statistics(df, all_features_to_log, log, stage="[generate_derived_features]")

    return df

def generate_context_features(df: pd.DataFrame, log_id=None, **kwargs) -> pd.DataFrame:
    """
    🧠 Generate contextual features: age_group, bp_category, chol_category, risk_level
    - Ensures all essential clinical context features are present.
    - Supports extended context features (bp_bin4, chol_bins, age_q3, feature_id_binned) which are generated automatically via clinical_features.py.
    """
    from utils.logging_utils import get_feature_engineering_logger
    log = get_feature_engineering_logger()
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    apply_feature_engineering = CONFIG.get("apply_feature_engineering", True)
    if not apply_feature_engineering:
        log.warning(f"[{log_id}] ⚠️ Feature engineering is disabled via config — skipping generation.")
        return df
    log.debug(f"[{log_id}] 🧪 STEP 1: Starting contextual feature generation pipeline...")

    log.debug(f"[{log_id}] 🧪 STEP 2: Calling build_clinical_features...")
    from context.clinical_features import build_clinical_features
    existing_cols = df.columns.tolist()
    # Add extended context features to the list of contextual columns
    contextual_cols = ["age_group", "bp_category", "chol_category", "bp_bin4", "chol_bins", "age_q3", "feature_id_binned"]
    missing_contextual_cols = [col for col in contextual_cols if col not in existing_cols]
    # Also rebuild if any context col is present but all values are null
    if missing_contextual_cols or any(col in df.columns and df[col].isnull().all() for col in contextual_cols):
        log.debug(f"[{log_id}] 🔄 Rebuilding clinical features for missing or null columns: {missing_contextual_cols}")
        df = build_clinical_features(df, **kwargs)
        # Log distributions for extended features after build_clinical_features
        for context_feature_col in ["bp_bin4", "chol_bins", "age_q3", "feature_id_binned"]:
            if context_feature_col in df.columns:
                context_feature_dist = df[context_feature_col].value_counts(dropna=False).to_dict()
                log.info(f"[{log_id}] Distribution for '{context_feature_col}': {context_feature_dist}")
    else:
        log.debug(f"[{log_id}] ⏩ Skipping build_clinical_features: Contextual columns already present.")
    log.info(f"[{log_id}] ✅ STEP 2 completed: Clinical features built successfully.")
    log.debug(f"[{log_id}] 📌 Columns after build_clinical_features: {df.columns.tolist()}")

    from utils.risk_score_transformer import RiskScoreTransformer
    log.debug(f"[{log_id}] 🧪 STEP 3: Applying RiskScoreTransformer...")
    risk_transformer = RiskScoreTransformer()
    df = risk_transformer.transform(df)
    log.info(f"[{log_id}] ✅ STEP 3 completed: Risk scoring applied.")
    log.debug(f"[{log_id}] 📌 Columns after RiskScoreTransformer: {df.columns.tolist()}")

    # ✅ Ensure context features are correctly preserved and assigned
    required_cols = ["age_group", "bp_category", "chol_category", "risk_level", "bp_bin4", "chol_bins", "age_q3", "feature_id_binned"]
    for col in required_cols:
        if col not in df.columns:
            log.warning(f"[{log_id}] ⚠️ Context feature '{col}' is missing — assigning 'Unspecified'")
            df[col] = "Unspecified"
        else:
            missing_count = df[col].isna().sum()
            if missing_count > 0:
                log.warning(f"[{log_id}] ⚠️ Context feature '{col}' has {missing_count} missing values — filling with 'Unknown'")
                df[col] = df[col].fillna("Unknown")
    # ➕ Enforce ordered categories for context columns after filling missings
    df = enforce_context_category_orders(df)

    # ➕ Check for duplicate rows after context features generation (if any reset_index or merge happened here)
    # (No reset_index or merge here, but adding assert for safety)
    try:
        assert len(df) == len(df.drop_duplicates()), "[core] Duplicate rows detected after context feature generation!"
    except AssertionError as e:
        log.error(str(e))
        raise

    from context.context_validation import check_context_columns
    log.debug(f"[{log_id}] 🧪 STEP 4: Validating required context columns...")
    check_context_columns(df)

    missing_cols = [col for col in required_cols if col not in df.columns]
    log.info(f"[{log_id}] ✅ Present context features: {[col for col in required_cols if col in df.columns]}")
    if missing_cols:
        log.warning(f"[{log_id}] ⚠️ Missing context features: {missing_cols}")
    else:
        log.info(f"[{log_id}] ✅ All required context features successfully generated.")
    log.debug(f"[{log_id}] 📊 Final DataFrame columns: {df.columns.tolist()}")

    # ➕ Log feature statistics for key features after context features generation
    key_features = ["age", "bp_category", "chol_category", "risk_level"]
    extended_features = ["bp_bin4", "chol_bins", "age_q3", "feature_id_binned"]
    all_features_to_log = key_features + [f for f in extended_features if f in df.columns]
    log_feature_statistics(df, all_features_to_log, log, stage=f"[generate_context_features {log_id}]")

    return df

def get_context_dict(df: pd.DataFrame, log_id=None) -> dict:
    """
    🔍 Extract context values from a post-encoding DataFrame before final column filtering.
    assumes the DataFrame has already passed through encoding and context columns are restored.

    Parameters:
        df (pd.DataFrame): DataFrame containing clinical context features.
        log_id (str, optional): Unique identifier used for logging context-related decisions.

    Returns:
        dict: Dictionary of extracted context features (bp_category, chol_category, risk_level, age_group).
    """
    from utils.logging_utils import get_feature_engineering_logger
    log = get_feature_engineering_logger()
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    context_keys = ["bp_category", "chol_category", "risk_level", "age_group"]
    context_dict = {}
    for key in context_keys:
        if key in df.columns and df[key].notnull().any():
            context_dict[key] = df[key].mode()[0]  # Most frequent valid value
        else:
            context_dict[key] = "Unknown"
            log.warning(f"[{log_id}] ⚠️ Context value for '{key}' is missing or null — defaulting to 'Unknown'")
    log.info(f"[{log_id}] 🧠 Final context_dict generated: {context_dict}")
    return context_dict

if __name__ == "__main__":
    import logging
    logger = logging.getLogger("core_test_logger")
    logging.basicConfig(level=logging.DEBUG)
    logger.debug("🧪 Running core feature generation test...")
    test_df = pd.DataFrame({'age': [15, 25, 35, 50, 68, 80], 'trestbps': [110, 122, 135, 140, 145, 160], 'chol': [170, 195, 220, 230, 250, 280]})
    test_df = generate_derived_features(test_df)
    test_df['context_feature_id'] = test_df.index.astype(str) + "_" + test_df['age'].astype(str)
    logger.debug(test_df[['age', 'age_group', 'systolic_bp', 'diastolic_bp', 'bp_category', 'chol_category', 'context_feature_id']])
    # Additionally, generate extended context features via build_clinical_features and log their distributions
    from context.clinical_features import build_clinical_features
    test_df = build_clinical_features(test_df)
    for test_feature_col in ["bp_bin4", "chol_bins", "age_q3", "feature_id_binned"]:
        if test_feature_col in test_df.columns:
            test_feature_dist = test_df[test_feature_col].value_counts(dropna=False).to_dict()
            logger.info(f"Test distribution for '{test_feature_col}': {test_feature_dist}")
