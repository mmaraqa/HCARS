# ⚠️ [2025-06-28] تم تحديث الأعمدة السياقية لتشمل فئات binning الجديدة: bp_bin4, chol_bins, age_q3, feature_id_binned.
from utils.config_loader import load_global_config
import uuid
config = load_global_config()
import logging

__all__ = ["check_context_columns", "get_missing_context_columns", "has_context_features", "requires_context_features", "validate_context_columns", "get_context_values"]

logger = logging.getLogger(__name__)

REQUIRED_CONTEXT_COLUMNS = config.get(
    "context_features",
    ["bp_category", "chol_category", "risk_level", "age_group", "bp_bin4", "chol_bins", "age_q3", "feature_id_binned"]
)


def check_context_columns(df, required_columns=None, context: str = "", log_id=None):
    """
    ✅ Check that all required contextual features, including new binning categories, are present in the DataFrame.
    Supports the expanded context columns: bp_category, chol_category, risk_level, age_group,
    bp_bin4, chol_bins, age_q3, feature_id_binned.
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    columns_to_check = required_columns or REQUIRED_CONTEXT_COLUMNS
    missing = [col for col in columns_to_check if col not in df.columns]
    if missing:
        logger.warning(f"[{log_id}][{context}] 🧪 Columns present at validation point: {sorted(df.columns.tolist())}")
        logger.error(f"[{log_id}][{context}] ❌ Missing contextual columns: {missing}")
        print(f"[{log_id}][{context}] ❌ Missing contextual columns: {missing}")
        print(f"[{log_id}][{context}] 🧪 Columns present: {sorted(df.columns.tolist())}")
        raise ValueError(f"[{log_id}][{context}] CRITICAL ERROR: Required contextual columns missing: {missing}")
    logger.info(f"[{log_id}][{context}] ✅ All contextual columns are present.")
    print(f"[{log_id}][{context}] ✅ All contextual columns are present.")
    logger.info(f"[{log_id}][{context}] ✅ Context columns found: {sorted(columns_to_check)}")

    # 🔥 تحليل تباين الأعمدة السياقية وضبط الجودة الصارم
    log_context_feature_statistics(df, logger, stage=context)

    return True

def log_context_feature_statistics(df, log, stage="context_validation"):
    """
    يسجل معلومات إحصائية عن الأعمدة السياقية الموسعة.
    • عدد القيم الفريدة لكل عمود
    • القيم المفقودة لكل عمود
    • إذا كانت الخاصية ثابتة تمامًا (عدد القيم الفريدة = 1)، يُسجل خطأ ويرفع Exception.
    يدعم الأعمدة الجديدة: bp_bin4, chol_bins, age_q3, feature_id_binned.
    """
    context_features = REQUIRED_CONTEXT_COLUMNS
    new_cols = ['bp_bin4','chol_bins','age_q3','feature_id_binned']
    for col in context_features:
        if col in df.columns:
            n_unique = df[col].nunique(dropna=True)
            n_missing = df[col].isna().sum()
            label = "NEW" if col in new_cols else "orig."
            log.info(f"[{stage}] Context column '{col}' ({label}): Unique={n_unique}, Missing={n_missing}, Sample={df[col].dropna().unique()[:3]}")
            if n_unique <= 1:
                log.error(f"[{stage}] ❌ Feature '{col}' is constant or nearly constant! Values: {df[col].unique()}")
                raise ValueError(f"[{stage}] ❌ Feature '{col}' is constant or nearly constant! Review feature engineering.")


# New function to extract context values from a valid DataFrame
def get_context_values(df, log_id=None):
    """
    ✅ Extract contextual values from a valid DataFrame including expanded context columns.
    Returns a dictionary with context keys and their first valid value.
    Supports: bp_category, chol_category, risk_level, age_group,
    bp_bin4, chol_bins, age_q3, feature_id_binned.
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    check_context_columns(df, context="get_context_values", log_id=log_id)
    context_values = {}
    for col in REQUIRED_CONTEXT_COLUMNS:
        val = df[col].dropna().unique()
        context_values[col] = val[0] if len(val) > 0 else "unknown"
    logger.info(f"[{log_id}][get_context_values] ✅ Extracted context values: {context_values}")
    return context_values

# Alias for check_context_columns
def validate_context_columns(df, context: str = "", log_id=None):
    """
    ✅ Alias function to validate presence of all expanded contextual columns before processing.
    Supports the new contextual columns added for binning and feature combinations.
    """
    return check_context_columns(df, context=context, log_id=log_id)

def get_missing_context_columns(df):
    """
    🧪 Return a list of contextual columns that are missing from the DataFrame,
    including the new binning and combined feature columns.
    """
    return [col for col in REQUIRED_CONTEXT_COLUMNS if col not in df.columns]

def has_context_features(df):
    """
    ✅ Boolean check: returns True if all expanded contextual columns are present.
    """
    return all(col in df.columns for col in REQUIRED_CONTEXT_COLUMNS)

def requires_context_features(func):
    """
    🚨 Decorator: enforce presence of all expanded contextual columns before running the function.
    """
    def wrapper(df, *args, **kwargs):
        log_id = kwargs.pop('log_id', None)
        check_context_columns(df, context=func.__name__, log_id=log_id)
        return func(df, *args, **kwargs)
    return wrapper
