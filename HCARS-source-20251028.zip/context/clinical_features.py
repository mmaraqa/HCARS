
import numpy as np
import pandas as pd
from dataclasses import dataclass
from typing import Optional
import logging
import uuid
from context.response_initializer import assign_feature_id_by_binned

logger = logging.getLogger(__name__)

# --- Constants and ordered category helpers ---
UNKNOWN = "unknown"

BP_CATEGORY_ORDER = [
    "Normal",
    "Elevated",
    "Hypertension Stage 1",
    "Hypertension Stage 2",
    "Hypertensive Crisis",
    UNKNOWN
]
CHOL_CATEGORY_ORDER = ["Desirable", "Borderline High", "High", UNKNOWN]
AGE_GROUP_ORDER = ["<18", "18–30", "31–45", "46–60", "61–75", "75+"]
RISK_LEVEL_ORDER = ["low", "medium", "high", UNKNOWN]

from pandas.api.types import CategoricalDtype

def enforce_context_category_orders(df: pd.DataFrame) -> pd.DataFrame:
    """
    Cast key context columns to ordered categoricals with a consistent logical order.
    This improves statistical summaries, plots, and model explainability.
    """
    orders = {
        "bp_category": BP_CATEGORY_ORDER,
        "chol_category": CHOL_CATEGORY_ORDER,
        "age_group": AGE_GROUP_ORDER,
        "risk_level": RISK_LEVEL_ORDER,
    }

    for col, order in orders.items():
        if col not in df.columns:
            continue

        # خرائط تطبيع مخصّصة لكل عمود لتفادي تضارب المفاتيح مثل 'high'
        if col == "bp_category":
            norm_map = {
                "normal": "Normal",
                "elevated": "Elevated",
                "hypertension stage 1": "Hypertension Stage 1",
                "hypertension stage 2": "Hypertension Stage 2",
                "hypertensive crisis": "Hypertensive Crisis",
                "unknown": UNKNOWN,
            }
        elif col == "chol_category":
            norm_map = {
                "desirable": "Desirable",
                "borderline high": "Borderline High",
                "high": "High",        # High للكوليسترول
                "unknown": UNKNOWN,
            }
        elif col == "age_group":
            # دعم كلا نوعي الشرطة (en dash / hyphen) وأي صيغ شائعة
            norm_map = {
                "<18": "<18",
                "18–30": "18–30",
                "18-30": "18–30",
                "31–45": "31–45",
                "31-45": "31–45",
                "46–60": "46–60",
                "46-60": "46–60",
                "61–75": "61–75",
                "61-75": "61–75",
                "75+": "75+",
                "unknown": UNKNOWN,
            }
        elif col == "risk_level":
            norm_map = {
                "low": "low",
                "medium": "medium",
                "high": "high",        # high لمستوى الخطر (تبقى بحروف صغيرة)
                "unknown": UNKNOWN,
            }
        else:
            norm_map = {"unknown": UNKNOWN}

        try:
            ser = df[col].astype(str).str.strip().str.lower().replace({"": "unknown"})
            ser = ser.replace(norm_map)
            cat_dtype = CategoricalDtype(categories=order, ordered=True)
            df[col] = ser.astype(cat_dtype)  # استخدام المتغيّر فعلياً (لا تحذير unused)
        except (ValueError, TypeError) as e:
            logger.warning(
                f"[enforce_context_category_orders] Failed to cast '{col}' "
                f"to ordered categorical: {e}. Falling back to safe cast."
            )
            cat_dtype = CategoricalDtype(categories=order, ordered=True)
            df[col] = df[col].astype(cat_dtype)

    return df
# --- Low-level binning utility functions (for direct Series binning) ---
def bin_trestbps_to_4q(series):
    """
    Quartile binning for systolic blood pressure (trestbps).
    """
    return pd.qcut(series, q=4, labels=['Q1', 'Q2', 'Q3', 'Q4'])

def bin_chol_to_5q(series):
    """
    Quintile binning for cholesterol.
    """
    return pd.qcut(series, q=5)

def bin_age_to_3q(series):
    """
    Tertile binning for age.
    """
    return pd.qcut(series, q=3, labels=['Young', 'Middle', 'Old'])

def make_feature_id_binned(df):
    """
    Combines bp_bin4, chol_bins, and age_q3 columns into a composite binned feature_id.
    """
    if all(col in df.columns for col in ['bp_bin4', 'chol_bins', 'age_q3']):
        return (
            df['bp_bin4'].astype(str) + '__' +
            df['chol_bins'].astype(str) + '__' +
            df['age_q3'].astype(str)
        )
    else:
        raise ValueError("Required columns for feature_id_binned are missing: bp_bin4, chol_bins, age_q3")

# --- Advanced binning and composite feature functions ---
def add_bp_bin4(df: pd.DataFrame, log_id=None) -> pd.DataFrame:
    """
    Adds 'bp_bin4' column: Quartile bins for systolic BP (trestbps).
    """
    import uuid
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    if "trestbps" in df.columns:
        df["bp_bin4"] = pd.qcut(df["trestbps"], q=4, labels=['Q1', 'Q2', 'Q3', 'Q4'])
        logger.info(f"[{log_id}] Created 'bp_bin4' with value counts:\n{df['bp_bin4'].value_counts()}")
    else:
        logger.warning(f"[{log_id}] 'trestbps' missing. 'bp_bin4' not created.")
    return df

def add_chol_bins(df: pd.DataFrame, log_id=None) -> pd.DataFrame:
    """
    Adds 'chol_bins' column: Quintile bins for cholesterol.
    """
    import uuid
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    if "chol" in df.columns:
        df["chol_bins"] = pd.qcut(df["chol"], q=5)
        logger.info(f"[{log_id}] Created 'chol_bins' with value counts:\n{df['chol_bins'].value_counts()}")
    else:
        logger.warning(f"[{log_id}] 'chol' missing. 'chol_bins' not created.")
    return df

def add_age_q3(df: pd.DataFrame, log_id=None) -> pd.DataFrame:
    """
    Adds 'age_q3' column: Tertile bins for age.
    """
    import uuid
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    if "age" in df.columns:
        df["age_q3"] = pd.qcut(df["age"], q=3, labels=['Young', 'Middle', 'Old'])
        logger.info(f"[{log_id}] Created 'age_q3' with value counts:\n{df['age_q3'].value_counts()}")
    else:
        logger.warning(f"[{log_id}] 'age' missing. 'age_q3' not created.")
    return df

def add_feature_id_binned(df: pd.DataFrame, log_id=None) -> pd.DataFrame:
    """
    Combines the binned features into a unique context key.
    """
    import uuid
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    needed_cols = ['bp_bin4', 'chol_bins', 'age_q3']
    if all(col in df.columns for col in needed_cols):
        df['feature_id_binned'] = (
            df['bp_bin4'].astype(str) + '__' +
            df['chol_bins'].astype(str) + '__' +
            df['age_q3'].astype(str)
        )
        logger.info(f"[{log_id}] Created 'feature_id_binned' with {df['feature_id_binned'].nunique()} unique values.")
    else:
        logger.warning(f"[{log_id}] Missing one or more binned columns. 'feature_id_binned' not created.")
    return df

def add_binned_features_pipeline(df: pd.DataFrame, log_id=None) -> pd.DataFrame:
    """
    Pipeline for adding all binned context columns and combined feature_id_binned.
    """
    df = add_bp_bin4(df, log_id=log_id)
    df = add_chol_bins(df, log_id=log_id)
    df = add_age_q3(df, log_id=log_id)
    df = add_feature_id_binned(df, log_id=log_id)
    return df

def log_feature_statistics(df, features, log, stage=""):
    for feature in features:
        if feature in df.columns:
            unique_vals = df[feature].nunique(dropna=True)
            min_val = df[feature].min() if hasattr(df[feature], 'min') else None
            max_val = df[feature].max() if hasattr(df[feature], 'max') else None
            sample_vals = df[feature].dropna().unique()[:5]
            log.info(f"{stage} Feature '{feature}': Unique={unique_vals}, Min={min_val}, Max={max_val}, Sample={sample_vals}")
            if unique_vals <= 1:
                log.error(f"{stage} Feature '{feature}' is constant or nearly constant!")
                raise ValueError(f"{stage} Feature '{feature}' is constant or nearly constant!")

from utils.config_loader import load_global_config
config = load_global_config()

# --- New simple add_* category/risk functions ---
def add_bp_category(df: pd.DataFrame, log_id=None) -> pd.DataFrame:
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]

    if "trestbps" in df.columns and df["trestbps"].notnull().any():
        df["bp_category"] = pd.cut(
            df["trestbps"],
            bins=[0, 120, 129, 139, 180, 300],
            labels=["Normal", "Elevated", "Hypertension Stage 1", "Hypertension Stage 2", "Hypertensive Crisis"],
            include_lowest=True, right=True
        )
        logger.info(f"[{log_id}] Assigned blood pressure categories based on 'trestbps'.")
    elif "systolic_bp" in df.columns and "diastolic_bp" in df.columns:
        df["bp_category"] = df.apply(
            lambda row: categorize_bp(row["systolic_bp"], row["diastolic_bp"])
            if pd.notnull(row["systolic_bp"]) and pd.notnull(row["diastolic_bp"])
            else UNKNOWN, axis=1
        )
        logger.info(f"[{log_id}] Assigned blood pressure categories based on 'systolic_bp' and 'diastolic_bp'.")
    else:
        logger.warning(f"[{log_id}] No available columns to assign blood pressure categories.")
        df["bp_category"] = UNKNOWN

    log_feature_statistics(df, ["bp_category"], logger, stage=f"[{log_id}] After add_bp_category")

    return df

def categorize_fbs(fbs):
    """
    يصنف Fasting Blood Sugar (fbs) حسب القيم السريرية:
      - high_fbs: إذا كان fbs = 1 (سكر صيامي مرتفع > 120 mg/dl)
      - normal_fbs: إذا كان fbs = 0 (طبيعي)
      - unknown: لأي قيمة ناقصة أو غير معروفة
    """
    try:
        if pd.isnull(fbs):
            return UNKNOWN
        return "high_fbs" if int(fbs) == 1 else "normal_fbs"
    except (TypeError, ValueError, OverflowError) as e:
        logger.error(f"[categorize_fbs] ❌ Failed to categorize fbs: {e} (fbs={fbs})")
        return UNKNOWN

def categorize_cp(cp):
    """
    يصنف Chest Pain Type (cp) سريرياً حسب تعريف بيانات القلب:
      - asymptomatic: 0
      - typical_angina: 1
      - atypical_angina: 2
      - non_anginal_pain: 3
      - unknown: لأي قيمة ناقصة أو غير معروفة
    """
    try:
        if pd.isnull(cp):
            return UNKNOWN
        mapping = {
            0: "asymptomatic",
            1: "typical_angina",
            2: "atypical_angina",
            3: "non_anginal_pain"
        }
        return mapping.get(int(cp), UNKNOWN)
    except (TypeError, ValueError, OverflowError) as e:
        logger.error(f"[categorize_cp] ❌ Failed to categorize cp: {e} (cp={cp})")
        return UNKNOWN

def add_fbs_cp_categories(df: pd.DataFrame, log_id=None) -> pd.DataFrame:
    """
    يضيف عمودين سياقيين مشتقين:
      - fbs_cat: تصنيف السكر الصيامي (categorize_fbs)
      - cp_cat: تصنيف ألم الصدر (categorize_cp)
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    if "fbs" in df.columns:
        df["fbs_cat"] = df["fbs"].apply(categorize_fbs)
        logger.info(f"[{log_id}] Created 'fbs_cat' via categorize_fbs. Unique: {df['fbs_cat'].unique().tolist()}")
    else:
        logger.warning(f"[{log_id}] Column 'fbs' missing. Cannot create 'fbs_cat'.")
        df["fbs_cat"] = UNKNOWN
    if "cp" in df.columns:
        df["cp_cat"] = df["cp"].apply(categorize_cp)
        logger.info(f"[{log_id}] Created 'cp_cat' via categorize_cp. Unique: {df['cp_cat'].unique().tolist()}")
    else:
        logger.warning(f"[{log_id}] Column 'cp' missing. Cannot create 'cp_cat'.")
        df["cp_cat"] = UNKNOWN
    return df


def add_chol_category(df: pd.DataFrame, log_id=None) -> pd.DataFrame:
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    if "chol" in df.columns:
        df["chol_category"] = pd.cut(
            df["chol"],
            bins=[0, 200, 239, float("inf")],
            labels=["Desirable", "Borderline High", "High"],
            include_lowest=True, right=True
        )
        logger.info(f"[{log_id}] Assigned cholesterol categories based on 'chol'.")
        log_feature_statistics(df, ["chol_category"], logger, stage=f"[{log_id}] After add_chol_category")
    else:
        logger.warning(f"[{log_id}] 'chol' column missing. Cannot assign cholesterol categories.")
    return df

def add_risk_level(df: pd.DataFrame, log_id=None) -> pd.DataFrame:
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    if "risk_score" not in df.columns:
        df["risk_score"] = df.apply(lambda row: calculate_risk_score(row), axis=1)
        logger.info(f"[{log_id}] Calculated 'risk_score' for DataFrame.")
    df["risk_level"] = df["risk_score"].apply(assign_risk_level)
    logger.info(f"[{log_id}] Assigned 'risk_level' based on 'risk_score'.")
    log_feature_statistics(df, ["risk_level"], logger, stage=f"[{log_id}] After add_risk_level")
    return df

@dataclass
class RiskScoringConfig:
    age_weight: float = 0.4
    bp_weight: float = 0.35
    chol_weight: float = 0.25
    bp_max: float = 200
    chol_max: float = 300
    age_max: float = 100

def calculate_risk_score(row, local_config: Optional[RiskScoringConfig] = None):
    if local_config is None:
        local_config = RiskScoringConfig()

    def _to_float_nonneg(x):
        """Return a non-negative float value or None if NaN/invalid/negative."""
        try:
            if pd.isna(x):
                return None
            xv = float(x)
            return xv if xv >= 0 else None
        except (TypeError, ValueError, OverflowError):
            return None

    # Coerce inputs safely to floats (None if invalid)
    age_v = _to_float_nonneg(row.get("age"))
    sbp_v = _to_float_nonneg(row.get("trestbps"))
    chol_v = _to_float_nonneg(row.get("chol"))

    # Log a warning if any raw values are negative (after safe coercion logic)
    # We re-check using raw values to preserve original logging context
    for _name, _raw in (("age", row.get("age")), ("trestbps", row.get("trestbps")), ("chol", row.get("chol"))):
        try:
            if pd.notna(_raw) and float(_raw) < 0:
                logger.warning(f"⚠️ [Risk Score] Detected negative values in: {row.to_dict()}")
                break
        except (TypeError, ValueError, OverflowError):
            # Ignore non-numeric raw values in negativity check
            pass

    age_factor  = (age_v  / local_config.age_max)  if age_v  is not None else 0.0
    bp_factor   = (sbp_v  / local_config.bp_max)   if sbp_v  is not None else 0.0
    chol_factor = (chol_v / local_config.chol_max) if chol_v is not None else 0.0

    total_score = (
        local_config.age_weight * age_factor +
        local_config.bp_weight * bp_factor +
        local_config.chol_weight * chol_factor
    )

    if total_score > 1.0:
        logger.warning(f"[Risk Score] Total score exceeded 1.0 and was clipped: {total_score} → 1.0")

    return round(min(1.0, total_score), 3)

def assign_risk_level(score: float) -> str:
    if pd.isnull(score):
        return "unknown"
    if score < 0.45:
        return "low"
    elif score < 0.7:
        return "medium"
    else:
        return "high"

# 📅 Age Group Classification
# ----------------------------
# Categorizes patient age into clinical age bands aligned with cardiovascular risk stratification.
# Source: WHO/ESC guidelines for hypertension and age-based risk grouping.
def assign_age_group(age: float, log_id=None) -> str:
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    if pd.isnull(age):
        logger.warning(f"[{log_id}] ⚠️ [Age Group] Null age encountered: {age}")
        return "unknown"
    try:
        if age < 0:
            logger.warning(f"[{log_id}] ⚠️ [Age Group] Negative age encountered: {age}")
            return "unknown"
        elif age < 18:
            return "<18"
        elif 18 <= age < 31:
            return "18–30"
        elif 31 <= age < 46:
            return "31–45"
        elif 46 <= age < 61:
            return "46–60"
        elif 61 <= age < 76:
            return "61–75"
        else:
            return "75+"
    except Exception as e:
        logger.error(f"[{log_id}] ❌ [Age Group] Failed to assign group for age '{age}': {e}")
        return "unknown"

AGE_GROUPS = ["<18", "18–30", "31–45", "46–60", "61–75", "75+"]

def build_clinical_features(
    df: pd.DataFrame,
    local_config: Optional[RiskScoringConfig] = None,
    overwrite: bool = False,
    log_id=None
) -> pd.DataFrame:
    """
    Builds and augments the clinical features DataFrame with all required context columns and derived features.
    الآن يتم توليد عمود feature_id ديناميكيًا تلقائيًا من الأعمدة السياقية المشتقة (bp_bin4, chol_bins, age_q3, feature_id_binned) عبر دالة assign_feature_id_by_binned مباشرة بعد إضافة هذه الأعمدة.

    Steps:
      - Cleans or overwrites pre-existing context columns if requested.
      - Validates required clinical columns.
      - Generates risk_score, risk_level, age_group, bp_category, chol_category, and other context columns.
      - Adds advanced binned features (bp_bin4, chol_bins, age_q3, feature_id_binned).
      - ثم يقوم تلقائيًا بتوليد عمود feature_id ديناميكيًا من الأعمدة السياقية المشتقة.
      - Ensures all required columns are present and logs relevant statistics.
    """
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    # --- Clean any pre-existing unstandardized context columns ---
    columns_to_clean = ["bp_category", "chol_category", "age_group", "risk_level"]
    for col in columns_to_clean:
        if col in df.columns:
            if overwrite:
                logger.warning(f"[{log_id}] ⚠️ [Sanitize] Overwriting pre-existing column: {col}")
                df.drop(columns=[col], inplace=True)
            else:
                logger.info(f"[{log_id}] ⏩ Column '{col}' already exists and will be reused. Set 'overwrite=True' to force recomputation.")
    logger.info(f"[{log_id}] 📌 Incoming columns to build_clinical_features: {df.columns.tolist()}")
    required_cols = ["age", "trestbps", "chol"]
    missing = [col for col in required_cols if col not in df.columns]
    if missing:
        raise ValueError(f"[{log_id}] ❌ Missing required clinical columns: {missing}")
    for col in required_cols:
        if df[col].dropna().empty:
            raise ValueError(f"[{log_id}] ❌ Column '{col}' exists but contains only null values.")

    df["chol_flag"] = df["chol"].apply(lambda x: 1 if x >= 239 else 0)
    if df["chol_flag"].isnull().all():
        raise ValueError(f"[{log_id}] ❌ Column 'chol_flag' is completely empty after generation.")
    logger.debug(f"[{log_id}] [chol_flag] Distribution: {df['chol_flag'].value_counts().to_dict()}")

    df["risk_score"] = df.apply(lambda row: calculate_risk_score(row, local_config), axis=1)
    df = add_risk_level(df, log_id=log_id)
    log_feature_statistics(df, ["risk_level"], logger, stage=f"[{log_id}] After add_risk_level in build_clinical_features")
    logger.info(f"[{log_id}] ✅ After risk_score head:\n{df[['risk_score']].head()}")
    logger.debug(f"[{log_id}] [risk_score] Sample: {df['risk_score'].head().tolist()}")

    # Assign or reuse risk_level
    non_null_count = df["risk_level"].notnull().sum()
    total_count = df.shape[0]
    logger.info(f"[{log_id}] [Validation] risk_level — Non-null: {non_null_count} / {total_count}")
    if non_null_count == 0:
        raise ValueError(f"[{log_id}] ❌ Column 'risk_level' is completely empty after generation.")

    # Assign or reuse age_group
    if "age_group" not in df.columns or overwrite:
        df["age_group"] = df["age"].apply(assign_age_group, log_id=log_id)
    non_null_count = df["age_group"].notnull().sum()
    total_count = df.shape[0]
    logger.info(f"[{log_id}] [Validation] age_group — Non-null: {non_null_count} / {total_count}")
    if non_null_count == 0:
        raise ValueError(f"[{log_id}] ❌ Column 'age_group' is completely empty after generation.")

    # Assign or reuse bp_category
    if "bp_category" not in df.columns or overwrite:
        df = add_bp_category(df, log_id=log_id)
    log_feature_statistics(df, ["bp_category"], logger, stage=f"[{log_id}] After add_bp_category in build_clinical_features")
    non_null_count = df["bp_category"].notnull().sum()
    total_count = df.shape[0]
    logger.info(f"[{log_id}] [Validation] bp_category — Non-null: {non_null_count} / {total_count}")
    if non_null_count == 0:
        raise ValueError(f"[{log_id}] ❌ Column 'bp_category' is completely empty after generation.")

    # Assign or reuse chol_category
    if "chol_category" not in df.columns or overwrite:
        df = add_chol_category(df, log_id=log_id)
    log_feature_statistics(df, ["chol_category"], logger, stage=f"[{log_id}] After add_chol_category in build_clinical_features")
    non_null_count = df["chol_category"].notnull().sum()
    total_count = df.shape[0]
    logger.info(f"[{log_id}] [Validation] chol_category — Non-null: {non_null_count} / {total_count}")
    if non_null_count == 0:
        raise ValueError(f"[{log_id}] ❌ Column 'chol_category' is completely empty after generation.")

    logger.info(f"[{log_id}] Risk level distribution:\n{df['risk_level'].value_counts()}")
    logger.info(f"[{log_id}] BP category distribution:\n{df['bp_category'].value_counts()}")
    logger.info(f"[{log_id}] Chol flag counts:\n{df['chol_flag'].value_counts()}")
    logger.info(f"[{log_id}] Cholesterol category distribution:\n{df['chol_category'].value_counts()}")

    # Verify all required context columns are present
    required_context_cols = ["bp_category", "chol_category", "chol_flag", "risk_level", "age_group", "risk_score"]
    missing_context_cols = [col for col in required_context_cols if col not in df.columns]

    if missing_context_cols:
        logger.critical(f"[{log_id}] Missing context columns after feature building: {missing_context_cols}")
        raise ValueError(f"[{log_id}] Missing context columns after feature building: {missing_context_cols}")
    else:
        logger.info(f"[{log_id}] ✅ All required context columns are present after feature building.")

    for col in required_context_cols:
        logger.info(f"[{log_id}] [Verification] {col} unique values:\n{df[col].value_counts(dropna=False)}")

    logger.debug(f"[{log_id}] [Final Columns] {list(df.columns)}")
    logger.info(f"[{log_id}] 📋 Final DataFrame columns: {df.columns.tolist()}")

    logger.info(f"[{log_id}] ✅ Contextual Feature Check — Non-null counts:")
    logger.info(f"[{log_id}] {df[required_context_cols].notnull().sum()}")

    if df[required_context_cols].isnull().any().any():
        null_context_cols = df[required_context_cols].isnull().any()
        failed_cols = [col for col, is_null in null_context_cols.items() if is_null]
        raise ValueError(f"[{log_id}] ❌ Context columns with nulls: {failed_cols}. Clinical feature generation is invalid.")

    # Final logging of context columns before return
    for col in ["bp_category", "chol_category", "risk_level", "age_group"]:
        logger.info(f"[{log_id}] [Final Check] {col} sample values:\n{df[col].value_counts(dropna=False)}")

    # مراقبة القيم المفقودة وتحذير واضح
    core_features = ["age", "bp_category", "chol_category", "risk_level"]
    # مراقبة القيم المفقودة وتحذير واضح
    for col in core_features:
        n_missing = df[col].isna().sum()
        if n_missing > 0:
            logger.warning(f"[{log_id}] Filling {n_missing} missing '{col}' with '{UNKNOWN}'.")
            df[col].fillna(UNKNOWN, inplace=True)
    log_feature_statistics(df, core_features, logger, stage=f"[{log_id}] [Final check before return]")

    # إضافة تصنيفات fbs وcp قبل الفئات الجديدة والتقسيمات الإحصائية المتقدمة
    df = add_fbs_cp_categories(df, log_id=log_id)
    # إضافة الفئات الجديدة والتقسيمات الإحصائية المتقدمة
    df = add_binned_features_pipeline(df, log_id=log_id)
    # Add contextual categories for recommendation/context modules
    df = add_contextual_categories(df, log_id=log_id)
    # إضافة التصنيفات المتقدمة
    df = add_contextual_advanced_categories(df)
    # ربط توليد عمود feature_id ديناميكيًا بعد الفئات الجديدة
    try:
        df = assign_feature_id_by_binned(df)
        logger.info(f"[{log_id}] [build_clinical_features] 'feature_id' column assigned via assign_feature_id_by_binned. Unique values: {df['feature_id'].nunique()}")
        logger.info(f"[{log_id}] [build_clinical_features] Top 10 feature_id counts:\n{df['feature_id'].value_counts().head(10)}")
    except Exception as e:
        logger.error(f"[{log_id}] [build_clinical_features] Failed to assign 'feature_id' using assign_feature_id_by_binned: {e}")

    # Ensure any additional derived features are appended at the end
    from context.core import generate_derived_features
    df = generate_derived_features(df)
    df = enforce_context_category_orders(df)
    return df
def add_contextual_categories(df, log_id=None):
    """
    Auto-generates clinical context categorical columns for recommendation and context modules.

    For each context feature (bp_category, chol_category, risk_level, fbs_cat, cp_cat):
      - If not present, derive from relevant source columns using clinical cutoffs.
      - Handles missing values as 'unknown'.
      - Logs value counts and derivations.

    Author: OpenAI Assistant
    Date: 2024-06-09
    """
    import uuid
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    context_cols = []
    # --- bp_category ---
    if "bp_category" not in df.columns:
        if "trestbps" in df.columns:
            df["bp_category"] = pd.cut(
                df["trestbps"],
                bins=[0, 120, 129, 139, 180, 300],
                labels=["Normal", "Elevated", "Hypertension Stage 1", "Hypertension Stage 2", "Hypertensive Crisis"],
                include_lowest=True, right=True
            )
            logger.info(f"[{log_id}] [add_contextual_categories] Derived 'bp_category' from 'trestbps'.")
        else:
            df["bp_category"] = UNKNOWN
            logger.warning(f"[{log_id}] [add_contextual_categories] Could not derive 'bp_category' (missing 'trestbps').")
        context_cols.append("bp_category")
    # --- chol_category ---
    if "chol_category" not in df.columns:
        if "chol" in df.columns:
            df["chol_category"] = pd.cut(
                df["chol"],
                bins=[0, 200, 239, float("inf")],
                labels=["Desirable", "Borderline High", "High"],
                include_lowest=True, right=True
            )
            logger.info(f"[{log_id}] [add_contextual_categories] Derived 'chol_category' from 'chol'.")
        else:
            df["chol_category"] = UNKNOWN
            logger.warning(f"[{log_id}] [add_contextual_categories] Could not derive 'chol_category' (missing 'chol').")
        context_cols.append("chol_category")
    # --- risk_level ---
    if "risk_level" not in df.columns:
        if "risk_score" in df.columns:
            df["risk_level"] = df["risk_score"].apply(assign_risk_level)
            logger.info(f"[{log_id}] [add_contextual_categories] Derived 'risk_level' from 'risk_score'.")
        else:
            df["risk_level"] = UNKNOWN
            logger.warning(f"[{log_id}] [add_contextual_categories] Could not derive 'risk_level' (missing 'risk_score').")
        context_cols.append("risk_level")
    # --- fbs_cat ---
    if "fbs_cat" not in df.columns:
        if "fbs" in df.columns:
            def _fbs_map(val):
                if pd.isnull(val):
                    return UNKNOWN
                if val == 0:
                    return "normal_fbs"
                elif val == 1:
                    return "high_fbs"
                else:
                    return UNKNOWN
            df["fbs_cat"] = df["fbs"].apply(_fbs_map)
            logger.info(f"[{log_id}] [add_contextual_categories] Derived 'fbs_cat' from 'fbs'.")
        else:
            df["fbs_cat"] = UNKNOWN
            logger.warning(f"[{log_id}] [add_contextual_categories] Could not derive 'fbs_cat' (missing 'fbs').")
        context_cols.append("fbs_cat")
    # --- cp_cat ---
    if "cp_cat" not in df.columns:
        if "cp" in df.columns:
            def _cp_map(val):
                if pd.isnull(val):
                    return UNKNOWN
                if val == 0:
                    return "asymptomatic"
                elif val == 1:
                    return "typical_angina"
                elif val == 2:
                    return "atypical_angina"
                elif val == 3:
                    return "non_anginal_pain"
                else:
                    return UNKNOWN
            df["cp_cat"] = df["cp"].apply(_cp_map)
            logger.info(f"[{log_id}] [add_contextual_categories] Derived 'cp_cat' from 'cp'.")
        else:
            df["cp_cat"] = UNKNOWN
            logger.warning(f"[{log_id}] [add_contextual_categories] Could not derive 'cp_cat' (missing 'cp').")
        context_cols.append("cp_cat")
    # --- Fill missing values as 'unknown' for all context columns ---
    for col in ["bp_category", "chol_category", "risk_level", "fbs_cat", "cp_cat"]:
        if col in df.columns:
            n_missing = df[col].isna().sum()
            if n_missing > 0:
                logger.warning(f"[{log_id}] [add_contextual_categories] Filling {n_missing} missing values in '{col}' with '{UNKNOWN}'.")
                df[col] = df[col].fillna(UNKNOWN)
    # --- Logging value counts and samples ---
    for col in ["bp_category", "chol_category", "risk_level", "fbs_cat", "cp_cat"]:
        if col in df.columns:
            vc = df[col].value_counts(dropna=False)
            logger.info(f"[{log_id}] [add_contextual_categories] {col} value counts:\n{vc}")
            sample_vals = df[col].unique()[:5]
            logger.info(f"[{log_id}] [add_contextual_categories] {col} sample values: {sample_vals}")
    logger.info(f"[{log_id}] [add_contextual_categories] Context columns added/filled: {context_cols}")
    df = enforce_context_category_orders(df)
    return df




def derive_chol_flag(df: pd.DataFrame) -> pd.DataFrame:
    df_before = df.copy()
    if "chol" in df.columns:
        df["chol_flag"] = df["chol"].apply(lambda x: 1 if x >= 239 else 0)
    from utils.validation import check_column_consistency
    df_after = df.copy()
    check_column_consistency(df_before, df_after, stage="Clinical Feature Extraction")
    return df

def derive_bp_category(df: pd.DataFrame) -> pd.DataFrame:
    if "trestbps" in df.columns:
        df["bp_category"] = pd.cut(
            df["trestbps"],
            bins=[0, 120, 129, 139, 180, 300],
            labels=["Normal", "Elevated", "Hypertension Stage 1", "Hypertension Stage 2", "Hypertensive Crisis"],
            include_lowest=True, right=True
        )
    return df

def derive_chol_category(df: pd.DataFrame) -> pd.DataFrame:
    if "chol" in df.columns:
        df["chol_category"] = pd.cut(
            df["chol"],
            bins=[0, 200, 239, np.inf],
            labels=["Desirable", "Borderline High", "High"],
            include_lowest=True, right=True
        )
    return df



def categorize_bp(systolic_bp, diastolic_bp):
    """
    يصنف مستوى ضغط الدم وفقًا لمعايير AHA/ESC.
    """
    try:
        if pd.isnull(systolic_bp) or pd.isnull(diastolic_bp):
            return UNKNOWN
        sbp = float(systolic_bp)
        dbp = float(diastolic_bp)
        if sbp < 120 and dbp < 80:
            return "Normal"
        elif 120 <= sbp < 130 and dbp < 80:
            return "Elevated"
        elif (130 <= sbp < 140) or (80 <= dbp < 90):
            return "Hypertension Stage 1"
        elif (140 <= sbp < 180) or (90 <= dbp < 120):
            return "Hypertension Stage 2"
        elif sbp >= 180 or dbp >= 120:
            return "Hypertensive Crisis"
        else:
            return UNKNOWN
    except (TypeError, ValueError, OverflowError) as e:
        logger.error(f"[categorize_bp] ❌ Failed to categorize BP: {e} (systolic={systolic_bp}, diastolic={diastolic_bp})")
        return UNKNOWN

# --- Sequential clinical feature derivation ---
def derive_clinical_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Apply all clinical derivation functions in sequence:
    - Blood pressure category
    - Cholesterol category
    - Risk score and risk level
    - Age group
    """
    raw_enabled = config.get("apply_feature_engineering", None)

    # Decide enabled flag with explicit type check to avoid 'expression can be simplified' warnings
    if isinstance(raw_enabled, bool):
        enabled = raw_enabled
    else:
        # Not provided or wrong type → default to True with a warning
        logger.warning("⚠️ 'apply_feature_engineering' is not a boolean in config (or missing). Defaulting to True.")
        enabled = True

    if not enabled:
        logger.info("🛑 Skipping clinical feature derivation as apply_feature_engineering is disabled in config.")
        return df

    df = add_bp_category(df)
    log_feature_statistics(df, ["bp_category"], logger, stage="[derive_clinical_features] After add_bp_category")

    df = add_chol_category(df)
    log_feature_statistics(df, ["chol_category"], logger, stage="[derive_clinical_features] After add_chol_category")

    df = add_risk_level(df)
    log_feature_statistics(df, ["risk_level"], logger, stage="[derive_clinical_features] After add_risk_level")

    df["age_group"] = df["age"].apply(assign_age_group)
    log_feature_statistics(df, ["age_group"], logger, stage="[derive_clinical_features] After age_group assignment")

    return df

def categorize_chol(chol):
    """
    يصنف مستوى الكوليسترول وفقًا لمعايير NCEP/WHO.
    """
    try:
        if pd.isnull(chol):
            return UNKNOWN
        chol = float(chol)
        if chol < 200:
            return "Desirable"
        elif 200 <= chol < 239:
            return "Borderline High"
        elif chol >= 239:
            return "High"
        else:
            return UNKNOWN
    except (TypeError, ValueError, OverflowError) as e:
        logger.error(f"[categorize_chol] ❌ Failed to categorize cholesterol: {e} (chol={chol})")
        return UNKNOWN

__all__ = [
    "calculate_risk_score", "assign_risk_level", "assign_age_group", "build_clinical_features", "derive_chol_flag", "derive_bp_category", "derive_chol_category",
    "add_bp_category", "add_chol_category", "add_risk_level", "derive_clinical_features", "categorize_bp", "categorize_chol",
    "add_bp_bin4", "add_chol_bins", "add_age_q3", "add_feature_id_binned", "add_binned_features_pipeline",
    "bin_trestbps_to_4q", "bin_chol_to_5q", "bin_age_to_3q", "make_feature_id_binned",
    "add_contextual_categories", "categorize_restecg", "categorize_exang", "categorize_oldpeak", "categorize_ca", "categorize_thal", "add_contextual_advanced_categories",
    "enforce_context_category_orders", "UNKNOWN"
]


# --- Advanced contextual categorical features ---
def categorize_restecg(val):
    try:
        if pd.isnull(val):
            return UNKNOWN
        mapping = {
            0: "normal_ecg",
            1: "st_t_abnormality",
            2: "lv_hypertrophy"
        }
        return mapping.get(int(val), UNKNOWN)
    except (ValueError, TypeError) as e:
        logger.error(f"[categorize_restecg] Error: {e} (val={val})")
        return UNKNOWN

def categorize_exang(val):
    try:
        if pd.isnull(val):
            return UNKNOWN
        if int(val) == 1:
            return "exercise_angina"
        elif int(val) == 0:
            return "no_exercise_angina"
        else:
            return UNKNOWN
    except (ValueError, TypeError) as e:
        logger.error(f"[categorize_exang] Error: {e} (val={val})")
        return UNKNOWN

def categorize_oldpeak(val):
    try:
        if pd.isnull(val):
            return UNKNOWN
        val = float(val)
        if val < 1.0:
            return "normal"
        elif 1.0 <= val <= 2.0:
            return "borderline"
        elif val > 2.0:
            return "abnormal"
        else:
            return UNKNOWN
    except (ValueError, TypeError) as e:
        logger.error(f"[categorize_oldpeak] Error: {e} (val={val})")
        return UNKNOWN

def categorize_ca(val):
    try:
        if pd.isnull(val):
            return UNKNOWN
        val = float(val)
        if val == 0:
            return "no_vessel"
        elif val == 1:
            return "one_vessel"
        elif val == 2:
            return "two_vessels"
        elif val == 3:
            return "three_vessels"
        elif val >= 4:
            return "more_than_three"
        else:
            return UNKNOWN
    except (ValueError, TypeError) as e:
        logger.error(f"[categorize_ca] Error: {e} (val={val})")
        return UNKNOWN

def categorize_thal(val):
    try:
        if pd.isnull(val):
            return UNKNOWN
        val = float(val)
        if val < 3:
            return "normal_thal"
        elif 3 <= val < 6:
            return "fixed_defect"
        elif 6 <= val <= 7:
            return "reversable_defect"
        else:
            return UNKNOWN
    except (ValueError, TypeError) as e:
        logger.error(f"[categorize_thal] Error: {e} (val={val})")
        return UNKNOWN

def add_contextual_advanced_categories(df: pd.DataFrame) -> pd.DataFrame:
    df['restecg_cat'] = (
        df['restecg'].apply(categorize_restecg)
        if 'restecg' in df.columns
        else pd.Series(UNKNOWN, index=df.index)
    )
    df['exang_cat'] = (
        df['exang'].apply(categorize_exang)
        if 'exang' in df.columns
        else pd.Series(UNKNOWN, index=df.index)
    )
    df['oldpeak_cat'] = (
        df['oldpeak'].apply(categorize_oldpeak)
        if 'oldpeak' in df.columns
        else pd.Series(UNKNOWN, index=df.index)
    )
    df['ca_cat'] = (
        df['ca'].apply(categorize_ca)
        if 'ca' in df.columns
        else pd.Series(UNKNOWN, index=df.index)
    )
    df['thal_cat'] = (
        df['thal'].apply(categorize_thal)
        if 'thal' in df.columns
        else pd.Series(UNKNOWN, index=df.index)
    )
    return df

