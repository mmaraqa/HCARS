"""
WARNING:
Current patient_id is built from sex, age, cp (clinical features) due to lack of true patient identifier.
This may cause merging or splitting of the same person into multiple IDs across visits.
"""
import logging
import uuid
from typing import List
import pandas as pd

logger = logging.getLogger(__name__)

# ------------------------- Helpers & Constants -------------------------
UNKNOWN = "unknown"

def _safe_str(v) -> str:
    """Normalize any value to a safe, lowercase, underscore-joined string; 'unknown' for None/NaN."""
    if pd.isna(v):
        return UNKNOWN
    s = str(v).strip()
    if s == "" or s.lower() in {"nan", "none", "null"}:
        return UNKNOWN
    return s.lower().replace(" ", "_")

def _safe_int_like(v) -> str:
    """Return a compact string for numeric types (e.g., '57' not '57.0'); otherwise _safe_str."""
    try:
        # Try int casting (covers floats like 57.0)
        i = int(float(v))
        if float(v) == float(i):
            return str(i)
    except (TypeError, ValueError):
        pass
    return _safe_str(v)
# ----------------------------------------------------------------------

def initialize_true_response(df):
    """
    Initializes the 'true_response' column for downstream supervised recommendation tasks.
    This column represents the true outcome or label indicating the clinical effectiveness
    or relevance of a treatment, medication, or intervention.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame containing raw or processed clinical records, including a 'target' column.

    Returns
    -------
    pd.DataFrame
        Modified DataFrame with a valid 'true_response' column derived from 'target' when applicable.
    """

    if "true_response" not in df.columns:
        if "target" in df.columns:
            valid_target_mask = df["target"].notna()
            valid_count = valid_target_mask.sum()

            if valid_count > 0:
                df["true_response"] = df["target"]
                logger.info(f"📌 'true_response' column initialized from 'target'. Non-null values: {valid_count}")
            else:
                logger.warning("⚠️ 'target' column exists but contains only null values. Skipped 'true_response' creation.")
        else:
            logger.warning("⚠️ 'target' column not found. Cannot create 'true_response'.")
    else:
        logger.info("✅ 'true_response' column already exists. Initialization skipped.")

    # --- Quality checks for true_response column (auto-generated, by Mohammed Maraqa AI pipeline) ---
    # تحقق صارم بعد توليد العمود true_response
    if "true_response" in df.columns:
        unique_vals = df["true_response"].unique()
        value_counts = df["true_response"].value_counts(dropna=False)
        logger.info(f"[response_initializer] 'true_response' unique values: {unique_vals}, counts: {value_counts.to_dict()}")

        if len(unique_vals) == 1:
            logger.error(f"[response_initializer] 'true_response' column is constant ({unique_vals[0]}). Cannot proceed with a non-informative target.")
            raise AssertionError("'true_response' column is constant. Please verify your labeling logic.")

        dominant_frac = value_counts.max() / value_counts.sum()
        if dominant_frac > 0.95:
            logger.warning(f"[response_initializer] 'true_response' is highly imbalanced: {dominant_frac:.2%} for value {value_counts.idxmax()}. Consider stratified sampling or relabeling.")

    return df

def assign_patient_id(df):
    """
    Assigns a quasi-stable 'patient_id' to each row if not already present.
    Uses a combination of the most stable and distinguishing columns (e.g., sex, age, cp).
    Falls back to index-based UUID if none of the expected columns are present.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    pd.DataFrame
        DataFrame with a new 'patient_id' column.
    """
    if "patient_id" in df.columns:
        logger.info("✅ 'patient_id' column already exists. Generation skipped.")
        return df

    # Preferred columns for ID generation
    preferred_cols = ["sex", "age", "cp"]
    used_cols = [col for col in preferred_cols if col in df.columns]

    if used_cols:
        # Generate patient_id as a concatenation of available columns
        def make_id(row):
            # Normalize each component; numeric-looking values rendered compactly (e.g., 57 not 57.0)
            parts: List[str] = []
            for col in used_cols:
                val = row[col]
                parts.append(_safe_int_like(val))
            return "_".join(parts)
        df["patient_id"] = df.apply(make_id, axis=1)
        df["patient_id"] = df["patient_id"].astype(str)
        logger.info(
            f"🆔 'patient_id' column generated using columns: {used_cols}. "
            f"Format: {'_'.join(used_cols)} (as string)."
        )
    else:
        # Fallback: use UUID from index
        df["patient_id"] = df.index.map(lambda x: f"PID_{uuid.uuid5(uuid.NAMESPACE_OID, str(x))}")
        logger.warning(
            "⚠️ None of the preferred columns ('sex', 'age', 'cp') found. "
            "Fallback to UUIDv5 from index for 'patient_id' generation."
        )
    return df

def assign_context_feature_id(df, use_binned=False):
    """
    Constructs a clinically meaningful 'context_feature_id' by concatenating key clinical attributes,
    or uses a pre-binned feature column if specified.

    Recommended schema when use_binned=False: bp_category + chol_category + risk_level

    Parameters
    ----------
    df : pd.DataFrame
    use_binned : bool, optional (default=False)
        If True and 'feature_id_binned' column exists, use it directly as 'context_feature_id'.
        Otherwise, generate 'context_feature_id' by concatenating 'bp_category', 'chol_category', and 'risk_level'.

    Returns
    -------
    pd.DataFrame
        DataFrame with a new 'context_feature_id' column.
    """
    def normalize_val(val):
        """Safely normalize any value (string, Interval, number) to string for mapping."""
        if isinstance(val, pd.Interval):
            # Standardize to (left, right] textual form
            return f"({val.left}, {val.right}]"
        return _safe_str(val)

    if use_binned and "feature_id_binned" in df.columns:
        if "context_feature_id" not in df.columns:
            # Always convert to string
            df["context_feature_id"] = df["feature_id_binned"].apply(normalize_val).astype(str)
            logger.info("🧬 'context_feature_id' assigned directly from 'feature_id_binned' (normalized to string) due to use_binned=True.")
        else:
            logger.info("✅ 'context_feature_id' column already exists. Generation skipped.")
    else:
        required_cols = ["bp_category", "chol_category", "risk_level"]
        missing = [col for col in required_cols if col not in df.columns]

        if missing:
            logger.warning(f"⚠️ Missing columns for 'context_feature_id' generation: {missing}. Skipping generation.")
        elif "context_feature_id" not in df.columns:
            df["context_feature_id"] = (
                df["bp_category"].apply(normalize_val).astype(str) + "__" +
                df["chol_category"].apply(normalize_val).astype(str) + "__" +
                df["risk_level"].apply(normalize_val).astype(str)
            ).astype(str)
            logger.info("🧬 'context_feature_id' column generated from bp_category, chol_category, and risk_level (all normalized).")
        else:
            logger.info("✅ 'context_feature_id' column already exists. Generation skipped.")

    if "context_feature_id" in df.columns:
        unique_vals = df["context_feature_id"].nunique()
        value_counts = df["context_feature_id"].value_counts(dropna=False)
        logger.info(f"[response_initializer] 'context_feature_id' unique values count: {unique_vals}")
        logger.info(f"[response_initializer] 'context_feature_id' value counts sample: {value_counts.head(10).to_dict()}")
        # Type check for debugging
        bad_types = df["context_feature_id"].apply(lambda x: not isinstance(x, str)).sum()
        if bad_types > 0:
            logger.warning(f"[response_initializer] 'context_feature_id' has {bad_types} non-string values after normalization!")

    return df

# ----------------------------------------------------------------------
# Assigns 'feature_id' using binned context (feature_id_binned)
import logging

def assign_feature_id_by_binned(df, use_map=True, default_value="manual_review", unmatched_log_path="logs/unmatched_feature_id_binned.log"):
    """
    Assigns 'feature_id' to each row using the binned context (feature_id_binned),
    with normalization and robust error handling. Logs all unmatched keys.
    """
    if "feature_id_binned" not in df.columns:
        logging.warning("[assign_feature_id_by_binned] 'feature_id_binned' column missing. Cannot assign feature_id by binned context.")
        return df

    from utils.constants import FEATURE_ID_BINNED_MAP, recommend_by_binned

    def normalize_bin_val(val):
        # Normalize any value (string/Interval/number) to a comparable key
        if isinstance(val, pd.Interval) or (hasattr(val, "left") and hasattr(val, "right")):
            return f"({val.left}, {val.right}]"
        return _safe_str(val)

    # تطبيع جميع مفاتيح القاموس حتى لو لم تكن كذلك من قبل
    normalized_map = {normalize_bin_val(k): v for k, v in FEATURE_ID_BINNED_MAP.items()}

    unmatched_keys = set()

    def _recommend(row):
        binned_key = normalize_bin_val(row["feature_id_binned"])
        # تطابق مع القاموس بعد التطبيع
        if use_map and binned_key in normalized_map:
            return normalized_map[binned_key]
        # التوليد التلقائي إذا لم يوجد في القاموس
        try:
            parts = binned_key.split("__")
            if len(parts) == 3:
                bp, chol, age = parts
                rec = recommend_by_binned(bp, chol, age)
                if rec is not None and rec != default_value:
                    return rec
        except (AttributeError, TypeError, ValueError) as ex:
            logging.warning(f"[assign_feature_id_by_binned] Error in dynamic recommend: {ex}")
        unmatched_keys.add(binned_key)
        return default_value

    df["feature_id"] = df.apply(_recommend, axis=1)
    df["feature_id"] = df["feature_id"].astype(str)
    # تسجيل جميع القيم غير المطابقة للرجوع والتحليل لاحقًا
    if unmatched_keys:
        try:
            with open(unmatched_log_path, "w", encoding="utf-8") as f:
                for key in sorted(unmatched_keys):
                    f.write(f"{key}\n")
            logging.warning(f"[assign_feature_id_by_binned] {len(unmatched_keys)} unmatched keys were logged to {unmatched_log_path}. Sample: {list(unmatched_keys)[:5]}")
        except OSError as io_ex:
            logging.warning(f"[assign_feature_id_by_binned] Could not write unmatched keys to {unmatched_log_path}: {io_ex}")

    # إحصائيات نهائية للمراجعة
    num_manual_review = df['feature_id'].eq(default_value).sum()
    num_unique_feature_ids = df['feature_id'].nunique()
    logging.info(f"[assign_feature_id_by_binned] 'feature_id' unique values: {num_unique_feature_ids} | Missing/Manual review: {num_manual_review} rows.")
    return df
