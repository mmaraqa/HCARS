
import pandas as pd
import uuid

from utils.constants import assign_feature_id_by_binned

from context.clinical_features import bin_trestbps_to_4q, bin_chol_to_5q, bin_age_to_3q, make_feature_id_binned

from utils.config_loader import load_global_config
config = load_global_config()


def assert_column_variability(df: pd.DataFrame, column: str, log_id: str, strict_mode: bool = False):
    """
    Checks the variability of a column after restoration or filling.
    If strict_mode is True, raises an exception if the column is constant or dominated by a single value.
    If strict_mode is False, logs a strong warning and does NOT raise an exception for insufficient variability.
    If variability is insufficient, tries fallback restoration using cluster-based mode or global mode.
    """
    from utils.logging_utils import get_feature_engineering_logger
    logger = get_feature_engineering_logger()
    if column not in df.columns:
        logger.warning(f"[{log_id}] ⚠️ Column '{column}' missing for variability check. Skipping variability check for this column.")
        return

    if df[column].isnull().all():
        logger.error(f"[{log_id}] ❌ Column '{column}' is entirely null after restoration.")
        if strict_mode:
            raise ValueError(f"Column '{column}' is entirely null after restoration.")
        else:
            logger.warning(f"[NON-STOP][DEBUG][{log_id}] Column '{column}' is entirely null, skipping exception in debug mode (strict_mode=False).")
            return

    value_counts = df[column].value_counts(dropna=True)
    if len(value_counts) <= 1:
        logger.warning(f"[{log_id}] ⚠️ Column '{column}' has low variability (only one unique value). Attempting fallback restoration.")
        # Attempt fallback restoration using cluster if available
        if 'cluster' in df.columns and df['cluster'].notnull().any():
            def fill_mode(group):
                mode_val_local = group[column].mode(dropna=True)
                if not mode_val_local.empty:
                    return group[column].fillna(mode_val_local[0])
                else:
                    return group[column]

            df[column] = df.groupby('cluster').apply(fill_mode).reset_index(level=0, drop=True)
            # Recalculate variability
            value_counts = df[column].value_counts(dropna=True)
            if len(value_counts) <= 1:
                logger.error(f"[{log_id}] ❌ Column '{column}' still has low variability after cluster-based fallback restoration.")
                if strict_mode:
                    raise ValueError(f"Column '{column}' has insufficient variability after fallback restoration.")
                else:
                    logger.warning(f"[NON-STOP][DEBUG][{log_id}] Column '{column}' is constant (nunique=1), skipping exception in debug mode (strict_mode=False).")
                    return
            else:
                logger.info(f"[{log_id}] ✅ Column '{column}' variability restored after cluster-based fallback.")
        else:
            # No cluster column, fallback to global mode fill
            mode_val = df[column].mode(dropna=True)
            if not mode_val.empty:
                df[column] = df[column].fillna(mode_val[0])
                value_counts = df[column].value_counts(dropna=True)
                if len(value_counts) <= 1:
                    logger.error(f"[{log_id}] ❌ Column '{column}' still has low variability after global mode fallback restoration.")
                    if strict_mode:
                        raise ValueError(f"Column '{column}' has insufficient variability after fallback restoration.")
                    else:
                        logger.warning(f"[NON-STOP][DEBUG][{log_id}] Column '{column}' is constant (nunique=1), skipping exception in debug mode (strict_mode=False).")
                        return
                else:
                    logger.info(f"[{log_id}] ✅ Column '{column}' variability restored after global mode fallback.")
            else:
                logger.error(f"[{log_id}] ❌ Unable to determine mode for column '{column}' during fallback restoration.")
                if strict_mode:
                    raise ValueError(f"Unable to restore variability for column '{column}'.")
                else:
                    logger.warning(f"[NON-STOP][DEBUG][{log_id}] Unable to restore variability for column '{column}', skipping exception in debug mode (strict_mode=False).")
                    return
    else:
        logger.info(f"[{log_id}] ✅ Column '{column}' has sufficient variability after restoration.")


def validate_schema(df: pd.DataFrame, schema):
    if isinstance(schema, dict):
        expected = set(schema.get('columns', []))
    elif isinstance(schema, list):
        expected = set(schema)
    else:
        raise ValueError("Schema must be either a dict with 'columns' or a list of column names.")
    actual = set(df.columns)
    missing = expected - actual
    if missing:
        print("❌ Schema validation failed. Missing columns:", missing)
        raise ValueError(f"Missing required columns: {missing}")

class FallbackRestorer:
    @staticmethod
    def restore_target_column(df: pd.DataFrame, log_id=None, strict_mode: bool = False) -> pd.DataFrame:
        from utils.logging_utils import get_feature_engineering_logger
        logger = get_feature_engineering_logger()
        if log_id is None:
            log_id = uuid.uuid4().hex[:8]
        if "target_copy" in df.columns and df["target_copy"].notnull().any():
            df["target"] = df["target_copy"]
            logger.info(f"[{log_id}] ✅ 'target' column restored from 'target_copy'.")
        elif "target_backup" in df.columns and df["target_backup"].notnull().any():
            df["target"] = df["target_backup"]
            logger.info(f"[{log_id}] ✅ 'target' column restored from 'target_backup'.")
        else:
            logger.warning(f"[{log_id}] ⚠️ No backup column found to restore 'target'.")
        # Pass strict_mode to variability assertion
        try:
            assert_column_variability(df, "target", log_id, strict_mode=strict_mode)
        except Exception as e:
            logger.error(f"[{log_id}] ❌ Variability check failed for 'target': {e}")
            raise
        return df

    @staticmethod
    def restore_derived_clinical_columns(df: pd.DataFrame, log_id=None, strict_mode: bool = False) -> pd.DataFrame:
        """
        Ensure this method is called after protected columns have been merged.
        It restores key clinical columns if missing or fully null.
        """
        from utils.logging_utils import get_feature_engineering_logger
        logger = get_feature_engineering_logger()
        if log_id is None:
            log_id = uuid.uuid4().hex[:8]
        derived_fields = {
            "risk_level": "risk_level_backup",
            "target_copy": "target_copy_backup",
            "context_feature_id": "context_feature_id_backup",
            "age_group": "age_group_backup",
            "bp_category": "bp_category_backup",
            "chol_category": "chol_category_backup"
        }

        # Updated valid categories for bp_category and chol_category to match clinical_features.py
        valid_bp_categories = ["Normal", "Elevated", "Hypertension Stage 1", "Hypertension Stage 2", "Hypertensive Crisis"]
        valid_chol_categories = ["Desirable", "Borderline High", "High"]

        logger.info(f"[{log_id}] 🛡️ [Fallback] Attempting to restore clinical fields after full column merge...")

        # This is often populated as a list comprehension, so ensure contextual columns are included below.
        final_cols = config.get("final_columns_after_encoding", [])
        # Ensure contextual columns are included if they exist
        for col in ["risk_score", "risk_level", "bp_category", "chol_category"]:
            if col in df.columns and col not in final_cols:
                final_cols.append(col)

        # --- Restoration attempts for derived fields ---
        for col, backup in derived_fields.items():
            if col not in final_cols:
                logger.info(f"[{log_id}] ⏭️ Skipping restoration for '{col}' — not listed in final schema.")
                continue
            if col not in df.columns or df[col].isnull().all():
                if backup in df.columns and df[backup].notnull().any():
                    df[col] = df[backup]
                    logger.info(f"[{log_id}] ✅ Restored '{col}' from '{backup}'.")
                else:
                    logger.warning(f"[{log_id}] ⚠️ Missing both '{col}' and its backup '{backup}'. Cannot restore.")
            # After restoration or if column exists, log value counts for diagnostic visibility
            if col in df.columns:
                if col == "bp_category":
                    # Filter to only valid categories to align with updated labels
                    counts = df[col].value_counts()
                    counts = counts[counts.index.isin(valid_bp_categories)]
                    logger.info(f"[{log_id}] [Restoration] '{col}' distribution (filtered to valid categories):\n{counts}")
                elif col == "chol_category":
                    counts = df[col].value_counts()
                    counts = counts[counts.index.isin(valid_chol_categories)]
                    logger.info(f"[{log_id}] [Restoration] '{col}' distribution (filtered to valid categories):\n{counts}")
                else:
                    logger.info(f"[{log_id}] [Restoration] {col} distribution:\n{df[col].value_counts()}")
            # Check variability after restoration
            try:
                # Pass strict_mode to variability assertion
                assert_column_variability(df, col, log_id, strict_mode=strict_mode)
            except Exception as e:
                logger.error(f"[{log_id}] ❌ Variability check failed for '{col}': {e}")
                raise

        # --- Additional fallback: derive bp_category from raw BP columns if missing ---
        if "bp_category" not in df.columns:
            if "systolic_bp" in df.columns and "diastolic_bp" in df.columns:
                try:
                    from context.clinical_features import categorize_bp
                    df["bp_category"] = df.apply(
                        lambda row: categorize_bp(row["systolic_bp"], row["diastolic_bp"])
                        if pd.notnull(row["systolic_bp"]) and pd.notnull(row["diastolic_bp"])
                        else None, axis=1
                    )
                    logger.info(f"[{log_id}] ✅ 'bp_category' derived from systolic/diastolic_bp columns (emergency fallback).")
                except Exception as e:
                    logger.error(f"[{log_id}] ❌ Could not derive 'bp_category' from BP columns: {e}")

        # --- Additional fallback: derive chol_category from raw cholesterol column if missing ---
        if "chol_category" not in df.columns:
            if "chol" in df.columns:
                try:
                    from context.clinical_features import categorize_chol
                    df["chol_category"] = df["chol"].apply(
                        lambda x: categorize_chol(x) if pd.notnull(x) else None
                    )
                    logger.info(f"[{log_id}] ✅ 'chol_category' derived from 'chol' column (emergency fallback).")
                except Exception as e:
                    logger.error(f"[{log_id}] ❌ Could not derive 'chol_category' from 'chol' column: {e}")

        # Normalization of bp_category and chol_category values after restoration
        if "bp_category" in df.columns:
            df["bp_category"] = df["bp_category"].replace({
                "stage_1": "Hypertension Stage 1",
                "stage_2": "Hypertension Stage 2",
                "crisis": "Hypertensive Crisis"
            })
        if "chol_category" in df.columns:
            df["chol_category"] = df["chol_category"].replace({
                "borderline": "Borderline High"
            })

        # --- Extra fallback: if any critical column is still missing, fill with 'Unknown' and log strong warning ---
        critical_columns = [
            "age", "bp_category", "chol_category", "risk_level",
            "bp_bin4", "chol_bins", "age_q3", "feature_id_binned"
        ]
        for col in critical_columns:
            if col not in df.columns:
                logger.warning(f"[{log_id}] ⚠️ Critical column '{col}' is missing after all restoration attempts. Filling with 'Unknown'.")
                df[col] = 'Unknown'

        # --- Strict final verification block for critical columns ---
        # Final check for critical columns: if strict_mode is False, only log warnings, do not raise
        for col in critical_columns:
            if col not in df.columns:
                logger.warning(f"[{log_id}] ⚠️ Critical column '{col}' is missing after all restoration attempts. Filling with 'Unknown'.")
                df[col] = 'Unknown'
            if df[col].isnull().all():
                logger.warning(f"[{log_id}] ⚠️ Critical column '{col}' is entirely null after all restoration attempts. Filling with 'Unknown'.")
                df[col] = 'Unknown'
            nunique = df[col].nunique(dropna=True)
            if nunique <= 1:
                if strict_mode:
                    logger.error(f"[{log_id}] ❌ Critical column '{col}' is constant or non-informative after restoration (nunique={nunique}).")
                    raise ValueError(f"Critical column '{col}' is constant or non-informative after restoration.")
                else:
                    logger.warning(f"[NON-STOP][DEBUG][{log_id}] Critical column '{col}' is constant or non-informative after restoration (nunique={nunique}), skipping exception in debug mode (strict_mode=False).")

        # Restore binned features before returning
        df = FallbackRestorer.restore_binned_features(df, log_id=log_id, strict_mode=strict_mode)

        # --- Hybrid Recommendation Support: feature_id assignment based on feature_id_binned ---
        # هذا الجزء خاص بدعم توصيات النظام الهجين الجديدة المستندة إلى feature_id_binned
        # Ensure feature_id is filled using feature_id_binned logic (new recommendation engine)
        if "feature_id_binned" in df.columns:
            df = assign_feature_id_by_binned(df)
            from utils.logging_utils import get_feature_engineering_logger
            logger = get_feature_engineering_logger()
            null_count = df["feature_id"].isnull().sum() if "feature_id" in df.columns else "all"
            if null_count == 0:
                logger.info(f"[{log_id}] ✅ All feature_id values assigned successfully from feature_id_binned.")
            else:
                logger.warning(f"[{log_id}] ⚠️ {null_count} rows in 'feature_id' are NULL after assignment! Manual review required.")
        else:
            from utils.logging_utils import get_feature_engineering_logger
            logger = get_feature_engineering_logger()
            logger.warning(f"[{log_id}] ⚠️ feature_id_binned is missing after all restoration attempts. Assigning 'manual_review' to feature_id.")
            df["feature_id"] = "manual_review"

        return df

    @staticmethod
    def restore_binned_features(df: pd.DataFrame, log_id=None, strict_mode: bool = False) -> pd.DataFrame:
        from utils.logging_utils import get_feature_engineering_logger
        logger = get_feature_engineering_logger()
        if log_id is None:
            log_id = uuid.uuid4().hex[:8]
        # bp_bin4
        if "bp_bin4" not in df.columns or df["bp_bin4"].isnull().all():
            if "trestbps" in df.columns:
                df["bp_bin4"] = bin_trestbps_to_4q(df["trestbps"])
                logger.info(f"[{log_id}] ✅ Restored 'bp_bin4' from 'trestbps'.")
            else:
                logger.warning(f"[{log_id}] ⚠️ Cannot restore 'bp_bin4' (missing trestbps).")
        assert_column_variability(df, "bp_bin4", log_id, strict_mode)
        # chol_bins
        if "chol_bins" not in df.columns or df["chol_bins"].isnull().all():
            if "chol" in df.columns:
                df["chol_bins"] = bin_chol_to_5q(df["chol"])
                logger.info(f"[{log_id}] ✅ Restored 'chol_bins' from 'chol'.")
            else:
                logger.warning(f"[{log_id}] ⚠️ Cannot restore 'chol_bins' (missing chol).")
        assert_column_variability(df, "chol_bins", log_id, strict_mode)
        # age_q3
        if "age_q3" not in df.columns or df["age_q3"].isnull().all():
            if "age" in df.columns:
                df["age_q3"] = bin_age_to_3q(df["age"])
                logger.info(f"[{log_id}] ✅ Restored 'age_q3' from 'age'.")
            else:
                logger.warning(f"[{log_id}] ⚠️ Cannot restore 'age_q3' (missing age).")
        assert_column_variability(df, "age_q3", log_id, strict_mode)
        # feature_id_binned
        if "feature_id_binned" not in df.columns or df["feature_id_binned"].isnull().all():
            if all(x in df.columns for x in ["bp_bin4", "chol_bins", "age_q3"]):
                df["feature_id_binned"] = make_feature_id_binned(df)
                logger.info(f"[{log_id}] ✅ Restored 'feature_id_binned' from binned features.")
            else:
                logger.warning(f"[{log_id}] ⚠️ Cannot restore 'feature_id_binned' (missing binned features).")
        assert_column_variability(df, "feature_id_binned", log_id, strict_mode)
        return df

    @staticmethod
    def categorize_and_restore_age(df: pd.DataFrame, log_id=None, strict_mode: bool = False) -> pd.DataFrame:
        from utils.logging_utils import get_feature_engineering_logger
        logger = get_feature_engineering_logger()
        if log_id is None:
            log_id = uuid.uuid4().hex[:8]
        if "age_group" not in df.columns or df["age_group"].isnull().all():
            if "age" in df.columns:
                try:
                    from context.core import categorize_age
                    df["age_group"] = df["age"].apply(lambda x: categorize_age(x) if pd.notnull(x) else "Unspecified")
                    logger.info(f"[{log_id}] ✅ 'age_group' derived from 'age' for {df['age_group'].notnull().sum()} rows.")
                except Exception as e:
                    logger.error(f"[{log_id}] ❌ Failed to apply 'categorize_age': {e}")
        try:
            assert_column_variability(df, "age_group", log_id, strict_mode=strict_mode)
        except Exception as e:
            logger.error(f"[{log_id}] ❌ Variability check failed for 'age_group': {e}")
            raise
        return df

    @staticmethod
    def restore_from_remainder(df: pd.DataFrame, source_col: str, target_col: str, log_id=None, strict_mode: bool = False) -> pd.DataFrame:
        from utils.logging_utils import get_feature_engineering_logger
        logger = get_feature_engineering_logger()
        if log_id is None:
            log_id = uuid.uuid4().hex[:8]
        final_cols = config.get("final_columns_after_encoding", [])
        if target_col not in final_cols:
            logger.info(f"[{log_id}] ⏭️ Skipping restoration for '{target_col}' — not listed in final schema.")
            return df
        if source_col in df.columns:
            if target_col not in df.columns:
                df[target_col] = df[source_col]
                logger.info(f"[{log_id}] ✅ '{target_col}' created from '{source_col}'.")
            else:
                null_mask = df[target_col].isnull()
                if target_col in final_cols and null_mask.any():
                    df.loc[null_mask, target_col] = df.loc[null_mask, source_col]
                    logger.info(f"[{log_id}] 🔁 Restored {null_mask.sum()} missing '{target_col}' entries from '{source_col}'.")
        else:
            logger.warning(f"[{log_id}] ⚠️ Source column '{source_col}' not found for restoring '{target_col}'.")
        try:
            assert_column_variability(df, target_col, log_id, strict_mode=strict_mode)
        except Exception as e:
            logger.error(f"[{log_id}] ❌ Variability check failed for '{target_col}': {e}")
            raise
        return df

    @staticmethod
    def generate_context_feature_id_static(df: pd.DataFrame, log_id=None, strict_mode: bool = False) -> pd.DataFrame:
        from utils.logging_utils import get_feature_engineering_logger
        logger = get_feature_engineering_logger()
        if log_id is None:
            log_id = uuid.uuid4().hex[:8]

        required_cols = ["bp_category", "chol_category", "risk_level"]
        missing = [col for col in required_cols if col not in df.columns]
        if missing:
            logger.warning(f"[{log_id}] ⚠️ Cannot restore 'context_feature_id'. Missing columns: {missing}")
            return df

        if "context_feature_id" not in df.columns or df["context_feature_id"].isnull().all():
            df["context_feature_id"] = (
                df["bp_category"].astype(str).str.lower().str.replace(" ", "_") + "__" +
                df["chol_category"].astype(str).str.lower().str.replace(" ", "_") + "__" +
                df["risk_level"].astype(str).str.lower().str.replace(" ", "_")
            )
            logger.info(f"[{log_id}] ✅ 'context_feature_id' restored from clinical context.")
        else:
            logger.info(f"[{log_id}] ✅ 'context_feature_id' already present. Restoration skipped.")
        try:
            assert_column_variability(df, "context_feature_id", log_id, strict_mode=strict_mode)
        except Exception as e:
            logger.error(f"[{log_id}] ❌ Variability check failed for 'context_feature_id': {e}")
            raise
        return df

# Module-level alias for direct import
generate_context_feature_id = FallbackRestorer.generate_context_feature_id_static

def restore_derived_clinical_columns(df: pd.DataFrame, log_id=None, strict_mode: bool = False) -> pd.DataFrame:
    from utils.logging_utils import get_feature_engineering_logger
    logger = get_feature_engineering_logger()
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    logger.info(f"[{log_id}] 🛡️ [Fallback] Triggered top-level clinical recovery routine.")
    restorer = FallbackRestorer()
    # Propagate strict_mode to all restoration checks inside this function
    df = restorer.restore_derived_clinical_columns(df, log_id=log_id, strict_mode=strict_mode)
    return df


# --------------------------------------------------------
# Context Extraction Utilities (Post-Restoration, Pre-Filtering)
# --------------------------------------------------------
def get_context_dict(df: pd.DataFrame, log_id=None) -> dict:
    from utils.logging_utils import get_feature_engineering_logger
    logger = get_feature_engineering_logger()
    if log_id is None:
        log_id = uuid.uuid4().hex[:8]
    context_keys = ["bp_category", "chol_category", "risk_level", "age_group"]
    context_dict = {}
    for context_key in context_keys:
        if context_key in df.columns and df[context_key].notnull().any():
            context_dict[context_key] = df[context_key].mode(dropna=True)[0]
        else:
            context_dict[context_key] = "unknown"
            logger.warning(f"[{log_id}] ⚠️ Missing or null values for context key: '{context_key}', defaulting to 'unknown'")
    logger.info(f"[{log_id}] 📌 Generated context_dict with values: {context_dict}")
    return context_dict

__all__ = [
    "FallbackRestorer", "restore_derived_clinical_columns",
    "get_context_dict", "generate_context_feature_id"
]
